<%@page isELIgnored="false" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<body bgcolor="lavender">
<h1><center>EXLNT HR Consultancy</center></h1>
       			
			
		<div>
		<center>	<a href="index"> Home</a></center>
		</div>
	
</body>
</html>