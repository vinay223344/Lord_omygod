<%@ taglib uri="http://www.springframework.org/tags/form" prefix="form"%>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1" isELIgnored="false"%>


<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<body style="background-color:lavender">
<h1><center>EXLNT HR Consultancy</center></h1>
<center>
<a href="showRegisterCandidate">Register A Candidate</a><br><br>
<a href="viewAllCandidate" >View all Candidate Info</a>
</center>

</body>
</html>	 	  	    	    	     	      	 	
