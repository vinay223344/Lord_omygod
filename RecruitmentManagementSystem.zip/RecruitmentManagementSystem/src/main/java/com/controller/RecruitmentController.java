package com.controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.servlet.ModelAndView;

import com.model.CandidateInfo;
import com.service.RecruitmentService;

//use appropriate annotation to configure RecruitmentController as Controller
public class RecruitmentController {
	
	//use appropriate annotation
	RecruitmentService recruitmentService;
	
	//fill code
	public String showRegisterCandidatePage(CandidateInfo candidate) {
		
		//fill code
		return null;
		
	}
	
	//fill the code
	public String addCandidateToList(CandidateInfo candidate,BindingResult result,ModelMap model) {
		
		//fill code
		return null;
		
	}
	
	//fill the code
	public String viewAllCandidateInfo(ModelMap model) {
		
		//fill code
		return null;
		
	}
	
	//Use appropriate annotation
	public ModelAndView exceptionHandler(Exception e) {		
		
		//fill the code
		return null;
		
	}
		

}
