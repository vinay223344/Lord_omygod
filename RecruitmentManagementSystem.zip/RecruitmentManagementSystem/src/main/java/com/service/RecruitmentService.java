package com.service;

import java.util.ArrayList;
import com.model.CandidateInfo;

//use appropriate annotation to configure RecruitmentService as a Service
public class RecruitmentService {
	
	private ArrayList<CandidateInfo> candidateList = new ArrayList<>();
	
	//add CandidateInfo object to candidateList
	public boolean addCandidate(CandidateInfo candidate) {
		
		//fill code
		return false;
		
	}	
	
	//To get information about all CandidateInfo
	public ArrayList<CandidateInfo> viewAllCandidates() {
		
		//fill code
		return null;
		
	}

	public ArrayList<CandidateInfo> getCandidateList() {
		return candidateList;
	}

	public void setCandidateList(ArrayList<CandidateInfo> candidateList) {
		this.candidateList = candidateList;
	}
	
	

}
