package com.model;

//use appropriate annotation to make this class as a component class
public class CandidateInfo {
	
	//fill the code	
	private int candidateId;
	//fill the code	
	private String name;
	//fill the code	
	private String emailId;
	
	private String designation;
	//fill the code	
	private int yearsOfExperience;
	//fill the code	
	private double expectedSalary;
	
	public CandidateInfo() {
		
	}

	public int getCandidateId() {
		return candidateId;
	}

	public void setCandidateId(int candidateId) {
		this.candidateId = candidateId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public int getYearsOfExperience() {
		return yearsOfExperience;
	}

	public void setYearsOfExperience(int yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}

	public double getExpectedSalary() {
		return expectedSalary;
	}

	public void setExpectedSalary(double expectedSalary) {
		this.expectedSalary = expectedSalary;
	}	

}
