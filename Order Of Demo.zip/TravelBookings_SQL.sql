use travelbookings_db;
select * from bookings;