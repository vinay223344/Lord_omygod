Create Database library;
use library;
select * from user;