package com.example.NetWatch.service;

import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.NetworkSite;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.repository.NetworkSiteRepo;
import com.example.NetWatch.requestdto.NetworkElementRequestDTO;
import com.example.NetWatch.responsedto.NetworkElementResponseDTO;
import com.example.NetWatch.enums.ElementType;
import com.example.NetWatch.enums.ElementStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class NetworkElementServiceImpTest {

    @Mock
    private NetworkElementRepo elementRepository;

    @Mock
    private NetworkSiteRepo siteRepository;

    @InjectMocks
    private NetworkElementServiceImp elementService;

    private NetworkElementRequestDTO elementRequest;
    private NetworkElement element;
    private NetworkSite site;

    @BeforeEach
    public void setUp() {
        site = new NetworkSite();
        site.setSiteId(10L);
        site.setSiteName("Site-A");

        elementRequest = NetworkElementRequestDTO.builder()
                .elementName("Router-01")
                .elementType(ElementType.ROUTER)
                .vendor("Cisco")
                .model("ASR9000")
                .ipAddress("10.0.0.1")
                .regionId(1L)

                .status(ElementStatus.ACTIVE)
                .siteId(10L)
                .build();

        element = new NetworkElement();
        element.setElementId(1L);
        element.setElementName("Router-01");
        element.setElementType(ElementType.ROUTER);
        element.setVendor("Cisco");
        element.setModel("ASR9000");
        element.setIpAddress("10.0.0.1");
        element.setRegionId(1L);

        element.setStatus(ElementStatus.ACTIVE);
        element.setSite(site);
    }

    @Test
    public void testGetAllElements() {
        when(elementRepository.findAll()).thenReturn(List.of(element));

        List<NetworkElementResponseDTO> list = elementService.getAllElements();

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals("Router-01", list.get(0).getElementName());
        assertEquals(10L, list.get(0).getSiteId());
        assertEquals("Site-A", list.get(0).getSiteName());
    }

    @Test
    public void testCreateElement_WithSite() {
        when(siteRepository.findById(10L)).thenReturn(Optional.of(site));
        when(elementRepository.save(any(NetworkElement.class))).thenReturn(element);

        NetworkElementResponseDTO response = elementService.createElement(elementRequest);

        assertNotNull(response);
        assertEquals(1L, response.getElementId());
        assertEquals("Router-01", response.getElementName());
        assertEquals(ElementType.ROUTER, response.getElementType());
        assertEquals(10L, response.getSiteId());
    }

    @Test
    public void testCreateElement_NoSite() {
        elementRequest.setSiteId(null);
        element.setSite(null);
        when(elementRepository.save(any(NetworkElement.class))).thenReturn(element);

        NetworkElementResponseDTO response = elementService.createElement(elementRequest);

        assertNotNull(response);
        assertEquals(1L, response.getElementId());
        assertNull(response.getSiteId());
    }
}
