package com.example.NetWatch.service;

import com.example.NetWatch.entity.MaintenanceWindow;
import com.example.NetWatch.requestdto.NetworkAlarmRequestDTO;
import com.example.NetWatch.responsedto.NetworkAlarmResponseDTO;
import java.util.List;

public interface AlarmService {
    NetworkAlarmResponseDTO create(NetworkAlarmRequestDTO alarmRequest, Long creatorId);
    List<NetworkAlarmResponseDTO> getAll();
    NetworkAlarmResponseDTO acknowledge(Long id, Long userId);
    NetworkAlarmResponseDTO clearAlarm(Long id, Long userId);

    /** Auto-creates a MAINTENANCE_SCHEDULED alarm for every affected element in a maintenance window. */
    void createMaintenanceAlarm(MaintenanceWindow window);
}