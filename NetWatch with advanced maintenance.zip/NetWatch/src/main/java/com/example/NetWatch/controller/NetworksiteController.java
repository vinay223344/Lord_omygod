package com.example.NetWatch.controller;

import com.example.NetWatch.requestdto.NetworkSiteRequestDTO;
import com.example.NetWatch.responsedto.NetworkSiteResponseDTO;
import com.example.NetWatch.service.NetworkSiteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/site")
public class NetworksiteController {

    @Autowired
    private NetworkSiteService service;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') ")
    public ResponseEntity<List<NetworkSiteResponseDTO>> getAllSites() {
        log.debug("Fetching all network sites");
        List<NetworkSiteResponseDTO> list = service.getAllSites();
        return ResponseEntity.ok(list);
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN') ")
    public ResponseEntity<NetworkSiteResponseDTO> createSite(@RequestBody NetworkSiteRequestDTO siteRequest) {
        log.info("Creating network site: name={}", siteRequest.getSiteName());
        NetworkSiteResponseDTO saved = service.createSite(siteRequest);
        log.info("Network site created: id={}", saved.getSiteId());
        return ResponseEntity.ok(saved);
    }
}
