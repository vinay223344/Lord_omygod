package com.example.NetWatch.controller;

import com.example.NetWatch.requestdto.NetworkElementRequestDTO;
import com.example.NetWatch.responsedto.NetworkElementResponseDTO;
import com.example.NetWatch.service.NetworkElementService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/element")
public class NetworkElementController {

    @Autowired
    private NetworkElementService service;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') ")
    public ResponseEntity<List<NetworkElementResponseDTO>> getAllElements() {
        log.debug("Fetching all network elements");
        List<NetworkElementResponseDTO> list = service.getAllElements();
        return ResponseEntity.ok(list);
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN') ")
    public ResponseEntity<NetworkElementResponseDTO> createElement(@RequestBody NetworkElementRequestDTO elementRequest) {
        log.info("Creating network element: name={}", elementRequest.getElementName());
        NetworkElementResponseDTO saved = service.createElement(elementRequest);
        log.info("Network element created: id={}", saved.getElementId());
        return ResponseEntity.ok(saved);
    }
}
