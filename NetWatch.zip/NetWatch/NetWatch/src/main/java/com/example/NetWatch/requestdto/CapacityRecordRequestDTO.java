package com.example.NetWatch.requestdto;

import com.example.NetWatch.enums.MetricType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CapacityRecordRequestDTO {
    private Long elementId;
    private MetricType metricType;
    private Double peakValue;
    private Double averageValue;
    private Double thresholdPercent;
}
