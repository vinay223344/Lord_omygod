package com.example.NetWatch.repository;

import com.example.NetWatch.entity.MaintenanceWindow;
import com.example.NetWatch.enums.MaintenanceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MaintenanceWindowRepo extends JpaRepository<MaintenanceWindow, Long> {
    List<MaintenanceWindow> findByStatus(MaintenanceStatus status);
}
