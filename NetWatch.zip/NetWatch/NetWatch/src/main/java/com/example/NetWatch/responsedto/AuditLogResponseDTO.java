package com.example.NetWatch.responsedto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditLogResponseDTO {
    private Long auditId;
    private Long userId;
    private String action;
    private String entityType;
    private Long recordId;
    private LocalDateTime timestamp;
}
