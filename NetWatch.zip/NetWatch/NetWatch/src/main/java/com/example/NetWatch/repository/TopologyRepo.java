package com.example.NetWatch.repository;

import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.TopologyLink;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TopologyRepo extends JpaRepository<TopologyLink,Long> {
    List<TopologyLink> findByElementAOrElementB(NetworkElement a, NetworkElement b);
}
