package com.example.NetWatch.responsedto;

import com.example.NetWatch.enums.ServiceType;
import com.example.NetWatch.enums.CircuitStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CircuitResponseDTO {
    private Long circuitId;
    private String circuitReference;
    private ServiceType serviceType;
    private String customerId;
    private Double bandwidthMbps;
    private String routePath;
    private LocalDateTime activationDate;
    private CircuitStatus status;
}
