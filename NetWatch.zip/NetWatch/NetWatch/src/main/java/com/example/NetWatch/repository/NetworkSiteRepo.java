package com.example.NetWatch.repository;

import com.example.NetWatch.entity.NetworkSite;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NetworkSiteRepo  extends JpaRepository<NetworkSite,Long> {
}
