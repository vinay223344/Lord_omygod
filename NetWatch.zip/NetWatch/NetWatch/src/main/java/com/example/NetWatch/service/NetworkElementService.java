package com.example.NetWatch.service;

import com.example.NetWatch.requestdto.NetworkElementRequestDTO;
import com.example.NetWatch.responsedto.NetworkElementResponseDTO;
import java.util.List;

public interface NetworkElementService {
    List<NetworkElementResponseDTO> getAllElements();
    NetworkElementResponseDTO createElement(NetworkElementRequestDTO elementRequest);
    NetworkElementResponseDTO updateElement(Long id, NetworkElementRequestDTO request);
}
