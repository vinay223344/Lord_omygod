package com.example.NetWatch.service;

import com.example.NetWatch.requestdto.NetworkSiteRequestDTO;
import com.example.NetWatch.responsedto.NetworkSiteResponseDTO;
import java.util.List;

public interface NetworkSiteService {
    List<NetworkSiteResponseDTO> getAllSites();
    NetworkSiteResponseDTO createSite(NetworkSiteRequestDTO siteRequest);
    NetworkSiteResponseDTO updateSite(Long id, NetworkSiteRequestDTO request);
}
