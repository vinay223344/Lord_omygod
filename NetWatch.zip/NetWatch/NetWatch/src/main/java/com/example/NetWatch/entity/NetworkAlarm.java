package com.example.NetWatch.entity;

import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.enums.AlarmStatus;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class NetworkAlarm {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long alarmId;

    @ManyToOne
    @JoinColumn(name = "element_id")
    private NetworkElement element;

    @Enumerated(EnumType.STRING)
    private AlarmType alarmType;

    @Enumerated(EnumType.STRING)
    private Severity severity;

    private String alarmTime;

    private Long acknowledgedById;
    private String acknowledgedTime;

    private String clearedTime;

    @Enumerated(EnumType.STRING)
    private AlarmStatus status;
}