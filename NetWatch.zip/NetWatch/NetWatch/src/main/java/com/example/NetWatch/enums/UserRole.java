package com.example.NetWatch.enums;

public enum UserRole {
    ADMIN,
    NOC_ENGINEER,
    FIELD_ENGINEER,
    PLANNING_ENGINEER,
    SERVICE_DESK,
    CHANGE_MANAGER
}
