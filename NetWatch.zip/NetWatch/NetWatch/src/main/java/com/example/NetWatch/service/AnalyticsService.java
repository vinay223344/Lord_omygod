package com.example.NetWatch.service;

import com.example.NetWatch.responsedto.AnalyticsDashboardDTO;

public interface AnalyticsService {
    AnalyticsDashboardDTO getDashboardStats();
}
