package com.example.NetWatch.entity;

import com.example.NetWatch.enums.LinkType;
import com.example.NetWatch.enums.LinkStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "topology_link")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TopologyLink {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long linkId;

    @Enumerated(EnumType.STRING)
    private LinkType linkType;

    private Double capacityMbps;
    private Double utilisationPercent;

    @Enumerated(EnumType.STRING)
    private LinkStatus status;

    @ManyToOne
    @JoinColumn(name = "element_a_id")
    private NetworkElement elementA;

    @ManyToOne
    @JoinColumn(name = "element_b_id")
    private NetworkElement elementB;
}
