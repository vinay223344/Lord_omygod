package com.example.NetWatch.service;

import com.example.NetWatch.entity.AuditLog;
import com.example.NetWatch.responsedto.AuditLogResponseDTO;
import java.util.List;

public interface AuditLogService {
    AuditLog log(Long userId, String action, String entityType, Long recordId);
    List<AuditLogResponseDTO> getAllLogs();
    List<AuditLogResponseDTO> getLogsByUser(Long userId);
    List<AuditLogResponseDTO> getLogsByEntity(String entityType);
}
