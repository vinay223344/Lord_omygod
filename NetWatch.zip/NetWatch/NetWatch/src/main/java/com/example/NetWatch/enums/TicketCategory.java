package com.example.NetWatch.enums;

public enum TicketCategory {
    LINK_FAULT,
    NODE_FAULT,
    POWER_ISSUE,
    CONGESTION,
    CONFIG_ERROR
}
