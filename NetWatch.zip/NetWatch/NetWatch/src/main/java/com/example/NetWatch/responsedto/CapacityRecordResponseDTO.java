package com.example.NetWatch.responsedto;

import com.example.NetWatch.enums.MetricType;
import com.example.NetWatch.enums.CapacityStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CapacityRecordResponseDTO {
    private Long capacityId;
    private Long elementId;
    private String elementName;
    private MetricType metricType;
    private Double peakValue;
    private Double averageValue;
    private Double thresholdPercent;
    private LocalDateTime recordedDate;
    private CapacityStatus status;
}
