package com.example.NetWatch.repository;

import com.example.NetWatch.entity.TroubleTicket;
import com.example.NetWatch.enums.TicketStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TroubleTicketRepo extends JpaRepository<TroubleTicket, Long> {

    List<TroubleTicket> findByStatus(TicketStatus status);
}
