package com.example.NetWatch.controller;

import com.example.NetWatch.responsedto.FieldDispatchResponseDTO;
import com.example.NetWatch.requestdto.TroubleTicketRequestDTO;
import com.example.NetWatch.responsedto.TroubleTicketResponseDTO;
import com.example.NetWatch.enums.DispatchStatus;
import com.example.NetWatch.security.CustomUserDetails;
import com.example.NetWatch.service.TicketService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/ticket")
public class TicketController {

    @Autowired
    private TicketService ticketService;



    private CustomUserDetails getCurrentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        return (CustomUserDetails) auth.getPrincipal();
    }

    private boolean isFieldEngineer(CustomUserDetails user) {
        return user.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_FIELD_ENGINEER"));
    }





    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('SERVICE_DESK') or hasRole('FIELD_ENGINEER')")
    public ResponseEntity<List<TroubleTicketResponseDTO>> getAllTickets() {
        CustomUserDetails currentUser = getCurrentUser();
        if (isFieldEngineer(currentUser)) {
            // Field engineers only see tickets linked to their own dispatches
            log.debug("Field engineer {} fetching their own tickets", currentUser.getUserId());
            return ResponseEntity.ok(ticketService.getTicketsForFieldEngineer(currentUser.getUserId()));
        }
        log.debug("Fetching all tickets");
        return ResponseEntity.ok(ticketService.getAllTickets());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('SERVICE_DESK') or hasRole('FIELD_ENGINEER')")
    public ResponseEntity<TroubleTicketResponseDTO> getTicketById(@PathVariable Long id) {
        CustomUserDetails currentUser = getCurrentUser();
        if (isFieldEngineer(currentUser)) {
            // Field engineer can only view a ticket that is linked to one of their dispatches
            boolean hasAccess = ticketService.getDispatchesForEngineer(currentUser.getUserId())
                    .stream()
                    .anyMatch(d -> d.getTicketId() != null && d.getTicketId().equals(id));
            if (!hasAccess) {
                throw new AccessDeniedException("You can only view tickets assigned to you");
            }
        }
        TroubleTicketResponseDTO saved = ticketService.getTicketById(id);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}/close")
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('SERVICE_DESK')")
    public ResponseEntity<TroubleTicketResponseDTO> closeTicket(@PathVariable Long id, @RequestParam Long updaterId) {
        log.info("Closing ticket id={} by updaterId={}", id, updaterId);
        TroubleTicketResponseDTO saved = ticketService.closeTicket(id, updaterId);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}/escalate")
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('SERVICE_DESK')")
    public ResponseEntity<TroubleTicketResponseDTO> escalateTicket(@PathVariable Long id, @RequestParam Long updaterId) {
        log.info("Escalating ticket id={} by updaterId={}", id, updaterId);
        TroubleTicketResponseDTO saved = ticketService.escalateTicket(id, updaterId);
        return ResponseEntity.ok(saved);
    }



    @PostMapping("/dispatch")
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER')")
    public ResponseEntity<FieldDispatchResponseDTO> createDispatch(@RequestParam Long ticketId, @RequestParam Long fieldEngineerId, @RequestParam Long creatorId) {
        log.info("Creating dispatch for ticketId={}, fieldEngineerId={}", ticketId, fieldEngineerId);
        FieldDispatchResponseDTO saved = ticketService.createDispatch(ticketId, fieldEngineerId, creatorId);
        log.info("Dispatch created: id={}", saved.getDispatchId());
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/dispatch")
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER')")
    public ResponseEntity<List<FieldDispatchResponseDTO>> getAllDispatches() {
        List<FieldDispatchResponseDTO> list = ticketService.getAllDispatches();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/dispatch/engineer/{fieldEngineerId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('FIELD_ENGINEER')")
    public ResponseEntity<List<FieldDispatchResponseDTO>> getDispatchesForEngineer(@PathVariable Long fieldEngineerId) {
        CustomUserDetails currentUser = getCurrentUser();
        if (isFieldEngineer(currentUser) && !currentUser.getUserId().equals(fieldEngineerId)) {
            // Field engineers can only fetch their own dispatches, not another engineer's
            throw new AccessDeniedException("You can only view your own dispatches");
        }
        List<FieldDispatchResponseDTO> list = ticketService.getDispatchesForEngineer(fieldEngineerId);
        return ResponseEntity.ok(list);
    }

    @GetMapping("/dispatch/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('FIELD_ENGINEER') or hasRole('NOC_ENGINEER')")
    public ResponseEntity<FieldDispatchResponseDTO> getDispatchById(@PathVariable Long id) {
        FieldDispatchResponseDTO saved = ticketService.getDispatchById(id);
        CustomUserDetails currentUser = getCurrentUser();
        if (isFieldEngineer(currentUser) && !saved.getFieldEngineerId().equals(currentUser.getUserId())) {
            // Field engineers can only view dispatches assigned to them
            throw new AccessDeniedException("You can only view your own dispatches");
        }
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/dispatch/{id}/status")
    @PreAuthorize("hasRole('ADMIN') or hasRole('FIELD_ENGINEER')")
    public ResponseEntity<FieldDispatchResponseDTO> updateDispatchStatus(
            @PathVariable Long id,
            @RequestParam DispatchStatus status,
            @RequestParam(required = false) String resolutionSummary,
            @RequestParam Long engineerId) {
        CustomUserDetails currentUser = getCurrentUser();
        if (isFieldEngineer(currentUser)) {

            FieldDispatchResponseDTO dispatch = ticketService.getDispatchById(id);
            if (!dispatch.getFieldEngineerId().equals(currentUser.getUserId())) {
                throw new AccessDeniedException("You can only update your own dispatches");
            }
            // Override engineerId with authenticated user's ID to prevent spoofing via request param
            engineerId = currentUser.getUserId();
        }
        log.info("Updating dispatch id={} to status={} by engineerId={}", id, status, engineerId);
        FieldDispatchResponseDTO saved = ticketService.updateDispatchStatus(id, status, resolutionSummary, engineerId);
        return ResponseEntity.ok(saved);
    }
}
