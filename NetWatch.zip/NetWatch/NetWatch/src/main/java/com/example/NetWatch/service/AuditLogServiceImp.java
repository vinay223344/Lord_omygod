package com.example.NetWatch.service;

import com.example.NetWatch.entity.AuditLog;
import com.example.NetWatch.repository.AuditLogRepo;
import com.example.NetWatch.responsedto.AuditLogResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AuditLogServiceImp implements AuditLogService {

    @Autowired
    private AuditLogRepo auditLogRepo;

    @Override
    public AuditLog log(Long userId, String action, String entityType, Long recordId) {
        AuditLog logRecord = new AuditLog();
        logRecord.setUserId(userId);
        logRecord.setAction(action);
        logRecord.setEntityType(entityType);
        logRecord.setRecordId(recordId);
        logRecord.setTimestamp(LocalDateTime.now());
        return auditLogRepo.save(logRecord);
    }

    @Override
    public List<AuditLogResponseDTO> getAllLogs() {
        return auditLogRepo.findAll().stream()
                .map(this::mapLogToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<AuditLogResponseDTO> getLogsByUser(Long userId) {
        return auditLogRepo.findByUserId(userId).stream()
                .map(this::mapLogToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<AuditLogResponseDTO> getLogsByEntity(String entityType) {
        return auditLogRepo.findByEntityType(entityType).stream()
                .map(this::mapLogToResponse)
                .collect(Collectors.toList());
    }

    private AuditLogResponseDTO mapLogToResponse(AuditLog logRecord) {
        if (logRecord == null) return null;
        return AuditLogResponseDTO.builder()
                .auditId(logRecord.getAuditId())
                .userId(logRecord.getUserId())
                .action(logRecord.getAction())
                .entityType(logRecord.getEntityType())
                .recordId(logRecord.getRecordId())
                .timestamp(logRecord.getTimestamp())
                .build();
    }
}
