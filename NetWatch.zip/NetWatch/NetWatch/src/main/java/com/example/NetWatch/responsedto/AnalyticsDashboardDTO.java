package com.example.NetWatch.responsedto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnalyticsDashboardDTO {
    private Double networkAvailability; // Availability percentage
    private Double mttrMinutes;         // Mean Time to Resolution in minutes
    private Long alarmCount;            // Total alarms
    private Long p1TicketCount;         // Total P1 tickets
    private Double slaComplianceRate;   // SLA compliance percentage
    private Long capacityBreachCount;   // Number of capacity warnings/critical records
    private Long fieldDispatchSuccessRate; // Success percentage of field repairs
}
