package com.example.NetWatch.requestdto;

import com.example.NetWatch.enums.ServiceType;
import com.example.NetWatch.enums.CircuitStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CircuitRequestDTO {
    private String circuitReference;
    private ServiceType serviceType;
    private String customerId;
    private Double bandwidthMbps;
    private String routePath;
    private CircuitStatus status;
}
