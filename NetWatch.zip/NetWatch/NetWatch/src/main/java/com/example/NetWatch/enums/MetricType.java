package com.example.NetWatch.enums;

public enum MetricType {
    LINK_UTILISATION, CPU_LOAD, MEMORY_USAGE, STORAGE_USAGE
}
