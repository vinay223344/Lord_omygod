package com.example.NetWatch.enums;

public enum ServiceType {
    LEASED_LINE, VPN, INTERNET, VOICE, MPLS
}
