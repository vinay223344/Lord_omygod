package com.example.NetWatch.enums;

public enum CapacityStatus {
    NORMAL,
    WARNING,
    CRITICAL
}
