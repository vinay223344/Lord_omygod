package com.example.NetWatch.enums;

public enum TicketPriority {
    P1,
    P2,
    P3,
    P4
}
