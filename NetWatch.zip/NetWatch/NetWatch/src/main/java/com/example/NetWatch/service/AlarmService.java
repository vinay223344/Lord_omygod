package com.example.NetWatch.service;

import com.example.NetWatch.requestdto.NetworkAlarmRequestDTO;
import com.example.NetWatch.responsedto.NetworkAlarmResponseDTO;
import java.util.List;

public interface AlarmService {
    NetworkAlarmResponseDTO create(NetworkAlarmRequestDTO alarmRequest, Long creatorId);
    List<NetworkAlarmResponseDTO> getAll();
    NetworkAlarmResponseDTO acknowledge(Long id, Long userId);
    NetworkAlarmResponseDTO clearAlarm(Long id, Long userId);
}