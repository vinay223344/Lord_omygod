package com.example.NetWatch.enums;

public enum ProvisioningRequestType {
    BANDWIDTH_UPGRADE,
    SUSPENSION,
    TERMINATION
}
