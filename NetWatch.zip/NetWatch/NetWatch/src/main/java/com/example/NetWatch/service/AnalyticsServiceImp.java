package com.example.NetWatch.service;

import com.example.NetWatch.responsedto.AnalyticsDashboardDTO;
import com.example.NetWatch.entity.FieldDispatch;
import com.example.NetWatch.entity.NetworkAlarm;
import com.example.NetWatch.entity.TroubleTicket;
import com.example.NetWatch.repository.*;
import com.example.NetWatch.enums.AlarmStatus;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.enums.TicketPriority;
import com.example.NetWatch.enums.CapacityStatus;
import com.example.NetWatch.enums.DispatchStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.List;

@Service
public class AnalyticsServiceImp implements AnalyticsService {

    @Autowired
    private AlarmRepo alarmRepo;

    @Autowired
    private NetworkElementRepo elementRepo;

    @Autowired
    private TroubleTicketRepo ticketRepo;

    @Autowired
    private FieldDispatchRepo dispatchRepo;

    @Autowired
    private CapacityRecordRepo capacityRepo;

    @Override
    public AnalyticsDashboardDTO getDashboardStats() {
        // 1. Network Availability Calculation
        long totalElements = elementRepo.count();
        long activeCriticalAlarms = alarmRepo.findAll().stream()
                .filter(a -> (a.getStatus() == AlarmStatus.ACTIVE || a.getStatus() == AlarmStatus.ACKNOWLEDGED)
                        && a.getSeverity() == Severity.CRITICAL)
                .map(NetworkAlarm::getElement)
                .distinct()
                .count();

        double availability = 100.0;
        if (totalElements > 0) {
            availability = ((double) (totalElements - activeCriticalAlarms) / totalElements) * 100.0;
        }

        // 2. MTTR (Mean Time to Resolution)
        List<TroubleTicket> allTickets = ticketRepo.findAll();
        List<TroubleTicket> resolvedTickets = allTickets.stream()
                .filter(t -> t.getRestoredDateTime() != null && t.getRaisedDateTime() != null)
                .toList();

        double mttr = 0.0;
        if (!resolvedTickets.isEmpty()) {
            double totalMinutes = resolvedTickets.stream()
                    .mapToDouble(t -> Duration.between(t.getRaisedDateTime(), t.getRestoredDateTime()).toMinutes())
                    .sum();
            mttr = totalMinutes / resolvedTickets.size();
        }

        // 3. Alarm Counts
        long alarmCount = alarmRepo.count();

        // 4. P1 Ticket Counts
        long p1Count = allTickets.stream()
                .filter(t -> t.getPriority() == TicketPriority.P1)
                .count();

        // 5. SLA Compliance Rate
        long compliantCount = resolvedTickets.stream()
                .filter(t -> !t.getRestoredDateTime().isAfter(t.getRestorationSLATime()))
                .count();

        double slaCompliance = 100.0;
        if (!resolvedTickets.isEmpty()) {
            slaCompliance = ((double) compliantCount / resolvedTickets.size()) * 100.0;
        }

        // 6. Capacity Breach Count
        long capacityBreaches = capacityRepo.findAll().stream()
                .filter(r -> r.getStatus() == CapacityStatus.CRITICAL || r.getStatus() == CapacityStatus.WARNING)
                .count();

        // 7. Field Dispatch Success Rate
        List<FieldDispatch> allDispatches = dispatchRepo.findAll();
        long resolvedDispatches = allDispatches.stream()
                .filter(d -> d.getStatus() == DispatchStatus.RESOLVED)
                .count();

        long dispatchSuccessRate = 100;
        if (!allDispatches.isEmpty()) {
            dispatchSuccessRate = Math.round(((double) resolvedDispatches / allDispatches.size()) * 100.0);
        }

        return AnalyticsDashboardDTO.builder()
                .networkAvailability(Math.round(availability * 100.0) / 100.0)
                .mttrMinutes(Math.round(mttr * 100.0) / 100.0)
                .alarmCount(alarmCount)
                .p1TicketCount(p1Count)
                .slaComplianceRate(Math.round(slaCompliance * 100.0) / 100.0)
                .capacityBreachCount(capacityBreaches)
                .fieldDispatchSuccessRate(dispatchSuccessRate)
                .build();
    }
}
