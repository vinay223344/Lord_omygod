package com.example.NetWatch.enums;

public enum SiteType {
    DATACENTRE, EXCHANGE, TOWER, POP, REMOTE_NODE
}
