package com.example.NetWatch.service;

import com.example.NetWatch.entity.User;
import com.example.NetWatch.repository.UserRepo;
import com.example.NetWatch.requestdto.UserRequestDTO;
import com.example.NetWatch.responsedto.UserResponseDTO;
import com.example.NetWatch.security.CustomUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImp implements UserService {

    @Autowired
    private UserRepo repo;

    @Autowired
    private PasswordEncoder encoder;

    @Override
    public UserResponseDTO register(UserRequestDTO userRequestDTO) {
        User user = new User();
        user.setName(userRequestDTO.getName());
        user.setEmail(userRequestDTO.getEmail());
        user.setPassword(encoder.encode(userRequestDTO.getPassword()));
        user.setRole(userRequestDTO.getRole());
        user.setPhone(userRequestDTO.getPhone());
        user.setShiftGroup(userRequestDTO.getShiftGroup());
        user.setStatus(userRequestDTO.getStatus());


        User savedUser = repo.save(user);

        return UserResponseDTO.builder()
                .userId(savedUser.getUserId())
                .name(savedUser.getName())
                .email(savedUser.getEmail())
                .role(savedUser.getRole())
                .phone(savedUser.getPhone())
                .shiftGroup(savedUser.getShiftGroup())
                .status(savedUser.getStatus())

                .build();
    }

    @Override
    public Optional<User> findByEmail(String email) {
        return repo.findByEmail(email);
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = repo.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        return new CustomUserDetails(user);
    }
}
