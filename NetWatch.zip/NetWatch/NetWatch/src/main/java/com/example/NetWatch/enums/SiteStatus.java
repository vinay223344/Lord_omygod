package com.example.NetWatch.enums;

public enum SiteStatus {
    ACTIVE, INACTIVE
}
