package com.example.NetWatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NetwatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(NetwatchApplication.class, args);
	}

}
