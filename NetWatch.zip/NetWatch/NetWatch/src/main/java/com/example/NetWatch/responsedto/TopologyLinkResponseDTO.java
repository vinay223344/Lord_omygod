package com.example.NetWatch.responsedto;

import com.example.NetWatch.enums.LinkType;
import com.example.NetWatch.enums.LinkStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TopologyLinkResponseDTO {
    private Long linkId;
    private LinkType linkType;
    private Double capacityMbps;
    private Double utilisationPercent;
    private LinkStatus status;
    private Long elementAId;
    private String elementAName;
    private Long elementBId;
    private String elementBName;
}
