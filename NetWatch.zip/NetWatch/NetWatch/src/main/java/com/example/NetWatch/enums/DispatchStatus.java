package com.example.NetWatch.enums;

public enum DispatchStatus {
    DISPATCHED, ON_SITE, RESOLVED, CANNOT_REPAIR
}
