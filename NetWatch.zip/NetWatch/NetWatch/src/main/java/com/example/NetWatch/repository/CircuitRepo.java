package com.example.NetWatch.repository;

import com.example.NetWatch.entity.Circuit;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface CircuitRepo extends JpaRepository<Circuit, Long> {
    Optional<Circuit> findByCircuitReference(String circuitReference);
}
