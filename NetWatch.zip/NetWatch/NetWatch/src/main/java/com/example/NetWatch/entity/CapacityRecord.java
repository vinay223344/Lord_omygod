package com.example.NetWatch.entity;

import com.example.NetWatch.enums.MetricType;
import com.example.NetWatch.enums.CapacityStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "capacity_record")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CapacityRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long capacityId;

    @ManyToOne
    @JoinColumn(name = "element_id")
    private NetworkElement element;

    @Enumerated(EnumType.STRING)
    private MetricType metricType;

    private Double peakValue;

    private Double averageValue;

    private Double thresholdPercent;

    private LocalDateTime recordedDate;

    @Enumerated(EnumType.STRING)
    private CapacityStatus status;
}
