package com.example.NetWatch.enums;

public enum ProvisioningStatus {
    PENDING, IN_PROGRESS, COMPLETED, REJECTED
}
