package com.example.NetWatch.service;

import com.example.NetWatch.entity.NetworkAlarm;
import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.TroubleTicket;
import com.example.NetWatch.repository.AlarmRepo;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.repository.TroubleTicketRepo;
import com.example.NetWatch.requestdto.NetworkAlarmRequestDTO;
import com.example.NetWatch.responsedto.NetworkAlarmResponseDTO;
import com.example.NetWatch.enums.AlarmStatus;
import com.example.NetWatch.enums.TicketCategory;
import com.example.NetWatch.enums.TicketPriority;
import com.example.NetWatch.enums.TicketStatus;
import com.example.NetWatch.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AlarmServiceImp implements AlarmService {

    @Autowired
    private AlarmRepo alarmRepo;

    @Autowired
    private TroubleTicketRepo ticketRepo;

    @Autowired
    private NetworkElementRepo elementRepo;

    @Autowired
    private AuditLogService auditService;

    @Override
    @Transactional
    public NetworkAlarmResponseDTO create(NetworkAlarmRequestDTO alarmRequest, Long creatorId) {
        NetworkAlarm alarm = mapToEntity(alarmRequest);
        alarm.setAlarmTime(String.valueOf(LocalDateTime.now()));
        alarm.setStatus(AlarmStatus.ACTIVE);

        NetworkAlarm saved = alarmRepo.save(alarm);

        // ✅ AUTO-GENERATE TROUBLE TICKET from alarm
        autoGenerateTicket(saved);

        auditService.log(creatorId, "CREATE_ALARM", "NetworkAlarm", saved.getAlarmId());

        return mapToResponse(saved);
    }

    private void autoGenerateTicket(NetworkAlarm alarm) {
        TroubleTicket ticket = new TroubleTicket();

        // Link alarm and element/site from alarm
        ticket.setAlarm(alarm);
        ticket.setElement(alarm.getElement());

        // Map AlarmType → TroubleTicket Category
        TicketCategory category = switch (alarm.getAlarmType()) {
            case LINK_DOWN         -> TicketCategory.LINK_FAULT;
            case NODE_UNREACHABLE  -> TicketCategory.NODE_FAULT;
            case HIGH_UTILISATION  -> TicketCategory.CONGESTION;
            case POWER_FAILURE     -> TicketCategory.POWER_ISSUE;
            case HARDWARE_FAULT    -> TicketCategory.NODE_FAULT;
            case COOLING_ALERT     -> TicketCategory.NODE_FAULT;
        };
        ticket.setCategory(category);

        // Map Severity → Priority
        TicketPriority priority = switch (alarm.getSeverity()) {
            case CRITICAL -> TicketPriority.P1;
            case MAJOR    -> TicketPriority.P2;
            case MINOR    -> TicketPriority.P3;
            case WARNING  -> TicketPriority.P4;
        };
        ticket.setPriority(priority);

        // SLA based on priority
        LocalDateTime raisedAt = LocalDateTime.now();
        int slaHours = switch (priority) {
            case P1 -> 2;
            case P2 -> 4;
            case P3 -> 12;
            case P4 -> 24;
        };
        ticket.setSite(alarm.getElement().getSite());

        ticket.setRaisedDateTime(raisedAt);
        ticket.setRestorationSLATime(raisedAt.plusHours(slaHours));
        ticket.setStatus(TicketStatus.OPEN);

        ticketRepo.save(ticket);
    }

    @Override
    public List<NetworkAlarmResponseDTO> getAll() {
        return alarmRepo.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public NetworkAlarmResponseDTO acknowledge(Long id, Long userId) {
        NetworkAlarm alarm = alarmRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Alarm not found: " + id));

        alarm.setStatus(AlarmStatus.ACKNOWLEDGED);
        alarm.setAcknowledgedById(userId);
        alarm.setAcknowledgedTime(String.valueOf(LocalDateTime.now()));

        NetworkAlarm saved = alarmRepo.save(alarm);
        auditService.log(userId, "ACKNOWLEDGE_ALARM", "NetworkAlarm", saved.getAlarmId());
        return mapToResponse(saved);
    }

    @Override
    @Transactional
    public NetworkAlarmResponseDTO clearAlarm(Long id, Long userId) {
        NetworkAlarm alarm = alarmRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Alarm not found: " + id));

        alarm.setStatus(AlarmStatus.CLEARED);
        alarm.setClearedTime(String.valueOf(LocalDateTime.now()));

        NetworkAlarm saved = alarmRepo.save(alarm);
        auditService.log(userId, "CLEAR_ALARM", "NetworkAlarm", saved.getAlarmId());
        return mapToResponse(saved);
    }

    private NetworkAlarm mapToEntity(NetworkAlarmRequestDTO request) {
        if (request == null) return null;
        NetworkAlarm alarm = new NetworkAlarm();
        if (request.getElementId() != null) {
            NetworkElement element = elementRepo.findById(request.getElementId())
                    .orElseThrow(() -> new ResourceNotFoundException("Network Element not found with ID: " + request.getElementId()));
            alarm.setElement(element);
        }
        alarm.setAlarmType(request.getAlarmType());
        alarm.setSeverity(request.getSeverity());
        alarm.setStatus(request.getStatus());
        return alarm;
    }

    private NetworkAlarmResponseDTO mapToResponse(NetworkAlarm alarm) {
        if (alarm == null) return null;
        return NetworkAlarmResponseDTO.builder()
                .alarmId(alarm.getAlarmId())
                .elementId(alarm.getElement() != null ? alarm.getElement().getElementId() : null)
                .elementName(alarm.getElement() != null ? alarm.getElement().getElementName() : null)
                .alarmType(alarm.getAlarmType())
                .severity(alarm.getSeverity())
                .alarmTime(alarm.getAlarmTime())
                .acknowledgedById(alarm.getAcknowledgedById())
                .acknowledgedTime(alarm.getAcknowledgedTime())
                .clearedTime(alarm.getClearedTime())
                .status(alarm.getStatus())
                .build();
    }
}
