package com.example.NetWatch.requestdto;

import com.example.NetWatch.enums.TicketCategory;
import com.example.NetWatch.enums.TicketPriority;
import com.example.NetWatch.enums.TicketStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TroubleTicketRequestDTO {
    private Long alarmId;
    private Long elementId;
    private Long siteId;
    private TicketCategory category;
    private TicketPriority priority;
    private TicketStatus status;
}
