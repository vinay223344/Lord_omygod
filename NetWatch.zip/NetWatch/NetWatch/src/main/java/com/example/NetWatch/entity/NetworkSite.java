package com.example.NetWatch.entity;

import com.example.NetWatch.enums.SiteType;
import com.example.NetWatch.enums.SiteStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Table(name = "network_site")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class NetworkSite {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long siteId;

    private String siteName;

    @Enumerated(EnumType.STRING)
    private SiteType siteType;

    private String address;

    @Enumerated(EnumType.STRING)
    private SiteStatus status;

    @OneToMany(mappedBy = "site" ,cascade = CascadeType.ALL)
    private List<NetworkElement> elements;
}
