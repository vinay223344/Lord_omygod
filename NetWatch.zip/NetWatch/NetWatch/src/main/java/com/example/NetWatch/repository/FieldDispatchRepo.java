package com.example.NetWatch.repository;

import com.example.NetWatch.entity.FieldDispatch;
import com.example.NetWatch.enums.DispatchStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface FieldDispatchRepo extends JpaRepository<FieldDispatch, Long> {
    List<FieldDispatch> findByFieldEngineerId(Long fieldEngineerId);
    List<FieldDispatch> findByStatus(DispatchStatus status);
    boolean existsByTicket_TicketIdAndFieldEngineerId(Long ticketId, Long fieldEngineerId);
}
