package com.example.NetWatch.service;

import com.example.NetWatch.requestdto.TopologyLinkRequestDTO;
import com.example.NetWatch.responsedto.TopologyLinkResponseDTO;
import java.util.List;

public interface TopologyLinkService {
    List<TopologyLinkResponseDTO> getAllLinks();
    TopologyLinkResponseDTO createLink(TopologyLinkRequestDTO linkRequest);
    TopologyLinkResponseDTO updateLink(Long id, TopologyLinkRequestDTO request);
}