package com.example.NetWatch.enums;

public enum CircuitStatus {
    ACTIVE, SUSPENDED, DECOMMISSIONED
}
