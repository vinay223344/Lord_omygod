package com.example.NetWatch.enums;

public enum MaintenanceType {
    PLANNED,
    EMERGENCY
}
