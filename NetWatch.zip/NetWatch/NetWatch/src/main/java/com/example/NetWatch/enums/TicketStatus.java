package com.example.NetWatch.enums;

public enum TicketStatus {
    OPEN,

    FIELD_DISPATCHED,
    RESOLVED,
    CLOSED,
    ESCALATED
}
