package com.example.NetWatch.responsedto;

import com.example.NetWatch.enums.TicketCategory;
import com.example.NetWatch.enums.TicketPriority;
import com.example.NetWatch.enums.TicketStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TroubleTicketResponseDTO {
    private Long ticketId;
    private Long alarmId;
    private Long elementId;
    private String elementName;
    private Long siteId;
    private String siteName;
    private TicketCategory category;
    private TicketPriority priority;

    private LocalDateTime raisedDateTime;
    private LocalDateTime restorationSLATime;
    private LocalDateTime restoredDateTime;
    private TicketStatus status;
}
