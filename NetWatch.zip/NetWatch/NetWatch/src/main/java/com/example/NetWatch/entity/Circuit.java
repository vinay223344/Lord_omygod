package com.example.NetWatch.entity;

import com.example.NetWatch.enums.ServiceType;
import com.example.NetWatch.enums.CircuitStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "circuit")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Circuit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long circuitId;

    @Column(unique = true, nullable = false)
    private String circuitReference;

    @Enumerated(EnumType.STRING)
    private ServiceType serviceType;

    private String customerId;

    private Double bandwidthMbps;

    @Column(length = 1000)
    private String routePath;

    private LocalDateTime activationDate;

    @Enumerated(EnumType.STRING)
    private CircuitStatus status;
}
