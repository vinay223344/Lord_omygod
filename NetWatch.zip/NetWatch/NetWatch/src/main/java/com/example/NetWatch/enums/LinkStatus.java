package com.example.NetWatch.enums;

public enum LinkStatus {
    ACTIVE, DEGRADED, DOWN
}
