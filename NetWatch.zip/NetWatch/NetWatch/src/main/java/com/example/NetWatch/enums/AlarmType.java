package com.example.NetWatch.enums;

public enum AlarmType {
    LINK_DOWN,
    NODE_UNREACHABLE,
    HIGH_UTILISATION,
    POWER_FAILURE,
    HARDWARE_FAULT,
    COOLING_ALERT
}
