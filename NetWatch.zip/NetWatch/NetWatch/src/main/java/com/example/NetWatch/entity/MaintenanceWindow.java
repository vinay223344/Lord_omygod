package com.example.NetWatch.entity;

import com.example.NetWatch.enums.MaintenanceType;
import com.example.NetWatch.enums.MaintenanceStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "maintenance_window")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MaintenanceWindow {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long maintenanceId;

    private String title;

    @Column(length = 1000)
    private String affectedElementIds;

    @Enumerated(EnumType.STRING)
    private MaintenanceType maintenanceType;

    private LocalDateTime startDateTime;

    private LocalDateTime endDateTime;

    private Long requestedById;

    private Long approvedById;

    @Column(length = 2000)
    private String rollbackPlan;

    @Enumerated(EnumType.STRING)
    private MaintenanceStatus status;
}
