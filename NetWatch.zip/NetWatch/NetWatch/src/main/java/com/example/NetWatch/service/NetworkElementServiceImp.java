package com.example.NetWatch.service;

import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.NetworkSite;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.repository.NetworkSiteRepo;
import com.example.NetWatch.requestdto.NetworkElementRequestDTO;
import com.example.NetWatch.responsedto.NetworkElementResponseDTO;
import com.example.NetWatch.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class NetworkElementServiceImp implements NetworkElementService {

    @Autowired
    private NetworkElementRepo elementRepository;

    @Autowired
    private NetworkSiteRepo siteRepository;

    @Override
    @Transactional
    public NetworkElementResponseDTO updateElement(Long id, NetworkElementRequestDTO request) {
        NetworkElement element = elementRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Network element not found with id: " + id));
        element.setElementName(request.getElementName());
        element.setElementType(request.getElementType());
        element.setVendor(request.getVendor());
        element.setModel(request.getModel());
        element.setIpAddress(request.getIpAddress());
        element.setStatus(request.getStatus());
        if (request.getSiteId() != null) {
            NetworkSite site = siteRepository.findById(request.getSiteId())
                    .orElseThrow(() -> new ResourceNotFoundException("Network site not found with id: " + request.getSiteId()));
            element.setSite(site);
        } else {
            element.setSite(null);
        }
        NetworkElement saved = elementRepository.save(element);
        return mapElementToResponse(saved);
    }

    @Override
    public List<NetworkElementResponseDTO> getAllElements() {
        return elementRepository.findAll().stream()
                .map(this::mapElementToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public NetworkElementResponseDTO createElement(NetworkElementRequestDTO elementRequest) {
        NetworkElement element = mapElementToEntity(elementRequest);
        NetworkElement saved = elementRepository.save(element);
        return mapElementToResponse(saved);
    }

    private NetworkElementResponseDTO mapElementToResponse(NetworkElement element) {
        if (element == null) return null;
        return NetworkElementResponseDTO.builder()
                .elementId(element.getElementId())
                .elementName(element.getElementName())
                .elementType(element.getElementType())
                .vendor(element.getVendor())
                .model(element.getModel())
                .ipAddress(element.getIpAddress())
                .status(element.getStatus())
                .siteId(element.getSite() != null ? element.getSite().getSiteId() : null)
                .siteName(element.getSite() != null ? element.getSite().getSiteName() : null)
                .build();
    }

    private NetworkElement mapElementToEntity(NetworkElementRequestDTO request) {
        if (request == null) return null;
        NetworkElement element = new NetworkElement();
        element.setElementName(request.getElementName());
        element.setElementType(request.getElementType());
        element.setVendor(request.getVendor());
        element.setModel(request.getModel());
        element.setIpAddress(request.getIpAddress());
        element.setStatus(request.getStatus());
        if (request.getSiteId() != null) {
            NetworkSite site = siteRepository.findById(request.getSiteId()).orElse(null);
            element.setSite(site);
        }
        return element;
    }
}
