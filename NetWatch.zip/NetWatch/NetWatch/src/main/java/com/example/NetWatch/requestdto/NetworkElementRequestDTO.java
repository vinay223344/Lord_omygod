package com.example.NetWatch.requestdto;

import com.example.NetWatch.enums.ElementType;
import com.example.NetWatch.enums.ElementStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NetworkElementRequestDTO {
    private String elementName;
    private ElementType elementType;
    private String vendor;
    private String model;
    private String ipAddress;

    private ElementStatus status;
    private Long siteId;
}
