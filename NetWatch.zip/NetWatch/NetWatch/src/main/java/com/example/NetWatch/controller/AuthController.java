package com.example.NetWatch.controller;

import com.example.NetWatch.requestdto.LoginRequestDTO;
import com.example.NetWatch.requestdto.UserRequestDTO;
import com.example.NetWatch.responsedto.LoginResponseDTO;
import com.example.NetWatch.responsedto.UserResponseDTO;
import com.example.NetWatch.entity.User;
import com.example.NetWatch.security.JwtUtil;
import com.example.NetWatch.exception.ResourceNotFoundException;
import com.example.NetWatch.service.UserService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.*;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UserService service;

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private AuthenticationManager authManager;

    @PostMapping("/register")
    public UserResponseDTO register(@Valid @RequestBody UserRequestDTO userRequestDTO) {
        log.info("Registering new user: email={}, role={}", userRequestDTO.getEmail(), userRequestDTO.getRole());
        return service.register(userRequestDTO);
    }

    @PostMapping("/login")
    public LoginResponseDTO login(@Valid @RequestBody LoginRequestDTO loginRequestDTO) {
        log.info("Login attempt: email={}", loginRequestDTO.getEmail());
        authManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginRequestDTO.getEmail(), loginRequestDTO.getPassword())
        );

        User dbUser = service.findByEmail(loginRequestDTO.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + loginRequestDTO.getEmail()));
        log.info("Login successful: email={}, role={}", dbUser.getEmail(), dbUser.getRole());

        String token = jwtUtil.generateToken(
                dbUser.getEmail(),
                dbUser.getRole().name(),
                dbUser.getUserId()
        );

        return LoginResponseDTO.builder()
                .success(true)
                .message("Login successful")
                .token(token)
                .username(dbUser.getName())
                .role(dbUser.getRole() != null ? dbUser.getRole().name() : null)
                .email(dbUser.getEmail())
                .status(dbUser.getStatus() != null ? dbUser.getStatus().name() : null)
                .build();
    }
}