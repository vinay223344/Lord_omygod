package com.example.NetWatch.requestdto;

import com.example.NetWatch.enums.LinkType;
import com.example.NetWatch.enums.LinkStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TopologyLinkRequestDTO {
    private LinkType linkType;
    private Double capacityMbps;
    private Double utilisationPercent;
    private LinkStatus status;
    private Long elementAId;
    private Long elementBId;
}
