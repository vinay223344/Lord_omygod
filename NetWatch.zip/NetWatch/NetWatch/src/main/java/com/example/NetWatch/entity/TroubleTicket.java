package com.example.NetWatch.entity;

import com.example.NetWatch.enums.TicketCategory;
import com.example.NetWatch.enums.TicketPriority;
import com.example.NetWatch.enums.TicketStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "trouble_ticket")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TroubleTicket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ticketId;

    @OneToOne
    @JoinColumn(name = "alarm_id")
    private NetworkAlarm alarm;

    @ManyToOne
    @JoinColumn(name = "element_id")
    private NetworkElement element;

    @ManyToOne
    @JoinColumn(name = "site_id")
    private NetworkSite site;

    @Enumerated(EnumType.STRING)
    private TicketCategory category;

    @Enumerated(EnumType.STRING)
    private TicketPriority priority;



    private LocalDateTime raisedDateTime;

    private LocalDateTime restorationSLATime;

    private LocalDateTime restoredDateTime;

    @Enumerated(EnumType.STRING)
    private TicketStatus status;
}
