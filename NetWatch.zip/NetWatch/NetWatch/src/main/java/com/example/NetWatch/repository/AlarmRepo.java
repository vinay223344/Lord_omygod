package com.example.NetWatch.repository;

import com.example.NetWatch.entity.NetworkAlarm;
import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.enums.AlarmStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AlarmRepo extends JpaRepository<NetworkAlarm, Long> {

    List<NetworkAlarm> findByElementAndStatus(NetworkElement e, AlarmStatus s);
}