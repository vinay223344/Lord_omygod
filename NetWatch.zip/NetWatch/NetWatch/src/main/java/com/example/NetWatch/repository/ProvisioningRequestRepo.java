package com.example.NetWatch.repository;

import com.example.NetWatch.entity.ProvisioningRequest;
import com.example.NetWatch.enums.ProvisioningStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface ProvisioningRequestRepo extends JpaRepository<ProvisioningRequest, Long> {
    List<ProvisioningRequest> findByStatus(ProvisioningStatus status);
}
