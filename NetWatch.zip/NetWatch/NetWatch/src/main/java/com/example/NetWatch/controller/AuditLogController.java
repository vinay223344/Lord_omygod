package com.example.NetWatch.controller;

import com.example.NetWatch.responsedto.AuditLogResponseDTO;
import com.example.NetWatch.service.AuditLogService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/audit")
@PreAuthorize("hasRole('ADMIN') or hasRole('CHANGE_MANAGER')")
public class AuditLogController {

    @Autowired
    private AuditLogService auditLogService;

    @GetMapping
    public ResponseEntity<List<AuditLogResponseDTO>> getAllLogs() {
        log.debug("Fetching all audit logs");
        List<AuditLogResponseDTO> list = auditLogService.getAllLogs();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<AuditLogResponseDTO>> getLogsByUser(@PathVariable Long userId) {
        log.debug("Fetching audit logs for userId={}", userId);
        List<AuditLogResponseDTO> list = auditLogService.getLogsByUser(userId);
        return ResponseEntity.ok(list);
    }

    @GetMapping("/entity/{entityType}")
    public ResponseEntity<List<AuditLogResponseDTO>> getLogsByEntity(@PathVariable String entityType) {
        log.debug("Fetching audit logs for entityType={}", entityType);
        List<AuditLogResponseDTO> list = auditLogService.getLogsByEntity(entityType);
        return ResponseEntity.ok(list);
    }
}
