package com.example.NetWatch.enums;

public enum ElementType {
    ROUTER, SWITCH, FIREWALL, OLT, BTS, TRANSMISSION, SERVER
}
