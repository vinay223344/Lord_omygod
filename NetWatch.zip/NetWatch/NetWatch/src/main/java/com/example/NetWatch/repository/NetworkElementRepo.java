package com.example.NetWatch.repository;


import com.example.NetWatch.entity.NetworkElement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NetworkElementRepo extends JpaRepository<NetworkElement,Long> {

}
