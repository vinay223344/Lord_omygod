package com.example.NetWatch.enums;

public enum Severity {
    CRITICAL,
    MAJOR,
    MINOR,
    WARNING
}
