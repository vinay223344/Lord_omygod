package com.example.NetWatch.entity;

import com.example.NetWatch.enums.DispatchStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "field_dispatch")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FieldDispatch {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long dispatchId;

    @ManyToOne
    @JoinColumn(name = "ticket_id")
    private TroubleTicket ticket;

    private Long fieldEngineerId;

    private LocalDateTime dispatchTime;

    private LocalDateTime siteArrivalTime;

    private LocalDateTime restorationTime;

    private String resolutionSummary;

    @Enumerated(EnumType.STRING)
    private DispatchStatus status;
}
