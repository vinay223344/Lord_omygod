package com.example.NetWatch.enums;

public enum ElementStatus {
    ACTIVE, MAINTENANCE, DECOMMISSIONED, INACTIVE
}
