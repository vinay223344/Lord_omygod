package com.example.NetWatch.enums;

public enum AlarmStatus {
    ACTIVE, ACKNOWLEDGED, CLEARED, SUPPRESSED
}
