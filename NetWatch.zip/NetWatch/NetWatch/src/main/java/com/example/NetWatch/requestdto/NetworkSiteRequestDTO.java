package com.example.NetWatch.requestdto;

import com.example.NetWatch.enums.SiteType;
import com.example.NetWatch.enums.SiteStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NetworkSiteRequestDTO {
    private String siteName;
    private SiteType siteType;
    private String address;
    private SiteStatus status;
}
