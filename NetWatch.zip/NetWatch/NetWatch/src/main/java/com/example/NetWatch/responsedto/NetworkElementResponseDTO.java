package com.example.NetWatch.responsedto;

import com.example.NetWatch.enums.ElementType;
import com.example.NetWatch.enums.ElementStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NetworkElementResponseDTO {
    private Long elementId;
    private String elementName;
    private ElementType elementType;
    private String vendor;
    private String model;
    private String ipAddress;
    private Long regionId;

    private ElementStatus status;
    private Long siteId;
    private String siteName;
}
