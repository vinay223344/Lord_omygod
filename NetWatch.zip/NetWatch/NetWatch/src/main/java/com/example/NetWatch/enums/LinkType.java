package com.example.NetWatch.enums;

public enum LinkType {
    FIBRE, MICROWAVE, ETHERNET, SDH
}
