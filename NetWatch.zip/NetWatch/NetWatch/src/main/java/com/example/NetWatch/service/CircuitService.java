package com.example.NetWatch.service;

import com.example.NetWatch.requestdto.CircuitRequestDTO;
import com.example.NetWatch.responsedto.CircuitResponseDTO;
import com.example.NetWatch.requestdto.ProvisioningRequestDTO;
import com.example.NetWatch.responsedto.ProvisioningResponseDTO;
import java.util.List;

public interface CircuitService {
    CircuitResponseDTO createCircuit(CircuitRequestDTO circuitRequestDTO, Long creatorId);
    CircuitResponseDTO updateCircuit(Long id, CircuitRequestDTO circuitRequestDTO, Long updaterId);
    List<CircuitResponseDTO> getAllCircuits();
    CircuitResponseDTO getCircuitById(Long id);
    ProvisioningResponseDTO createProvisioningRequest(ProvisioningRequestDTO requestDto, Long creatorId);
    List<ProvisioningResponseDTO> getAllRequests();
    ProvisioningResponseDTO getRequestById(Long id);
    List<ProvisioningResponseDTO> getPendingRequests();
    List<ProvisioningResponseDTO> getInProgressRequests();
    ProvisioningResponseDTO processProvisioningRequest(Long id, Long processorId);
    ProvisioningResponseDTO executeAfterMaintenanceWindow(Long id, Long processorId);
}
