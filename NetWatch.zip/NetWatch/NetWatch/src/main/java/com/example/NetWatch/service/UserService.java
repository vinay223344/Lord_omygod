package com.example.NetWatch.service;

import com.example.NetWatch.requestdto.UserRequestDTO;
import com.example.NetWatch.responsedto.UserResponseDTO;
import com.example.NetWatch.entity.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import java.util.Optional;

public interface UserService extends UserDetailsService {
    UserResponseDTO register(UserRequestDTO userRequestDTO);
    Optional<User> findByEmail(String email);
}