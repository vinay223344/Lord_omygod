package com.example.NetWatch.enums;

public enum MaintenanceStatus {
    PENDING, APPROVED, IN_PROGRESS, COMPLETED, CANCELLED
}
