package com.example.NetWatch.requestdto;

import com.example.NetWatch.enums.MaintenanceType;
import com.example.NetWatch.enums.MaintenanceStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MaintenanceWindowRequestDTO {
    private String title;
    private String affectedElementIds;
    private MaintenanceType maintenanceType;
    private LocalDateTime startDateTime;
    private LocalDateTime endDateTime;
    private String rollbackPlan;
    private MaintenanceStatus status;
}
