INSERT INTO network_site (site_id, address, site_name, site_type, status) VALUES
(1, 'Coimbatore, Tamil Nadu', 'Coimbatore POP', 'POP', 'ACTIVE'),
(2, 'Chennai, Tamil Nadu', 'Chennai Data Center', 'DATACENTRE', 'ACTIVE'),
(3, 'Bangalore, Karnataka', 'Bangalore POP', 'POP', 'ACTIVE'),
(4, 'Hyderabad, Telangana', 'Hyderabad Data Center', 'DATACENTRE', 'ACTIVE'),
(5, 'Mumbai, Maharashtra', 'Mumbai POP', 'POP', 'ACTIVE'),
(6, 'Delhi, India', 'Delhi POP', 'POP', 'ACTIVE'),
(7, 'Pune, Maharashtra', 'Pune Data Center', 'DATACENTRE', 'ACTIVE'),
(8, 'Kolkata, West Bengal', 'Kolkata POP', 'POP', 'ACTIVE'),
(9, 'Ahmedabad, Gujarat', 'Ahmedabad DC', 'DATACENTRE', 'ACTIVE'),
(10, 'Jaipur, Rajasthan', 'Jaipur POP', 'POP', 'ACTIVE');


INSERT INTO network_element
(element_id, element_name, element_type, vendor, model, ip_address, site_id, status)
VALUES
(1, 'Router A', 'ROUTER', 'Cisco', 'ISR4451', '192.168.1.1', 1, 'ACTIVE'),
(2, 'Switch B', 'SWITCH', 'Aruba', 'Aruba2930', '192.168.1.2', 2, 'ACTIVE'),
(3, 'Router C', 'ROUTER', 'Juniper', 'MX480', '192.168.2.1', 3, 'ACTIVE'),
(4, 'Switch D', 'SWITCH', 'Cisco', 'Catalyst 9500', '192.168.2.2', 4, 'ACTIVE'),
(5, 'Server X', 'SERVER', 'Dell', 'PowerEdge R750', '192.168.3.10', 5, 'ACTIVE'),
(6, 'OLT Z', 'ROUTER', 'Huawei', 'MA5800', '192.168.3.11', 5, 'ACTIVE'),

(7, 'Router E', 'ROUTER', 'Cisco', 'ASR1001', '192.168.4.1', 6, 'ACTIVE'),
(8, 'Switch F', 'SWITCH', 'Aruba', 'Aruba3810', '192.168.4.2', 6, 'ACTIVE'),

(9, 'Router G', 'ROUTER', 'Juniper', 'MX204', '192.168.5.1', 7, 'ACTIVE'),
(10, 'Switch H', 'SWITCH', 'Cisco', 'Catalyst 9300', '192.168.5.2', 7, 'ACTIVE'),

(11, 'Server Y', 'SERVER', 'HP', 'ProLiant DL380', '192.168.6.10', 8, 'ACTIVE'),
(12, 'Router H', 'ROUTER', 'Huawei', 'NE40E', '192.168.6.1', 8, 'ACTIVE'),

(13, 'Switch I', 'SWITCH', 'Juniper', 'EX4300', '192.168.7.1', 9, 'ACTIVE'),
(14, 'Server Z', 'SERVER', 'Dell', 'R740', '192.168.7.10', 9, 'ACTIVE'),

(15, 'OLT Y', 'ROUTER', 'Huawei', 'MA5800-X7', '192.168.8.1', 10, 'ACTIVE'),
(16, 'Switch J', 'SWITCH', 'Cisco', '2960X', '192.168.8.2', 10, 'ACTIVE');



INSERT INTO topology_link
(link_id, link_type, status, capacity_mbps, utilisation_percent, element_a_id, element_b_id)
VALUES
(1, 'FIBRE', 'ACTIVE', 1000, 40, 1, 2),
(2, 'FIBRE', 'ACTIVE', 2000, 55, 3, 4),
(3, 'ETHERNET', 'ACTIVE', 1000, 20, 5, 6),

(4, 'FIBRE', 'ACTIVE', 1000, 45, 2, 3),
(5, 'FIBRE', 'ACTIVE', 1500, 60, 4, 5),
(6, 'ETHERNET', 'ACTIVE', 500, 30, 6, 1),

(7, 'FIBRE', 'ACTIVE', 2000, 50, 7, 8),
(8, 'FIBRE', 'ACTIVE', 2500, 65, 9, 10),

(9, 'ETHERNET', 'ACTIVE', 1000, 40, 11, 12),
(10, 'FIBRE', 'ACTIVE', 3000, 70, 12, 13),

(11, 'FIBRE', 'ACTIVE', 1200, 35, 13, 14),
(12, 'FIBRE', 'ACTIVE', 1100, 25, 14, 15),

(13, 'ETHERNET', 'ACTIVE', 800, 20, 15, 16),
(14, 'FIBRE', 'ACTIVE', 1800, 55, 16, 7);
