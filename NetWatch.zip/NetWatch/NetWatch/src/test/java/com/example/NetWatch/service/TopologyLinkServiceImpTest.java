package com.example.NetWatch.service;

import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.TopologyLink;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.repository.TopologyRepo;
import com.example.NetWatch.requestdto.TopologyLinkRequestDTO;
import com.example.NetWatch.responsedto.TopologyLinkResponseDTO;
import com.example.NetWatch.enums.LinkType;
import com.example.NetWatch.enums.LinkStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TopologyLinkServiceImpTest {

    @Mock
    private TopologyRepo linkRepository;

    @Mock
    private NetworkElementRepo elementRepo;

    @InjectMocks
    private TopologyLinkServiceImp topologyService;

    private TopologyLinkRequestDTO linkRequest;
    private TopologyLink link;
    private NetworkElement elementA;
    private NetworkElement elementB;

    @BeforeEach
    public void setUp() {
        elementA = new NetworkElement();
        elementA.setElementId(1L);
        elementA.setElementName("Router-A");

        elementB = new NetworkElement();
        elementB.setElementId(2L);
        elementB.setElementName("Router-B");

        linkRequest = TopologyLinkRequestDTO.builder()
                .linkType(LinkType.FIBRE)
                .capacityMbps(10000.0)
                .utilisationPercent(35.5)
                .status(LinkStatus.ACTIVE)
                .elementAId(1L)
                .elementBId(2L)
                .build();

        link = new TopologyLink();
        link.setLinkId(10L);
        link.setLinkType(LinkType.FIBRE);
        link.setCapacityMbps(10000.0);
        link.setUtilisationPercent(35.5);
        link.setStatus(LinkStatus.ACTIVE);
        link.setElementA(elementA);
        link.setElementB(elementB);
    }

    @Test
    public void testGetAllLinks() {
        when(linkRepository.findAll()).thenReturn(List.of(link));

        List<TopologyLinkResponseDTO> list = topologyService.getAllLinks();

        assertNotNull(list);
        assertEquals(1, list.size());
        TopologyLinkResponseDTO resp = list.get(0);
        assertEquals(10L, resp.getLinkId());
        assertEquals(LinkType.FIBRE, resp.getLinkType());
        assertEquals(10000.0, resp.getCapacityMbps());
        assertEquals(1L, resp.getElementAId());
        assertEquals("Router-A", resp.getElementAName());
        assertEquals(2L, resp.getElementBId());
        assertEquals("Router-B", resp.getElementBName());
    }

    @Test
    public void testCreateLink_Success() {
        when(elementRepo.findById(1L)).thenReturn(Optional.of(elementA));
        when(elementRepo.findById(2L)).thenReturn(Optional.of(elementB));
        when(linkRepository.save(any(TopologyLink.class))).thenReturn(link);

        TopologyLinkResponseDTO response = topologyService.createLink(linkRequest);

        assertNotNull(response);
        assertEquals(10L, response.getLinkId());
        assertEquals(LinkType.FIBRE, response.getLinkType());
        assertEquals(1L, response.getElementAId());
        assertEquals(2L, response.getElementBId());
        assertEquals(LinkStatus.ACTIVE, response.getStatus());
        verify(elementRepo, times(1)).findById(1L);
        verify(elementRepo, times(1)).findById(2L);
        verify(linkRepository, times(1)).save(any(TopologyLink.class));
    }

    @Test
    public void testCreateLink_ElementANotFound_ThrowsException() {
        when(elementRepo.findById(1L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> topologyService.createLink(linkRequest));

        verify(linkRepository, never()).save(any(TopologyLink.class));
    }

    @Test
    public void testCreateLink_ElementBNotFound_ThrowsException() {
        when(elementRepo.findById(1L)).thenReturn(Optional.of(elementA));
        when(elementRepo.findById(2L)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> topologyService.createLink(linkRequest));

        verify(linkRepository, never()).save(any(TopologyLink.class));
    }

    @Test
    public void testGetAllLinks_Empty() {
        when(linkRepository.findAll()).thenReturn(List.of());

        List<TopologyLinkResponseDTO> list = topologyService.getAllLinks();

        assertNotNull(list);
        assertTrue(list.isEmpty());
    }
}
