package com.example.NetWatch.service;

import com.example.NetWatch.entity.NetworkSite;
import com.example.NetWatch.repository.NetworkSiteRepo;
import com.example.NetWatch.requestdto.NetworkSiteRequestDTO;
import com.example.NetWatch.responsedto.NetworkSiteResponseDTO;
import com.example.NetWatch.enums.SiteType;
import com.example.NetWatch.enums.SiteStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class NetworkSiteServiceImpTest {

    @Mock
    private NetworkSiteRepo siteRepository;

    @InjectMocks
    private NetworkSiteServiceImp siteService;

    private NetworkSiteRequestDTO siteRequest;
    private NetworkSite site;

    @BeforeEach
    public void setUp() {
        siteRequest = NetworkSiteRequestDTO.builder()
                .siteName("Site-London")
                .siteType(SiteType.DATACENTRE)
                .address("100 London Way")

                .status(SiteStatus.ACTIVE)
                .build();

        site = new NetworkSite();
        site.setSiteId(10L);
        site.setSiteName("Site-London");
        site.setSiteType(SiteType.DATACENTRE);
        site.setAddress("100 London Way");

        site.setStatus(SiteStatus.ACTIVE);
    }

    @Test
    public void testGetAllSites() {
        when(siteRepository.findAll()).thenReturn(List.of(site));

        List<NetworkSiteResponseDTO> list = siteService.getAllSites();

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals("Site-London", list.get(0).getSiteName());
        assertEquals(SiteStatus.ACTIVE, list.get(0).getStatus());
    }

    @Test
    public void testCreateSite() {
        when(siteRepository.save(any(NetworkSite.class))).thenReturn(site);

        NetworkSiteResponseDTO response = siteService.createSite(siteRequest);

        assertNotNull(response);
        assertEquals(10L, response.getSiteId());
        assertEquals("Site-London", response.getSiteName());
        assertEquals(SiteType.DATACENTRE, response.getSiteType());
        verify(siteRepository, times(1)).save(any(NetworkSite.class));
    }
}
