package com.example.NetWatch.service;

import com.example.NetWatch.responsedto.AnalyticsDashboardDTO;
import com.example.NetWatch.entity.CapacityRecord;
import com.example.NetWatch.entity.FieldDispatch;
import com.example.NetWatch.entity.NetworkAlarm;
import com.example.NetWatch.entity.TroubleTicket;
import com.example.NetWatch.repository.*;
import com.example.NetWatch.enums.AlarmStatus;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.enums.TicketPriority;
import com.example.NetWatch.enums.CapacityStatus;
import com.example.NetWatch.enums.DispatchStatus;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AnalyticsServiceImpTest {

    @Mock
    private AlarmRepo alarmRepo;

    @Mock
    private NetworkElementRepo elementRepo;

    @Mock
    private TroubleTicketRepo ticketRepo;

    @Mock
    private FieldDispatchRepo dispatchRepo;

    @Mock
    private CapacityRecordRepo capacityRepo;

    @InjectMocks
    private AnalyticsServiceImp analyticsService;

    @Test
    public void testGetDashboardStats() {
        when(elementRepo.count()).thenReturn(10L);

        // Alarms mocking
        NetworkAlarm alarm = new NetworkAlarm();
        alarm.setStatus(AlarmStatus.ACTIVE);
        alarm.setSeverity(Severity.CRITICAL);
        when(alarmRepo.findAll()).thenReturn(List.of(alarm));
        when(alarmRepo.count()).thenReturn(1L);

        // Tickets mocking
        TroubleTicket ticket = new TroubleTicket();
        ticket.setPriority(TicketPriority.P1);
        ticket.setRaisedDateTime(LocalDateTime.now().minusHours(3));
        ticket.setRestoredDateTime(LocalDateTime.now().minusHours(1));
        ticket.setRestorationSLATime(LocalDateTime.now().plusHours(1));
        when(ticketRepo.findAll()).thenReturn(List.of(ticket));

        // Capacity mocking
        CapacityRecord capRecord = new CapacityRecord();
        capRecord.setStatus(CapacityStatus.CRITICAL);
        when(capacityRepo.findAll()).thenReturn(List.of(capRecord));

        // Dispatch mocking
        FieldDispatch dispatch = new FieldDispatch();
        dispatch.setStatus(DispatchStatus.RESOLVED);
        when(dispatchRepo.findAll()).thenReturn(List.of(dispatch));

        AnalyticsDashboardDTO dashboard = analyticsService.getDashboardStats();

        assertNotNull(dashboard);
        assertEquals(90.0, dashboard.getNetworkAvailability()); // 10 elements, 1 critical active alarm
        assertEquals(120.0, dashboard.getMttrMinutes()); // 3 hours - 1 hour = 2 hours = 120 mins
        assertEquals(1L, dashboard.getAlarmCount());
        assertEquals(1L, dashboard.getP1TicketCount());
        assertEquals(100.0, dashboard.getSlaComplianceRate());
        assertEquals(1L, dashboard.getCapacityBreachCount());
        assertEquals(100L, dashboard.getFieldDispatchSuccessRate());
    }
}
