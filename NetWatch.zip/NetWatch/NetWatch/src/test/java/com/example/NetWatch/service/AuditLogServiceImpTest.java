package com.example.NetWatch.service;

import com.example.NetWatch.entity.AuditLog;
import com.example.NetWatch.repository.AuditLogRepo;
import com.example.NetWatch.responsedto.AuditLogResponseDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AuditLogServiceImpTest {

    @Mock
    private AuditLogRepo auditLogRepo;

    @InjectMocks
    private AuditLogServiceImp auditLogService;

    private AuditLog logRecord;

    @BeforeEach
    public void setUp() {
        logRecord = new AuditLog();
        logRecord.setAuditId(1L);
        logRecord.setUserId(100L);
        logRecord.setAction("CREATE_CIRCUIT");
        logRecord.setEntityType("Circuit");
        logRecord.setRecordId(10L);
        logRecord.setTimestamp(LocalDateTime.now());
    }

    @Test
    public void testLog() {
        when(auditLogRepo.save(any(AuditLog.class))).thenReturn(logRecord);

        AuditLog saved = auditLogService.log(100L, "CREATE_CIRCUIT", "Circuit", 10L);

        assertNotNull(saved);
        assertEquals(1L, saved.getAuditId());
        assertEquals("CREATE_CIRCUIT", saved.getAction());
        verify(auditLogRepo, times(1)).save(any(AuditLog.class));
    }

    @Test
    public void testGetAllLogs() {
        when(auditLogRepo.findAll()).thenReturn(List.of(logRecord));

        List<AuditLogResponseDTO> list = auditLogService.getAllLogs();

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals(1L, list.get(0).getAuditId());
    }

    @Test
    public void testGetLogsByUser() {
        when(auditLogRepo.findByUserId(100L)).thenReturn(List.of(logRecord));

        List<AuditLogResponseDTO> list = auditLogService.getLogsByUser(100L);

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals(100L, list.get(0).getUserId());
    }

    @Test
    public void testGetLogsByEntity() {
        when(auditLogRepo.findByEntityType("Circuit")).thenReturn(List.of(logRecord));

        List<AuditLogResponseDTO> list = auditLogService.getLogsByEntity("Circuit");

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals("Circuit", list.get(0).getEntityType());
    }
}
