package com.example.NetWatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetwatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
