package com.example.NetWatch.service;

import com.example.NetWatch.entity.Circuit;
import com.example.NetWatch.entity.MaintenanceWindow;
import com.example.NetWatch.entity.ProvisioningRequest;
import com.example.NetWatch.repository.CircuitRepo;
import com.example.NetWatch.repository.ProvisioningRequestRepo;
import com.example.NetWatch.requestdto.CircuitRequestDTO;
import com.example.NetWatch.responsedto.CircuitResponseDTO;
import com.example.NetWatch.requestdto.ProvisioningRequestDTO;
import com.example.NetWatch.responsedto.ProvisioningResponseDTO;
import com.example.NetWatch.enums.ProvisioningStatus;
import com.example.NetWatch.enums.CircuitStatus;
import com.example.NetWatch.enums.ProvisioningRequestType;
import com.example.NetWatch.enums.ServiceType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CircuitServiceImpTest {

    @Mock
    private CircuitRepo circuitRepo;

    @Mock
    private ProvisioningRequestRepo requestRepo;

    @Mock
    private AuditLogService auditService;

    @Mock
    private CapacityService capacityService;

    @InjectMocks
    private CircuitServiceImp circuitService;

    private CircuitRequestDTO circuitRequest;
    private Circuit circuit;
    private ProvisioningRequestDTO provisionDto;
    private ProvisioningRequest provisioningRequest;

    @BeforeEach
    public void setUp() {
        circuitRequest = CircuitRequestDTO.builder()
                .circuitReference("CKT-100")
                .serviceType(ServiceType.MPLS)
                .customerId("CUST-01")
                .bandwidthMbps(100.0)
                .routePath("A-B-C")
                .status(CircuitStatus.ACTIVE)
                .build();

        circuit = new Circuit();
        circuit.setCircuitId(1L);
        circuit.setCircuitReference("CKT-100");
        circuit.setServiceType(ServiceType.MPLS);
        circuit.setCustomerId("CUST-01");
        circuit.setBandwidthMbps(100.0);
        circuit.setRoutePath("A-B-C");
        circuit.setStatus(CircuitStatus.ACTIVE);
        circuit.setActivationDate(LocalDateTime.now());

        provisionDto = ProvisioningRequestDTO.builder()
                .circuitId(1L)
                .bandwidthMbps(50.0)
                .requestType(ProvisioningRequestType.BANDWIDTH_UPGRADE)
                .requestedById(100L)
                .build();

        provisioningRequest = new ProvisioningRequest();
        provisioningRequest.setProvisionId(10L);
        provisioningRequest.setCircuit(circuit);
        provisioningRequest.setBandwidthMbps(50.0);
        provisioningRequest.setRequestType(ProvisioningRequestType.BANDWIDTH_UPGRADE);
        provisioningRequest.setRequestedById(100L);
        provisioningRequest.setStatus(ProvisioningStatus.PENDING);
        provisioningRequest.setRequestDate(LocalDateTime.now());
    }

    @Test
    public void testCreateCircuit() {
        when(circuitRepo.save(any(Circuit.class))).thenReturn(circuit);

        CircuitResponseDTO response = circuitService.createCircuit(circuitRequest, 100L);

        assertNotNull(response);
        assertEquals(1L, response.getCircuitId());
        assertEquals("CKT-100", response.getCircuitReference());
        verify(circuitRepo, times(1)).save(any(Circuit.class));
        verify(auditService, times(1)).log(100L, "CREATE_CIRCUIT", "Circuit", 1L);
    }

    @Test
    public void testUpdateCircuit() {
        when(circuitRepo.findById(1L)).thenReturn(Optional.of(circuit));
        when(circuitRepo.save(any(Circuit.class))).thenReturn(circuit);

        CircuitResponseDTO response = circuitService.updateCircuit(1L, circuitRequest, 100L);

        assertNotNull(response);
        assertEquals(1L, response.getCircuitId());
        verify(circuitRepo, times(1)).save(any(Circuit.class));
        verify(auditService, times(1)).log(100L, "UPDATE_CIRCUIT", "Circuit", 1L);
    }

    @Test
    public void testGetAllCircuits() {
        when(circuitRepo.findAll()).thenReturn(List.of(circuit));

        List<CircuitResponseDTO> list = circuitService.getAllCircuits();

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals(1L, list.get(0).getCircuitId());
    }

    @Test
    public void testGetCircuitById() {
        when(circuitRepo.findById(1L)).thenReturn(Optional.of(circuit));

        CircuitResponseDTO response = circuitService.getCircuitById(1L);

        assertNotNull(response);
        assertEquals(1L, response.getCircuitId());
    }

    @Test
    public void testCreateProvisioningRequest() {
        when(circuitRepo.findById(1L)).thenReturn(Optional.of(circuit));
        when(requestRepo.save(any(ProvisioningRequest.class))).thenReturn(provisioningRequest);

        ProvisioningResponseDTO response = circuitService.createProvisioningRequest(provisionDto, 100L);

        assertNotNull(response);
        assertEquals(10L, response.getProvisionId());
        assertEquals(ProvisioningStatus.PENDING, response.getStatus());
        verify(auditService, times(1)).log(100L, "CREATE_PROVISION_REQUEST", "ProvisioningRequest", 10L);
    }

    @Test
    public void testProcessProvisioningRequest_NoWindowRequired() {
        when(requestRepo.findById(10L)).thenReturn(Optional.of(provisioningRequest));
        when(circuitRepo.findById(1L)).thenReturn(Optional.of(circuit));
        when(capacityService.checkCapacityForProvisioning(any(ProvisioningRequest.class))).thenReturn("OK");
        when(capacityService.requiresMaintenanceWindow(any(ProvisioningRequest.class), eq("OK"))).thenReturn(false);
        when(requestRepo.save(any(ProvisioningRequest.class))).thenAnswer(inv -> inv.getArgument(0));

        ProvisioningResponseDTO response = circuitService.processProvisioningRequest(10L, 100L);

        assertNotNull(response);
        assertEquals(ProvisioningStatus.COMPLETED, response.getStatus());
        assertEquals(150.0, circuit.getBandwidthMbps()); // 100 + 50
        verify(circuitRepo, times(1)).save(circuit);
        verify(auditService, times(1)).log(100L, "PROVISION_COMPLETED", "ProvisioningRequest", 10L);
    }

    @Test
    public void testProcessProvisioningRequest_WindowRequired() {
        when(requestRepo.findById(10L)).thenReturn(Optional.of(provisioningRequest));
        when(capacityService.checkCapacityForProvisioning(any(ProvisioningRequest.class))).thenReturn("CRITICAL: Exceeds threshold");
        when(capacityService.requiresMaintenanceWindow(any(ProvisioningRequest.class), eq("CRITICAL: Exceeds threshold"))).thenReturn(true);

        MaintenanceWindow window = new MaintenanceWindow();
        window.setMaintenanceId(99L);
        when(capacityService.scheduleMaintenanceWindow(any(ProvisioningRequest.class))).thenReturn(window);
        when(requestRepo.save(any(ProvisioningRequest.class))).thenAnswer(inv -> inv.getArgument(0));

        ProvisioningResponseDTO response = circuitService.processProvisioningRequest(10L, 100L);

        assertNotNull(response);
        assertEquals(ProvisioningStatus.IN_PROGRESS, response.getStatus());
        verify(circuitRepo, never()).save(any(Circuit.class));
        verify(auditService, times(1)).log(eq(100L), contains("PROVISION_WINDOW_SCHEDULED"), eq("ProvisioningRequest"), eq(10L));
    }

    @Test
    public void testExecuteAfterMaintenanceWindow() {
        provisioningRequest.setStatus(ProvisioningStatus.IN_PROGRESS);
        when(requestRepo.findById(10L)).thenReturn(Optional.of(provisioningRequest));
        when(circuitRepo.findById(1L)).thenReturn(Optional.of(circuit));
        when(requestRepo.save(any(ProvisioningRequest.class))).thenAnswer(inv -> inv.getArgument(0));

        ProvisioningResponseDTO response = circuitService.executeAfterMaintenanceWindow(10L, 100L);

        assertNotNull(response);
        assertEquals(ProvisioningStatus.COMPLETED, response.getStatus());
        assertEquals(150.0, circuit.getBandwidthMbps());
        verify(circuitRepo, times(1)).save(circuit);
        verify(auditService, times(1)).log(100L, "PROVISION_EXECUTED_POST_MAINTENANCE", "ProvisioningRequest", 10L);
    }

    @Test
    public void testGetAllRequests() {
        when(requestRepo.findAll()).thenReturn(List.of(provisioningRequest));

        List<ProvisioningResponseDTO> list = circuitService.getAllRequests();

        assertNotNull(list);
        assertEquals(1, list.size());
    }

    @Test
    public void testGetRequestById() {
        when(requestRepo.findById(10L)).thenReturn(Optional.of(provisioningRequest));

        ProvisioningResponseDTO response = circuitService.getRequestById(10L);

        assertNotNull(response);
        assertEquals(10L, response.getProvisionId());
    }

    @Test
    public void testGetPendingRequests() {
        when(requestRepo.findByStatus(ProvisioningStatus.PENDING)).thenReturn(List.of(provisioningRequest));

        List<ProvisioningResponseDTO> list = circuitService.getPendingRequests();

        assertNotNull(list);
        assertEquals(1, list.size());
    }

    @Test
    public void testGetInProgressRequests() {
        provisioningRequest.setStatus(ProvisioningStatus.IN_PROGRESS);
        when(requestRepo.findByStatus(ProvisioningStatus.IN_PROGRESS)).thenReturn(List.of(provisioningRequest));

        List<ProvisioningResponseDTO> list = circuitService.getInProgressRequests();

        assertNotNull(list);
        assertEquals(1, list.size());
    }
}
