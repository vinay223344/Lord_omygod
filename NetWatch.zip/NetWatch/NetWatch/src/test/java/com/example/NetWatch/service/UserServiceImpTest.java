package com.example.NetWatch.service;

import com.example.NetWatch.entity.User;
import com.example.NetWatch.enums.UserRole;
import com.example.NetWatch.enums.UserStatus;
import com.example.NetWatch.repository.UserRepo;
import com.example.NetWatch.requestdto.UserRequestDTO;
import com.example.NetWatch.responsedto.UserResponseDTO;
import com.example.NetWatch.security.CustomUserDetails;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceImpTest {

    @Mock
    private UserRepo repo;

    @Mock
    private PasswordEncoder encoder;

    @InjectMocks
    private UserServiceImp userService;

    private UserRequestDTO userRequestDTO;
    private User user;

    @BeforeEach
    public void setUp() {
        userRequestDTO = UserRequestDTO.builder()
                .name("Alice")
                .email("alice@netwatch.com")
                .password("password123")
                .role(UserRole.ADMIN)
                .phone("123456789")
                .shiftGroup("G1")
                .status(UserStatus.ACTIVE)

                .build();

        user = new User();
        user.setUserId(1L);
        user.setName("Alice");
        user.setEmail("alice@netwatch.com");
        user.setPassword("encodedPassword");
        user.setRole(UserRole.ADMIN);
        user.setPhone("123456789");
        user.setShiftGroup("G1");
        user.setStatus(UserStatus.ACTIVE);

    }

    @Test
    public void testRegister() {
        when(encoder.encode(any(String.class))).thenReturn("encodedPassword");
        when(repo.save(any(User.class))).thenReturn(user);

        UserResponseDTO response = userService.register(userRequestDTO);

        assertNotNull(response);
        assertEquals(1L, response.getUserId());
        assertEquals("alice@netwatch.com", response.getEmail());
        assertEquals(UserRole.ADMIN, response.getRole());
        verify(repo, times(1)).save(any(User.class));
    }

    @Test
    public void testFindByEmail() {
        when(repo.findByEmail("alice@netwatch.com")).thenReturn(Optional.of(user));

        Optional<User> found = userService.findByEmail("alice@netwatch.com");

        assertTrue(found.isPresent());
        assertEquals("alice@netwatch.com", found.get().getEmail());
    }

    @Test
    public void testLoadUserByUsername_Success() {
        when(repo.findByEmail("alice@netwatch.com")).thenReturn(Optional.of(user));

        UserDetails userDetails = userService.loadUserByUsername("alice@netwatch.com");

        assertNotNull(userDetails);
        assertEquals("alice@netwatch.com", userDetails.getUsername());
        assertTrue(userDetails instanceof CustomUserDetails);
    }

    @Test
    public void testLoadUserByUsername_NotFound() {
        when(repo.findByEmail("unknown@netwatch.com")).thenReturn(Optional.empty());

        assertThrows(UsernameNotFoundException.class, () -> {
            userService.loadUserByUsername("unknown@netwatch.com");
        });
    }
}
