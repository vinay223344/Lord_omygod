package com.example.NetWatch.service;

import com.example.NetWatch.entity.Circuit;
import com.example.NetWatch.entity.MaintenanceWindow;
import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.ProvisioningRequest;
import com.example.NetWatch.enums.ElementStatus;
import com.example.NetWatch.exception.NetworkTopologyValidationException;
import com.example.NetWatch.repository.CircuitRepo;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.repository.ProvisioningRequestRepo;
import com.example.NetWatch.repository.TopologyRepo;
import com.example.NetWatch.requestdto.CircuitRequestDTO;
import com.example.NetWatch.responsedto.CircuitResponseDTO;
import com.example.NetWatch.requestdto.ProvisioningRequestDTO;
import com.example.NetWatch.responsedto.ProvisioningResponseDTO;
import com.example.NetWatch.enums.ProvisioningStatus;
import com.example.NetWatch.enums.CircuitStatus;
import com.example.NetWatch.exception.ResourceNotFoundException;
import com.example.NetWatch.exception.InvalidStateTransitionException;
import com.example.NetWatch.requestdto.NetworkAlarmRequestDTO;
import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.enums.AlarmStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CircuitServiceImp implements CircuitService {

    @Autowired
    private CircuitRepo circuitRepo;

    @Autowired
    private ProvisioningRequestRepo requestRepo;

    @Autowired
    private NetworkElementRepo networkElementRepo;

    @Autowired
    private TopologyRepo topologyRepo;

    @Autowired
    private AuditLogService auditService;

    @Lazy
    @Autowired
    private CapacityService capacityService;

    @Autowired
    private AlarmService alarmService;

    // ─────────────────────────────────────────────────────────────────────────
    // TOPOLOGY VALIDATION
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Validates the network path before a circuit is created or updated.
     *
     * Checks (in order):
     *   1. Each element ID in routeElementIds exists in the network inventory.
     *   2. Each element's status is ACTIVE.
     *   3. A topology link exists between every consecutive pair of elements
     *      (checked bidirectionally, so undirected links are supported).
     *
     * Validation is skipped when routeElementIds is null or empty.
     *
     * @throws NetworkTopologyValidationException with a descriptive message on failure
     */
    private void validateNetworkTopology(List<Long> routeElementIds) {
        if (routeElementIds == null || routeElementIds.isEmpty()) {
            return; // optional field — skip when not provided
        }

        if (routeElementIds.size() < 2) {
            throw new NetworkTopologyValidationException(
                    "A circuit route must include at least 2 network elements, but "
                            + routeElementIds.size() + " element(s) were provided.");
        }

        // ── Step 1 & 2: Verify each element exists and is ACTIVE ──────────────
        List<NetworkElement> elements = new ArrayList<>();
        for (Long elementId : routeElementIds) {
            NetworkElement element = networkElementRepo.findById(elementId)
                    .orElseThrow(() -> new NetworkTopologyValidationException(
                            "Network element with ID " + elementId
                                    + " was not found in the network inventory."));

            if (element.getStatus() != ElementStatus.ACTIVE) {
                throw new NetworkTopologyValidationException(
                        "Network element '" + element.getElementName()
                                + "' (ID=" + elementId + ") is not ACTIVE."
                                + " Current status: " + element.getStatus()
                                + ". Only ACTIVE devices can be added to a circuit.");
            }
            elements.add(element);
        }

        // ── Step 3: Verify a topology link exists between consecutive pairs ───
        for (int i = 0; i < elements.size() - 1; i++) {
            NetworkElement a = elements.get(i);
            NetworkElement b = elements.get(i + 1);

            // Check both directions (A→B or B→A) to support undirected links
            boolean linkExists = topologyRepo.existsByElementAAndElementB(a, b)
                    || topologyRepo.existsByElementBAndElementA(b, a);

            if (!linkExists) {
                throw new NetworkTopologyValidationException(
                        "No topology link found between '" + a.getElementName()
                                + "' (ID=" + a.getElementId() + ") and '"
                                + b.getElementName() + "' (ID=" + b.getElementId() + ")."
                                + " Configure the link before creating this circuit.");
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CIRCUIT OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public CircuitResponseDTO createCircuit(CircuitRequestDTO circuitRequestDTO, Long creatorId) {
        // Validate: all devices present & ACTIVE, topology links exist between pairs
        validateNetworkTopology(circuitRequestDTO.getRouteElementIds());

        Circuit circuit = mapCircuitToEntity(circuitRequestDTO);
        if (circuit.getStatus() == null) {
            circuit.setStatus(CircuitStatus.ACTIVE);
        }
        if (circuit.getActivationDate() == null) {
            circuit.setActivationDate(LocalDateTime.now());
        }
        Circuit saved = circuitRepo.save(circuit);
        auditService.log(creatorId, "CREATE_CIRCUIT", "Circuit", saved.getCircuitId());
        return mapCircuitToResponse(saved);
    }

    @Override
    @Transactional
    public CircuitResponseDTO updateCircuit(Long id, CircuitRequestDTO circuitRequestDTO, Long updaterId) {
        // Validate: all devices present & ACTIVE, topology links exist between pairs
        validateNetworkTopology(circuitRequestDTO.getRouteElementIds());

        Circuit updatedCircuit = mapCircuitToEntity(circuitRequestDTO);
        Circuit circuit = circuitRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Circuit not found"));
        circuit.setCircuitReference(updatedCircuit.getCircuitReference());
        circuit.setServiceType(updatedCircuit.getServiceType());
        circuit.setCustomerId(updatedCircuit.getCustomerId());
        circuit.setBandwidthMbps(updatedCircuit.getBandwidthMbps());
        circuit.setRoutePath(updatedCircuit.getRoutePath());
        circuit.setStatus(updatedCircuit.getStatus());
        circuit.setRouteElementIds(updatedCircuit.getRouteElementIds());
        Circuit saved = circuitRepo.save(circuit);
        auditService.log(updaterId, "UPDATE_CIRCUIT", "Circuit", saved.getCircuitId());
        return mapCircuitToResponse(saved);
    }

    @Override
    public List<CircuitResponseDTO> getAllCircuits() {
        return circuitRepo.findAll().stream()
                .map(this::mapCircuitToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public CircuitResponseDTO getCircuitById(Long id) {
        Circuit saved = circuitRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Circuit not found"));
        return mapCircuitToResponse(saved);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PROVISIONING REQUEST OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public ProvisioningResponseDTO createProvisioningRequest(ProvisioningRequestDTO requestDto, Long creatorId) {
        ProvisioningRequest request = mapProvisionToEntity(requestDto);
        request.setRequestDate(LocalDateTime.now());
        request.setStatus(ProvisioningStatus.PENDING);
        request.setRequestedById(creatorId);

        if (requestDto.getElementId() != null) {
            NetworkElement element = networkElementRepo.findById(requestDto.getElementId())
                    .orElseThrow(() -> new ResourceNotFoundException("NetworkElement not found with ID: " + requestDto.getElementId()));
            request.setElement(element);

            // Derive Circuit containing the element
            Circuit circuit = circuitRepo.findByRouteElementId(requestDto.getElementId())
                    .orElseThrow(() -> new ResourceNotFoundException("No Circuit found containing NetworkElement with ID: " + requestDto.getElementId()));
            request.setCircuit(circuit);
        } else {
            throw new IllegalArgumentException("elementId is required for provisioning request");
        }

        ProvisioningRequest saved = requestRepo.save(request);
        auditService.log(creatorId, "CREATE_PROVISION_REQUEST", "ProvisioningRequest", saved.getProvisionId());
        return mapProvisionToResponse(saved);
    }

    @Override
    @Transactional
    public ProvisioningResponseDTO processProvisioningRequest(Long requestId, Long processorId) {
        ProvisioningRequest request = requestRepo.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("ProvisioningRequest not found: " + requestId));

        if (request.getStatus() != ProvisioningStatus.PENDING) {
            throw new InvalidStateTransitionException(
                    "Only PENDING requests can be processed. Current status: " + request.getStatus());
        }

        String capacityResult = capacityService.checkCapacityForProvisioning(request);
        System.out.println("capacityResult" + capacityResult);

        boolean needsWindow = capacityService.requiresMaintenanceWindow(request, capacityResult);
        System.out.println("needswindow=" + capacityResult);

        if (needsWindow) {
            MaintenanceWindow window = capacityService.scheduleMaintenanceWindow(request);

            request.setStatus(ProvisioningStatus.IN_PROGRESS);
            request.setMaintenanceWindow(window);
            ProvisioningRequest saved = requestRepo.save(request);

            String auditAction = capacityResult.startsWith("CRITICAL")
                    ? "PROVISION_WINDOW_SCHEDULED [" + capacityResult + "] WINDOW_ID=" + window.getMaintenanceId()
                    : "PROVISION_WINDOW_SCHEDULED_ID=" + window.getMaintenanceId();
            auditService.log(processorId, auditAction, "ProvisioningRequest", saved.getProvisionId());
            return mapProvisionToResponse(saved);
        }

        applyCircuitChange(request);

        request.setStatus(ProvisioningStatus.COMPLETED);
        request.setCompletedDate(LocalDateTime.now());
        ProvisioningRequest saved = requestRepo.save(request);
        auditService.log(processorId, "PROVISION_COMPLETED", "ProvisioningRequest", saved.getProvisionId());
        return mapProvisionToResponse(saved);
    }

    @Override
    @Transactional
    public ProvisioningResponseDTO executeAfterMaintenanceWindow(Long requestId, Long processorId) {
        ProvisioningRequest request = requestRepo.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("ProvisioningRequest not found: " + requestId));

        if (request.getStatus() != ProvisioningStatus.IN_PROGRESS) {
            throw new InvalidStateTransitionException(
                    "Only IN_PROGRESS requests can be executed post-maintenance. Status: " + request.getStatus());
        }

        applyCircuitChange(request);

        // Maintenance is now complete: close the window and return the element to service.
        if (request.getMaintenanceWindow() != null) {
            capacityService.completeMaintenanceWindow(request.getMaintenanceWindow().getMaintenanceId());
        }

        request.setStatus(ProvisioningStatus.COMPLETED);
        request.setCompletedDate(LocalDateTime.now());
        ProvisioningRequest saved = requestRepo.save(request);
        auditService.log(processorId, "PROVISION_EXECUTED_POST_MAINTENANCE",
                "ProvisioningRequest", saved.getProvisionId());
        return mapProvisionToResponse(saved);
    }

    private void applyCircuitChange(ProvisioningRequest request) {
        if (request.getCircuit() == null)
            return;

        Circuit circuit = circuitRepo.findById(request.getCircuit().getCircuitId())
                .orElseThrow(() -> new ResourceNotFoundException("Circuit not found during execution"));

        NetworkElement element = null;
        if (request.getElement() != null && request.getElement().getElementId() != null) {
            element = networkElementRepo.findById(request.getElement().getElementId()).orElse(null);
        }

        switch (request.getRequestType()) {
            case BANDWIDTH_UPGRADE -> {
                if (request.getBandwidthMbps() != null) {
                    double currentBandwidth = circuit.getBandwidthMbps() != null ? circuit.getBandwidthMbps() : 0.0;
                    circuit.setBandwidthMbps(currentBandwidth + request.getBandwidthMbps());
                }
                // Reflect the added load on the element's capacity utilisation.
                if (element != null) {
                    capacityService.applyBandwidthUpgradeToCapacity(element.getElementId(), request.getBandwidthMbps());
                }
            }
            case SUSPENSION -> {
                circuit.setStatus(CircuitStatus.SUSPENDED);
                if (element != null) {
                    element.setStatus(ElementStatus.INACTIVE);
                    networkElementRepo.save(element);
                }
            }
            case TERMINATION -> {
                circuit.setStatus(CircuitStatus.DECOMMISSIONED);
                if (element != null) {
                    element.setStatus(ElementStatus.DECOMMISSIONED);
                    networkElementRepo.save(element);
                }
            }
        }

        circuitRepo.save(circuit);
    }


    @Override
    public List<ProvisioningResponseDTO> getAllRequests() {
        return requestRepo.findAll().stream()
                .map(this::mapProvisionToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public ProvisioningResponseDTO getRequestById(Long id) {
        ProvisioningRequest saved = requestRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ProvisioningRequest not found: " + id));
        return mapProvisionToResponse(saved);
    }

    @Override
    public List<ProvisioningResponseDTO> getPendingRequests() {
        return requestRepo.findByStatus(ProvisioningStatus.PENDING).stream()
                .map(this::mapProvisionToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ProvisioningResponseDTO> getInProgressRequests() {
        return requestRepo.findByStatus(ProvisioningStatus.IN_PROGRESS).stream()
                .map(this::mapProvisionToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ProvisioningResponseDTO> getRequestsByElement(Long elementId) {
        return requestRepo.findByElement_ElementId(elementId).stream()
                .map(this::mapProvisionToResponse)
                .collect(Collectors.toList());
    }

    // MAPPINGS

    private CircuitResponseDTO mapCircuitToResponse(Circuit circuit) {
        if (circuit == null)
            return null;
        return CircuitResponseDTO.builder()
                .circuitId(circuit.getCircuitId())
                .circuitReference(circuit.getCircuitReference())
                .serviceType(circuit.getServiceType())
                .customerId(circuit.getCustomerId())
                .bandwidthMbps(circuit.getBandwidthMbps())
                .routePath(circuit.getRoutePath())
                .activationDate(circuit.getActivationDate())
                .status(circuit.getStatus())
                .routeElementIds(circuit.getRouteElementIds())
                .build();
    }

    private Circuit mapCircuitToEntity(CircuitRequestDTO request) {
        if (request == null)
            return null;
        Circuit circuit = new Circuit();
        circuit.setCircuitReference(request.getCircuitReference());
        circuit.setServiceType(request.getServiceType());
        circuit.setCustomerId(request.getCustomerId());
        circuit.setBandwidthMbps(request.getBandwidthMbps());
        circuit.setRoutePath(request.getRoutePath());
        circuit.setStatus(request.getStatus());
        circuit.setRouteElementIds(request.getRouteElementIds());
        return circuit;
    }


    private ProvisioningResponseDTO mapProvisionToResponse(ProvisioningRequest request) {
        if (request == null)
            return null;

        return ProvisioningResponseDTO.builder()
                .provisionId(request.getProvisionId())
                .elementId(request.getElement() != null ? request.getElement().getElementId() : null)
                .elementName(request.getElement() != null ? request.getElement().getElementName() : null)
                .circuitId(request.getCircuit() != null ? request.getCircuit().getCircuitId() : null)
                .circuitReference(request.getCircuit() != null ? request.getCircuit().getCircuitReference() : null)
                .requestType(request.getRequestType())
                .bandwidthMbps(request.getBandwidthMbps())
                .requestedById(request.getRequestedById())
                .requestDate(request.getRequestDate())
                .completedDate(request.getCompletedDate())
                .status(request.getStatus())
                .maintenanceWindowId(request.getMaintenanceWindow() != null ? request.getMaintenanceWindow().getMaintenanceId() : null)
                .build();
    }


    private ProvisioningRequest mapProvisionToEntity(ProvisioningRequestDTO requestDto) {
        if (requestDto == null)
            return null;
        ProvisioningRequest request = new ProvisioningRequest();
        request.setRequestType(requestDto.getRequestType());
        request.setRequestedById(requestDto.getRequestedById());
        request.setBandwidthMbps(requestDto.getBandwidthMbps());
        if (requestDto.getElementId() != null) {
            NetworkElement element = new NetworkElement();
            element.setElementId(requestDto.getElementId());
            request.setElement(element);
        }
        return request;
    }
}
