package com.example.NetWatch.responsedto;

import com.example.NetWatch.enums.ProvisioningRequestType;
import com.example.NetWatch.enums.ProvisioningStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProvisioningResponseDTO {
    private Long provisionId;
    private Long elementId;
    private String elementName;
    private Long circuitId;
    private String circuitReference;
    private ProvisioningRequestType requestType;
    private Double bandwidthMbps;
    private Long requestedById;
    private LocalDateTime requestDate;
    private LocalDateTime completedDate;
    private ProvisioningStatus status;
    private Long maintenanceWindowId;
}

