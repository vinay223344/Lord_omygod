package com.example.NetWatch.requestdto;

import com.example.NetWatch.enums.ProvisioningRequestType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProvisioningRequestDTO {
    private Long elementId;
    private Double bandwidthMbps;
    private ProvisioningRequestType requestType;
    private Long requestedById;
}
