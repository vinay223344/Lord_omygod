package com.example.NetWatch.service;

import com.example.NetWatch.entity.User;
import com.example.NetWatch.repository.UserRepo;
import com.example.NetWatch.requestdto.UserRequestDTO;
import com.example.NetWatch.responsedto.UserResponseDTO;
import com.example.NetWatch.security.CustomUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserServiceImp implements UserService {

    @Autowired
    private UserRepo repo;

    @Autowired
    private PasswordEncoder encoder;

    @Override
    public UserResponseDTO register(UserRequestDTO userRequestDTO) {
        if (userRequestDTO.getPassword() == null || userRequestDTO.getPassword().isBlank()) {
            throw new IllegalArgumentException("Password is required");
        }
        User user = new User();
        user.setName(userRequestDTO.getName());
        user.setEmail(userRequestDTO.getEmail());
        user.setPassword(encoder.encode(userRequestDTO.getPassword()));
        user.setRole(userRequestDTO.getRole());
        user.setPhone(userRequestDTO.getPhone());
        user.setStatus(userRequestDTO.getStatus());
        user.setRegion(userRequestDTO.getRegion());


        User savedUser = repo.save(user);

        return UserResponseDTO.builder()
                .userId(savedUser.getUserId())
                .name(savedUser.getName())
                .email(savedUser.getEmail())
                .role(savedUser.getRole())
                .phone(savedUser.getPhone())
                .status(savedUser.getStatus())
                .region(savedUser.getRegion())

                .build();
    }

    @Override
    public Optional<User> findByEmail(String email) {
        return repo.findByEmail(email);
    }

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        User user = repo.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        return new CustomUserDetails(user);
    }

    private UserResponseDTO mapToResponse(User user) {
        if (user == null) return null;
        return UserResponseDTO.builder()
                .userId(user.getUserId())
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole())
                .phone(user.getPhone())
                .status(user.getStatus())
                .region(user.getRegion())
                .build();
    }

    @Override
    public java.util.List<UserResponseDTO> getAllUsers() {
        return repo.findAll().stream()
                .map(this::mapToResponse)
                .collect(java.util.stream.Collectors.toList());
    }

    @Override
    public UserResponseDTO getUserById(Long id) {
        User user = repo.findById(id)
                .orElseThrow(() -> new com.example.NetWatch.exception.ResourceNotFoundException("User not found: " + id));
        return mapToResponse(user);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public UserResponseDTO updateUser(Long id, UserRequestDTO request) {
        User user = repo.findById(id)
                .orElseThrow(() -> new com.example.NetWatch.exception.ResourceNotFoundException("User not found: " + id));
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        if (request.getPassword() != null && !request.getPassword().isBlank()) {
            user.setPassword(encoder.encode(request.getPassword()));
        }
        user.setRole(request.getRole());
        user.setPhone(request.getPhone());
        user.setStatus(request.getStatus());
        user.setRegion(request.getRegion());

        User saved = repo.save(user);
        return mapToResponse(saved);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public UserResponseDTO deactivateUser(Long id) {
        User user = repo.findById(id)
                .orElseThrow(() -> new com.example.NetWatch.exception.ResourceNotFoundException("User not found: " + id));
        user.setStatus(com.example.NetWatch.enums.UserStatus.DEACTIVATED);
        User saved = repo.save(user);
        return mapToResponse(saved);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional
    public UserResponseDTO activateUser(Long id) {
        User user = repo.findById(id)
                .orElseThrow(() -> new com.example.NetWatch.exception.ResourceNotFoundException("User not found: " + id));
        user.setStatus(com.example.NetWatch.enums.UserStatus.ACTIVE);
        User saved = repo.save(user);
        return mapToResponse(saved);
    }
}
