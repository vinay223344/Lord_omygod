package com.example.NetWatch.controller;

import com.example.NetWatch.responsedto.AnalyticsDashboardDTO;
import com.example.NetWatch.service.AnalyticsService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/analytics")
@PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('CHANGE_MANAGER')")
public class AnalyticsController {

    @Autowired
    private AnalyticsService analyticsService;

    @GetMapping("/dashboard")
    public ResponseEntity<AnalyticsDashboardDTO> getDashboardStats() {
        log.info("Fetching analytics dashboard stats");
        return ResponseEntity.ok(analyticsService.getDashboardStats());
    }
}
