package com.example.NetWatch.config;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class CustomPasswordEncoder implements PasswordEncoder {

    private final BCryptPasswordEncoder bcryptEncoder = new BCryptPasswordEncoder();

    @Override
    public String encode(CharSequence rawPassword) {
        return bcryptEncoder.encode(rawPassword);
    }

    @Override
    public boolean matches(CharSequence rawPassword, String encodedPassword) {
        if (encodedPassword == null || encodedPassword.isBlank()) {
            return false;
        }
        // BCrypt match (standard path for properly encoded passwords)
        if (bcryptEncoder.matches(rawPassword, encodedPassword)) {
            return true;
        }
        // Fallback: plain-text comparison (legacy / dev data)
        return rawPassword.toString().equals(encodedPassword);
    }
}
