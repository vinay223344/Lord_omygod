package com.example.NetWatch.controller;

import com.example.NetWatch.requestdto.TopologyLinkRequestDTO;
import com.example.NetWatch.responsedto.TopologyLinkResponseDTO;
import com.example.NetWatch.service.TopologyLinkService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/link")
public class TopologyLinkController {

    @Autowired
    private TopologyLinkService service;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER')")
    public ResponseEntity<List<TopologyLinkResponseDTO>> getAllLinks() {
        log.debug("Fetching all topology links");
        List<TopologyLinkResponseDTO> list = service.getAllLinks();
        return ResponseEntity.ok(list);
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN') ")
    public ResponseEntity<TopologyLinkResponseDTO> createLink(@RequestBody TopologyLinkRequestDTO linkRequest) {
        log.info("Creating topology link: type={}", linkRequest.getLinkType());
        TopologyLinkResponseDTO saved = service.createLink(linkRequest);
        log.info("Topology link created: id={}", saved.getLinkId());
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') ")
    public ResponseEntity<TopologyLinkResponseDTO> updateLink(@PathVariable Long id, @RequestBody TopologyLinkRequestDTO linkRequest) {
        log.info("Updating topology link id={}: type={}", id, linkRequest.getLinkType());
        TopologyLinkResponseDTO updated = service.updateLink(id, linkRequest);
        return ResponseEntity.ok(updated);
    }
}
