package com.example.NetWatch.responsedto;

import com.example.NetWatch.enums.UserRole;
import com.example.NetWatch.enums.UserStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserResponseDTO {
    private Long userId;
    private String name;
    private String email;
    private UserRole role;
    private String phone;
    private UserStatus status;
    private String region;

}
