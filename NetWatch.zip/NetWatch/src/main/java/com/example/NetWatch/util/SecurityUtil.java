package com.example.NetWatch.util;

import com.example.NetWatch.security.CustomUserDetails;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

public class SecurityUtil {

    /**
     * Returns the currently authenticated user cast to CustomUserDetails.
     * Throws ClassCastException if the principal is not a CustomUserDetails (should never happen in normal flow).
     */
    public static CustomUserDetails getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated()) {
            return null;
        }
        Object principal = authentication.getPrincipal();
        if (principal instanceof CustomUserDetails) {
            return (CustomUserDetails) principal;
        }
        return null;
    }

    /** Returns the current user's ID, or null if not authenticated. */
    public static Long getCurrentUserId() {
        CustomUserDetails user = getCurrentUser();
        return user != null ? user.getUserId() : null;
    }

    /** Returns true if the currently authenticated user holds the FIELD_ENGINEER role. */
    public static boolean isFieldEngineer() {
        CustomUserDetails user = getCurrentUser();
        if (user == null) return false;
        return user.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_FIELD_ENGINEER"));
    }
}

