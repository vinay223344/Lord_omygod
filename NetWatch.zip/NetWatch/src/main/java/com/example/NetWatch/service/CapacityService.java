package com.example.NetWatch.service;

import com.example.NetWatch.requestdto.CapacityRecordRequestDTO;
import com.example.NetWatch.responsedto.CapacityRecordResponseDTO;
import com.example.NetWatch.requestdto.MaintenanceWindowRequestDTO;
import com.example.NetWatch.responsedto.MaintenanceWindowResponseDTO;
import com.example.NetWatch.entity.MaintenanceWindow;
import com.example.NetWatch.entity.ProvisioningRequest;
import com.example.NetWatch.enums.MaintenanceStatus;
import java.util.List;

public interface CapacityService {
    CapacityRecordResponseDTO addCapacityRecord(CapacityRecordRequestDTO recordRequest, Long creatorId);
    List<CapacityRecordResponseDTO> getAllCapacityRecords();
    List<CapacityRecordResponseDTO> getCapacityBreaches();
    MaintenanceWindowResponseDTO createMaintenanceWindow(MaintenanceWindowRequestDTO windowRequest, Long creatorId);
    MaintenanceWindowResponseDTO approveMaintenanceWindow(Long id, Long approverId);
    MaintenanceWindowResponseDTO updateMaintenanceStatus(Long id, MaintenanceStatus status, Long updaterId);
    List<MaintenanceWindowResponseDTO> getAllMaintenanceWindows();
    List<MaintenanceWindowResponseDTO> getPendingMaintenanceWindows();
    MaintenanceWindowResponseDTO getMaintenanceWindowById(Long id);

    // Cross-service helper methods
    String checkCapacityForProvisioning(ProvisioningRequest request);
    boolean requiresMaintenanceWindow(ProvisioningRequest request, String capacityResult);
    MaintenanceWindow scheduleMaintenanceWindow(ProvisioningRequest request);

    /** Recalculate an element's capacity utilisation after a bandwidth upgrade is applied. */
    void applyBandwidthUpgradeToCapacity(Long elementId, Double upgradeMbps);

    /** Mark a maintenance window COMPLETED and restore its affected elements to ACTIVE. */
    MaintenanceWindowResponseDTO completeMaintenanceWindow(Long id);
}
