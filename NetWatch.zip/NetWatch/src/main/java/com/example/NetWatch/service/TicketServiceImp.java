package com.example.NetWatch.service;

import com.example.NetWatch.entity.FieldDispatch;
import com.example.NetWatch.entity.TroubleTicket;
import com.example.NetWatch.repository.AlarmRepo;
import com.example.NetWatch.repository.FieldDispatchRepo;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.repository.NetworkSiteRepo;
import com.example.NetWatch.repository.TroubleTicketRepo;
import com.example.NetWatch.responsedto.TroubleTicketResponseDTO;
import com.example.NetWatch.responsedto.FieldDispatchResponseDTO;
import com.example.NetWatch.enums.TicketStatus;
import com.example.NetWatch.util.SecurityUtil;
import com.example.NetWatch.enums.DispatchStatus;
import com.example.NetWatch.exception.ResourceNotFoundException;
import com.example.NetWatch.exception.InvalidStateTransitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TicketServiceImp implements TicketService {

    @Autowired
    private TroubleTicketRepo ticketRepo;

    @Autowired
    private FieldDispatchRepo dispatchRepo;

    @Autowired
    private AlarmRepo alarmRepo;

    @Autowired
    private NetworkElementRepo elementRepo;

    @Autowired
    private NetworkSiteRepo siteRepo;

    @Autowired
    private AuditLogService auditService;





    @Override
    @Transactional
    public FieldDispatchResponseDTO createDispatch(Long ticketId, Long fieldEngineerId, Long creatorId) {
        TroubleTicket ticket = ticketRepo.findById(ticketId)
                .orElseThrow(() -> new ResourceNotFoundException("TroubleTicket not found: " + ticketId));

        FieldDispatch dispatch = new FieldDispatch();
        dispatch.setTicket(ticket);
        dispatch.setFieldEngineerId(fieldEngineerId);
        dispatch.setDispatchTime(LocalDateTime.now());
        dispatch.setStatus(DispatchStatus.DISPATCHED);

        FieldDispatch savedDispatch = dispatchRepo.save(dispatch);

        ticket.setStatus(TicketStatus.FIELD_DISPATCHED);
        ticketRepo.save(ticket);

        auditService.log(creatorId, "CREATE_DISPATCH", "FieldDispatch", savedDispatch.getDispatchId());
        return mapDispatchToResponse(savedDispatch);
    }

    @Override
    @Transactional
    public FieldDispatchResponseDTO updateDispatchStatus(Long dispatchId, DispatchStatus status, String resolutionSummary, Long engineerId) {
        FieldDispatch dispatch = dispatchRepo.findById(dispatchId)
                .orElseThrow(() -> new ResourceNotFoundException("FieldDispatch not found: " + dispatchId));

        // ✅ Ownership check: only the assigned field engineer can update this dispatch
        if (!dispatch.getFieldEngineerId().equals(engineerId)) {
            throw new InvalidStateTransitionException(
                "Access denied: Engineer " + engineerId + " is not assigned to dispatch " + dispatchId +
                ". Only the assigned engineer (ID: " + dispatch.getFieldEngineerId() + ") can update this dispatch."
            );
        }

        dispatch.setStatus(status);

        if (status == DispatchStatus.ON_SITE) {
            dispatch.setSiteArrivalTime(LocalDateTime.now());
        } else if (status == DispatchStatus.RESOLVED) {
            dispatch.setRestorationTime(LocalDateTime.now());
            dispatch.setResolutionSummary(resolutionSummary);

            // Automatically resolve the associated trouble ticket
            TroubleTicket ticket = dispatch.getTicket();
            ticket.setStatus(TicketStatus.RESOLVED);
            ticket.setRestoredDateTime(LocalDateTime.now());
            ticketRepo.save(ticket);
        } else if (status == DispatchStatus.CANNOT_REPAIR) {
            dispatch.setResolutionSummary(resolutionSummary);

            // Automatically escalate the associated trouble ticket
            TroubleTicket ticket = dispatch.getTicket();
            ticket.setStatus(TicketStatus.ESCALATED);
            ticketRepo.save(ticket);
        }

        FieldDispatch saved = dispatchRepo.save(dispatch);
        auditService.log(engineerId, "UPDATE_DISPATCH_STATUS", "FieldDispatch", saved.getDispatchId());
        return mapDispatchToResponse(saved);
    }

    @Override
    @Transactional
    public TroubleTicketResponseDTO closeTicket(Long ticketId, Long updaterId) {
        TroubleTicket ticket = ticketRepo.findById(ticketId)
                .orElseThrow(() -> new ResourceNotFoundException("TroubleTicket not found: " + ticketId));
        ticket.setStatus(TicketStatus.CLOSED);
        TroubleTicket saved = ticketRepo.save(ticket);
        auditService.log(updaterId, "CLOSE_TICKET", "TroubleTicket", saved.getTicketId());
        return mapTicketToResponse(saved);
    }

    @Override
    @Transactional
    public TroubleTicketResponseDTO escalateTicket(Long ticketId, Long updaterId) {
        TroubleTicket ticket = ticketRepo.findById(ticketId)
                .orElseThrow(() -> new ResourceNotFoundException("TroubleTicket not found: " + ticketId));
        ticket.setStatus(TicketStatus.ESCALATED);
        TroubleTicket saved = ticketRepo.save(ticket);
        auditService.log(updaterId, "ESCALATE_TICKET", "TroubleTicket", saved.getTicketId());
        return mapTicketToResponse(saved);
    }

    @Override
    public List<TroubleTicketResponseDTO> getAllTickets() {
        return ticketRepo.findAll().stream()
                .map(this::mapTicketToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public TroubleTicketResponseDTO getTicketById(Long ticketId) {
        TroubleTicket saved = ticketRepo.findById(ticketId)
                .orElseThrow(() -> new ResourceNotFoundException("TroubleTicket not found: " + ticketId));
        return mapTicketToResponse(saved);
    }

    @Override
    public List<FieldDispatchResponseDTO> getAllDispatches() {
        return dispatchRepo.findAll().stream()
                .map(this::mapDispatchToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<FieldDispatchResponseDTO> getDispatchesForEngineer(Long fieldEngineerId) {
        return dispatchRepo.findByFieldEngineerId(fieldEngineerId).stream()
                .map(this::mapDispatchToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<TroubleTicketResponseDTO> getTicketsForFieldEngineer(Long engineerId) {
        return dispatchRepo.findByFieldEngineerId(engineerId).stream()
                .map(FieldDispatch::getTicket)
                .filter(ticket -> ticket != null)
                .distinct()
                .map(this::mapTicketToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public FieldDispatchResponseDTO getDispatchById(Long dispatchId) {
        FieldDispatch saved = dispatchRepo.findById(dispatchId)
                .orElseThrow(() -> new ResourceNotFoundException("FieldDispatch not found: " + dispatchId));
        return mapDispatchToResponse(saved);
    }

    // MAPPINGS

    private TroubleTicketResponseDTO mapTicketToResponse(TroubleTicket ticket) {
        if (ticket == null) return null;

        String resolutionSummary = null;
        if (ticket.getTicketId() != null) {
            List<FieldDispatch> dispatches = dispatchRepo.findByTicket_TicketId(ticket.getTicketId());
            if (dispatches != null && !dispatches.isEmpty()) {
                resolutionSummary = dispatches.stream()
                        .map(FieldDispatch::getResolutionSummary)
                        .filter(summary -> summary != null && !summary.isBlank())
                        .findFirst()
                        .orElse(null);
            }
        }

        return TroubleTicketResponseDTO.builder()
                .ticketId(ticket.getTicketId())
                .alarmId(ticket.getAlarm() != null ? ticket.getAlarm().getAlarmId() : null)
                .elementId(ticket.getElement() != null ? ticket.getElement().getElementId() : null)
                .elementName(ticket.getElement() != null ? ticket.getElement().getElementName() : null)
                .siteId(ticket.getSite() != null ? ticket.getSite().getSiteId() : null)
                .siteName(ticket.getSite() != null ? ticket.getSite().getSiteName() : null)
                .category(ticket.getCategory())
                .priority(ticket.getPriority())
                .raisedDateTime(ticket.getRaisedDateTime())
                .restorationSLATime(ticket.getRestorationSLATime())
                .restoredDateTime(ticket.getRestoredDateTime())
                .status(ticket.getStatus())
                .resolutionSummary(resolutionSummary)
                .build();
    }

    private FieldDispatchResponseDTO mapDispatchToResponse(FieldDispatch dispatch) {
        if (dispatch == null) return null;
        FieldDispatchResponseDTO.FieldDispatchResponseDTOBuilder builder = FieldDispatchResponseDTO.builder()
                .dispatchId(dispatch.getDispatchId())
                .ticketId(dispatch.getTicket() != null ? dispatch.getTicket().getTicketId() : null)
                .fieldEngineerId(dispatch.getFieldEngineerId())
                .dispatchTime(dispatch.getDispatchTime())
                .siteArrivalTime(dispatch.getSiteArrivalTime())
                .restorationTime(dispatch.getRestorationTime())
                .resolutionSummary(dispatch.getResolutionSummary())
                .status(dispatch.getStatus());

        Long currentUserId = SecurityUtil.getCurrentUserId();
        boolean isAssignedEngineer = currentUserId != null && currentUserId.equals(dispatch.getFieldEngineerId());
        boolean isStaffOrAdmin = currentUserId == null || !SecurityUtil.isFieldEngineer();

        if (isStaffOrAdmin || isAssignedEngineer) {
            if (dispatch.getTicket() != null) {
                TroubleTicket ticket = dispatch.getTicket();
                builder.category(ticket.getCategory());
                builder.priority(ticket.getPriority());
                if (ticket.getSite() != null) {
                    builder.siteId(ticket.getSite().getSiteId());
                    builder.siteAddress(ticket.getSite().getAddress());
                }
                if (ticket.getElement() != null) {
                    com.example.NetWatch.entity.NetworkElement el = ticket.getElement();
                    builder.elementDetails(el.getElementName() + " (" + el.getIpAddress() + " - " + el.getVendor() + " " + el.getModel() + ")");
                }
            }
        }

        return builder.build();
    }
}
