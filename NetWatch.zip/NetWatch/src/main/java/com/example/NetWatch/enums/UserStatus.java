package com.example.NetWatch.enums;

public enum UserStatus {
    ACTIVE,
    INACTIVE,
    ON_SHIFT,
    DEACTIVATED
}
