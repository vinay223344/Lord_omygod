package com.example.NetWatch.repository;

import com.example.NetWatch.entity.NetworkAlarm;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlarmRepo extends JpaRepository<NetworkAlarm, Long> {
}