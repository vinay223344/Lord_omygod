package com.example.NetWatch.controller;

import com.example.NetWatch.requestdto.CircuitRequestDTO;
import com.example.NetWatch.responsedto.CircuitResponseDTO;
import com.example.NetWatch.requestdto.ProvisioningRequestDTO;
import com.example.NetWatch.responsedto.ProvisioningResponseDTO;
import com.example.NetWatch.service.CircuitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/circuit")
public class CircuitController {

    @Autowired
    private CircuitService circuitService;

    // ─────────────────────────────────────────────────────────────────────────
    // CIRCUIT ENDPOINTS
    // ─────────────────────────────────────────────────────────────────────────

    /** Create a new circuit — Admin or Planning Engineer */
    @PostMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER')")
    public ResponseEntity<CircuitResponseDTO> createCircuit(
            @RequestBody CircuitRequestDTO circuitRequestDTO,
            @RequestParam Long creatorId) {
        log.info("Creating circuit: reference={}, creatorId={}", circuitRequestDTO.getCircuitReference(), creatorId);
        CircuitResponseDTO saved = circuitService.createCircuit(circuitRequestDTO, creatorId);
        log.info("Circuit created: id={}", saved.getCircuitId());
        return ResponseEntity.ok(saved);
    }

    /** Update an existing circuit — Admin or Planning Engineer */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER')")
    public ResponseEntity<CircuitResponseDTO> updateCircuit(
            @PathVariable Long id,
            @RequestBody CircuitRequestDTO circuitRequestDTO,
            @RequestParam Long updaterId) {
        log.info("Updating circuit id={} by updaterId={}", id, updaterId);
        CircuitResponseDTO saved = circuitService.updateCircuit(id, circuitRequestDTO, updaterId);
        return ResponseEntity.ok(saved);
    }

    /** Get all circuits — Admin, NOC, Service Desk, Planning */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('SERVICE_DESK') or hasRole('PLANNING_ENGINEER')")
    public ResponseEntity<List<CircuitResponseDTO>> getAllCircuits() {
        List<CircuitResponseDTO> list = circuitService.getAllCircuits();
        return ResponseEntity.ok(list);
    }

    /** Get a single circuit by ID */
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('SERVICE_DESK') or hasRole('PLANNING_ENGINEER')")
    public ResponseEntity<CircuitResponseDTO> getCircuitById(@PathVariable Long id) {
        CircuitResponseDTO saved = circuitService.getCircuitById(id);
        return ResponseEntity.ok(saved);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PROVISIONING REQUEST ENDPOINTS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Create a new provisioning request (bandwidth upgrade, new activation, etc.)
     * Service Desk or Planning Engineer raises the request.
     */
    @PostMapping("/request")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER') ")
    public ResponseEntity<ProvisioningResponseDTO> createProvisioningRequest(
            @RequestBody ProvisioningRequestDTO requestDto,
            @RequestParam Long creatorId) {
        log.info("Creating provisioning request: type={}, creatorId={}", requestDto.getRequestType(), creatorId);
        ProvisioningResponseDTO saved = circuitService.createProvisioningRequest(requestDto, creatorId);
        log.info("Provisioning request created: id={}", saved.getProvisionId());
        return ResponseEntity.ok(saved);
    }

    /** Get all provisioning requests */
    @GetMapping("/request")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER') or hasRole('NOC_ENGINEER') or hasRole('CHANGE_MANAGER')")
    public ResponseEntity<List<ProvisioningResponseDTO>> getAllRequests() {
        List<ProvisioningResponseDTO> list = circuitService.getAllRequests();
        return ResponseEntity.ok(list);
    }

    /** Get all provisioning requests for a specific NetworkElement */
    @GetMapping("/request/element/{elementId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER') or hasRole('NOC_ENGINEER') or hasRole('CHANGE_MANAGER') or hasRole('SERVICE_DESK')")
    public ResponseEntity<List<ProvisioningResponseDTO>> getRequestsByElement(@PathVariable Long elementId) {
        log.debug("Fetching provisioning requests for elementId={}", elementId);
        List<ProvisioningResponseDTO> list = circuitService.getRequestsByElement(elementId);
        return ResponseEntity.ok(list);
    }


    /** Get a single provisioning request by ID */
    @GetMapping("/request/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER') or hasRole('NOC_ENGINEER') or hasRole('CHANGE_MANAGER') or hasRole('SERVICE_DESK')")
    public ResponseEntity<ProvisioningResponseDTO> getRequestById(@PathVariable Long id) {
        ProvisioningResponseDTO saved = circuitService.getRequestById(id);
        return ResponseEntity.ok(saved);
    }

    /** Get all PENDING provisioning requests */
    @GetMapping("/request/pending")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER') or hasRole('CHANGE_MANAGER')")
    public ResponseEntity<List<ProvisioningResponseDTO>> getPendingRequests() {
        List<ProvisioningResponseDTO> list = circuitService.getPendingRequests();
        return ResponseEntity.ok(list);
    }

    /**
     * Get all IN_PROGRESS requests (awaiting maintenance window approval + execution)
     */
    @GetMapping("/request/in-progress")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER') or hasRole('CHANGE_MANAGER')")
    public ResponseEntity<List<ProvisioningResponseDTO>> getInProgressRequests() {
        List<ProvisioningResponseDTO> list = circuitService.getInProgressRequests();
        return ResponseEntity.ok(list);
    }

    /**
     * ✅ MAIN PROVISIONING FLOW TRIGGER
     *
     * Admin or Planning Engineer calls this to run the 3-step flow:
     *   STEP 1 → Capacity check   (blocks if CRITICAL)
     *   STEP 2 → Maintenance check (schedules window if needed → IN_PROGRESS)
     *   STEP 3 → Execute circuit change (COMPLETED if no window needed)
     *
     * @param id          ProvisioningRequest ID
     * @param processorId User ID of processor
     */
    @PutMapping("/request/{id}/process")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER')")
    public ResponseEntity<ProvisioningResponseDTO> processProvisioningRequest(
            @PathVariable Long id,
            @RequestParam Long processorId) {
        log.info("Processing provisioning request id={} by processorId={}", id, processorId);
        ProvisioningResponseDTO saved = circuitService.processProvisioningRequest(id, processorId);
        log.info("Provisioning request id={} processed: status={}", id, saved.getStatus());
        return ResponseEntity.ok(saved);
    }

    /**
     * ✅ POST-MAINTENANCE EXECUTION
     *
     * Change Manager calls this after the maintenance window is approved and completed,
     * to execute the deferred circuit change for IN_PROGRESS requests.
     */
    @PutMapping("/request/{id}/execute")
    @PreAuthorize("hasRole('ADMIN') or hasRole('CHANGE_MANAGER') or hasRole('PLANNING_ENGINEER')")
    public ResponseEntity<ProvisioningResponseDTO> executeAfterMaintenance(
            @PathVariable Long id,
            @RequestParam Long processorId) {
        log.info("Executing post-maintenance provisioning request id={} by processorId={}", id, processorId);
        ProvisioningResponseDTO saved = circuitService.executeAfterMaintenanceWindow(id, processorId);
        log.info("Post-maintenance execution complete: id={}, status={}", id, saved.getStatus());
        return ResponseEntity.ok(saved);
    }
}
