package com.example.NetWatch.exception;

/**
 * Thrown when circuit creation or update fails because the requested
 * network path is invalid — e.g. a device is missing, not ACTIVE,
 * or no topology link exists between consecutive devices.
 */
public class NetworkTopologyValidationException extends RuntimeException {
    public NetworkTopologyValidationException(String message) {
        super(message);
    }
}
