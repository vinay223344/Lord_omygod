package com.example.NetWatch.config;

import com.example.NetWatch.service.UserServiceImp;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;

@Configuration
public class AuthConfig {

    @Bean
    public AuthenticationProvider authenticationProvider(UserServiceImp userService, CustomPasswordEncoder passwordEncoder) {
        // Spring Security 7 removed the no-arg constructor and setUserDetailsService().
        // UserDetailsService must now be passed directly to the constructor.
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider(userService);
        provider.setPasswordEncoder(passwordEncoder);
        return provider;
    }
}
