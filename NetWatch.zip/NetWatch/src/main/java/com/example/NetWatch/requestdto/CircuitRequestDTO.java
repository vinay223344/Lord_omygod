package com.example.NetWatch.requestdto;

import com.example.NetWatch.enums.ServiceType;
import com.example.NetWatch.enums.CircuitStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CircuitRequestDTO {
    private String circuitReference;
    private ServiceType serviceType;
    private String customerId;
    private Double bandwidthMbps;

    /** Free-text description of the circuit path (e.g. "Router-A → Switch-B → Router-C"). */
    private String routePath;

    private CircuitStatus status;

    /**
     * Ordered list of NetworkElement IDs that the circuit physically traverses.
     * Used to validate:
     *   1. Each device exists in the network inventory.
     *   2. Each device is ACTIVE.
     *   3. A topology link exists between every consecutive pair.
     * Optional — skip validation if null or empty.
     */
    private List<Long> routeElementIds;
}
