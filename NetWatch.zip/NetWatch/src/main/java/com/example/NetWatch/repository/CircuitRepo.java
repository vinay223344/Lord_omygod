package com.example.NetWatch.repository;

import com.example.NetWatch.entity.Circuit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.Optional;

public interface CircuitRepo extends JpaRepository<Circuit, Long> {

    @Query("SELECT c FROM Circuit c JOIN c.routeElementIds r WHERE r = :elementId")
    Optional<Circuit> findByRouteElementId(@Param("elementId") Long elementId);
}

