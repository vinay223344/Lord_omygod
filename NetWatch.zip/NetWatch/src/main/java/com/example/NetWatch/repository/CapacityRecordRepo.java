package com.example.NetWatch.repository;

import com.example.NetWatch.entity.CapacityRecord;
import com.example.NetWatch.enums.CapacityStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CapacityRecordRepo extends JpaRepository<CapacityRecord, Long> {
    List<CapacityRecord> findByStatus(CapacityStatus status);
    List<CapacityRecord> findByElement_ElementId(Long elementId);
}

