package com.example.NetWatch.repository;

import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.TopologyLink;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TopologyRepo extends JpaRepository<TopologyLink, Long> {

    /** True when a link exists with elementA=a and elementB=b */
    boolean existsByElementAAndElementB(NetworkElement a, NetworkElement b);

    /** True when a link exists with elementB=b and elementA=a (reverse direction) */
    boolean existsByElementBAndElementA(NetworkElement b, NetworkElement a);
}

