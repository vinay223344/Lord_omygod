package com.example.NetWatch.controller;

import com.example.NetWatch.requestdto.NetworkSiteRequestDTO;
import com.example.NetWatch.responsedto.NetworkSiteResponseDTO;
import com.example.NetWatch.service.NetworkSiteService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/site")
public class NetworksiteController {

    @Autowired
    private NetworkSiteService service;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('PLANNING_ENGINEER') or hasRole('CHANGE_MANAGER') or hasRole('SERVICE_DESK') or hasRole('FIELD_ENGINEER')")
    public ResponseEntity<List<NetworkSiteResponseDTO>> getAllSites() {
        log.debug("Fetching all network sites");
        List<NetworkSiteResponseDTO> list = service.getAllSites();
        return ResponseEntity.ok(list);
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN') ")
    public ResponseEntity<NetworkSiteResponseDTO> createSite(@RequestBody NetworkSiteRequestDTO siteRequest) {
        log.info("Creating network site: name={}", siteRequest.getSiteName());
        NetworkSiteResponseDTO saved = service.createSite(siteRequest);
        log.info("Network site created: id={}", saved.getSiteId());
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') ")
    public ResponseEntity<NetworkSiteResponseDTO> updateSite(@PathVariable Long id, @RequestBody NetworkSiteRequestDTO siteRequest) {
        log.info("Updating network site id={}: name={}", id, siteRequest.getSiteName());
        NetworkSiteResponseDTO updated = service.updateSite(id, siteRequest);
        return ResponseEntity.ok(updated);
    }
}
