package com.example.NetWatch.entity;

import com.example.NetWatch.enums.UserRole;
import com.example.NetWatch.enums.UserStatus;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Entity
@Data
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email address format")
    @Column(unique = true)
    private String email;

    @NotBlank(message = "Password is required")
    private String password;

    @Enumerated(EnumType.STRING)
    private UserRole role;

    private String phone;

    @Enumerated(EnumType.STRING)
    private UserStatus status;

    // Operational region (city) — only meaningful for FIELD_ENGINEER accounts.
    // Used to scope which tickets/dispatches a field engineer serves.
    private String region;

}