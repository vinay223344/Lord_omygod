package com.example.NetWatch.controller;

import com.example.NetWatch.responsedto.FieldDispatchResponseDTO;
import com.example.NetWatch.responsedto.TroubleTicketResponseDTO;
import com.example.NetWatch.enums.DispatchStatus;
import com.example.NetWatch.service.TicketService;
import com.example.NetWatch.util.SecurityUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/ticket")
public class TicketController {

    @Autowired
    private TicketService ticketService;

    // ─── Ticket Endpoints ────────────────────────────────────────────────────────

    @GetMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('SERVICE_DESK') or hasRole('FIELD_ENGINEER')")
    public ResponseEntity<List<TroubleTicketResponseDTO>> getAllTickets() {
        // FIELD_ENGINEER sees only tickets assigned to them via dispatches
        if (SecurityUtil.isFieldEngineer()) {
            return ResponseEntity.ok(ticketService.getTicketsForFieldEngineer(SecurityUtil.getCurrentUserId()));
        }
        // ADMIN, NOC_ENGINEER, SERVICE_DESK see all tickets
        return ResponseEntity.ok(ticketService.getAllTickets());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('SERVICE_DESK') or hasRole('FIELD_ENGINEER')")
    public ResponseEntity<TroubleTicketResponseDTO> getTicketById(@PathVariable Long id) {
        if (SecurityUtil.isFieldEngineer()) {
            // Field engineers can only view a ticket linked to one of their dispatches
            Long userId = SecurityUtil.getCurrentUserId();
            boolean hasAccess = ticketService.getDispatchesForEngineer(userId)
                    .stream()
                    .anyMatch(d -> d.getTicketId() != null && d.getTicketId().equals(id));
            if (!hasAccess) {
                throw new AccessDeniedException("You can only view tickets assigned to you");
            }
        }
        return ResponseEntity.ok(ticketService.getTicketById(id));
    }

    @PutMapping("/{id}/close")
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('SERVICE_DESK')")
    public ResponseEntity<TroubleTicketResponseDTO> closeTicket(@PathVariable Long id) {
        Long userId = SecurityUtil.getCurrentUserId();
        log.info("Closing ticket id={} by userId={}", id, userId);
        return ResponseEntity.ok(ticketService.closeTicket(id, userId));
    }

    @PutMapping("/{id}/escalate")
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER') or hasRole('SERVICE_DESK')")
    public ResponseEntity<TroubleTicketResponseDTO> escalateTicket(@PathVariable Long id) {
        Long userId = SecurityUtil.getCurrentUserId();
        log.info("Escalating ticket id={} by userId={}", id, userId);
        return ResponseEntity.ok(ticketService.escalateTicket(id, userId));
    }

    // ─── Dispatch Endpoints ──────────────────────────────────────────────────────

    @PostMapping("/dispatch")
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER')")
    public ResponseEntity<FieldDispatchResponseDTO> createDispatch(
            @RequestParam Long ticketId,
            @RequestParam Long fieldEngineerId) {
        Long creatorId = SecurityUtil.getCurrentUserId();
        log.info("Creating dispatch for ticketId={}, fieldEngineerId={} by userId={}", ticketId, fieldEngineerId, creatorId);
        FieldDispatchResponseDTO saved = ticketService.createDispatch(ticketId, fieldEngineerId, creatorId);
        log.info("Dispatch created: id={}", saved.getDispatchId());
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/dispatch")
    @PreAuthorize("hasRole('ADMIN') or hasRole('NOC_ENGINEER')")
    public ResponseEntity<List<FieldDispatchResponseDTO>> getAllDispatches() {
        return ResponseEntity.ok(ticketService.getAllDispatches());
    }

    @GetMapping("/dispatch/engineer/{fieldEngineerId}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('FIELD_ENGINEER')")
    public ResponseEntity<List<FieldDispatchResponseDTO>> getDispatchesForEngineer(@PathVariable Long fieldEngineerId) {
        if (SecurityUtil.isFieldEngineer() && !SecurityUtil.getCurrentUserId().equals(fieldEngineerId)) {
            throw new AccessDeniedException("You can only view your own dispatches");
        }
        return ResponseEntity.ok(ticketService.getDispatchesForEngineer(fieldEngineerId));
    }

    @GetMapping("/dispatch/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('FIELD_ENGINEER') or hasRole('NOC_ENGINEER')")
    public ResponseEntity<FieldDispatchResponseDTO> getDispatchById(@PathVariable Long id) {
        FieldDispatchResponseDTO dispatch = ticketService.getDispatchById(id);
        if (SecurityUtil.isFieldEngineer() && !dispatch.getFieldEngineerId().equals(SecurityUtil.getCurrentUserId())) {
            throw new AccessDeniedException("You can only view your own dispatches");
        }
        return ResponseEntity.ok(dispatch);
    }

    @PutMapping("/dispatch/{id}/status")
    @PreAuthorize("hasRole('ADMIN') or hasRole('FIELD_ENGINEER')")
    public ResponseEntity<FieldDispatchResponseDTO> updateDispatchStatus(
            @PathVariable Long id,
            @RequestParam DispatchStatus status,
            @RequestParam(required = false) String resolutionSummary) {
        Long userId = SecurityUtil.getCurrentUserId();
        if (SecurityUtil.isFieldEngineer()) {
            FieldDispatchResponseDTO dispatch = ticketService.getDispatchById(id);
            if (!dispatch.getFieldEngineerId().equals(userId)) {
                throw new AccessDeniedException("You can only update your own dispatches");
            }
        }
        log.info("Updating dispatch id={} to status={} by userId={}", id, status, userId);
        return ResponseEntity.ok(ticketService.updateDispatchStatus(id, status, resolutionSummary, userId));
    }
}
