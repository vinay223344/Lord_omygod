package com.example.NetWatch.repository;

import com.example.NetWatch.entity.TroubleTicket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TroubleTicketRepo extends JpaRepository<TroubleTicket, Long> {
}
