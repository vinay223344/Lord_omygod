package com.example.NetWatch.entity;

import com.example.NetWatch.enums.ServiceType;
import com.example.NetWatch.enums.CircuitStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "circuit")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Circuit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long circuitId;

    @Column(unique = true, nullable = false)
    private String circuitReference;

    @Enumerated(EnumType.STRING)
    private ServiceType serviceType;

    private String customerId;

    private Double bandwidthMbps;

    @Column(length = 1000)
    private String routePath;

    private LocalDateTime activationDate;

    @Enumerated(EnumType.STRING)
    private CircuitStatus status;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "circuit_route_elements", joinColumns = @JoinColumn(name = "circuit_id"))
    @Column(name = "element_id")
    private List<Long> routeElementIds;
}

