package com.example.NetWatch.responsedto;

import com.example.NetWatch.enums.DispatchStatus;
import com.example.NetWatch.enums.TicketCategory;
import com.example.NetWatch.enums.TicketPriority;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FieldDispatchResponseDTO {
    private Long dispatchId;
    private Long ticketId;
    private Long fieldEngineerId;
    private LocalDateTime dispatchTime;
    private LocalDateTime siteArrivalTime;
    private LocalDateTime restorationTime;
    private String resolutionSummary;
    private DispatchStatus status;
    private Long siteId;
    private String siteAddress;
    private String elementDetails;
    private TicketCategory category;
    private TicketPriority priority;
}
