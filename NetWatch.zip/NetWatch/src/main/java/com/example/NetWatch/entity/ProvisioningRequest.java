package com.example.NetWatch.entity;

import com.example.NetWatch.enums.ProvisioningRequestType;
import com.example.NetWatch.enums.ProvisioningStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "provisioning_request")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProvisioningRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long provisionId;

    @ManyToOne
    @JoinColumn(name = "circuit_id")
    private Circuit circuit;

    @ManyToOne
    @JoinColumn(name = "element_id")
    private NetworkElement element;

    @ManyToOne
    @JoinColumn(name = "maintenance_id")
    private MaintenanceWindow maintenanceWindow;



    @Enumerated(EnumType.STRING)
    private ProvisioningRequestType requestType;

    private Long requestedById;

    private LocalDateTime requestDate;

    private Double bandwidthMbps;

    private LocalDateTime completedDate;

    @Enumerated(EnumType.STRING)
    private ProvisioningStatus status;
}
