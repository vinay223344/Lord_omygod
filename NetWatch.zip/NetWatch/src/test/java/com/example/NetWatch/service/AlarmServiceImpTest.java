package com.example.NetWatch.service;

import com.example.NetWatch.entity.NetworkAlarm;
import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.TroubleTicket;
import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.enums.AlarmStatus;
import com.example.NetWatch.repository.AlarmRepo;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.repository.TroubleTicketRepo;
import com.example.NetWatch.requestdto.NetworkAlarmRequestDTO;
import com.example.NetWatch.responsedto.NetworkAlarmResponseDTO;
import com.example.NetWatch.enums.TicketStatus;
import com.example.NetWatch.enums.TicketCategory;
import org.mockito.ArgumentCaptor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AlarmServiceImpTest {

    @Mock
    private AlarmRepo alarmRepo;

    @Mock
    private TroubleTicketRepo ticketRepo;

    @Mock
    private NetworkElementRepo elementRepo;

    @Mock
    private AuditLogService auditService;

    @Mock
    private com.example.NetWatch.repository.ProvisioningRequestRepo provisioningRequestRepo;

    @Mock
    private com.example.NetWatch.repository.MaintenanceWindowRepo maintenanceWindowRepo;



    @InjectMocks
    private AlarmServiceImp alarmService;

    private NetworkAlarmRequestDTO alarmRequest;
    private NetworkAlarm alarm;
    private NetworkElement element;

    @BeforeEach
    public void setUp() {
        element = new NetworkElement();
        element.setElementId(1L);
        element.setElementName("Router-01");

        alarmRequest = NetworkAlarmRequestDTO.builder()
                .elementId(1L)
                .alarmType(AlarmType.LINK_DOWN)
                .severity(Severity.CRITICAL)
                .status(AlarmStatus.ACTIVE)
                .build();

        alarm = new NetworkAlarm();
        alarm.setAlarmId(10L);
        alarm.setElement(element);
        alarm.setAlarmType(AlarmType.LINK_DOWN);
        alarm.setSeverity(Severity.CRITICAL);
        alarm.setStatus(AlarmStatus.ACTIVE);
    }

    @Test
    public void testCreateAlarm_AutoTicket() {
        when(elementRepo.findById(1L)).thenReturn(Optional.of(element));
        when(alarmRepo.save(any(NetworkAlarm.class))).thenReturn(alarm);

        NetworkAlarmResponseDTO response = alarmService.create(alarmRequest, 100L);

        assertNotNull(response);
        assertEquals(10L, response.getAlarmId());
        assertEquals(AlarmStatus.ACTIVE, response.getStatus());

        verify(alarmRepo, times(1)).save(any(NetworkAlarm.class));
        verify(ticketRepo, times(1)).save(any(TroubleTicket.class));
        verify(auditService, times(1)).log(eq(100L), any(String.class), eq("NetworkAlarm"), eq(10L));
    }

    @Test
    public void testGetAll() {
        when(alarmRepo.findAll()).thenReturn(List.of(alarm));

        List<NetworkAlarmResponseDTO> list = alarmService.getAll();

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals(10L, list.get(0).getAlarmId());
    }

    @Test
    public void testAcknowledge() {
        com.example.NetWatch.entity.MaintenanceWindow window = new com.example.NetWatch.entity.MaintenanceWindow();
        window.setStatus(com.example.NetWatch.enums.MaintenanceStatus.APPROVED);

        com.example.NetWatch.entity.ProvisioningRequest req = new com.example.NetWatch.entity.ProvisioningRequest();
        req.setMaintenanceWindow(window);

        when(alarmRepo.findById(10L)).thenReturn(Optional.of(alarm));
        when(alarmRepo.save(any(NetworkAlarm.class))).thenReturn(alarm);
        when(provisioningRequestRepo.findByElement_ElementIdAndMaintenanceWindowIsNotNull(1L)).thenReturn(List.of(req));

        NetworkAlarmResponseDTO response = alarmService.acknowledge(10L, 100L);

        assertNotNull(response);
        assertEquals(com.example.NetWatch.enums.MaintenanceStatus.IN_PROGRESS, window.getStatus());
        verify(maintenanceWindowRepo, times(1)).save(window);
        verify(auditService, times(1)).log(eq(100L), eq("ACKNOWLEDGE_ALARM"), eq("NetworkAlarm"), eq(10L));
    }

    @Test
    public void testClearAlarm() {
        com.example.NetWatch.entity.MaintenanceWindow window = new com.example.NetWatch.entity.MaintenanceWindow();
        window.setStatus(com.example.NetWatch.enums.MaintenanceStatus.IN_PROGRESS);

        com.example.NetWatch.entity.ProvisioningRequest req = new com.example.NetWatch.entity.ProvisioningRequest();
        req.setMaintenanceWindow(window);

        when(alarmRepo.findById(10L)).thenReturn(Optional.of(alarm));
        when(alarmRepo.save(any(NetworkAlarm.class))).thenReturn(alarm);
        when(provisioningRequestRepo.findByElement_ElementIdAndMaintenanceWindowIsNotNull(1L)).thenReturn(List.of(req));

        NetworkAlarmResponseDTO response = alarmService.clearAlarm(10L, 100L);

        assertNotNull(response);
        assertEquals(com.example.NetWatch.enums.MaintenanceStatus.COMPLETED, window.getStatus());
        verify(maintenanceWindowRepo, times(1)).save(window);
        verify(auditService, times(1)).log(eq(100L), eq("CLEAR_ALARM"), eq("NetworkAlarm"), eq(10L));
    }

    @Test
    public void testCreateAlarm_AutoTicket_HighUtilisation() {
        alarmRequest.setAlarmType(AlarmType.HIGH_UTILISATION);
        alarm.setAlarmType(AlarmType.HIGH_UTILISATION);

        when(elementRepo.findById(1L)).thenReturn(Optional.of(element));
        when(alarmRepo.save(any(NetworkAlarm.class))).thenReturn(alarm);
        when(ticketRepo.save(any(TroubleTicket.class))).thenAnswer(invocation -> invocation.getArgument(0));

        NetworkAlarmResponseDTO response = alarmService.create(alarmRequest, 100L);

        assertNotNull(response);
        assertEquals(10L, response.getAlarmId());
        assertEquals(AlarmStatus.ACTIVE, response.getStatus());

        verify(alarmRepo, times(1)).save(any(NetworkAlarm.class));
        
        ArgumentCaptor<TroubleTicket> ticketCaptor = ArgumentCaptor.forClass(TroubleTicket.class);
        verify(ticketRepo, times(1)).save(ticketCaptor.capture());
        TroubleTicket capturedTicket = ticketCaptor.getValue();
        assertEquals(TicketCategory.CONGESTION, capturedTicket.getCategory());
        assertEquals(TicketStatus.OPEN, capturedTicket.getStatus());
        
        verify(auditService, times(1)).log(eq(100L), any(String.class), eq("NetworkAlarm"), eq(10L));
    }
}
