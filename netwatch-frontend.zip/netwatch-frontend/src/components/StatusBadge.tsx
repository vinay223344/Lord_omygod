import React from 'react';
import styles from './StatusBadge.module.css';

interface StatusBadgeProps {
  status: string | undefined;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status }) => {
  if (!status) return null;

  const normalized = status.toUpperCase().trim();

  // Mapping status string to corresponding CSS module class
  let statusClass = styles.warning; // Default fallback

  switch (normalized) {
    // Critical / Down
    case 'CRITICAL':
    case 'DOWN':
    case 'DEACTIVATED':
    case 'OFFLINE':
    case 'INACTIVE':
    case 'HIGH':
    case 'REJECTED':
    case 'CANCELLED':
    case 'CANNOT_REPAIR':
      statusClass = styles.critical;
      break;

    // Major / Warning
    case 'MAJOR':
    case 'WARNING':
    case 'DEGRADED':
    case 'P1':
    case 'ESCALATED':
      statusClass = styles.major;
      break;

    // Minor / Pending
    case 'MINOR':
    case 'PENDING':
    case 'IN_PROGRESS':
    case 'P2':
      statusClass = styles.minor;
      break;

    // Active / Operations
    case 'ACTIVE':
    case 'ONLINE':
    case 'OPERATIONAL':
    case 'COMPLETED':
    case 'APPROVED':
    case 'UP':
    case 'P3':
    case 'P4':
      statusClass = styles.active;
      break;

    // Cleared / Closed
    case 'CLEARED':
    case 'RESOLVED':
    case 'CLOSED':
    case 'NORMAL':
    case 'UNDER_MAINTENANCE':
    case 'MAINTENANCE':
    case 'SUSPENDED':
    case 'DECOMMISSIONED':
      statusClass = styles.warning; // Styled as gray neutral
      break;

    // Info / Inactive state
    case 'OPEN':
    case 'ASSIGNED':
    case 'FIELD_DISPATCHED':
    case 'DISPATCHED':
    case 'ON_SITE':
      statusClass = styles.info;
      break;
  }

  return <span className={`${styles.badge} ${statusClass}`}>{status}</span>;
};

export default StatusBadge;
