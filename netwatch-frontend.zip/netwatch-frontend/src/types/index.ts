export type UserRole =
  | 'ADMIN'
  | 'NOC_ENGINEER'
  | 'FIELD_ENGINEER'
  | 'PLANNING_ENGINEER'
  | 'SERVICE_DESK'
  | 'CHANGE_MANAGER';

export type UserStatus = 'ACTIVE' | 'DEACTIVATED';

export type AlarmSeverity = 'CRITICAL' | 'MAJOR' | 'MINOR' | 'WARNING';

export type AlarmType =
  | 'LINK_DOWN'
  | 'NODE_UNREACHABLE'
  | 'HIGH_UTILISATION'
  | 'POWER_FAILURE'
  | 'HARDWARE_FAULT'
  | 'COOLING_ALERT';

export type AlarmStatus = 'ACTIVE' | 'ACKNOWLEDGED' | 'CLEARED';

export type TicketCategory =
  | 'HARDWARE_FAULT'
  | 'SOFTWARE_FAULT'
  | 'FIBER_CUT'
  | 'POWER_ISSUE'
  | 'BGP_FLAP'
  | 'OTHER';

export type TicketPriority = 'P1' | 'P2' | 'P3' | 'P4';

export type TicketStatus =
  | 'OPEN'
  | 'ASSIGNED'
  | 'FIELD_DISPATCHED'
  | 'RESOLVED'
  | 'CLOSED'
  | 'ESCALATED';

export type DispatchStatus = 'DISPATCHED' | 'ON_SITE' | 'RESOLVED' | 'CANNOT_REPAIR';

export type ElementType =
  | 'ROUTER'
  | 'SWITCH'
  | 'FIREWALL'
  | 'OLT'
  | 'BTS'
  | 'TRANSMISSION'
  | 'SERVER';

// Canonical list of element types, matching the backend ElementType enum.
// Use this as the single source of truth for element-type dropdowns.
export const ELEMENT_TYPES: ElementType[] = [
  'ROUTER',
  'SWITCH',
  'FIREWALL',
  'OLT',
  'BTS',
  'TRANSMISSION',
  'SERVER',
];

export type ElementStatus = 'ACTIVE' | 'INACTIVE' | 'MAINTENANCE' | 'DECOMMISSIONED';

export type SiteType =
  | 'DATACENTRE'
  | 'EXCHANGE'
  | 'TOWER'
  | 'POP'
  | 'REMOTE_NODE';

export type SiteStatus = 'ACTIVE' | 'INACTIVE';

export type LinkType = 'FIBRE' | 'MICROWAVE' | 'ETHERNET' | 'SDH';

export type LinkStatus = 'ACTIVE' | 'DEGRADED' | 'DOWN';

export type ServiceType =
  | 'LEASED_LINE'
  | 'VPN'
  | 'INTERNET'
  | 'VOICE'
  | 'MPLS';

export type CircuitStatus =
  | 'ACTIVE'
  | 'SUSPENDED'
  | 'DECOMMISSIONED';

export type ProvisioningRequestType =
  | 'BANDWIDTH_UPGRADE'
  | 'SUSPENSION'
  | 'TERMINATION';

export type ProvisioningStatus =
  | 'PENDING'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'REJECTED';

export type MetricType = 'LINK_UTILISATION' | 'CPU_LOAD' | 'MEMORY_USAGE' | 'STORAGE_USAGE';

export type CapacityStatus = 'NORMAL' | 'WARNING' | 'CRITICAL';

export type MaintenanceType = 'SCHEDULED' | 'EMERGENCY' | 'UPGRADE';

export type MaintenanceStatus =
  | 'PENDING'
  | 'APPROVED'
  | 'IN_PROGRESS'
  | 'COMPLETED'
  | 'CANCELLED';

export interface User {
  userId: number;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  status: UserStatus;
  password?: string;
  // Operational region (city) — only set for FIELD_ENGINEER accounts.
  region?: string;
}

export interface AuditLog {
  auditId: number;
  userId: number;
  action: string;
  entityType: string;
  recordId: number;
  timestamp: string;
}

export interface NetworkAlarm {
  alarmId: number;
  elementId: number;
  elementName?: string;
  alarmType: AlarmType;
  severity: AlarmSeverity;
  alarmTime: string;
  acknowledgedById?: number | null;
  acknowledgedTime?: string | null;
  clearedTime?: string | null;
  status: AlarmStatus;
}

export interface TroubleTicket {
  ticketId: number;
  alarmId?: number | null;
  elementId: number;
  elementName?: string;
  siteId: number;
  siteName?: string;
  category: TicketCategory;
  priority: TicketPriority;
  raisedDateTime: string;
  restorationSLATime: string;
  restoredDateTime?: string | null;
  status: TicketStatus;
  resolutionSummary?: string | null;
}

export interface FieldDispatch {
  dispatchId: number;
  ticketId: number;
  fieldEngineerId: number;
  dispatchTime: string;
  siteArrivalTime?: string | null;
  restorationTime?: string | null;
  resolutionSummary?: string | null;
  status: DispatchStatus;
  siteId?: number | null;
  siteAddress?: string | null;
  elementDetails?: string | null;
  category?: TicketCategory | null;
  priority?: TicketPriority | null;
}

export interface NetworkElement {
  elementId: number;
  elementName: string;
  elementType: ElementType;
  vendor: string;
  model: string;
  ipAddress: string;
  status: ElementStatus;
  siteId: number;
  siteName?: string;
}

export interface NetworkSite {
  siteId: number;
  siteName: string;
  siteType: SiteType;
  address: string;
  status: SiteStatus;
}

export interface TopologyLink {
  linkId: number;
  linkType: LinkType;
  capacityMbps: number;
  utilisationPercent: number;
  status: LinkStatus;
  elementAId: number;
  elementAName?: string;
  elementBId: number;
  elementBName?: string;
}

export interface Circuit {
  circuitId: number;
  circuitReference: string;
  serviceType: ServiceType;
  customerId: string;
  bandwidthMbps: number;
  routePath: string;
  activationDate: string;
  status: CircuitStatus;
  routeElementIds?: number[];
}

export interface ProvisioningRequest {
  provisionId: number;
  elementId: number;
  elementName?: string;
  circuitId: number;
  circuitReference?: string;
  requestType: ProvisioningRequestType;
  bandwidthMbps: number;
  requestedById: number;
  requestDate: string;
  completedDate?: string | null;
  status: ProvisioningStatus;
  maintenanceWindowId?: number | null;
}

export interface CapacityRecord {
  capacityId: number;
  elementId: number;
  elementName?: string;
  metricType: MetricType;
  peakValue: number;
  averageValue: number;
  thresholdPercent: number;
  recordedDate: string;
  status: CapacityStatus;
}

export interface MaintenanceWindow {
  maintenanceId: number;
  title: string;
  affectedElementIds: string; // Comma-separated list or JSON array string as returned by backend
  maintenanceType: MaintenanceType;
  startDateTime: string;
  endDateTime: string;
  requestedById: number;
  approvedById?: number | null;
  rollbackPlan: string;
  status: MaintenanceStatus;
}

export interface AnalyticsDashboard {
  networkAvailability: number;
  mttrMinutes: number;
  alarmCount: number;
  p1TicketCount: number;
  slaComplianceRate: number;
  capacityBreachCount: number;
  fieldDispatchSuccessRate: number;
}
