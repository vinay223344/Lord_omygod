import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import { StatCard, StatGrid } from '../../components/StatCard';
import { alarmsApi } from '../../api/alarms';
import { ticketsApi } from '../../api/tickets';
import { analyticsApi } from '../../api/analytics';
import { elementsApi } from '../../api/elements';
import { sitesApi } from '../../api/sites';
import {
  NetworkAlarm,
  TroubleTicket,
  AnalyticsDashboard,
  NetworkElement,
  NetworkSite,
  SiteType,
} from '../../types';
import { formatDate } from '../../utils/date';
import styles from './NocDashboard.module.css';
import { AlertTriangle, ClipboardList, ShieldCheck, AlertOctagon } from 'lucide-react';

// Site Type dropdown — backend SiteType enum names, used directly for filtering.
const SITE_TYPE_OPTIONS: { value: SiteType; label: string }[] = [
  { value: 'DATACENTRE', label: 'DATACENTRE' },
  { value: 'EXCHANGE', label: 'EXCHANGE' },
  { value: 'TOWER', label: 'TOWER' },
  { value: 'POP', label: 'POP' },
  { value: 'REMOTE_NODE', label: 'REMOTE_NODE' },
];

// Region = site name with the trailing facility-type words stripped
// (e.g. "Chennai Data Center" → "Chennai", "Coimbatore POP" → "Coimbatore").
const regionOf = (name: string): string =>
  (name || '')
    .replace(/\b(data\s*cent(?:er|re)|datacentre|datacenter|dc|pop|exchange|tower|remote\s*node|node)\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim() || name;

export const NocDashboard: React.FC = () => {
  const navigate = useNavigate();
  const [stats, setStats] = useState<AnalyticsDashboard | null>(null);
  const [alarms, setAlarms] = useState<NetworkAlarm[]>([]);
  const [tickets, setTickets] = useState<TroubleTicket[]>([]);
  const [elements, setElements] = useState<NetworkElement[]>([]);
  const [sites, setSites] = useState<NetworkSite[]>([]);
  const [loading, setLoading] = useState(true);

  // Scope filters — drive the KPI cards (and their preview tables) below.
  const [scopeRegion, setScopeRegion] = useState<string>('ALL');
  const [scopeSiteType, setScopeSiteType] = useState<string>('ALL');
  const [scopeElementType, setScopeElementType] = useState<string>('ALL');

  useEffect(() => {
    const loadDashboardData = async () => {
      setLoading(true);
      try {
        const [dashboardStats, allAlarms, allTickets, allElements, allSites] = await axios.all<any>([
          analyticsApi.getStats(),
          alarmsApi.getAllAlarms(),
          ticketsApi.getAllTickets(),
          elementsApi.getAll().catch(() => [] as NetworkElement[]),
          sitesApi.getAll().catch(() => [] as NetworkSite[]),
        ]) as [AnalyticsDashboard, NetworkAlarm[], TroubleTicket[], NetworkElement[], NetworkSite[]];

        setStats(dashboardStats);
        // Retain the full arrays so KPIs/charts are accurate; the preview tables
        // below still show only the latest few via a derived slice.
        setAlarms(allAlarms);
        setTickets(allTickets);
        setElements(allElements);
        setSites(allSites);
      } catch (err) {
        console.error('Failed to load dashboard metrics:', err);
      } finally {
        setLoading(false);
      }
    };

    loadDashboardData();
  }, []);

  // siteId → site (for resolving each element's region / site type).
  const siteMap = useMemo(() => {
    const map = new Map<number, NetworkSite>();
    sites.forEach((s) => map.set(s.siteId, s));
    return map;
  }, [sites]);

  // Site Region dropdown options — distinct region names only.
  const regionOptions = useMemo(
    () => Array.from(new Set(sites.map((s) => regionOf(s.siteName)).filter(Boolean))).sort(),
    [sites]
  );

  // Element Type dropdown options — from the element registry.
  const elementTypeOptions = useMemo(
    () => Array.from(new Set(elements.map((el) => el.elementType).filter(Boolean))),
    [elements]
  );

  const scopeActive = scopeRegion !== 'ALL' || scopeSiteType !== 'ALL' || scopeElementType !== 'ALL';

  // ── Shared scoped dataset ─────────────────────────────────────────────────
  // Filters alarms / tickets to the elements matching the selected Site Region /
  // Site Type / Element Type. With no scope selected, everything is returned in
  // full so the cards match the network-wide numbers exactly.
  const scoped = useMemo(() => {
    if (!scopeActive) {
      return { elements, alarms, tickets };
    }

    const matchScope = (el?: NetworkElement) => {
      if (!el) return false;
      if (scopeElementType !== 'ALL' && el.elementType !== scopeElementType) return false;
      if (scopeRegion !== 'ALL' || scopeSiteType !== 'ALL') {
        const site = siteMap.get(el.siteId);
        if (!site) return false;
        if (scopeRegion !== 'ALL' && regionOf(site.siteName) !== scopeRegion) return false;
        if (scopeSiteType !== 'ALL' && site.siteType !== scopeSiteType) return false;
      }
      return true;
    };

    const scopedElements = elements.filter((el) => matchScope(el));
    const ids = new Set(scopedElements.map((el) => el.elementId));

    return {
      elements: scopedElements,
      alarms: alarms.filter((a) => ids.has(a.elementId)),
      tickets: tickets.filter((t) => ids.has(t.elementId)),
    };
  }, [scopeActive, scopeRegion, scopeSiteType, scopeElementType, elements, alarms, tickets, siteMap]);

  // ── Derived data (memoized from the scoped dataset) ────────────────────────
  const activeAlarms = useMemo(
    () => scoped.alarms.filter((a) => a.status !== 'CLEARED'),
    [scoped]
  );

  const activeTickets = useMemo(
    () =>
      scoped.tickets.filter(
        (t) =>
          t.status === 'OPEN' ||
          t.status === 'ASSIGNED' ||
          t.status === 'ESCALATED' ||
          t.status === 'FIELD_DISPATCHED'
      ),
    [scoped]
  );

  const criticalAlarmCount = useMemo(
    () => activeAlarms.filter((a) => a.severity === 'CRITICAL').length,
    [activeAlarms]
  );

  // Network Availability — unscoped uses the backend value; scoped recomputes it
  // the same way the backend does: an element is "down" only if it has an ACTIVE
  // or ACKNOWLEDGED alarm with CRITICAL severity (distinct elements).
  const networkAvailability = useMemo(() => {
    if (!scopeActive) return stats ? stats.networkAvailability : null;
    const total = scoped.elements.length;
    const criticalElementIds = new Set(
      scoped.alarms
        .filter(
          (a) =>
            (a.status === 'ACTIVE' || a.status === 'ACKNOWLEDGED') && a.severity === 'CRITICAL'
        )
        .map((a) => a.elementId)
    );
    const availability = total ? ((total - criticalElementIds.size) / total) * 100 : 100;
    return Math.round(availability * 100) / 100;
  }, [scopeActive, scoped, stats]);

  const alarmPreview = useMemo(() => activeAlarms.slice(0, 5), [activeAlarms]);
  const ticketPreview = useMemo(() => activeTickets.slice(0, 5), [activeTickets]);

  const alarmColumns: Column<NetworkAlarm>[] = [
    { key: 'alarmId', header: 'Alarm ID' },
    { key: 'alarmType', header: 'Type' },
    { key: 'elementName', header: 'Network Element', render: (row) => row.elementName || `ID ${row.elementId}` },
    { key: 'severity', header: 'Severity', render: (row) => <StatusBadge status={row.severity} /> },
    { key: 'alarmTime', header: 'Time Raised', render: (row) => formatDate(row.alarmTime) },
    { key: 'status', header: 'Status', render: (row) => <StatusBadge status={row.status} /> },
  ];

  const ticketColumns: Column<TroubleTicket>[] = [
    { key: 'ticketId', header: 'Ticket ID' },
    { key: 'category', header: 'Category' },
    { key: 'priority', header: 'Priority', render: (row) => <StatusBadge status={row.priority} /> },
    { key: 'raisedDateTime', header: 'Raised At', render: (row) => formatDate(row.raisedDateTime) },
    { key: 'status', header: 'Status', render: (row) => <StatusBadge status={row.status} /> },
  ];

  return (
    <div className="page-container">
      <PageHeader
        title="Network Operations Center Dashboard"
        description="Real-time operations monitor, active alarm volumes, and SLA performance summaries."
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading NOC statistics...</div>
      ) : (
        <div className={styles.dashboard}>
          {/* Scope filter bar — recomputes the KPI cards below */}
          <div className="card">
            <div className={styles['filter-bar']}>
              <div className={styles['filter-group']}>
                <span className={styles['filter-label']}>Scope — Site Region</span>
                <select className={styles.select} value={scopeRegion} onChange={(e) => setScopeRegion(e.target.value)}>
                  <option value="ALL">All Regions</option>
                  {regionOptions.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>
              <div className={styles['filter-group']}>
                <span className={styles['filter-label']}>Scope — Site Type</span>
                <select className={styles.select} value={scopeSiteType} onChange={(e) => setScopeSiteType(e.target.value)}>
                  <option value="ALL">All Site Types</option>
                  {SITE_TYPE_OPTIONS.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className={styles['filter-group']}>
                <span className={styles['filter-label']}>Scope — Element Type</span>
                <select className={styles.select} value={scopeElementType} onChange={(e) => setScopeElementType(e.target.value)}>
                  <option value="ALL">All Element Types</option>
                  {elementTypeOptions.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>
              <span className={styles['filter-hint']}>
                {scopeActive
                  ? 'KPI summary below is scoped to the selected filters.'
                  : 'Select a Site Region, Site Type, or Element Type to scope the KPI summary below.'}
              </span>
            </div>
          </div>

          {/* KPI summary cards — reflect the scope selected above */}
          <StatGrid>
            <StatCard
              label="Active Alarms"
              value={activeAlarms.length}
              icon={<AlertTriangle size={20} />}
              variant="warning"
            />
            <StatCard
              label="Open Tickets"
              value={activeTickets.length}
              icon={<ClipboardList size={20} />}
              variant="info"
            />
            <StatCard
              label="Critical Alarms"
              value={criticalAlarmCount}
              icon={<AlertOctagon size={20} />}
              variant="critical"
            />
            <StatCard
              label="Network Availability"
              value={networkAvailability !== null ? `${networkAvailability}%` : '—'}
              icon={<ShieldCheck size={20} />}
              variant="success"
            />
          </StatGrid>

          <div className={styles['section-grid']}>
            {/* Active Alarms Board */}
            <div className="card">
              <div className={styles['panel-header']}>
                <h3 className={styles['panel-title']}>Critical Active Alarms</h3>
                <button className={styles['link-btn']} onClick={() => navigate('/alarms')}>
                  View Alarm Board →
                </button>
              </div>
              <DataTable
                columns={alarmColumns}
                data={alarmPreview}
                pageSize={5}
                onRowClick={() => navigate('/alarms')}
              />
            </div>

            {/* Active Tickets Queue */}
            <div className="card">
              <div className={styles['panel-header']}>
                <h3 className={styles['panel-title']}>Active Incident Queue</h3>
                <button className={styles['link-btn']} onClick={() => navigate('/tickets')}>
                  View Tickets Queue →
                </button>
              </div>
              <DataTable
                columns={ticketColumns}
                data={ticketPreview}
                pageSize={5}
                onRowClick={(row) => navigate(`/tickets?id=${row.ticketId}`)}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NocDashboard;
