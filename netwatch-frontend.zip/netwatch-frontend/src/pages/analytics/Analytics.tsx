import React, { useState, useEffect, useMemo } from 'react';
import PageHeader from '../../components/PageHeader';
import ChartCard from '../../components/ChartCard';
import { StatCard, StatGrid } from '../../components/StatCard';
import { analyticsApi } from '../../api/analytics';
import { capacityApi } from '../../api/capacity';
import { ticketsApi } from '../../api/tickets';
import { alarmsApi } from '../../api/alarms';
import { elementsApi } from '../../api/elements';
import { sitesApi } from '../../api/sites';
import {
  AnalyticsDashboard,
  CapacityRecord,
  TroubleTicket,
  FieldDispatch,
  NetworkAlarm,
  NetworkElement,
  NetworkSite,
  SiteType,
  ELEMENT_TYPES,
} from '../../types';
import { TOKEN } from '../../theme/statusColors';
import styles from './Analytics.module.css';
import { ShieldCheck, Target, Timer, Truck, Bell, Ticket, Gauge } from 'lucide-react';
import {
  BarChart,
  Bar,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';


const TICKET_STATUS_META: { key: TroubleTicket['status']; label: string; color: string }[] = [
  { key: 'OPEN', label: 'Open', color: '#60A5FA' },
  { key: 'FIELD_DISPATCHED', label: 'Field Dispatched', color: '#2563EB' },
  { key: 'RESOLVED', label: 'Resolved', color: '#1D4ED8' },
  { key: 'CLOSED', label: 'Closed', color: '#1E40AF' },
  { key: 'ESCALATED', label: 'Escalated', color: '#1E3A8A' },
];

// Capacity threshold status → bar color (green / orange / red).
const CAPACITY_STATUS_META: { key: CapacityRecord['status']; label: string; color: string }[] = [
  { key: 'NORMAL', label: 'Normal', color: TOKEN.active },
  { key: 'WARNING', label: 'Warning', color: TOKEN.major },
  { key: 'CRITICAL', label: 'Critical', color: TOKEN.critical },
];

// Site Type dropdown — values are the backend SiteType enum names, used directly
// for filtering against each site's siteType.
const SITE_TYPE_OPTIONS: { value: SiteType; label: string }[] = [
  { value: 'DATACENTRE', label: 'DATACENTRE' },
  { value: 'EXCHANGE', label: 'EXCHANGE' },
  { value: 'TOWER', label: 'TOWER' },
  { value: 'POP', label: 'POP' },
  { value: 'REMOTE_NODE', label: 'REMOTE_NODE' },
];

// Region = site name with the trailing facility-type words stripped
// (e.g. "Chennai Data Center" → "Chennai", "Coimbatore POP" → "Coimbatore").
const regionOf = (name: string): string =>
  (name || '')
    .replace(/\b(data\s*cent(?:er|re)|datacentre|datacenter|dc|pop|exchange|tower|remote\s*node|node)\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim() || name;

export const Analytics: React.FC = () => {
  const [stats, setStats] = useState<AnalyticsDashboard | null>(null);
  const [tickets, setTickets] = useState<TroubleTicket[]>([]);
  const [dispatches, setDispatches] = useState<FieldDispatch[]>([]);
  const [alarms, setAlarms] = useState<NetworkAlarm[]>([]);
  const [capacityRecords, setCapacityRecords] = useState<CapacityRecord[]>([]);
  const [elements, setElements] = useState<NetworkElement[]>([]);
  const [sites, setSites] = useState<NetworkSite[]>([]);
  const [loading, setLoading] = useState(true);

  // Scope filters — drive the KPI summary cards below.
  const [scopeRegion, setScopeRegion] = useState<string>('ALL'); // by siteId (site region)
  const [scopeSiteType, setScopeSiteType] = useState<string>('ALL');
  const [scopeElementType, setScopeElementType] = useState<string>('ALL');

  const loadData = async () => {
    setLoading(true);
    try {
      const dashboardStats = await analyticsApi.getStats();
      setStats(dashboardStats);

      const [ticketList, dispatchList, alarmList, capacityList, elementList, siteList] = await Promise.all([
        ticketsApi.getAllTickets().catch(() => [] as TroubleTicket[]),
        ticketsApi.getAllDispatches().catch(() => [] as FieldDispatch[]),
        alarmsApi.getAllAlarms().catch(() => [] as NetworkAlarm[]),
        capacityApi.getAllRecords().catch(() => [] as CapacityRecord[]),
        elementsApi.getAll().catch(() => [] as NetworkElement[]),
        sitesApi.getAll().catch(() => [] as NetworkSite[]),
      ]);
      setTickets(ticketList);
      setDispatches(dispatchList);
      setAlarms(alarmList);
      setCapacityRecords(capacityList);
      setElements(elementList);
      setSites(siteList);
    } catch (err) {
      console.error('Failed to load analytics dashboard stats:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // siteId → site (for resolving each element's region / site type).
  const siteMap = useMemo(() => {
    const map = new Map<number, NetworkSite>();
    sites.forEach((s) => map.set(s.siteId, s));
    return map;
  }, [sites]);

  // Site Region dropdown options — distinct region names only.
  const regionOptions = useMemo(
    () => Array.from(new Set(sites.map((s) => regionOf(s.siteName)).filter(Boolean))).sort(),
    [sites]
  );

  // Element Type dropdown options — the full canonical list of element types
  // supported by the backend, so every type is selectable regardless of whether
  // an element of that type currently exists in the registry.
  const elementTypeOptions = ELEMENT_TYPES;

  const scopeActive = scopeRegion !== 'ALL' || scopeSiteType !== 'ALL' || scopeElementType !== 'ALL';

  // ── Shared scoped dataset ─────────────────────────────────────────────────
  // Filters the raw elements / alarms / tickets / capacity records to the
  // selected Site Region / Site Type / Element Type. With no scope selected,
  // every dataset is returned in full. Both the KPI cards and the two charts
  // below read from this single source so they stay in sync with the dropdowns.
  const scoped = useMemo(() => {
    if (!scopeActive) {
      return { elements, alarms, tickets, capacityRecords, dispatches };
    }

    const matchScope = (el?: NetworkElement) => {
      if (!el) return false;
      if (scopeElementType !== 'ALL' && el.elementType !== scopeElementType) return false;
      if (scopeRegion !== 'ALL' || scopeSiteType !== 'ALL') {
        const site = siteMap.get(el.siteId);
        if (!site) return false;
        if (scopeRegion !== 'ALL' && regionOf(site.siteName) !== scopeRegion) return false;
        if (scopeSiteType !== 'ALL' && site.siteType !== scopeSiteType) return false;
      }
      return true;
    };

    const scopedElements = elements.filter((el) => matchScope(el));
    const ids = new Set(scopedElements.map((el) => el.elementId));

    const scopedTickets = tickets.filter((t) => ids.has(t.elementId));
    // Dispatches are scoped via their parent ticket, so they follow the same
    // Region / Site Type / Element Type filtering as every other KPI dataset.
    const scopedTicketIds = new Set(scopedTickets.map((t) => t.ticketId));

    return {
      elements: scopedElements,
      alarms: alarms.filter((a) => ids.has(a.elementId)),
      tickets: scopedTickets,
      capacityRecords: capacityRecords.filter((r) => ids.has(r.elementId)),
      dispatches: dispatches.filter((d) => scopedTicketIds.has(d.ticketId)),
    };
  }, [scopeActive, scopeRegion, scopeSiteType, scopeElementType, elements, alarms, tickets, capacityRecords, dispatches, siteMap]);

  // ── Scoped KPI summary ────────────────────────────────────────────────────
  // With no scope selected we show the backend dashboard stats unchanged.
  // When a scope is applied, all operational KPIs are recomputed from the
  // scoped data — including Field Dispatch Success Rate.
  const kpis = useMemo(() => {
    if (!stats) return null;
    if (!scopeActive) return stats;

    const scopedElements = scoped.elements;
    const scopedAlarms = scoped.alarms;
    const scopedTickets = scoped.tickets;
    const scopedCapacity = scoped.capacityRecords;
    const scopedDispatches = scoped.dispatches;

    const total = scopedElements.length;

    // Network Availability — mirror backend: an element is "down" only if it has an
    // ACTIVE or ACKNOWLEDGED alarm with CRITICAL severity (distinct elements).
    const criticalElementIds = new Set(
      scopedAlarms
        .filter(
          (a) =>
            (a.status === 'ACTIVE' || a.status === 'ACKNOWLEDGED') && a.severity === 'CRITICAL'
        )
        .map((a) => a.elementId)
    );
    const availability = total ? ((total - criticalElementIds.size) / total) * 100 : 100;

    // MTTR — backend averages whole-minute durations (Duration.toMinutes()).
    const resolved = scopedTickets.filter((t) => !!t.restoredDateTime);
    const mttrValues = resolved
      .map((t) =>
        Math.floor(
          (new Date(t.restoredDateTime as string).getTime() - new Date(t.raisedDateTime).getTime()) /
            60000
        )
      )
      .filter((m) => isFinite(m) && m >= 0);
    const avgMttr = mttrValues.length
      ? mttrValues.reduce((sum, m) => sum + m, 0) / mttrValues.length
      : 0;
    const compliant = resolved.filter(
      (t) =>
        new Date(t.restoredDateTime as string).getTime() <=
        new Date(t.restorationSLATime).getTime()
    ).length;

    // Field Dispatch Success Rate — mirror the backend definition exactly so the
    // scoped value stays consistent with the unscoped dashboard figure:
    //   RESOLVED dispatches ÷ ALL dispatches in scope.
    // In-progress dispatches (DISPATCHED / ON_SITE) and failed ones
    // (CANNOT_REPAIR) count against the rate, so resolving a dispatch raises it.
    // With no dispatches in scope the rate is 100% (nothing has failed) — the
    // same default the backend and the other rate KPIs use.
    const totalScopedDispatches = scopedDispatches.length;
    const successfulDispatches = scopedDispatches.filter(
      (d) => d.status === 'RESOLVED'
    ).length;

    return {
      networkAvailability: Math.round(availability * 100) / 100,
      mttrMinutes: Math.round(avgMttr * 100) / 100,
      // Backend Alarm Count = alarmRepo.count() — every alarm, regardless of status.
      alarmCount: scopedAlarms.length,
      p1TicketCount: scopedTickets.filter((t) => t.priority === 'P1').length,
      slaComplianceRate: resolved.length
        ? Math.round((compliant / resolved.length) * 100 * 100) / 100
        : 100,
      capacityBreachCount: scopedCapacity.filter(
        (r) => r.status === 'WARNING' || r.status === 'CRITICAL'
      ).length,
      fieldDispatchSuccessRate: totalScopedDispatches
        ? Math.round((successfulDispatches / totalScopedDispatches) * 100)
        : 100,
    };
  }, [stats, scopeActive, scoped]);

  // ── Chart 1: Ticket Status Distribution (scoped) ──────────────────────────
  const ticketStatusData = useMemo(
    () =>
      TICKET_STATUS_META.map((s) => ({
        label: s.label,
        value: scoped.tickets.filter((t) => t.status === s.key).length,
        color: s.color,
      })),
    [scoped]
  );

  // ── Chart 2: Capacity Threshold Warnings Count (scoped) ───────────────────
  const capacityStatusData = useMemo(
    () =>
      CAPACITY_STATUS_META.map((s) => ({
        label: s.label,
        value: scoped.capacityRecords.filter((r) => r.status === s.key).length,
        color: s.color,
      })),
    [scoped]
  );

  return (
    <div className="page-container">
      <PageHeader
        title="Network SLA & Capacity Analytics Console"
        description="Verify service availability, mean-time-to-repair (MTTR), SLA compliance metrics, and hardware breach trends."
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Calculating network analytics...</div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Scope filter bar — recomputes the KPI cards below */}
          <div className="card">
            <div className={styles['filter-bar']}>
              <div className={styles['filter-group']}>
                <span className={styles['filter-label']}>Scope — Site Region</span>
                <select className={styles.select} value={scopeRegion} onChange={(e) => setScopeRegion(e.target.value)}>
                  <option value="ALL">All Regions</option>
                  {regionOptions.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>
              <div className={styles['filter-group']}>
                <span className={styles['filter-label']}>Scope — Site Type</span>
                <select className={styles.select} value={scopeSiteType} onChange={(e) => setScopeSiteType(e.target.value)}>
                  <option value="ALL">All Site Types</option>
                  {SITE_TYPE_OPTIONS.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              </div>
              <div className={styles['filter-group']}>
                <span className={styles['filter-label']}>Scope — Element Type</span>
                <select className={styles.select} value={scopeElementType} onChange={(e) => setScopeElementType(e.target.value)}>
                  <option value="ALL">All Element Types</option>
                  {elementTypeOptions.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>
              <span className={styles['filter-hint']}>
                {scopeActive
                  ? 'KPI summary and charts below are scoped to the selected filters.'
                  : 'Select a Site Region, Site Type, or Element Type to scope the KPI summary and charts below.'}
              </span>
            </div>
          </div>

          {/* KPI summary cards — reflect the scope selected above */}
          <StatGrid>
            <StatCard label="Network Availability" value={kpis ? `${kpis.networkAvailability}%` : '—'} icon={<ShieldCheck size={20} />} variant="success" color="#16A34A" />
            <StatCard label="Mean Time to Resolution" value={kpis ? `${kpis.mttrMinutes} Min` : '—'} icon={<Timer size={20} />} variant="warning" color="#F97316" />
            <StatCard label="Alarm Count" value={kpis ? kpis.alarmCount : '—'} icon={<Bell size={20} />} variant="critical" color="#DC2626" />
            <StatCard label="P1 Ticket Count" value={kpis ? kpis.p1TicketCount : '—'} icon={<Ticket size={20} />} variant="critical" color="#7C3AED" />
            <StatCard label="SLA Compliance Rate" value={kpis ? `${kpis.slaComplianceRate}%` : '—'} icon={<Target size={20} />} variant="info" color="#2563EB" />
            <StatCard label="Capacity Breach Count" value={kpis ? kpis.capacityBreachCount : '—'} icon={<Gauge size={20} />} variant="warning" color="#D97706" />
            <StatCard label="Field Dispatch Success Rate" value={kpis ? `${kpis.fieldDispatchSuccessRate}%` : '—'} icon={<Truck size={20} />} variant="primary" color="#0D9488" />
          </StatGrid>

          {/* The two required charts */}
          <div className={styles['charts-grid']}>
            {/* Ticket Status Distribution */}
            <ChartCard title="Ticket Status Distribution" height={300}>
              {ticketStatusData.some((d) => d.value > 0) ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={ticketStatusData} margin={{ top: 8, right: 12, bottom: 0, left: -12 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e6eaf0" />
                    <XAxis dataKey="label" fontSize={11} stroke="#94a3b8" tickLine={false} interval={0} />
                    <YAxis fontSize={11} stroke="#94a3b8" tickLine={false} axisLine={false} allowDecimals={false} />
                    <Tooltip cursor={{ fill: 'rgba(42, 111, 206, 0.06)' }} />
                    <Bar dataKey="value" name="Tickets" radius={[6, 6, 0, 0]} maxBarSize={72} isAnimationActive={false}>
                      {ticketStatusData.map((entry, i) => (
                        <Cell key={i} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className={styles.empty}>No ticket data available.</div>
              )}
            </ChartCard>

            {/* Capacity Threshold Warnings Count */}
            <ChartCard title="Capacity Threshold Warnings Count" height={300}>
              {capacityStatusData.some((d) => d.value > 0) ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={capacityStatusData} margin={{ top: 8, right: 12, bottom: 0, left: -12 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e6eaf0" />
                    <XAxis dataKey="label" fontSize={11} stroke="#94a3b8" tickLine={false} interval={0} />
                    <YAxis fontSize={11} stroke="#94a3b8" tickLine={false} axisLine={false} allowDecimals={false} />
                    <Tooltip cursor={{ fill: 'rgba(42, 111, 206, 0.06)' }} />
                    <Bar dataKey="value" name="Records" radius={[6, 6, 0, 0]} maxBarSize={72} isAnimationActive={false}>
                      {capacityStatusData.map((entry, i) => (
                        <Cell key={i} fill={entry.color} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className={styles.empty}>No capacity data available.</div>
              )}
            </ChartCard>
          </div>
        </div>
      )}
    </div>
  );
};

export default Analytics;
