import React, { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import axios from 'axios';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import CapacityOverview from './CapacityOverview';
import { useAuth } from '../../auth/AuthContext';
import { capacityApi } from '../../api/capacity';
import { elementsApi } from '../../api/elements';
import { CapacityRecord, NetworkElement, MetricType } from '../../types';
import { formatDate } from '../../utils/date';
import styles from './Capacity.module.css';
import { PlusCircle } from 'lucide-react';

const recordSchema = z
  .object({
    elementId: z.string().min(1, 'Network element is required'),
    metricType: z.enum(['LINK_UTILISATION', 'CPU_LOAD', 'MEMORY_USAGE', 'STORAGE_USAGE']),
    peakValue: z.coerce
      .number()
      .min(0, 'Peak utilisation must be between 0 and 100%')
      .max(100, 'Peak utilisation must be between 0 and 100%'),
    averageValue: z.coerce
      .number()
      .min(0, 'Average utilisation must be between 0 and 100%')
      .max(100, 'Average utilisation must be between 0 and 100%'),
    thresholdPercent: z.coerce.number().min(0, 'Min threshold is 0%').max(100, 'Max threshold is 100%'),
  })
  .refine((d) => d.peakValue >= d.averageValue, {
    message: 'Peak value cannot be lower than the average value',
    path: ['peakValue'],
  });

type RecordFormFields = z.infer<typeof recordSchema>;

export const Capacity: React.FC = () => {
  const { user } = useAuth();
  const [records, setRecords] = useState<CapacityRecord[]>([]);
  const [elements, setElements] = useState<NetworkElement[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Elements that don't yet have a capacity record — only these can be chosen,
  // since each element is allowed a single capacity record.
  const availableElements = useMemo(
    () => elements.filter((el) => !records.some((r) => r.elementId === el.elementId)),
    [elements, records]
  );

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<any>({
    resolver: zodResolver(recordSchema),
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [allRecords, allElements] = await axios.all<any>([
        capacityApi.getAllRecords(),
        elementsApi.getAll().catch(() => [] as NetworkElement[]),
      ]) as [CapacityRecord[], NetworkElement[]];
      setRecords(allRecords);
      setElements(allElements);
    } catch (err) {
      console.error('Failed to load capacity records:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  const handleAddRecord = async (data: RecordFormFields) => {
    if (!user) return;
    setSubmitError(null);
    try {
      const payload: Partial<CapacityRecord> = {
        elementId: Number(data.elementId),
        metricType: data.metricType as MetricType,
        peakValue: data.peakValue,
        averageValue: data.averageValue,
        thresholdPercent: data.thresholdPercent,
      };

      await capacityApi.addRecord(payload, user.userId);
      setIsModalOpen(false);
      reset();
      loadData();
    } catch (err: any) {
      console.error('Failed to add capacity record:', err);
      setSubmitError(err?.response?.data?.message || 'Failed to add capacity record.');
    }
  };

  const columns: Column<CapacityRecord>[] = [
    { key: 'capacityId', header: 'Record ID', sortable: true },
    { key: 'elementName', header: 'Network Element', sortable: true, render: (row) => row.elementName || `ID ${row.elementId}` },
    { key: 'metricType', header: 'Metric Monitored', sortable: true },
    { key: 'averageValue', header: 'Average Value', sortable: true },
    { key: 'peakValue', header: 'Peak Value', sortable: true },
    { key: 'thresholdPercent', header: 'Threshold Limit (%)', sortable: true, render: (row) => `${row.thresholdPercent}%` },
    { key: 'recordedDate', header: 'Recorded At', sortable: true, render: (row) => formatDate(row.recordedDate) },
    { key: 'status', header: 'Breach Status', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
  ];

  // Table row highlight mapping based on status
  const getRowClassName = (row: CapacityRecord) => {
    if (row.status === 'CRITICAL') return styles['row-critical'];
    if (row.status === 'WARNING') return styles['row-warning'];
    return '';
  };

  return (
    <div className="page-container">
      <PageHeader
        title="Capacity Records & Metric Alarms"
        description="Inspect hardware element utilisation rates (CPU, Memory, and Interface traffic peaks)."
        action={
          (user?.role === 'PLANNING_ENGINEER' || user?.role === 'ADMIN' || user?.role === 'CHANGE_MANAGER') && (
            <button className={`${styles.btn} ${styles['btn-primary']}`} onClick={() => { setSubmitError(null); reset(); setIsModalOpen(true); }}>
              <PlusCircle size={14} /> Add Capacity Record
            </button>
          )
        }
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading capacity matrix...</div>
      ) : (
        <>
          {/* Capacity Overview summary cards — derived from records already in state */}
          <CapacityOverview records={records} />

          <div className="card">
            <DataTable
              columns={columns}
              data={records}
              rowClassName={getRowClassName}
              searchPlaceholder="Search capacity logs by element name..."
              searchKey={(row) => row.elementName || `ID ${row.elementId}`}
            />
          </div>
        </>
      )}

      {/* Add Capacity Record Modal */}
      <Modal isOpen={isModalOpen} onClose={() => { setIsModalOpen(false); setSubmitError(null); }} title="Add Capacity Record">
        <form className={styles.form} onSubmit={handleSubmit(handleAddRecord)}>
          {submitError && (
            <div className={styles['error-text']} style={{ marginBottom: '0.5rem' }}>{submitError}</div>
          )}
          <div className={styles['form-group']}>
            <label className={styles.label}>Select Network Element</label>
            <select className={styles.select} {...register('elementId')}>
              <option value="">-- Choose Element --</option>
              {availableElements.map((el) => (
                <option key={el.elementId} value={el.elementId}>
                  {el.elementName} ({el.ipAddress})
                </option>
              ))}
            </select>
            {availableElements.length === 0 && (
              <span className={styles['error-text']}>All network elements already have a capacity record.</span>
            )}
            {errors.elementId && <span className={styles['error-text']}>{errors.elementId.message?.toString()}</span>}
          </div>

          <div className={styles['form-row']}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Metric Category</label>
              <select className={styles.select} {...register('metricType')}>
                <option value="LINK_UTILISATION">LINK_UTILISATION</option>
                <option value="CPU_LOAD">CPU_LOAD</option>
                <option value="MEMORY_USAGE">MEMORY_USAGE</option>
                <option value="STORAGE_USAGE">STORAGE_USAGE</option>
              </select>
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>Critical Threshold (%)</label>
              <input type="number" className={styles.input} placeholder="e.g. 85" {...register('thresholdPercent')} />
              {errors.thresholdPercent && <span className={styles['error-text']}>{errors.thresholdPercent.message?.toString()}</span>}
            </div>
          </div>

          <div className={styles['form-row']}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Average Utilisation (%)</label>
              <input type="number" step="0.1" min="0" max="100" className={styles.input} placeholder="e.g. 52.4" {...register('averageValue')} />
              {errors.averageValue && <span className={styles['error-text']}>{errors.averageValue.message?.toString()}</span>}
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>Peak Utilisation (%)</label>
              <input type="number" step="0.1" min="0" max="100" className={styles.input} placeholder="e.g. 79.8" {...register('peakValue')} />
              {errors.peakValue && <span className={styles['error-text']}>{errors.peakValue.message?.toString()}</span>}
            </div>
          </div>

          <button type="submit" className={`${styles.btn} ${styles['btn-primary']}`} style={{ width: '100%', marginTop: '0.5rem', padding: '0.625rem' }}>
            Submit Metric Entry
          </button>
        </form>
      </Modal>
    </div>
  );
};

export default Capacity;
