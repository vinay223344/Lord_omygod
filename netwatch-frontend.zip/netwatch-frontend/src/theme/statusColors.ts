/**
 * Central status/severity color source for charts and visual indicators.
 *
 * Values mirror the CSS design tokens in index.css (the same colors StatusBadge
 * renders), so charts stay in lockstep with the rest of the UI. Recharts needs
 * concrete hex values, which CSS variables/classes can't provide — hence this
 * single shared module rather than per-page color literals.
 */

export const TOKEN = {
  primary: '#2a6fce',
  accent: '#2f9e6f',
  critical: '#a01717',
  major: '#b8480c',
  minor: '#a16207',
  neutral: '#475569',
  active: '#15803d',
  info: '#0369a1',
  muted: '#64748b',
  subtle: '#94a3b8',
} as const;

/**
 * General status → color, mirroring StatusBadge's grouping logic so a status
 * chart and its badges always agree.
 */
export const statusColor = (status?: string): string => {
  const s = (status || '').toUpperCase().trim();
  switch (s) {
    case 'CRITICAL':
    case 'DOWN':
    case 'DEACTIVATED':
    case 'OFFLINE':
    case 'INACTIVE':
    case 'HIGH':
    case 'REJECTED':
    case 'CANCELLED':
    case 'CANNOT_REPAIR':
      return TOKEN.critical;
    case 'MAJOR':
    case 'DEGRADED':
    case 'P1':
    case 'ESCALATED':
      return TOKEN.major;
    case 'WARNING':
      return TOKEN.neutral; // kept distinct from MAJOR for chart legibility
    case 'MINOR':
    case 'PENDING':
    case 'IN_PROGRESS':
    case 'P2':
      return TOKEN.minor;
    case 'ACTIVE':
    case 'ONLINE':
    case 'OPERATIONAL':
    case 'COMPLETED':
    case 'APPROVED':
    case 'UP':
    case 'P3':
    case 'P4':
      return TOKEN.active;
    case 'CLEARED':
    case 'RESOLVED':
    case 'CLOSED':
    case 'NORMAL':
    case 'UNDER_MAINTENANCE':
    case 'MAINTENANCE':
    case 'SUSPENDED':
    case 'DECOMMISSIONED':
      return TOKEN.neutral;
    case 'OPEN':
    case 'ASSIGNED':
    case 'FIELD_DISPATCHED':
    case 'DISPATCHED':
    case 'ON_SITE':
      return TOKEN.info;
    default:
      return TOKEN.muted;
  }
};
