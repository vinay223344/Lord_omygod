import apiClient from './apiClient';
import { Circuit, ProvisioningRequest } from '../types';

export const circuitsApi = {
  // ─── Circuit Endpoints ─────────────────────────────────────────────────────

  getAllCircuits: async () => {
    const response = await apiClient.get<Circuit[]>('/circuit');
    return response.data;
  },

  createCircuit: async (circuit: Partial<Circuit>, creatorId: number) => {
    const response = await apiClient.post<Circuit>('/circuit', circuit, {
      params: { creatorId },
    });
    return response.data;
  },

  updateCircuit: async (id: number, circuit: Partial<Circuit>, updaterId: number) => {
    const response = await apiClient.put<Circuit>(`/circuit/${id}`, circuit, {
      params: { updaterId },
    });
    return response.data;
  },

  // ─── Provisioning Endpoints ────────────────────────────────────────────────

  getAllRequests: async () => {
    const response = await apiClient.get<ProvisioningRequest[]>('/circuit/request');
    return response.data;
  },

  createProvisioningRequest: async (request: Partial<ProvisioningRequest>, creatorId: number) => {
    const response = await apiClient.post<ProvisioningRequest>('/circuit/request', request, {
      params: { creatorId },
    });
    return response.data;
  },

  processRequest: async (id: number, processorId: number) => {
    const response = await apiClient.put<ProvisioningRequest>(`/circuit/request/${id}/process`, null, {
      params: { processorId },
    });
    return response.data;
  },

  executeAfterMaintenance: async (id: number, processorId: number) => {
    const response = await apiClient.put<ProvisioningRequest>(`/circuit/request/${id}/execute`, null, {
      params: { processorId },
    });
    return response.data;
  },
};
