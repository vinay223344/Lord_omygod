import apiClient from './apiClient';
import { TopologyLink } from '../types';

export const topologyApi = {
  getAll: async () => {
    const response = await apiClient.get<TopologyLink[]>('/link');
    return response.data;
  },

  create: async (link: Partial<TopologyLink>) => {
    const response = await apiClient.post<TopologyLink>('/link', link);
    return response.data;
  },

  update: async (id: number, link: Partial<TopologyLink>) => {
    const response = await apiClient.put<TopologyLink>(`/link/${id}`, link);
    return response.data;
  },
};
