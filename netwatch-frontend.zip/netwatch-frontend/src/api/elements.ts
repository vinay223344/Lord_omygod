import apiClient from './apiClient';
import { NetworkElement } from '../types';

export const elementsApi = {
  getAll: async () => {
    const response = await apiClient.get<NetworkElement[]>('/element');
    return response.data;
  },

  create: async (element: Partial<NetworkElement>) => {
    const response = await apiClient.post<NetworkElement>('/element', element);
    return response.data;
  },

  update: async (id: number, element: Partial<NetworkElement>) => {
    const response = await apiClient.put<NetworkElement>(`/element/${id}`, element);
    return response.data;
  },
};
