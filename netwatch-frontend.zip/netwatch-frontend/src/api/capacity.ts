import apiClient from './apiClient';
import { CapacityRecord, MaintenanceWindow, MaintenanceStatus } from '../types';

export const capacityApi = {
  // ─── Capacity Record Endpoints ─────────────────────────────────────────────

  getAllRecords: async () => {
    const response = await apiClient.get<CapacityRecord[]>('/capacity/record');
    return response.data;
  },

  addRecord: async (record: Partial<CapacityRecord>, creatorId: number) => {
    const response = await apiClient.post<CapacityRecord>('/capacity/record', record, {
      params: { creatorId },
    });
    return response.data;
  },

  // ─── Maintenance Window Endpoints ──────────────────────────────────────────
  
  getAllWindows: async () => {
    const response = await apiClient.get<MaintenanceWindow[]>('/capacity/maintenance');
    return response.data;
  },

  getPendingWindows: async () => {
    const response = await apiClient.get<MaintenanceWindow[]>('/capacity/maintenance/pending');
    return response.data;
  },

  createWindow: async (window: Partial<MaintenanceWindow>, creatorId: number) => {
    const response = await apiClient.post<MaintenanceWindow>('/capacity/maintenance', window, {
      params: { creatorId },
    });
    return response.data;
  },

  approveWindow: async (id: number, approverId: number) => {
    const response = await apiClient.put<MaintenanceWindow>(`/capacity/maintenance/${id}/approve`, null, {
      params: { approverId },
    });
    return response.data;
  },

  updateWindowStatus: async (id: number, status: MaintenanceStatus, updaterId: number) => {
    const response = await apiClient.put<MaintenanceWindow>(`/capacity/maintenance/${id}/status`, null, {
      params: {
        status,
        updaterId,
      },
    });
    return response.data;
  },
};
