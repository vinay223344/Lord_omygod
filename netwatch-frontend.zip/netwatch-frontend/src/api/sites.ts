import apiClient from './apiClient';
import { NetworkSite } from '../types';

export const sitesApi = {
  getAll: async () => {
    const response = await apiClient.get<NetworkSite[]>('/site');
    return response.data;
  },

  create: async (site: Partial<NetworkSite>) => {
    const response = await apiClient.post<NetworkSite>('/site', site);
    return response.data;
  },

  update: async (id: number, site: Partial<NetworkSite>) => {
    const response = await apiClient.put<NetworkSite>(`/site/${id}`, site);
    return response.data;
  },
};
