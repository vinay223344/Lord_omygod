package com.cognizant.gateway.filter;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.cognizant.gateway.config.RouteValidator;
import com.cognizant.gateway.util.JwtUtil;

@Component
public class AuthenticationFilter
        extends AbstractGatewayFilterFactory<AuthenticationFilter.Config> {

    @Autowired
    private RouteValidator validator;

    @Autowired
    private JwtUtil jwtUtil;

    public AuthenticationFilter() {

        super(Config.class);
    }

    @Override
    public GatewayFilter apply(Config config) {

        return ((exchange, chain) -> {

            if (validator.isSecured.test(
                    exchange.getRequest())) {

                // Check header
                if (!exchange.getRequest()
                        .getHeaders()
                        .containsKey("Authorization")) {

                    exchange.getResponse()
                            .setStatusCode(
                                    HttpStatus.UNAUTHORIZED
                            );

                    return exchange.getResponse()
                            .setComplete();
                }

                String authHeader =
                        exchange.getRequest()
                                .getHeaders()
                                .getFirst("Authorization");

                if (authHeader != null
                        && authHeader.startsWith("Bearer ")) {

                    authHeader =
                            authHeader.substring(7);
                }

                try {

                    jwtUtil.validateToken(authHeader);

                } catch (Exception e) {

                    exchange.getResponse()
                            .setStatusCode(
                                    HttpStatus.UNAUTHORIZED
                            );

                    return exchange.getResponse()
                            .setComplete();
                }
            }

            return chain.filter(exchange);
        });
    }

    public static class Config {

    }
}