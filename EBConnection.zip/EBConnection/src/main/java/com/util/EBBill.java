package com.util;

import com.model.EBConnection;

public class EBBill {
	
	
	public static double calculateBillAmount(int units)
	{
		
		double amount=0.0;
		if(units > 0){
			if (units < 100)
    	  	{
    	  		amount = units * 2.60;
    	  	}
    	  	else if(units >= 100 && units < 900)
    	  	{
    	  		amount = units * 3.25;
    	  	}
    	  	else if(units >= 900)
    	  	{
    		   	amount = units * 5.26; 
    	  	}
    	  	else {
    	  	    amount = 0.0;
    	  	}
	  	   
	  	  }
	
		 return amount;
		}
	
	public static boolean validateConnectionType(String connectionType)
	{
		if(connectionType.equals("Domestic")||connectionType.equals("Industrial"))
		return true;
		else
		{
			return false;
		}
	}

}
