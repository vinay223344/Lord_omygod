package com.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.model.EBConnection;
import com.util.EBBill;

public class EBBillTest {
	
		//Write the code for testing assertion using JUNIT
		
	
		// Include appropriate annotation
		public static void setUp() throws Exception 
		{
			//Create few objects for EBConnection class
	
		}
    	

	//Add required annotation
	//Test the calculateBillAmount method in EBBill class to check bill for the units is valid - Use assertTrue
	
	public void test1_calculateBillAmountForUnitLessThan100()
	{	 	  	  	 		     	   	      	 	
		 // Fill the code here
			
	}
	
	//Add required annotation
	//Test the calculateBillAmount method in EBBill class to check bill for the units is valid - Use assertTrue
	
	public void test2_calculateBillAmountForUnitEqualTo100()
	{
		// Fill the code here
			
	}
	
    //Add required annotation
	//Test the calculateBillAmount method in EBBill class to check bill for the units is valid - Use assertTrue
	
	public void test3_calculateBillAmountForUnitGreaterThan100()
	{
		 // Fill the code here
		 
			
	}	 	  	  	 		     	   	      	 	
	
    //Add required annotation
	//Test the calculateBillAmount method in EBBill class to check bill for the units is valid - Use assertTrue
	
	public void test4_calculateBillAmountForUnitLessThan900()
	{
		 // Fill the code here
		
	}
	
	//Add required annotation
	//Test the calculateBillAmount method in EBBill class to check bill for the units is valid - Use assertTrue
	
	public void test5_calculateBillAmountForUnitEqualTo900()
	{
		// Fill the code here
		
	}
	
    //Add required annotation
	//Test the calculateBillAmount method in EBBill class to check bill for the units is valid - Use assertTrue
	
	public void test6_calculateBillAmountForUnitGreaterThan900()
	{	 	  	  	 		     	   	      	 	
		 // Fill the code here
		
			
	}
	
    //Add required annotation
	//Test the validateConnectionType method in EBBill class when the connectionType is valid  - Use assertTrue
	
	public void test7_validateConnectionType_Industrial()
	{
		 // Fill the code here
		
			
	}
	
	//Add required annotation
	//Test the validateConnectionType method in EBBill class when the connectionType is valid - Use assertTrue
	
	public void test8_validateConnectionType_Domestic()
	{
		 // Fill the code here
		 
	}
	
    //Add required annotation
	//Test the validateConnectionType method in EBBill class when the connectionType is invalid - Use assertFalse
	
	public void test9_validateConnectionType_Invalid()
	{	 	  	  	 		     	   	      	 	
		// Fill the code here
			
	}
    
    //Add required annotation
	//Test the calculateBillAmount method in EBBill class to check bill for Invalid units - Use assertTrue

	public void test10_calculateBillAmountForAnInvalidUnits()
	{	 	  	  	 		     	   	      	 	
		// Fill the code here
	}
	

}