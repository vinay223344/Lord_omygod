/**
 * 
 */
/**
 * 
 */
module SOLIDPRINCIPLES {
}