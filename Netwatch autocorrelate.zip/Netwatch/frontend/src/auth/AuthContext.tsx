import React, { createContext, useContext, useReducer, useCallback } from 'react';
import { User } from '../types';
import { authApi } from '../api/auth';
import { usersApi } from '../api/users';

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (email: string, password?: string) => Promise<void>;
  logout: () => void;
  loading: boolean;
}

interface AuthState {
  user: User | null;
  token: string | null;
  loading: boolean;
}

type AuthAction =
  | { type: 'LOGIN'; token: string; user: User }
  | { type: 'LOGOUT' };

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Legacy keys written by older builds of the app. The current code only uses
// the `netwatch_`-prefixed keys, so these are removed on startup/logout to stop
// a stale duplicate token lingering in localStorage.
function clearLegacyAuthKeys() {
  localStorage.removeItem('token');
  localStorage.removeItem('currentUser');
}

// Load persisted auth state from localStorage on startup.
function loadInitialState(): AuthState {
  try {
    clearLegacyAuthKeys();
    const token = localStorage.getItem('netwatch_token');
    const user = JSON.parse(localStorage.getItem('netwatch_user') || 'null');
    return { token, user, loading: false };
  } catch {
    return { token: null, user: null, loading: false };
  }
}

function authReducer(state: AuthState, action: AuthAction): AuthState {
  switch (action.type) {
    case 'LOGIN':
      return { token: action.token, user: action.user, loading: false };
    case 'LOGOUT':
      return { token: null, user: null, loading: false };
    default:
      return state;
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, undefined, loadInitialState);

  const login = useCallback(async (email: string, password?: string) => {
    // Clear any stale token so it is never attached to the login request.
    localStorage.removeItem('netwatch_token');

    const response = await authApi.login({ email, password });

    if (!response.success || !response.token) {
      throw new Error(response.message || 'Login failed');
    }

    // Store the token FIRST so the follow-up /user request is authenticated
    // (that endpoint returns 403 without a valid token).
    localStorage.setItem('netwatch_token', response.token);

    // Resolve the full user record for this email.
    const allUsers = await usersApi.getAll();
    const user = allUsers.find((u) => u.email.toLowerCase() === email.toLowerCase());

    if (!user) {
      throw new Error('Login failed: user record not found');
    }

    localStorage.setItem('netwatch_user', JSON.stringify(user));
    dispatch({ type: 'LOGIN', token: response.token, user });
  }, []);

  const logout = useCallback(() => {
    localStorage.removeItem('netwatch_token');
    localStorage.removeItem('netwatch_user');
    clearLegacyAuthKeys();
    dispatch({ type: 'LOGOUT' });
    window.location.href = '/login';
  }, []);

  return (
    <AuthContext.Provider
      value={{ user: state.user, token: state.token, login, logout, loading: state.loading }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
