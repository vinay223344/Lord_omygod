import { UserRole } from '../types';

export const ROLE_HOMES: Record<UserRole, string> = {
  ADMIN: '/analytics',
  NOC_ENGINEER: '/noc-dashboard',
  FIELD_ENGINEER: '/field-dispatches',
  PLANNING_ENGINEER: '/topology',
  SERVICE_DESK: '/alarms',
  CHANGE_MANAGER: '/maintenance',
};

export const ROLE_PERMISSIONS: Record<UserRole, string[]> = {
  ADMIN: [
    '/admin/users',
    '/admin/audit-log',
    '/network-elements',
    '/sites',
    '/topology',
    '/alarms',
    '/tickets',
    '/circuits',
    '/provisioning',
    '/capacity',
    '/maintenance',
    '/analytics',
  ],
  NOC_ENGINEER: [
    '/noc-dashboard',
    '/alarms',
    '/tickets',
  ],
  FIELD_ENGINEER: [
    '/field-dispatches',
  ],
  PLANNING_ENGINEER: [
    '/topology',
    '/circuits',
    '/provisioning',
    '/maintenance',
  ],
  SERVICE_DESK: [
    '/tickets',
    '/alarms',
    '/alarm-correlation',
  ],
  CHANGE_MANAGER: [
    '/maintenance',
    '/capacity',
    '/network-elements',
  ],
};
