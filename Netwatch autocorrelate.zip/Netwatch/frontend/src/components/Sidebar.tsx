import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import { ROLE_PERMISSIONS } from '../auth/roles';
import styles from './Sidebar.module.css';
import {
  LayoutDashboard,
  Shield,
  History,
  Network,
  MapPin,
  GitBranch,
  AlertTriangle,
  Ticket,
  Truck,
  Layers,
  Wrench,
  Cpu,
  BarChart3,
} from 'lucide-react';

interface SidebarItem {
  path: string;
  label: string;
  icon: React.ReactNode;
}

interface SidebarProps {
  /** Whether the mobile drawer is open (ignored on desktop where the sidebar is always visible). */
  isOpen?: boolean;
  /** Called to close the mobile drawer (e.g. after selecting a nav item or tapping the overlay). */
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen = false, onClose }) => {
  const { user } = useAuth();

  if (!user) return null;

  const allowedPaths = ROLE_PERMISSIONS[user.role] || [];

  const allItems: SidebarItem[] = [
    // Common (admin landing page — kept first so it heads the admin sidebar)
    { path: '/analytics', label: 'Network Analytics', icon: <BarChart3 size={16} /> },

    // NOC
    { path: '/noc-dashboard', label: 'NOC Dashboard', icon: <LayoutDashboard size={16} /> },

    // Field Engineer
    { path: '/field-dispatches', label: 'My Dispatches', icon: <Truck size={16} /> },

    // Alarms & Tickets
    { path: '/alarms', label: 'Alarm Board', icon: <AlertTriangle size={16} /> },
    { path: '/alarm-correlation', label: 'Alarm Correlation', icon: <Layers size={16} /> },
    { path: '/tickets', label: 'Trouble Tickets', icon: <Ticket size={16} /> },

    // Topology & Element Registry
    { path: '/network-elements', label: 'Network Elements', icon: <Network size={16} /> },
    { path: '/sites', label: 'Network Sites', icon: <MapPin size={16} /> },
    { path: '/topology', label: 'Topology Links', icon: <GitBranch size={16} /> },

    // Capacity & Maintenance
    { path: '/capacity', label: 'Capacity Metrics', icon: <Cpu size={16} /> },
    { path: '/maintenance', label: 'Maintenance Window', icon: <Wrench size={16} /> },

    // Circuits
    { path: '/circuits', label: 'Circuits Registry', icon: <Layers size={16} /> },
    { path: '/provisioning', label: 'Provisioning Requests', icon: <GitBranch size={16} /> },

    // Admin
    { path: '/admin/users', label: 'User Management', icon: <Shield size={16} /> },
    { path: '/admin/audit-log', label: 'Audit Trail', icon: <History size={16} /> },
  ];

  // Filter items based on user role permissions
  const navItems = allItems.filter((item) => allowedPaths.includes(item.path));

  return (
    <>
      <div
        className={`${styles.overlay} ${isOpen ? styles['overlay-visible'] : ''}`}
        onClick={onClose}
        aria-hidden="true"
      />
      <aside className={`${styles.sidebar} ${isOpen ? styles.open : ''}`}>
        <div className={styles['logo-container']}>
          <GitBranch className={styles.icon} size={22} color="var(--primary)" />
          <span className={styles['app-name']}>NETWATCH</span>
        </div>
        <nav className={styles['nav-links']}>
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={onClose}
              className={({ isActive }) =>
                `${styles['nav-item']} ${isActive ? styles.active : ''}`
              }
            >
              {item.icon}
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className={styles.footer}>
          <div>NetWatch NOC v1.0.0</div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
