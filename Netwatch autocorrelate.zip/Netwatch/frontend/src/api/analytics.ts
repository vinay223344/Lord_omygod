import apiClient from './apiClient';
import { AnalyticsDashboard } from '../types';

export const analyticsApi = {
  // Returns the live KPI summary, or null when the backend is unreachable.
  // Callers treat null as "no data" and render the '—' placeholder rather than
  // fabricated or zeroed figures that could be mistaken for real metrics.
  getStats: async (): Promise<AnalyticsDashboard | null> => {
    try {
      const response = await apiClient.get<AnalyticsDashboard>('/analytics/dashboard');
      return response.data;
    } catch (err) {
      console.warn('Backend analytics dashboard call failed; showing no data:', err);
      return null;
    }
  },
};
