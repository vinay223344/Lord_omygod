import { User } from '../types';
import { authApi } from './auth';
import apiClient from './apiClient';

export const usersApi = {
  getAll: async () => {
    const response = await apiClient.get<User[]>('/user');
    return response.data;
  },

  create: async (userData: Partial<User>) => {
    return authApi.register(userData);
  },

  update: async (id: number, userData: Partial<User>) => {
    const response = await apiClient.put<User>(`/user/${id}`, userData);
    return response.data;
  },
};
