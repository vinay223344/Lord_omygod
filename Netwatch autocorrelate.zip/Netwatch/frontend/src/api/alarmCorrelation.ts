import apiClient from './apiClient';
import { AlarmCorrelation } from '../types';

// Read-only API for the Service Desk Alarm Correlation page. It only fetches the
// correlated clusters computed by the backend — there are no write operations.
export const alarmCorrelationApi = {
  getCorrelations: async () => {
    try {
      const response = await apiClient.get<AlarmCorrelation[]>('/alarm-correlation');
      return response.data;
    } catch (err) {
      console.warn('Backend alarm-correlation retrieval failed, using empty list:', err);
      return [] as AlarmCorrelation[];
    }
  },
};
