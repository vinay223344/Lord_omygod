import React, { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import axios from 'axios';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import { StatCard, StatGrid } from '../../components/StatCard';
import { elementsApi } from '../../api/elements';
import { sitesApi } from '../../api/sites';
import { useAuth } from '../../auth/AuthContext';
import { NetworkElement, NetworkSite, ElementType, ElementStatus } from '../../types';
import styles from './NetworkElements.module.css';
import { CheckCircle, Edit, PlusCircle, Server, Wrench, XCircle } from 'lucide-react';

const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

const elementSchema = z.object({
  elementName: z.string().min(1, 'Element name is required'),
  elementType: z.enum(['ROUTER', 'SWITCH', 'FIREWALL', 'OLT', 'BTS', 'TRANSMISSION', 'SERVER']),
  vendor: z.string().min(1, 'Vendor is required'),
  model: z.string().min(1, 'Model is required'),
  ipAddress: z.string().min(1, 'IP Address is required').regex(ipv4Regex, 'Must be a valid IPv4 address'),
  siteId: z.string().min(1, 'Location site is required'),
  status: z.enum(['ACTIVE', 'INACTIVE', 'MAINTENANCE', 'DECOMMISSIONED']),
});

type ElementFormFields = z.infer<typeof elementSchema>;

export const NetworkElements: React.FC = () => {
  const { user } = useAuth();
  const [elements, setElements] = useState<NetworkElement[]>([]);
  const [sites, setSites] = useState<NetworkSite[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingElement, setEditingElement] = useState<NetworkElement | null>(null);
  const [loading, setLoading] = useState(true);

  // Change Managers may view the element registry but not modify it. (Planning
  // Engineers cannot reach this page — the /network-elements route is limited to
  // ADMIN and CHANGE_MANAGER — so no Planning Engineer check is needed here.)
  const isReadOnly = user?.role === 'CHANGE_MANAGER';

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm<ElementFormFields>({
    resolver: zodResolver(elementSchema),
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [allElements, allSites] = await axios.all<any>([
        elementsApi.getAll(),
        sitesApi.getAll().catch(() => [] as NetworkSite[]),
      ]) as [NetworkElement[], NetworkSite[]];
      setElements(allElements);
      setSites(allSites);
    } catch (err) {
      console.error('Failed to load element registries:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  const openCreateModal = () => {
    setEditingElement(null);
    reset();
    setIsModalOpen(true);
  };

  const openEditModal = (el: NetworkElement) => {
    setEditingElement(el);
    setValue('elementName', el.elementName);
    setValue('elementType', el.elementType);
    setValue('vendor', el.vendor);
    setValue('model', el.model);
    setValue('ipAddress', el.ipAddress);
    setValue('siteId', String(el.siteId));
    setValue('status', el.status);
    setIsModalOpen(true);
  };

  const onSubmit = async (data: ElementFormFields) => {
    try {
      const payload: Partial<NetworkElement> = {
        elementName: data.elementName,
        elementType: data.elementType as ElementType,
        vendor: data.vendor,
        model: data.model,
        ipAddress: data.ipAddress,
        siteId: Number(data.siteId),
        status: data.status as ElementStatus,
      };

      if (editingElement) {
        await elementsApi.update(editingElement.elementId, payload);
      } else {
        await elementsApi.create(payload);
      }
      setIsModalOpen(false);
      loadData();
    } catch (err) {
      console.error('Failed to save network element:', err);
    }
  };

  // ── Derived summary data (from elements already in state) ──
  const kpis = useMemo(
    () => ({
      active: elements.filter((e) => e.status === 'ACTIVE').length,
      inactive: elements.filter((e) => e.status === 'INACTIVE').length,
      maintenance: elements.filter((e) => e.status === 'MAINTENANCE').length,
      total: elements.length,
    }),
    [elements]
  );

  const columns: Column<NetworkElement>[] = [
    { key: 'elementId', header: 'ID', sortable: true },
    { key: 'elementName', header: 'Name', sortable: true },
    { key: 'elementType', header: 'Type', sortable: true },
    { key: 'vendor', header: 'Vendor', sortable: true },
    { key: 'model', header: 'Model', sortable: true },
    { key: 'ipAddress', header: 'IP Address', sortable: true },
    { key: 'siteName', header: 'Site Location', sortable: true, render: (row) => row.siteName || `Site ${row.siteId}` },
    { key: 'status', header: 'Status', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
  ];

  if (!isReadOnly) {
    columns.push({
      key: 'actions',
      header: 'Actions',
      render: (row) => (
        <button className={styles.btn} onClick={() => openEditModal(row)} style={{ padding: '0.25rem 0.5rem', background: '#f1f5f9', border: '1px solid var(--border-color)', color: 'var(--text-main)' }}>
          <Edit size={12} /> Edit
        </button>
      ),
    });
  }

  return (
    <div className="page-container">
      <PageHeader
        title="Network Element Registry"
        description="Register and configure network infrastructure nodes (routers, switches, firewalls, and OLTs)."
        action={!isReadOnly ? (
          <button className={`${styles.btn} ${styles['btn-primary']}`} onClick={openCreateModal}>
            <PlusCircle size={14} /> Add Network Element
          </button>
        ) : undefined}
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading network elements...</div>
      ) : (
        <div className={styles['page-body']}>
          {/* KPI summary cards */}
          <StatGrid>
            <StatCard label="Active" value={kpis.active} icon={<CheckCircle size={20} />} variant="success" />
            <StatCard label="Inactive" value={kpis.inactive} icon={<XCircle size={20} />} variant="critical" />
            <StatCard label="Maintenance" value={kpis.maintenance} icon={<Wrench size={20} />} variant="neutral" />
            <StatCard label="Total Elements" value={kpis.total} icon={<Server size={20} />} variant="primary" />
          </StatGrid>


          <div className="card">
            <DataTable
              columns={columns}
              data={elements}
              searchPlaceholder="Search elements by name, IP or vendor..."
              searchKey={(row) => `${row.elementName} ${row.ipAddress} ${row.vendor}`}
            />
          </div>
        </div>
      )}

      {/* Create / Edit Element Modal */}
      {!isReadOnly && (
        <Modal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          title={editingElement ? `Edit Network Element #${editingElement.elementId}` : 'Add Network Element'}
        >
          <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Element Name</label>
              <input type="text" className={styles.input} placeholder="e.g. CORE-RT-01" {...register('elementName')} />
              {errors.elementName && <span className={styles['error-text']}>{errors.elementName.message}</span>}
            </div>

            <div className={styles['form-row']}>
              <div className={styles['form-group']}>
                <label className={styles.label}>Element Type</label>
                <select className={styles.select} {...register('elementType')}>
                  <option value="ROUTER">ROUTER</option>
                  <option value="SWITCH">SWITCH</option>
                  <option value="FIREWALL">FIREWALL</option>
                  <option value="OLT">OLT</option>
                  <option value="BTS">BTS</option>
                  <option value="TRANSMISSION">TRANSMISSION</option>
                  <option value="SERVER">SERVER</option>
                </select>
              </div>

              <div className={styles['form-group']}>
                <label className={styles.label}>IP Address</label>
                <input type="text" className={styles.input} placeholder="e.g. 10.0.0.1" {...register('ipAddress')} />
                {errors.ipAddress && <span className={styles['error-text']}>{errors.ipAddress.message}</span>}
              </div>
            </div>

            <div className={styles['form-row']}>
              <div className={styles['form-group']}>
                <label className={styles.label}>Vendor</label>
                <input type="text" className={styles.input} placeholder="e.g. Cisco" {...register('vendor')} />
                {errors.vendor && <span className={styles['error-text']}>{errors.vendor.message}</span>}
              </div>

              <div className={styles['form-group']}>
                <label className={styles.label}>Model Reference</label>
                <input type="text" className={styles.input} placeholder="e.g. ASR-9001" {...register('model')} />
                {errors.model && <span className={styles['error-text']}>{errors.model.message}</span>}
              </div>
            </div>

            <div className={styles['form-row']}>
              <div className={styles['form-group']}>
                <label className={styles.label}>Location Site</label>
                <select className={styles.select} {...register('siteId')}>
                  <option value="">-- Select Site --</option>
                  {sites.map((s) => (
                    <option key={s.siteId} value={s.siteId}>
                      {s.siteName} ({s.siteType})
                    </option>
                  ))}
                </select>
                {errors.siteId && <span className={styles['error-text']}>{errors.siteId.message}</span>}
              </div>

              <div className={styles['form-group']}>
                <label className={styles.label}>Management Status</label>
                <select className={styles.select} {...register('status')}>
                  <option value="ACTIVE">ACTIVE</option>
                  <option value="INACTIVE">INACTIVE</option>
                  <option value="MAINTENANCE">MAINTENANCE</option>
                  <option value="DECOMMISSIONED">DECOMMISSIONED</option>
                </select>
              </div>
            </div>

            <button type="submit" className={`${styles.btn} ${styles['btn-primary']}`} style={{ width: '100%', marginTop: '0.5rem', padding: '0.625rem' }}>
              {editingElement ? 'Apply Changes' : 'Register Element'}
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
};

export default NetworkElements;
