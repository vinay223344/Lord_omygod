import React, { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import axios from 'axios';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import { StatCard, StatGrid } from '../../components/StatCard';
import { useAuth } from '../../auth/AuthContext';
import { alarmsApi } from '../../api/alarms';
import { elementsApi } from '../../api/elements';
import { NetworkAlarm, NetworkElement, AlarmSeverity, AlarmType } from '../../types';
import { formatDate } from '../../utils/date';
import styles from './Alarms.module.css';
import { Activity, AlertTriangle, Bell, CheckCircle, PlusCircle } from 'lucide-react';

const alarmSchema = z.object({
  elementId: z.string().min(1, 'Network element is required'),
  alarmType: z.enum(['LINK_DOWN', 'NODE_UNREACHABLE', 'HIGH_UTILISATION', 'POWER_FAILURE', 'HARDWARE_FAULT', 'COOLING_ALERT']),
  severity: z.enum(['CRITICAL', 'MAJOR', 'MINOR', 'WARNING']),
});

type AlarmFormFields = z.infer<typeof alarmSchema>;

export const Alarms: React.FC = () => {
  const { user } = useAuth();
  const [alarms, setAlarms] = useState<NetworkAlarm[]>([]);
  const [elements, setElements] = useState<NetworkElement[]>([]);
  const [loading, setLoading] = useState(true);
  // Row-click detail panel is a Service Desk aid only (NOC/Admin unaffected).
  const [selectedAlarm, setSelectedAlarm] = useState<NetworkAlarm | null>(null);

  const isServiceDeskOrAdmin = user?.role === 'SERVICE_DESK' || user?.role === 'ADMIN';
  const isServiceDesk = user?.role === 'SERVICE_DESK';

  // Modals state
  const [isAlarmModalOpen, setIsAlarmModalOpen] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<AlarmFormFields>({
    resolver: zodResolver(alarmSchema),
  });

  const loadData = async () => {
    setLoading(true);
    try {
      if (isServiceDeskOrAdmin) {
        const [allAlarms, allElements] = await axios.all<any>([
          alarmsApi.getAllAlarms(),
          elementsApi.getAll().catch(() => [] as NetworkElement[]), // fallback if empty
        ]) as [NetworkAlarm[], NetworkElement[]];
        setAlarms(allAlarms);
        setElements(allElements);
      } else {
        const allAlarms = await alarmsApi.getAllAlarms();
        setAlarms(allAlarms);
      }
    } catch (err) {
      console.error('Failed to retrieve alarm feed details:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  // Keep the open detail panel in sync after alarms reload (e.g. after an
  // acknowledge/clear) so its status and timestamps stay current.
  useEffect(() => {
    setSelectedAlarm((prev) => (prev ? alarms.find((a) => a.alarmId === prev.alarmId) ?? null : prev));
  }, [alarms]);

  const handleRaiseAlarm = async (data: AlarmFormFields) => {
    if (!user) return;
    try {
      const payload: Partial<NetworkAlarm> = {
        elementId: Number(data.elementId),
        alarmType: data.alarmType as AlarmType,
        severity: data.severity as AlarmSeverity,
        alarmTime: new Date().toISOString(),
        status: 'ACTIVE',
      };
      await alarmsApi.createAlarm(payload, user.userId);
      setIsAlarmModalOpen(false);
      reset();
      loadData();
    } catch (err) {
      console.error('Failed to raise manual network alarm:', err);
    }
  };

  const handleAcknowledge = async (alarmId: number) => {
    if (!user) return;
    try {
      await alarmsApi.acknowledgeAlarm(alarmId, user.userId);
      loadData();
    } catch (err) {
      console.error('Error acknowledging alarm:', err);
    }
  };

  const handleClear = async (alarmId: number) => {
    if (!user) return;
    try {
      await alarmsApi.clearAlarm(alarmId, user.userId);
      loadData();
    } catch (err) {
      console.error('Error clearing alarm:', err);
    }
  };

  // ── Derived summary data (from alarms already in state) ──
  const kpis = useMemo(
    () => ({
      active: alarms.filter((a) => a.status === 'ACTIVE').length,
      acknowledged: alarms.filter((a) => a.status === 'ACKNOWLEDGED').length,
      cleared: alarms.filter((a) => a.status === 'CLEARED').length,
      total: alarms.length,
    }),
    [alarms]
  );

  // Severity-coded row indicator for the table.
  const severityRowClass = (row: NetworkAlarm) => {
    switch (row.severity) {
      case 'CRITICAL':
        return styles['row-critical'];
      case 'MAJOR':
        return styles['row-major'];
      case 'MINOR':
        return styles['row-minor'];
      case 'WARNING':
        return styles['row-warning'];
      default:
        return '';
    }
  };

  // Define Columns for Alarms Table
  const alarmColumns: Column<NetworkAlarm>[] = [
    { key: 'alarmId', header: 'Alarm ID', sortable: true },
    { key: 'alarmType', header: 'Alarm Type', sortable: true },
    { key: 'elementName', header: 'Network Element', sortable: true, render: (row) => row.elementName || `ID ${row.elementId}` },
    { key: 'severity', header: 'Severity', sortable: true, render: (row) => <StatusBadge status={row.severity} /> },
    { key: 'alarmTime', header: 'Time Raised', sortable: true, render: (row) => formatDate(row.alarmTime) },
    { key: 'status', header: 'Status', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
  ];

  if (isServiceDeskOrAdmin) {
    alarmColumns.push({
      key: 'actions',
      header: 'Operations',
      render: (row) => {
        const canAck = row.status === 'ACTIVE';
        const canClear = row.status === 'ACKNOWLEDGED';
        
        return (
          <div style={{ display: 'flex', gap: '0.25rem' }}>
            {canAck && (
              <button className={styles['action-btn']} onClick={() => handleAcknowledge(row.alarmId)}>
                Acknowledge
              </button>
            )}
            {canClear && (
              <button className={styles['action-btn']} onClick={() => handleClear(row.alarmId)}>
                Clear
              </button>
            )}
          </div>
        );
      },
    });
  }

  return (
    <div className="page-container">
      <PageHeader
        title="Alarms Board"
        description="Monitor active physical element faults."
        action={isServiceDeskOrAdmin ? (
          <button
            className={`${styles['action-btn']} ${styles['action-btn-primary']}`}
            onClick={() => setIsAlarmModalOpen(true)}
            style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}
          >
            <PlusCircle size={14} /> Raise Manual Alarm
          </button>
        ) : undefined}
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading network faults...</div>
      ) : (
        <>
          {/* KPI summary cards */}
          <StatGrid>
            <StatCard label="Active" value={kpis.active} icon={<AlertTriangle size={20} />} variant="warning" />
            <StatCard label="Acknowledged" value={kpis.acknowledged} icon={<Bell size={20} />} variant="info" />
            <StatCard label="Cleared" value={kpis.cleared} icon={<CheckCircle size={20} />} variant="success" />
            <StatCard label="Total Alarms" value={kpis.total} icon={<Activity size={20} />} variant="primary" />
          </StatGrid>

          <div className="card">
            <DataTable
              columns={alarmColumns}
              data={alarms}
              rowClassName={severityRowClass}
              searchPlaceholder="Search alarms by id, type, element, severity, or status..."
              searchKey={(row) =>
                `${row.alarmId} ${row.alarmType} ${row.elementName || `ID ${row.elementId}`} ${row.severity} ${row.status}`
              }
              onRowClick={isServiceDesk ? (row) => setSelectedAlarm(row) : undefined}
            />
          </div>

          {/* Per-alarm detail panel — Service Desk & Admin (click a row to open) */}
          {isServiceDesk && selectedAlarm && (
            <div className="card" style={{ marginTop: '1.25rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: 600, color: 'var(--text-main)' }}>
                  Alarm #{selectedAlarm.alarmId} details
                </h3>
                <button
                  style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontWeight: 'bold', fontSize: '0.8rem', cursor: 'pointer' }}
                  onClick={() => setSelectedAlarm(null)}
                >
                  ✕ Close panel
                </button>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '0.75rem 1.25rem' }}>
                <div className={styles['detail-row']}>
                  <span className={styles['detail-label']}>Alarm Type</span>
                  <span className={styles['detail-value']}><StatusBadge status={selectedAlarm.alarmType} /></span>
                </div>
                <div className={styles['detail-row']}>
                  <span className={styles['detail-label']}>Severity</span>
                  <span className={styles['detail-value']}><StatusBadge status={selectedAlarm.severity} /></span>
                </div>
                <div className={styles['detail-row']}>
                  <span className={styles['detail-label']}>Status</span>
                  <span className={styles['detail-value']}><StatusBadge status={selectedAlarm.status} /></span>
                </div>
                <div className={styles['detail-row']}>
                  <span className={styles['detail-label']}>Source</span>
                  <span className={styles['detail-value']}>
                    {selectedAlarm.source === 'MAINTENANCE' ? '🛠 Maintenance Window' : 'Manual (Service Desk)'}
                  </span>
                </div>
                <div className={styles['detail-row']}>
                  <span className={styles['detail-label']}>Network Element</span>
                  <span className={styles['detail-value']}>{selectedAlarm.elementName || `ID ${selectedAlarm.elementId}`}</span>
                </div>
                <div className={styles['detail-row']}>
                  <span className={styles['detail-label']}>Element ID</span>
                  <span className={styles['detail-value']}>#{selectedAlarm.elementId}</span>
                </div>
                <div className={styles['detail-row']}>
                  <span className={styles['detail-label']}>Time Raised</span>
                  <span className={styles['detail-value']}>{formatDate(selectedAlarm.alarmTime)}</span>
                </div>
                <div className={styles['detail-row']}>
                  <span className={styles['detail-label']}>Acknowledged By</span>
                  <span className={styles['detail-value']}>
                    {selectedAlarm.acknowledgedById ? `User #${selectedAlarm.acknowledgedById}` : 'Not acknowledged'}
                  </span>
                </div>
                <div className={styles['detail-row']}>
                  <span className={styles['detail-label']}>Acknowledged Time</span>
                  <span className={styles['detail-value']}>
                    {selectedAlarm.acknowledgedTime ? formatDate(selectedAlarm.acknowledgedTime) : '—'}
                  </span>
                </div>
                <div className={styles['detail-row']}>
                  <span className={styles['detail-label']}>Cleared Time</span>
                  <span className={styles['detail-value']}>
                    {selectedAlarm.clearedTime ? formatDate(selectedAlarm.clearedTime) : '—'}
                  </span>
                </div>
              </div>

              {/* Acknowledge / clear from the panel (same operations as the table) */}
              {(selectedAlarm.status === 'ACTIVE' || selectedAlarm.status === 'ACKNOWLEDGED') && (
                <div style={{ display: 'flex', gap: '0.5rem', marginTop: '1rem' }}>
                  {selectedAlarm.status === 'ACTIVE' && (
                    <button className={styles['action-btn']} onClick={() => handleAcknowledge(selectedAlarm.alarmId)}>
                      Acknowledge
                    </button>
                  )}
                  {selectedAlarm.status === 'ACKNOWLEDGED' && (
                    <button className={styles['action-btn']} onClick={() => handleClear(selectedAlarm.alarmId)}>
                      Clear
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {isServiceDeskOrAdmin && (
        <Modal isOpen={isAlarmModalOpen} onClose={() => setIsAlarmModalOpen(false)} title="Raise Manual Network Alarm">
          <form className={styles.form} onSubmit={handleSubmit(handleRaiseAlarm)}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Network Element</label>
              <select className={styles.select} {...register('elementId')}>
                <option value="">-- Select Element --</option>
                {elements.map((el) => (
                  <option key={el.elementId} value={el.elementId}>
                    {el.elementName} ({el.ipAddress})
                  </option>
                ))}
              </select>
              {errors.elementId && (
                <span className={styles['error-text']}>{errors.elementId.message}</span>
              )}
            </div>

            <div className={styles['form-row']}>
              <div className={styles['form-group']}>
                <label className={styles.label}>Fault Type</label>
                <select className={styles.select} {...register('alarmType')}>
                  <option value="LINK_DOWN">LINK_DOWN</option>
                  <option value="NODE_UNREACHABLE">NODE_UNREACHABLE</option>
                  <option value="HIGH_UTILISATION">HIGH_UTILISATION</option>
                  <option value="POWER_FAILURE">POWER_FAILURE</option>
                  <option value="HARDWARE_FAULT">HARDWARE_FAULT</option>
                  <option value="COOLING_ALERT">COOLING_ALERT</option>
                </select>
              </div>

              <div className={styles['form-group']}>
                <label className={styles.label}>Severity</label>
                <select className={styles.select} {...register('severity')}>
                  <option value="CRITICAL">CRITICAL</option>
                  <option value="MAJOR">MAJOR</option>
                  <option value="MINOR">MINOR</option>
                  <option value="WARNING">WARNING</option>
                </select>
              </div>
            </div>

            <button type="submit" className={`${styles['action-btn']} ${styles['action-btn-primary']}`} style={{ width: '100%', marginTop: '0.5rem', padding: '0.625rem' }}>
              Submit Alarm Event
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
};

export default Alarms;
