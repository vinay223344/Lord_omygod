import React, { useState, useEffect, useMemo } from 'react';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import { StatCard, StatGrid } from '../../components/StatCard';
import { useAuth } from '../../auth/AuthContext';
import { alarmCorrelationApi } from '../../api/alarmCorrelation';
// Aliased to avoid colliding with this file's `AlarmCorrelation` component name.
import { AlarmCorrelation as CorrelationCluster, NetworkAlarm } from '../../types';
import { formatDate } from '../../utils/date';
import styles from './AlarmCorrelation.module.css';
import { Layers, Activity, AlertTriangle, AlertOctagon } from 'lucide-react';

/**
 * Service Desk — Alarm Correlation.
 *
 * A read-only view: it groups active alarms into clusters (by site) and shows the
 * probable root cause of each cluster. There are no actions here — the page is
 * purely for understanding how alarms relate to one another.
 */
export const AlarmCorrelation: React.FC = () => {
  const { user } = useAuth();
  // The per-alarm detail panel is available to Service Desk and Admin.
  const isServiceDeskOrAdmin = user?.role === 'SERVICE_DESK' || user?.role === 'ADMIN';
  const [correlations, setCorrelations] = useState<CorrelationCluster[]>([]);
  const [selected, setSelected] = useState<CorrelationCluster | null>(null);
  const [selectedAlarm, setSelectedAlarm] = useState<NetworkAlarm | null>(null);
  const [loading, setLoading] = useState(true);

  // Select a cluster and reset any previously opened alarm detail.
  const openCluster = (cluster: CorrelationCluster | null) => {
    setSelected(cluster);
    setSelectedAlarm(null);
  };

  const loadCorrelations = async () => {
    setLoading(true);
    try {
      const data = await alarmCorrelationApi.getCorrelations();
      setCorrelations(data);
    } catch (err) {
      console.error('Failed to load alarm correlations:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCorrelations();
  }, []);

  // After a reload (e.g. following an acknowledge/clear), re-sync the open
  // cluster and alarm panels so their contents reflect the latest alarm state.
  useEffect(() => {
    setSelected((prev) => (prev ? correlations.find((c) => c.correlationId === prev.correlationId) ?? null : prev));
  }, [correlations]);

  useEffect(() => {
    if (!selected) {
      setSelectedAlarm(null);
      return;
    }
    setSelectedAlarm((prev) => (prev ? selected.alarms.find((a) => a.alarmId === prev.alarmId) ?? null : prev));
  }, [selected]);

  // Sort member alarms: Root cause alarm first, then remaining alarms by time (newest first)
  const sortedAlarms = useMemo(() => {
    if (!selected?.alarms) return [];
    return [...selected.alarms].sort((a, b) => {
      // 1. Always prioritize the Root Cause Alarm
      if (a.alarmId === selected.rootCauseAlarmId) return -1;
      if (b.alarmId === selected.rootCauseAlarmId) return 1;

      // 2. Sort the remaining alarms by alarmTime (newest first)
      return new Date(b.alarmTime).getTime() - new Date(a.alarmTime).getTime();
    });
  }, [selected]);

  // ── Summary cards (derived from the clusters already in state) ──
  const kpis = useMemo(
    () => ({
      clusters: correlations.length,
      multiAlarm: correlations.filter((c) => c.alarmCount >= 2).length,
      alarmsCorrelated: correlations.reduce((sum, c) => sum + c.alarmCount, 0),
      critical: correlations.filter((c) => c.highestSeverity === 'CRITICAL').length,
    }),
    [correlations]
  );

  // Left-cornered severity stripe shared by the cluster and member-alarm tables.
  const severityRowClass = (severity?: string) => {
    switch (severity) {
      case 'CRITICAL':
        return styles['row-critical'];
      case 'MAJOR':
        return styles['row-major'];
      case 'MINOR':
        return styles['row-minor'];
      case 'WARNING':
        return styles['row-warning'];
      default:
        return '';
    }
  };

  // Cluster table columns. The search key also includes each member alarm's id so
  // an operator can find a cluster by typing any alarm id it contains.
  const clusterColumns: Column<CorrelationCluster>[] = [
    { key: 'correlationId', header: 'Cluster ID', sortable: true },
    { key: 'siteName', header: 'Site', sortable: true, render: (row) => row.siteName || `Site #${row.siteId}` },
    { key: 'alarmCount', header: 'Alarms', sortable: true },
    { key: 'highestSeverity', header: 'Highest Severity', sortable: true, render: (row) => <StatusBadge status={row.highestSeverity} /> },
    { key: 'rootCauseElementName', header: 'Root Cause Element', sortable: true, render: (row) => row.rootCauseElementName || 'N/A' },
    { key: 'rootCauseType', header: 'Root Cause Type', sortable: true, render: (row) => <StatusBadge status={row.rootCauseType} /> },
  ];

  // Member-alarm columns for the selected cluster's detail table.
  const alarmColumns: Column<NetworkAlarm>[] = [
    { key: 'alarmId', header: 'Alarm ID', sortable: true },
    { key: 'alarmType', header: 'Type', sortable: true, render: (row) => <StatusBadge status={row.alarmType} /> },
    { key: 'elementName', header: 'Network Element', sortable: true, render: (row) => row.elementName || `ID ${row.elementId}` },
    { key: 'severity', header: 'Severity', sortable: true, render: (row) => <StatusBadge status={row.severity} /> },
    { key: 'alarmTime', header: 'Time Raised', sortable: true, render: (row) => formatDate(row.alarmTime) },
    { key: 'status', header: 'Status', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
  ];

  return (
    <div className="page-container">
      <PageHeader
        title="Alarm Correlation"
        description="Active alarms grouped into incident clusters by site, with the most probable root cause of each cluster highlighted for faster triage."
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Correlating active alarms...</div>
      ) : (
        <div className={styles['page-body']}>
          {/* KPI summary cards */}
          <StatGrid>
            <StatCard label="Correlation Clusters" value={kpis.clusters} icon={<Layers size={20} />} variant="primary" />
            <StatCard label="Multi-Alarm Clusters" value={kpis.multiAlarm} icon={<Activity size={20} />} variant="info" />
            <StatCard label="Alarms Correlated" value={kpis.alarmsCorrelated} icon={<AlertTriangle size={20} />} variant="warning" />
            <StatCard label="Critical Clusters" value={kpis.critical} icon={<AlertOctagon size={20} />} variant="critical" />
          </StatGrid>

          {/* Clusters table */}
          <div className="card">
            <DataTable
              columns={clusterColumns}
              data={correlations}
              rowClassName={(row) => severityRowClass(row.highestSeverity)}
              searchPlaceholder="Search by cluster id, site, root cause, or alarm id..."
              searchKey={(row) =>
                `${row.correlationId} ${row.siteName} ${row.rootCauseElementName || ''} ${row.rootCauseType} ${row.alarms
                  .map((a) => a.alarmId)
                  .join(' ')}`
              }
              onRowClick={(row) => openCluster(row)}
            />
          </div>

          {/* Selected cluster details (read-only) */}
          {selected && (
            <div className="card">
              <div className={styles['panel-header']}>
                <h3 className={styles['panel-title']}>
                  {selected.correlationId} · {selected.siteName || `Site #${selected.siteId}`}
                </h3>
                <button className={styles['link-btn']} onClick={() => openCluster(null)}>
                  ✕ Close details
                </button>
              </div>

              {/* Root cause callout */}
              <div className={styles['root-cause']}>
                <span className={styles['root-cause-label']}>Probable Root Cause</span>
                <div className={styles['root-cause-head']}>
                  <StatusBadge status={selected.rootCauseSeverity} />
                  <StatusBadge status={selected.rootCauseType} />
                  <span className={styles['root-cause-element']}>
                    {selected.rootCauseElementName || 'Unknown element'} · Alarm #{selected.rootCauseAlarmId}
                  </span>
                </div>
                <p className={styles['root-cause-reason']}>{selected.rootCauseReason}</p>
                <span className={styles['root-cause-window']}>
                  Alarm window: {formatDate(selected.windowStart)} → {formatDate(selected.windowEnd)}
                </span>
              </div>

              {/* Member alarms of this cluster — click a row for full detail */}
              <h4 className={styles['sub-title']}>Correlated Alarms ({selected.alarmCount})</h4>
              <DataTable
                columns={alarmColumns}
                data={sortedAlarms}
                rowClassName={(row) => severityRowClass(row.severity)}
                searchPlaceholder="Search alarms by id, type, or element..."
                searchKey={(row) => `${row.alarmId} ${row.alarmType} ${row.elementName || ''}`}
                onRowClick={isServiceDeskOrAdmin ? (row) => setSelectedAlarm(row) : undefined}
              />

              {/* Per-alarm details panel — Service Desk & Admin (opens on row click) */}
              {isServiceDeskOrAdmin && selectedAlarm && (
                <div className={styles['alarm-detail']}>
                  <div className={styles['panel-header']}>
                    <h4 className={styles['sub-title']} style={{ margin: 0 }}>
                      Alarm #{selectedAlarm.alarmId} details
                      {selectedAlarm.alarmId === selected.rootCauseAlarmId && (
                        <span className={styles['root-tag']}>ROOT CAUSE</span>
                      )}
                    </h4>
                    <button className={styles['link-btn']} onClick={() => setSelectedAlarm(null)}>
                      ✕ Close alarm
                    </button>
                  </div>
                  <div className={styles['info-grid']}>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Cluster ID</span>
                      <span className={styles['info-value']}>{selected.correlationId}</span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Alarm Type</span>
                      <span className={styles['info-value']}><StatusBadge status={selectedAlarm.alarmType} /></span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Severity</span>
                      <span className={styles['info-value']}><StatusBadge status={selectedAlarm.severity} /></span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Status</span>
                      <span className={styles['info-value']}><StatusBadge status={selectedAlarm.status} /></span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Source</span>
                      <span className={styles['info-value']}>
                        {selectedAlarm.source === 'MAINTENANCE' ? '🛠 Maintenance Window' : 'Manual (Service Desk)'}
                      </span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Network Element</span>
                      <span className={styles['info-value']}>{selectedAlarm.elementName || `ID ${selectedAlarm.elementId}`}</span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Element ID</span>
                      <span className={styles['info-value']}>#{selectedAlarm.elementId}</span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Site</span>
                      <span className={styles['info-value']}>{selected.siteName || `Site #${selected.siteId}`}</span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Time Raised</span>
                      <span className={styles['info-value']}>{formatDate(selectedAlarm.alarmTime)}</span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Acknowledged By</span>
                      <span className={styles['info-value']}>
                        {selectedAlarm.acknowledgedById ? `User #${selectedAlarm.acknowledgedById}` : 'Not acknowledged'}
                      </span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Acknowledged Time</span>
                      <span className={styles['info-value']}>
                        {selectedAlarm.acknowledgedTime ? formatDate(selectedAlarm.acknowledgedTime) : '—'}
                      </span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Cleared Time</span>
                      <span className={styles['info-value']}>
                        {selectedAlarm.clearedTime ? formatDate(selectedAlarm.clearedTime) : '—'}
                      </span>
                    </div>
                    <div className={styles['info-item']}>
                      <span className={styles['info-label']}>Role in Cluster</span>
                      <span className={styles['info-value']}>
                        {selectedAlarm.alarmId === selected.rootCauseAlarmId ? 'Probable root cause' : 'Correlated symptom'}
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AlarmCorrelation;