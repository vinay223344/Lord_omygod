package com.example.NetWatch.service;

import com.example.NetWatch.entity.NetworkAlarm;
import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.NetworkSite;
import com.example.NetWatch.enums.AlarmStatus;
import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.repository.AlarmRepo;
import com.example.NetWatch.responsedto.AlarmCorrelationResponseDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AlarmCorrelationServiceImpTest {

    @Mock
    private AlarmRepo alarmRepo;

    @InjectMocks
    private AlarmCorrelationServiceImp service;

    private NetworkElement elementAt(NetworkSite site, Long id, String name) {
        NetworkElement element = new NetworkElement();
        element.setElementId(id);
        element.setElementName(name);
        element.setSite(site);
        return element;
    }

    private NetworkAlarm alarm(Long id, NetworkElement element, AlarmType type, Severity severity, String time) {
        NetworkAlarm alarm = new NetworkAlarm();
        alarm.setAlarmId(id);
        alarm.setElement(element);
        alarm.setAlarmType(type);
        alarm.setSeverity(severity);
        alarm.setStatus(AlarmStatus.ACTIVE);
        alarm.setAlarmTime(time);
        return alarm;
    }

    @Test
    public void correlatesAlarmsBySiteAndSelectsRootCause() {
        NetworkSite chennai = new NetworkSite();
        chennai.setSiteId(1L);
        chennai.setSiteName("Chennai Data Centre");

        NetworkElement router = elementAt(chennai, 101L, "CHN-DC-RTR");
        NetworkElement switchEl = elementAt(chennai, 102L, "CHN-DC-SW");

        // A CRITICAL power failure (a cause) and a MAJOR link down (a symptom),
        // both at the same site → one cluster, power failure is the root cause.
        NetworkAlarm power = alarm(1L, router, AlarmType.POWER_FAILURE, Severity.CRITICAL, "2026-07-28T10:00:00");
        NetworkAlarm link = alarm(2L, switchEl, AlarmType.LINK_DOWN, Severity.MAJOR, "2026-07-28T10:01:00");

        when(alarmRepo.findAll()).thenReturn(List.of(power, link));

        List<AlarmCorrelationResponseDTO> result = service.getCorrelations();

        assertEquals(1, result.size());
        AlarmCorrelationResponseDTO cluster = result.get(0);
        assertEquals("CORR-SITE-1", cluster.getCorrelationId());
        assertEquals(1L, cluster.getSiteId());
        assertEquals(2, cluster.getAlarmCount());
        assertEquals(Severity.CRITICAL, cluster.getHighestSeverity());
        assertEquals(1L, cluster.getRootCauseAlarmId());
        assertEquals(AlarmType.POWER_FAILURE, cluster.getRootCauseType());
        assertEquals(2, cluster.getAlarms().size());
    }

    @Test
    public void groupsAlarmsFromDifferentSitesSeparately() {
        NetworkSite chennai = new NetworkSite();
        chennai.setSiteId(1L);
        chennai.setSiteName("Chennai Data Centre");
        NetworkSite mumbai = new NetworkSite();
        mumbai.setSiteId(2L);
        mumbai.setSiteName("Mumbai Exchange");

        NetworkAlarm a1 = alarm(1L, elementAt(chennai, 101L, "CHN-DC-RTR"), AlarmType.NODE_UNREACHABLE, Severity.MAJOR, "2026-07-28T10:00:00");
        NetworkAlarm a2 = alarm(2L, elementAt(mumbai, 201L, "MUM-EX-RTR"), AlarmType.HIGH_UTILISATION, Severity.MINOR, "2026-07-28T10:05:00");

        when(alarmRepo.findAll()).thenReturn(List.of(a1, a2));

        List<AlarmCorrelationResponseDTO> result = service.getCorrelations();

        assertEquals(2, result.size());
        // Most urgent cluster (MAJOR) is ordered before the MINOR one.
        assertEquals(1L, result.get(0).getSiteId());
        assertEquals(2L, result.get(1).getSiteId());
    }

    @Test
    public void skipsAlarmsWithoutAResolvableSite() {
        NetworkAlarm orphan = alarm(9L, null, AlarmType.LINK_DOWN, Severity.MINOR, "2026-07-28T10:00:00");

        when(alarmRepo.findAll()).thenReturn(List.of(orphan));

        List<AlarmCorrelationResponseDTO> result = service.getCorrelations();

        assertTrue(result.isEmpty());
    }

    @Test
    public void excludesClearedAlarmsFromCorrelation() {
        NetworkSite chennai = new NetworkSite();
        chennai.setSiteId(1L);
        chennai.setSiteName("Chennai Data Centre");

        NetworkElement router = elementAt(chennai, 101L, "CHN-DC-RTR");

        // One ACTIVE alarm and one CLEARED alarm on the same element/site.
        // The cleared alarm is resolved, so only the active one is correlated.
        NetworkAlarm active = alarm(1L, router, AlarmType.LINK_DOWN, Severity.CRITICAL, "2026-07-29T01:18:40");
        NetworkAlarm cleared = alarm(2L, router, AlarmType.LINK_DOWN, Severity.WARNING, "2026-07-29T01:23:42");
        cleared.setStatus(AlarmStatus.CLEARED);

        when(alarmRepo.findAll()).thenReturn(List.of(active, cleared));

        List<AlarmCorrelationResponseDTO> result = service.getCorrelations();

        assertEquals(1, result.size());
        // The cluster reflects only the 1 active alarm, not the cleared one.
        assertEquals(1, result.get(0).getAlarmCount());
        assertEquals(1L, result.get(0).getRootCauseAlarmId());
    }
}
