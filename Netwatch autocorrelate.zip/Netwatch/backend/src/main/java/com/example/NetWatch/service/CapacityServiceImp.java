package com.example.NetWatch.service;

import com.example.NetWatch.entity.CapacityRecord;
import com.example.NetWatch.entity.Circuit;
import com.example.NetWatch.entity.MaintenanceWindow;
import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.ProvisioningRequest;
import com.example.NetWatch.repository.CapacityRecordRepo;
import com.example.NetWatch.repository.MaintenanceWindowRepo;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.requestdto.CapacityRecordRequestDTO;
import com.example.NetWatch.responsedto.CapacityRecordResponseDTO;
import com.example.NetWatch.requestdto.MaintenanceWindowRequestDTO;
import com.example.NetWatch.responsedto.MaintenanceWindowResponseDTO;
import com.example.NetWatch.enums.CapacityStatus;
import com.example.NetWatch.enums.ElementStatus;
import com.example.NetWatch.enums.MaintenanceStatus;
import com.example.NetWatch.enums.MaintenanceType;
import com.example.NetWatch.enums.MetricType;
import com.example.NetWatch.enums.ProvisioningRequestType;
import com.example.NetWatch.enums.ProvisioningStatus;
import com.example.NetWatch.exception.ResourceNotFoundException;
import com.example.NetWatch.exception.InvalidStateTransitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.NetWatch.repository.ProvisioningRequestRepo;
import com.example.NetWatch.service.AlarmService;
import com.example.NetWatch.requestdto.NetworkAlarmRequestDTO;
import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.AlarmSource;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.enums.AlarmStatus;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CapacityServiceImp implements CapacityService {

    @Autowired
    private CapacityRecordRepo capacityRepo;

    @Autowired
    private MaintenanceWindowRepo maintenanceRepo;

    @Autowired
    private NetworkElementRepo elementRepo;

    @Autowired
    private AuditLogService auditService;

    @Autowired
    private ProvisioningRequestRepo requestRepo;

    @Autowired
    private AlarmService alarmService;

    // ─────────────────────────────────────────────────────────────────────────
    // CAPACITY RECORD OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public CapacityRecordResponseDTO addCapacityRecord(CapacityRecordRequestDTO recordRequest, Long creatorId) {
        CapacityRecord record = mapCapacityToEntity(recordRequest);
        record.setRecordedDate(LocalDateTime.now());

        // Link NetworkElement
        if (record.getElement() != null && record.getElement().getElementId() != null) {
            NetworkElement element = elementRepo.findById(record.getElement().getElementId())
                    .orElseThrow(() -> new ResourceNotFoundException("NetworkElement not found: " + record.getElement().getElementId()));

            // Only one capacity record is allowed per network element.
            List<CapacityRecord> existing = capacityRepo.findByElement_ElementId(element.getElementId());
            if (existing != null && !existing.isEmpty()) {
                throw new InvalidStateTransitionException(
                        "A capacity record already exists for element '" + element.getElementName()
                                + "'. Each network element can have only one capacity record.");
            }

            record.setElement(element);
        }

        // Utilisation metrics are percentages — clamp to a valid 0-100 range so
        // stray inputs (e.g. raw Mbps values) can't produce nonsensical records.
        record.setPeakValue(clampPercent(record.getPeakValue()));
        record.setAverageValue(clampPercent(record.getAverageValue()));
        record.setThresholdPercent(clampPercent(record.getThresholdPercent()));

        // Auto-evaluate Status based on peak/avg vs threshold
        double peak = record.getPeakValue() != null ? record.getPeakValue() : 0.0;
        double avg = record.getAverageValue() != null ? record.getAverageValue() : 0.0;
        record.setStatus(evaluateStatus(peak, avg, record.getThresholdPercent()));

        CapacityRecord saved = capacityRepo.save(record);
        auditService.log(creatorId, "ADD_CAPACITY_RECORD", "CapacityRecord", saved.getCapacityId());
        return mapCapacityToResponse(saved);
    }

    @Override
    public List<CapacityRecordResponseDTO> getAllCapacityRecords() {
        return capacityRepo.findAll().stream()
                .map(this::mapCapacityToResponse)
                .collect(Collectors.toList());

    }

    @Override
    public List<CapacityRecordResponseDTO> getCapacityBreaches() {
        List<CapacityRecord> breaches = capacityRepo.findByStatus(CapacityStatus.CRITICAL);
        breaches.addAll(capacityRepo.findByStatus(CapacityStatus.WARNING));
        return breaches.stream()
                .map(this::mapCapacityToResponse)
                .collect(Collectors.toList());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MAINTENANCE WINDOW OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public MaintenanceWindowResponseDTO createMaintenanceWindow(MaintenanceWindowRequestDTO windowRequest, Long creatorId) {
        MaintenanceWindow window = mapMaintenanceToEntity(windowRequest);
        window.setStatus(MaintenanceStatus.PENDING);
        window.setRequestedById(creatorId);
        MaintenanceWindow saved = maintenanceRepo.save(window);
        auditService.log(creatorId, "REQUEST_MAINTENANCE_WINDOW", "MaintenanceWindow", saved.getMaintenanceId());
        return mapMaintenanceToResponse(saved);
    }

    @Override
    @Transactional
    public MaintenanceWindowResponseDTO approveMaintenanceWindow(Long id, Long approverId) {
        MaintenanceWindow window = maintenanceRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("MaintenanceWindow not found: " + id));

        // Block approval if any affected element's utilisation is already over its
        // threshold (both peak and average above the threshold %) — the change
        // cannot be safely carried out.
        CapacityRecord overThreshold = findOverThresholdRecord(window.getAffectedElementIds());
        if (overThreshold != null) {
            String elName = (overThreshold.getElement() != null && overThreshold.getElement().getElementName() != null)
                    ? overThreshold.getElement().getElementName()
                    : ("#" + (overThreshold.getElement() != null ? overThreshold.getElement().getElementId() : "?"));
            long peakPct = Math.round(overThreshold.getPeakValue() != null ? overThreshold.getPeakValue() : 0.0);
            long avgPct = Math.round(overThreshold.getAverageValue() != null ? overThreshold.getAverageValue() : 0.0);
            long thrPct = Math.round(overThreshold.getThresholdPercent() != null ? overThreshold.getThresholdPercent() : 0.0);
            throw new InvalidStateTransitionException(
                    "Cannot approve because element '" + elName + "' peak (" + peakPct + "%) and average ("
                            + avgPct + "%) utilisation exceed its threshold limit (" + thrPct + "%).");
        }

        window.setStatus(MaintenanceStatus.APPROVED);
        window.setApprovedById(approverId);
        MaintenanceWindow saved = maintenanceRepo.save(window);

        // Elements under an approved maintenance window go into MAINTENANCE state.
        setAffectedElementsStatus(saved.getAffectedElementIds(), ElementStatus.MAINTENANCE);

        // Raise alarm for provisioning request(s) linked to this maintenance window once approved
        List<ProvisioningRequest> reqs = requestRepo.findByMaintenanceWindow(saved);
        for (ProvisioningRequest request : reqs) {
            if (request.getElement() != null) {
                NetworkAlarmRequestDTO alarmRequest = NetworkAlarmRequestDTO.builder()
                        .elementId(request.getElement().getElementId())
                        .alarmType(AlarmType.HIGH_UTILISATION)
                        .severity(Severity.CRITICAL)
                        .status(AlarmStatus.ACTIVE)
                        // Tag as maintenance-generated so the Service Desk can tell
                        // it apart from a manually raised alarm.
                        .source(AlarmSource.MAINTENANCE)
                        .build();
                alarmService.create(alarmRequest, approverId);
            }
        }

        auditService.log(approverId, "APPROVE_MAINTENANCE_WINDOW", "MaintenanceWindow", saved.getMaintenanceId());
        return mapMaintenanceToResponse(saved);
    }

    @Override
    @Transactional
    public MaintenanceWindowResponseDTO updateMaintenanceStatus(Long id, MaintenanceStatus status, Long updaterId) {
        MaintenanceWindow window = maintenanceRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("MaintenanceWindow not found: " + id));
        window.setStatus(status);
        MaintenanceWindow saved = maintenanceRepo.save(window);

        // A rejected/cancelled window means any provisioning request waiting on it
        // can no longer proceed — mark those in-progress requests as REJECTED.
        if (status == MaintenanceStatus.CANCELLED) {
            List<ProvisioningRequest> linked = requestRepo.findByMaintenanceWindow(saved);
            for (ProvisioningRequest req : linked) {
                if (req.getStatus() == ProvisioningStatus.IN_PROGRESS) {
                    req.setStatus(ProvisioningStatus.REJECTED);
                    requestRepo.save(req);
                }
            }
        }

        auditService.log(updaterId, "UPDATE_MAINTENANCE_STATUS", "MaintenanceWindow", saved.getMaintenanceId());
        return mapMaintenanceToResponse(saved);
    }

    @Override
    public List<MaintenanceWindowResponseDTO> getAllMaintenanceWindows() {
        return maintenanceRepo.findAll().stream()
                .map(this::mapMaintenanceToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<MaintenanceWindowResponseDTO> getPendingMaintenanceWindows() {
        return maintenanceRepo.findByStatus(MaintenanceStatus.PENDING).stream()
                .map(this::mapMaintenanceToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public MaintenanceWindowResponseDTO getMaintenanceWindowById(Long id) {
        MaintenanceWindow saved = maintenanceRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("MaintenanceWindow not found: " + id));
        return mapMaintenanceToResponse(saved);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CROSS-SERVICE METHODS — called by CircuitService / ProvisioningService
    // ─────────────────────────────────────────────────────────────────────────

    private static final double DEFAULT_LINK_CAPACITY_MBPS = 1000.0;
    private static final double CAPACITY_THRESHOLD_PERCENT = 80.0;

    @Override
    public String checkCapacityForProvisioning(ProvisioningRequest request) {
        if (request.getRequestType() != ProvisioningRequestType.BANDWIDTH_UPGRADE) {
            return "OK";
        }

        NetworkElement element = request.getElement();
        if (element == null) {
            return "OK";
        }

        double requestedUpgrade = request.getBandwidthMbps() != null ? request.getBandwidthMbps() : 0.0;

        // Use the element's link-utilisation capacity record as the baseline.
        CapacityRecord record = findLinkUtilisationRecord(element.getElementId());

        double thresholdPercent = 80.0;
        double peakValue = 0.0;
        double averageValue = 0.0;

        if (record != null) {
            if (record.getThresholdPercent() != null) thresholdPercent = record.getThresholdPercent();
            if (record.getPeakValue() != null) peakValue = record.getPeakValue();
            if (record.getAverageValue() != null) averageValue = record.getAverageValue();
        }

        // Utilisation is tracked as a percentage; an X Mbps upgrade adds
        // (X / reference-capacity) * 100 percentage points to the utilisation.
        double deltaPercent = (requestedUpgrade / DEFAULT_LINK_CAPACITY_MBPS) * 100.0;
        double newPeak = peakValue + deltaPercent;
        double newAvg = averageValue + deltaPercent;

        if (newPeak >= thresholdPercent || newAvg >= thresholdPercent) {
            return "CRITICAL: Requested bandwidth upgrade of " + requestedUpgrade
                    + " Mbps would push utilisation to " + Math.round(Math.max(newPeak, newAvg))
                    + "%, meeting/exceeding the threshold limit of " + thresholdPercent + "%.";
        }

        return "OK";
    }


    @Override
    public boolean requiresMaintenanceWindow(ProvisioningRequest request, String capacityResult) {
        boolean isCritical = capacityResult.startsWith("CRITICAL");
        return switch (request.getRequestType()) {
            case BANDWIDTH_UPGRADE -> isCritical;
            case SUSPENSION, TERMINATION -> false;
        };
    }

    @Override
    @Transactional
    public MaintenanceWindow scheduleMaintenanceWindow(ProvisioningRequest request) {
        MaintenanceWindow window = new MaintenanceWindow();

        String circuitRef = request.getCircuit() != null
                ? request.getCircuit().getCircuitReference()
                : "Unknown Circuit";
        String elementName = request.getElement() != null
                ? request.getElement().getElementName()
                : "Unknown Element";

        window.setTitle("Auto: " + request.getRequestType().name()
                + " for Element [" + elementName + "] on Circuit [" + circuitRef + "]");
        window.setMaintenanceType(MaintenanceType.PLANNED);
        window.setStartDateTime(LocalDateTime.now().plusHours(2));
        window.setEndDateTime(LocalDateTime.now().plusHours(3));
        window.setRequestedById(request.getRequestedById());
        window.setStatus(MaintenanceStatus.PENDING);
        window.setRollbackPlan("Revert circuit/element configuration to previous state if change fails.");

        if (request.getElement() != null) {
            window.setAffectedElementIds("element:" + request.getElement().getElementId());
        } else if (request.getCircuit() != null) {
            window.setAffectedElementIds("circuit:" + request.getCircuit().getCircuitId());
        }

        return maintenanceRepo.save(window);
    }

    @Override
    @Transactional
    public void applyBandwidthUpgradeToCapacity(Long elementId, Double upgradeMbps) {
        if (elementId == null || upgradeMbps == null || upgradeMbps <= 0) {
            return;
        }
        List<CapacityRecord> records = capacityRepo.findByElement_ElementId(elementId);
        if (records == null || records.isEmpty()) {
            return;
        }

        double deltaPercent = (upgradeMbps / DEFAULT_LINK_CAPACITY_MBPS) * 100.0;
        for (CapacityRecord record : records) {
            // Reflect the added bandwidth load on the element's capacity record.
            double peak = record.getPeakValue() != null ? record.getPeakValue() : 0.0;
            double avg = record.getAverageValue() != null ? record.getAverageValue() : 0.0;
            double newPeak = Math.min(100.0, peak + deltaPercent);
            double newAvg = Math.min(100.0, avg + deltaPercent);
            record.setPeakValue(newPeak);
            record.setAverageValue(newAvg);
            record.setStatus(evaluateStatus(newPeak, newAvg, record.getThresholdPercent()));
            record.setRecordedDate(LocalDateTime.now());
            capacityRepo.save(record);
        }
    }

    @Override
    @Transactional
    public MaintenanceWindowResponseDTO completeMaintenanceWindow(Long id) {
        MaintenanceWindow window = maintenanceRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("MaintenanceWindow not found: " + id));
        window.setStatus(MaintenanceStatus.COMPLETED);
        MaintenanceWindow saved = maintenanceRepo.save(window);

        // Maintenance done — affected elements return to service.
        setAffectedElementsStatus(saved.getAffectedElementIds(), ElementStatus.ACTIVE);

        auditService.log(saved.getApprovedById(), "COMPLETE_MAINTENANCE_WINDOW", "MaintenanceWindow", saved.getMaintenanceId());
        return mapMaintenanceToResponse(saved);
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    /** Clamp a utilisation/threshold percentage into the valid 0-100 range. */
    private Double clampPercent(Double value) {
        if (value == null) {
            return null;
        }
        return Math.max(0.0, Math.min(100.0, value));
    }

    /** Evaluate a capacity status from peak/average utilisation against a threshold %. */
    private CapacityStatus evaluateStatus(double peak, double avg, Double thresholdPercentObj) {
        double threshold = thresholdPercentObj != null ? thresholdPercentObj : 80.0;
        if (peak >= threshold || avg >= threshold) {
            return CapacityStatus.CRITICAL;
        } else if (peak >= (threshold * 0.8) || avg >= (threshold * 0.8)) {
            return CapacityStatus.WARNING;
        }
        return CapacityStatus.NORMAL;
    }

    /** First LINK_UTILISATION capacity record for an element, or the first record if none, else null. */
    private CapacityRecord findLinkUtilisationRecord(Long elementId) {
        List<CapacityRecord> records = capacityRepo.findByElement_ElementId(elementId);
        if (records == null || records.isEmpty()) {
            return null;
        }
        return records.stream()
                .filter(r -> r.getMetricType() == MetricType.LINK_UTILISATION)
                .findFirst()
                .orElse(records.get(0));
    }

    /**
     * Return the first capacity record of an affected element whose utilisation is
     * over its threshold (both peak AND average greater than the threshold %), or
     * null if none. Uses the same affectedElementIds token formats as
     * {@link #setAffectedElementsStatus}.
     */
    private CapacityRecord findOverThresholdRecord(String affectedElementIds) {
        if (affectedElementIds == null || affectedElementIds.isBlank()) {
            return null;
        }
        for (String token : affectedElementIds.split(",")) {
            String t = token.trim();
            if (t.isEmpty() || t.toLowerCase().startsWith("circuit:")) {
                continue;
            }
            String num = t.contains(":") ? t.substring(t.indexOf(':') + 1) : t;
            try {
                Long elementId = Long.parseLong(num.trim());
                List<CapacityRecord> records = capacityRepo.findByElement_ElementId(elementId);
                if (records != null) {
                    for (CapacityRecord r : records) {
                        double peak = r.getPeakValue() != null ? r.getPeakValue() : 0.0;
                        double avg = r.getAverageValue() != null ? r.getAverageValue() : 0.0;
                        double threshold = r.getThresholdPercent() != null ? r.getThresholdPercent() : 100.0;
                        if (peak > threshold || avg > threshold) {
                            return r;
                        }
                    }
                }
            } catch (NumberFormatException ignored) {
                // Skip malformed tokens.
            }
        }
        return null;
    }

    /**
     * Set the status of every element referenced by a maintenance window's
     * affectedElementIds string. Supported token formats: "4", "element:4"
     * (auto-scheduled windows) and comma-separated lists. "circuit:*" tokens
     * are ignored.
     */
    private void setAffectedElementsStatus(String affectedElementIds, ElementStatus status) {
        if (affectedElementIds == null || affectedElementIds.isBlank()) {
            return;
        }
        for (String token : affectedElementIds.split(",")) {
            String t = token.trim();
            if (t.isEmpty() || t.toLowerCase().startsWith("circuit:")) {
                continue;
            }
            String num = t.contains(":") ? t.substring(t.indexOf(':') + 1) : t;
            try {
                Long id = Long.parseLong(num.trim());
                elementRepo.findById(id).ifPresent(el -> {
                    el.setStatus(status);
                    elementRepo.save(el);
                });
            } catch (NumberFormatException ignored) {
                // Skip malformed tokens.
            }
        }
    }


    // MAPPINGS

    private CapacityRecordResponseDTO mapCapacityToResponse(CapacityRecord record) {
        if (record == null) return null;
        return CapacityRecordResponseDTO.builder()
                .capacityId(record.getCapacityId())
                .elementId(record.getElement() != null ? record.getElement().getElementId() : null)
                .elementName(record.getElement() != null ? record.getElement().getElementName() : null)
                .metricType(record.getMetricType())
                .peakValue(clampPercent(record.getPeakValue()))
                .averageValue(clampPercent(record.getAverageValue()))
                .thresholdPercent(clampPercent(record.getThresholdPercent()))
                .recordedDate(record.getRecordedDate())
                .status(record.getStatus())
                .build();
    }

    private CapacityRecord mapCapacityToEntity(CapacityRecordRequestDTO request) {
        if (request == null) return null;
        CapacityRecord record = new CapacityRecord();
        if (request.getElementId() != null) {
            NetworkElement el = new NetworkElement();
            el.setElementId(request.getElementId());
            record.setElement(el);
        }
        record.setMetricType(request.getMetricType());
        record.setPeakValue(request.getPeakValue());
        record.setAverageValue(request.getAverageValue());
        record.setThresholdPercent(request.getThresholdPercent());
        return record;
    }

    private MaintenanceWindowResponseDTO mapMaintenanceToResponse(MaintenanceWindow window) {
        if (window == null) return null;
        return MaintenanceWindowResponseDTO.builder()
                .maintenanceId(window.getMaintenanceId())
                .title(window.getTitle())
                .affectedElementIds(window.getAffectedElementIds())
                .maintenanceType(window.getMaintenanceType())
                .startDateTime(window.getStartDateTime())
                .endDateTime(window.getEndDateTime())
                .requestedById(window.getRequestedById())
                .approvedById(window.getApprovedById())
                .rollbackPlan(window.getRollbackPlan())
                .status(window.getStatus())
                .build();
    }

    private MaintenanceWindow mapMaintenanceToEntity(MaintenanceWindowRequestDTO request) {
        if (request == null) return null;
        MaintenanceWindow window = new MaintenanceWindow();
        window.setTitle(request.getTitle());
        window.setAffectedElementIds(request.getAffectedElementIds());
        window.setMaintenanceType(request.getMaintenanceType());
        window.setStartDateTime(request.getStartDateTime());
        window.setEndDateTime(request.getEndDateTime());
        window.setRollbackPlan(request.getRollbackPlan());
        window.setStatus(request.getStatus());
        return window;
    }
}
