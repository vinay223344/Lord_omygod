package com.example.NetWatch.enums;


public enum AlarmSource {
    MANUAL,
    MAINTENANCE
}
