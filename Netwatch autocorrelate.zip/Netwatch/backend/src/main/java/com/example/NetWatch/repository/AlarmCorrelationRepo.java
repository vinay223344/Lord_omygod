package com.example.NetWatch.repository;

import com.example.NetWatch.entity.AlarmCorrelation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlarmCorrelationRepo extends JpaRepository<AlarmCorrelation, String> {
}
