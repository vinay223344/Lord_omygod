package com.example.NetWatch.entity;

import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.Severity;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class AlarmCorrelation {

    /** Stable synthetic id for the cluster, e.g. "CORR-SITE-3". */
    @Id
    private String correlationId;

    // ── Where the cluster is located ──────────────────────────────────────────
    private Long siteId;
    private String siteName;

    // ── Cluster summary ────────────────────────────────────────────────────────
    private int alarmCount;

    @Enumerated(EnumType.STRING)
    private Severity highestSeverity;

    private String windowStart;
    private String windowEnd;
    // ── Probable root cause (display only) ──────────────────────────────────────
    private Long rootCauseAlarmId;
    private String rootCauseElementName;

    @Enumerated(EnumType.STRING)
    private AlarmType rootCauseType;

    @Enumerated(EnumType.STRING)
    private Severity rootCauseSeverity;

    @Column(length = 1000)
    private String rootCauseReason;
}
