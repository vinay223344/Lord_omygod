package com.example.NetWatch.service;

import com.example.NetWatch.entity.AlarmCorrelation;
import com.example.NetWatch.entity.NetworkAlarm;
import com.example.NetWatch.entity.NetworkSite;
import com.example.NetWatch.enums.AlarmStatus;
import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.repository.AlarmCorrelationRepo;
import com.example.NetWatch.repository.AlarmRepo;
import com.example.NetWatch.responsedto.AlarmCorrelationResponseDTO;
import com.example.NetWatch.responsedto.NetworkAlarmResponseDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class AlarmCorrelationServiceImp implements AlarmCorrelationService {

    @Autowired
    private AlarmRepo alarmRepo;

    @Autowired
    private AlarmCorrelationRepo alarmCorrelationRepo;

    @Override
    public List<AlarmCorrelationResponseDTO> getCorrelations() {


        List<NetworkAlarm> activeAlarms = new ArrayList<>();
        for (NetworkAlarm alarm : alarmRepo.findAll()) {
            if (alarm.getStatus() != AlarmStatus.CLEARED) {
                activeAlarms.add(alarm);
            }
        }

        Map<Long, List<NetworkAlarm>> alarmsBySite = new LinkedHashMap<>();
        for (NetworkAlarm alarm : activeAlarms) {
            NetworkSite site = resolveSite(alarm);
            if (site == null || site.getSiteId() == null) {
                continue;
            }
            alarmsBySite
                    .computeIfAbsent(site.getSiteId(), key -> new ArrayList<>())
                    .add(alarm);
        }

        // STEP 3 — turn each site group into one correlation cluster.
        List<AlarmCorrelationResponseDTO> correlations = new ArrayList<>();
        for (List<NetworkAlarm> siteGroup : alarmsBySite.values()) {
            correlations.add(buildCluster(siteGroup));
        }

        correlations.sort((a, b) -> {
            int bySeverity = severityRank(a.getHighestSeverity()) - severityRank(b.getHighestSeverity());
            if (bySeverity != 0) {
                return bySeverity;
            }
            return b.getAlarmCount() - a.getAlarmCount();
        });

        persistSnapshot(correlations);

        return correlations;
    }

    // ── Cluster construction ────────────────────────────────────────────────────

    /** Summarise one site's alarms into a single cluster with a chosen root cause. */
    private AlarmCorrelationResponseDTO buildCluster(List<NetworkAlarm> siteGroup) {
        NetworkSite site = resolveSite(siteGroup.get(0));

        // The root cause is the single most important alarm in the group.
        NetworkAlarm rootCause = pickRootCause(siteGroup);

        // Find the earliest and latest alarm times (the "alarm window").
        String windowStart = safeTime(siteGroup.get(0).getAlarmTime());
        String windowEnd = windowStart;
        for (NetworkAlarm alarm : siteGroup) {
            String time = safeTime(alarm.getAlarmTime());
            if (time.compareTo(windowStart) < 0) {
                windowStart = time;
            }
            if (time.compareTo(windowEnd) > 0) {
                windowEnd = time;
            }
        }

        List<NetworkAlarmResponseDTO> alarmDtos = new ArrayList<>();
        for (NetworkAlarm alarm : siteGroup) {
            alarmDtos.add(mapAlarm(alarm));
        }

        return AlarmCorrelationResponseDTO.builder()
                .correlationId("CORR-SITE-" + site.getSiteId())
                .siteId(site.getSiteId())
                .siteName(site.getSiteName())
                .alarmCount(siteGroup.size())
                .highestSeverity(rootCause.getSeverity())
                .windowStart(windowStart)
                .windowEnd(windowEnd)
                .rootCauseAlarmId(rootCause.getAlarmId())
                .rootCauseElementName(rootCause.getElement() != null ? rootCause.getElement().getElementName() : null)
                .rootCauseType(rootCause.getAlarmType())
                .rootCauseSeverity(rootCause.getSeverity())
                .rootCauseReason(buildReason(rootCause, siteGroup.size()))
                .alarms(alarmDtos)
                .build();
    }

    private NetworkAlarm pickRootCause(List<NetworkAlarm> siteGroup) {
        NetworkAlarm best = siteGroup.get(0);
        for (NetworkAlarm candidate : siteGroup) {
            if (isMoreLikelyCause(candidate, best)) {
                best = candidate;
            }
        }
        return best;
    }

    private boolean isMoreLikelyCause(NetworkAlarm candidate, NetworkAlarm current) {
        // 1. More severe wins.
        int severityDiff = severityRank(candidate.getSeverity()) - severityRank(current.getSeverity());
        if (severityDiff != 0) {
            return severityDiff < 0;
        }
        // 2. Same severity → the more "cause-like" alarm type wins.
        int causalityDiff = causalityRank(candidate.getAlarmType()) - causalityRank(current.getAlarmType());
        if (causalityDiff != 0) {
            return causalityDiff < 0;
        }
        // 3. Still tied → the earlier alarm wins.
        return safeTime(candidate.getAlarmTime()).compareTo(safeTime(current.getAlarmTime())) < 0;
    }

    private String buildReason(NetworkAlarm rootCause, int clusterSize) {
        String element = rootCause.getElement() != null ? rootCause.getElement().getElementName() : "an unknown element";
        if (clusterSize <= 1) {
            return "Single active alarm at this site — no correlation with other alarms.";
        }
        return String.format(
                "%s %s on %s is the most probable root cause. The other %d alarm(s) at this site are likely downstream effects of the same incident.",
                rootCause.getSeverity(), rootCause.getAlarmType(), element, clusterSize - 1);
    }

    // ── Ranking helpers ─────────────────────────────────────────────────────────

    /** Lower rank = higher severity. Unknown/null sorts last. */
    private int severityRank(Severity severity) {
        if (severity == null) {
            return Integer.MAX_VALUE;
        }
        return switch (severity) {
            case CRITICAL -> 0;
            case MAJOR -> 1;
            case MINOR -> 2;
            case WARNING -> 3;
        };
    }

    /** Lower rank = more likely a cause than a symptom. Unknown/null sorts last. */
    private int causalityRank(AlarmType type) {
        if (type == null) {
            return Integer.MAX_VALUE;
        }
        return switch (type) {
            case POWER_FAILURE -> 0;     // site-wide power loss usually causes everything else
            case HARDWARE_FAULT -> 1;
            case COOLING_ALERT -> 2;
            case NODE_UNREACHABLE -> 3;
            case LINK_DOWN -> 4;
            case HIGH_UTILISATION -> 5;  // typically a downstream symptom
        };
    }

    // ── Small utilities ─────────────────────────────────────────────────────────

    private NetworkSite resolveSite(NetworkAlarm alarm) {
        if (alarm == null || alarm.getElement() == null) {
            return null;
        }
        return alarm.getElement().getSite();
    }

    private String safeTime(String time) {
        return time == null ? "" : time;
    }

    private NetworkAlarmResponseDTO mapAlarm(NetworkAlarm alarm) {
        return NetworkAlarmResponseDTO.builder()
                .alarmId(alarm.getAlarmId())
                .elementId(alarm.getElement() != null ? alarm.getElement().getElementId() : null)
                .elementName(alarm.getElement() != null ? alarm.getElement().getElementName() : null)
                .alarmType(alarm.getAlarmType())
                .severity(alarm.getSeverity())
                .alarmTime(alarm.getAlarmTime())
                .acknowledgedById(alarm.getAcknowledgedById())
                .acknowledgedTime(alarm.getAcknowledgedTime())
                .clearedTime(alarm.getClearedTime())
                .status(alarm.getStatus())
                .source(alarm.getSource())
                .build();
    }

    // ── MySQL snapshot ────────────────────────────────────────────

    private void persistSnapshot(List<AlarmCorrelationResponseDTO> correlations) {
        if (alarmCorrelationRepo == null) {
            return;
        }
        try {
            alarmCorrelationRepo.deleteAll();
            List<AlarmCorrelation> rows = new ArrayList<>();
            for (AlarmCorrelationResponseDTO dto : correlations) {
                rows.add(toEntity(dto));
            }
            alarmCorrelationRepo.saveAll(rows);
        } catch (Exception ex) {
            log.warn("Could not persist alarm correlation snapshot for MySQL display: {}", ex.getMessage());
        }
    }

    private AlarmCorrelation toEntity(AlarmCorrelationResponseDTO dto) {
        AlarmCorrelation entity = new AlarmCorrelation();
        entity.setCorrelationId(dto.getCorrelationId());
        entity.setSiteId(dto.getSiteId());
        entity.setSiteName(dto.getSiteName());
        entity.setAlarmCount(dto.getAlarmCount());
        entity.setHighestSeverity(dto.getHighestSeverity());
        entity.setWindowStart(dto.getWindowStart());
        entity.setWindowEnd(dto.getWindowEnd());
        entity.setRootCauseAlarmId(dto.getRootCauseAlarmId());
        entity.setRootCauseElementName(dto.getRootCauseElementName());
        entity.setRootCauseType(dto.getRootCauseType());
        entity.setRootCauseSeverity(dto.getRootCauseSeverity());
        entity.setRootCauseReason(dto.getRootCauseReason());
        return entity;
    }
}
