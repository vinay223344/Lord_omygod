package com.example.NetWatch.controller;

import com.example.NetWatch.responsedto.AlarmCorrelationResponseDTO;
import com.example.NetWatch.service.AlarmCorrelationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/alarm-correlation")
public class AlarmCorrelationController {

    @Autowired
    private AlarmCorrelationService service;

    @GetMapping
    @PreAuthorize("hasRole('SERVICE_DESK') or hasRole('ADMIN')")
    public ResponseEntity<List<AlarmCorrelationResponseDTO>> getCorrelations() {
        log.debug("Fetching alarm correlations for Service Desk");
        return ResponseEntity.ok(service.getCorrelations());
    }
}
