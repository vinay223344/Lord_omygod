package com.example.NetWatch.entity;

import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.enums.AlarmStatus;
import com.example.NetWatch.enums.AlarmSource;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Entity
@Data
public class NetworkAlarm {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long alarmId;


    @NotNull(message = "Network element is required")
    @ManyToOne
    @JoinColumn(name = "element_id")
    private NetworkElement element;

    @NotNull(message = "Alarm type is required")
    @Enumerated(EnumType.STRING)
    private AlarmType alarmType;

    @NotNull(message = "Severity is required")
    @Enumerated(EnumType.STRING)
    private Severity severity;

    private String alarmTime;

    private Long acknowledgedById;
    private String acknowledgedTime;

    private String clearedTime;

    @NotNull(message = "Status is required")
    @Enumerated(EnumType.STRING)
    private AlarmStatus status;

    @Enumerated(EnumType.STRING)
    private AlarmSource source;
}