package com.example.NetWatch.requestdto;

import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.enums.AlarmStatus;
import com.example.NetWatch.enums.AlarmSource;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NetworkAlarmRequestDTO {
    @NotNull(message = "Element ID is required")
    private Long elementId;
    private AlarmType alarmType;
    private Severity severity;
    private AlarmStatus status;
    private AlarmSource source;
}

