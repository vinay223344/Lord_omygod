package com.example.NetWatch.responsedto;

import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.enums.AlarmStatus;
import com.example.NetWatch.enums.AlarmSource;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NetworkAlarmResponseDTO {
    private Long alarmId;
    private Long elementId;
    private String elementName;
    private AlarmType alarmType;
    private Severity severity;
    private String alarmTime;
    private Long acknowledgedById;
    private String acknowledgedTime;
    private String clearedTime;
    private AlarmStatus status;
    private AlarmSource source;
}
