package com.example.NetWatch.responsedto;

import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.Severity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AlarmCorrelationResponseDTO {

    /** Stable synthetic id for the cluster, e.g. "CORR-SITE-3". */
    private String correlationId;

    // ── Where the cluster is located ──────────────────────────────────────────
    private Long siteId;
    private String siteName;

    // ── Cluster summary ────────────────────────────────────────────────────────
    private int alarmCount;
    private Severity highestSeverity;
    private String windowStart;
    private String windowEnd;

    // ── Probable root cause (display only, no side effects) ─────────────────────
    private Long rootCauseAlarmId;
    private String rootCauseElementName;
    private AlarmType rootCauseType;
    private Severity rootCauseSeverity;
    private String rootCauseReason;

    // ── The individual alarms that make up the cluster ──────────────────────────
    private List<NetworkAlarmResponseDTO> alarms;
}
