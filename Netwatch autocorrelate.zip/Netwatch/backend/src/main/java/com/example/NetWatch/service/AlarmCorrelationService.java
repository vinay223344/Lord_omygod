package com.example.NetWatch.service;

import com.example.NetWatch.responsedto.AlarmCorrelationResponseDTO;

import java.util.List;

/**
 * Builds correlated alarm clusters (grouped by site) with a probable root cause.
 * Read-only: it never modifies alarms, tickets, or any other data.
 */
public interface AlarmCorrelationService {
    List<AlarmCorrelationResponseDTO> getCorrelations();
}
