INSERT INTO network_site (site_id, address, site_name, site_type, status) VALUES
-- Chennai
(1, 'Chennai', 'Chennai Data Centre', 'DATACENTRE', 'ACTIVE'),
(2, 'Chennai', 'Chennai POP', 'POP', 'ACTIVE'),
(3, 'Chennai', 'Chennai Exchange', 'EXCHANGE', 'ACTIVE'),
(4, 'Chennai', 'Chennai Tower', 'TOWER', 'ACTIVE'),
(5, 'Chennai', 'Chennai Remote Node', 'REMOTE_NODE', 'ACTIVE'),

-- Coimbatore
(6, 'Coimbatore', 'Coimbatore Data Centre', 'DATACENTRE', 'ACTIVE'),
(7, 'Coimbatore', 'Coimbatore POP', 'POP', 'ACTIVE'),
(8, 'Coimbatore', 'Coimbatore Exchange', 'EXCHANGE', 'ACTIVE'),
(9, 'Coimbatore', 'Coimbatore Tower', 'TOWER', 'ACTIVE'),
(10, 'Coimbatore', 'Coimbatore Remote Node', 'REMOTE_NODE', 'ACTIVE'),

-- Bangalore
(11, 'Bangalore', 'Bangalore Data Centre', 'DATACENTRE', 'ACTIVE'),
(12, 'Bangalore', 'Bangalore POP', 'POP', 'ACTIVE'),
(13, 'Bangalore', 'Bangalore Exchange', 'EXCHANGE', 'ACTIVE'),
(14, 'Bangalore', 'Bangalore Tower', 'TOWER', 'ACTIVE'),
(15, 'Bangalore', 'Bangalore Remote Node', 'REMOTE_NODE', 'ACTIVE'),

-- Hyderabad
(16, 'Hyderabad', 'Hyderabad Data Centre', 'DATACENTRE', 'ACTIVE'),
(17, 'Hyderabad', 'Hyderabad POP', 'POP', 'ACTIVE'),
(18, 'Hyderabad', 'Hyderabad Exchange', 'EXCHANGE', 'ACTIVE'),
(19, 'Hyderabad', 'Hyderabad Tower', 'TOWER', 'ACTIVE'),
(20, 'Hyderabad', 'Hyderabad Remote Node', 'REMOTE_NODE', 'ACTIVE'),

-- Mumbai
(21, 'Mumbai', 'Mumbai Data Centre', 'DATACENTRE', 'ACTIVE'),
(22, 'Mumbai', 'Mumbai POP', 'POP', 'ACTIVE'),
(23, 'Mumbai', 'Mumbai Exchange', 'EXCHANGE', 'ACTIVE'),
(24, 'Mumbai', 'Mumbai Tower', 'TOWER', 'ACTIVE'),
(25, 'Mumbai', 'Mumbai Remote Node', 'REMOTE_NODE', 'ACTIVE');


INSERT INTO network_element
(element_id, element_name, element_type, vendor, model, ip_address, site_id, status)
VALUES
(101,'CHN-DC-RTR','ROUTER','Cisco','ASR1001','10.1.1.1',1,'ACTIVE'),
(102,'CHN-POP-SW','SWITCH','Cisco','Catalyst9500','10.1.2.1',2,'ACTIVE'),
(103,'CHN-EX-RTR','ROUTER','Juniper','MX480','10.1.3.1',3,'ACTIVE'),
(104,'CHN-TWR-BTS','BTS','Nokia','AirScale','10.1.4.1',4,'ACTIVE'),
(105,'CHN-RN-RTR','ROUTER','Huawei','NE40E','10.1.5.1',5,'ACTIVE'),

(106,'CBE-DC-RTR','ROUTER','Cisco','ASR1001','10.2.1.1',6,'ACTIVE'),
(107,'CBE-POP-SW','SWITCH','Cisco','Catalyst9500','10.2.2.1',7,'ACTIVE'),
(108,'CBE-EX-RTR','ROUTER','Juniper','MX480','10.2.3.1',8,'ACTIVE'),
(109,'CBE-TWR-BTS','BTS','Nokia','AirScale','10.2.4.1',9,'ACTIVE'),
(110,'CBE-RN-RTR','ROUTER','Huawei','NE40E','10.2.5.1',10,'ACTIVE'),

(111,'BLR-DC-RTR','ROUTER','Cisco','ASR1001','10.3.1.1',11,'ACTIVE'),
(112,'BLR-POP-SW','SWITCH','Cisco','Catalyst9500','10.3.2.1',12,'ACTIVE'),
(113,'BLR-EX-RTR','ROUTER','Juniper','MX480','10.3.3.1',13,'ACTIVE'),
(114,'BLR-TWR-BTS','BTS','Nokia','AirScale','10.3.4.1',14,'ACTIVE'),
(115,'BLR-RN-RTR','ROUTER','Huawei','NE40E','10.3.5.1',15,'ACTIVE'),

(116,'HYD-DC-RTR','ROUTER','Cisco','ASR1001','10.4.1.1',16,'ACTIVE'),
(117,'HYD-POP-SW','SWITCH','Cisco','Catalyst9500','10.4.2.1',17,'ACTIVE'),
(118,'HYD-EX-RTR','ROUTER','Juniper','MX480','10.4.3.1',18,'ACTIVE'),
(119,'HYD-TWR-BTS','BTS','Nokia','AirScale','10.4.4.1',19,'ACTIVE'),
(120,'HYD-RN-RTR','ROUTER','Huawei','NE40E','10.4.5.1',20,'ACTIVE'),

(121,'MUM-DC-RTR','ROUTER','Cisco','ASR1001','10.5.1.1',21,'ACTIVE'),
(122,'MUM-POP-SW','SWITCH','Cisco','Catalyst9500','10.5.2.1',22,'ACTIVE'),
(123,'MUM-EX-RTR','ROUTER','Juniper','MX480','10.5.3.1',23,'ACTIVE'),
(124,'MUM-TWR-BTS','BTS','Nokia','AirScale','10.5.4.1',24,'ACTIVE'),
(125,'MUM-RN-RTR','ROUTER','Huawei','NE40E','10.5.5.1',25,'ACTIVE');



INSERT INTO topology_link

(link_id, link_type, status, capacity_mbps, utilisation_percent, element_a_id, element_b_id)

VALUES

(1,'ETHERNET','ACTIVE',10000,45,101,102),

(2,'FIBRE','ACTIVE',5000,55,102,103),

(3,'MICROWAVE','ACTIVE',1000,60,103,104),

(4,'SDH','ACTIVE',500,35,104,105),


(5,'ETHERNET','ACTIVE',10000,50,106,107),

(6,'FIBRE','ACTIVE',5000,58,107,108),

(7,'MICROWAVE','ACTIVE',1000,62,108,109),

(8,'SDH','ACTIVE',500,40,109,110),


(9,'ETHERNET','ACTIVE',10000,48,111,112),

(10,'FIBRE','ACTIVE',5000,53,112,113),

(11,'MICROWAVE','ACTIVE',1000,67,113,114),

(12,'SDH','ACTIVE',500,38,114,115),


(15,'ETHERNET','ACTIVE',10000,46,116,117),

(16,'FIBRE','ACTIVE',5000,57,117,118),

(17,'MICROWAVE','ACTIVE',1000,64,118,119),

(18,'SDH','ACTIVE',500,42,119,120),


(19,'ETHERNET','ACTIVE',10000,51,121,122),

(20,'FIBRE','ACTIVE',5000,56,122,123),

(21,'MICROWAVE','ACTIVE',1000,61,123,124),

(22,'SDH','ACTIVE',500,39,124,125);