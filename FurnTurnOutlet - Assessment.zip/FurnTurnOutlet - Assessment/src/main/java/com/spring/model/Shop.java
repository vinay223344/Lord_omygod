package com.spring.model;

import java.util.Map;

//Use proper annotation to define the class as a Component

public class Shop {
    
	//Use proper annotation
	private String shopName;
	
	//Use proper annotation
	private String shopLocation;
	
	//Use proper annotation
	private Map<String,Integer> discountDetails;

	public String getShopName() {
		return shopName;
	}
	public void setShopName(String shopName) {
		this.shopName = shopName;
	}
	public String getShopLocation() {
		return shopLocation;
	}
	public void setShopLocation(String shopLocation) {
		this.shopLocation = shopLocation;
	}
	public Map<String, Integer> getDiscountDetails() {
		return discountDetails;
	}
	public void setDiscountDetails(Map<String, Integer> discountDetails) {
		this.discountDetails = discountDetails;
	}	
	
}
