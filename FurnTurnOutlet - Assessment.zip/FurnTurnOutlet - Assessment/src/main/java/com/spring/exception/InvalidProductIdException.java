package com.spring.exception;

public class InvalidProductIdException extends Exception {

	public InvalidProductIdException(String msg) {

		// fill the code
	}

}
