package com.spring.bo;

import com.spring.model.Product;

//Use proper annotation to define the class as a Component

public class ProductBO {
	
	public double calculateBill(Product furObj,String woodType) {

		double amount=0;
		
		// fill the code
		
		return amount;
	}

}
