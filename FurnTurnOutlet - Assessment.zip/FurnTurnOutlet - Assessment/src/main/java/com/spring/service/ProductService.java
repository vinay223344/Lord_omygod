package com.spring.service;

import com.spring.bo.ProductBO;

//Use proper annotation to define the class as a Component
public class ProductService {
	
	private ProductBO productBOObj;

//Use proper annotation 
	public ProductService(ProductBO productBOObj) {
		super();
		this.productBOObj = productBOObj;
	}

	public ProductBO getProductBOObj() {
		return productBOObj;
	}

	public void setProductBOObj(ProductBO productBOObj) {
		this.productBOObj = productBOObj;
	}

	public double calculateBill(String productId,String productName,double mrpValue,String dimension, String woodType) {

		double amount=0;
		// fill the code
		return amount;
	}

}
