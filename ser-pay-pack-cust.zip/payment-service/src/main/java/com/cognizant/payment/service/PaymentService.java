package com.cognizant.payment.service;

import java.util.List;

import com.cognizant.payment.dto.PaymentRequestDTO;
import com.cognizant.payment.dto.PaymentResponseDTO;

public interface PaymentService {

    // CREATE PAYMENT (returns message)
    String createPayment(PaymentRequestDTO dto);

    // GET PAYMENT BY ID
    PaymentResponseDTO getPaymentById(Long id);

    // GET ALL PAYMENTS
    List<PaymentResponseDTO> getAllPayments();

    // DELETE (CANCEL)
    void deletePayment(Long id);
}