package com.cognizant.payment.service;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.payment.dto.BookingResponseDTO;
import com.cognizant.payment.dto.PaymentRequestDTO;
import com.cognizant.payment.dto.PaymentResponseDTO;
import com.cognizant.payment.entity.PaymentEntity;
import com.cognizant.payment.exceptions.BookingNotFoundException;
import com.cognizant.payment.exceptions.PaymentNotFoundException;
import com.cognizant.payment.feign.BookingClient;
import com.cognizant.payment.repository.PaymentRepository;

import feign.FeignException;

@Service
public class PaymentServiceImpl implements PaymentService {

    private PaymentRepository repository;
    private BookingClient bookingClient;

    public PaymentServiceImpl(PaymentRepository repository,
                             BookingClient bookingClient) {
        this.repository = repository;
        this.bookingClient = bookingClient;
    }

    // ✅ CREATE PAYMENT = ACTUAL PAYMENT ✅🔥
    @Override
    public String createPayment(PaymentRequestDTO dto) {

        BookingResponseDTO booking;
        
        
        // ✅ Validate booking
        try {
            booking = bookingClient.getBookingById(dto.getBookingId());
        } catch (FeignException.NotFound ex) {
            throw new BookingNotFoundException("Booking not found with id "+dto.getBookingId());
        }

        // ✅ Create Payment
        PaymentEntity entity = new PaymentEntity();

        entity.setBookingId(dto.getBookingId());
        entity.setPaymentMethod(dto.getPaymentMethod());
        entity.setAmount(booking.getTotalAmount());

        // ✅ DIRECT SUCCESS ✅
        entity.setPaymentStatus("SUCCESS");
        entity.setPaymentDate(LocalDateTime.now());

        repository.save(entity);

        // ✅ UPDATE BOOKING ✅🔥
        bookingClient.updateBookingPaymentStatus(
                dto.getBookingId(),
                "SUCCESS"
        );

        return "Payment done successfully. Booking confirmed.";
    }

    // GET BY ID
    @Override
    public PaymentResponseDTO getPaymentById(Long id) {

        PaymentEntity p = repository.findById(id)
                .orElseThrow(() -> new PaymentNotFoundException("Payment not found"));

        return map(p);
    }

    // ✅ GET ALL
    @Override
    public List<PaymentResponseDTO> getAllPayments() {

        List<PaymentResponseDTO> list = new ArrayList<>();

        for (PaymentEntity p : repository.findAll()) {
            list.add(map(p));
        }

        return list;
    }

    // ✅ DELETE
    @Override
    public void deletePayment(Long id) {

        PaymentEntity p = repository.findById(id)
                .orElseThrow(() -> new PaymentNotFoundException("Payment not found"));

       

        repository.delete(p);
    }

    // ✅ MAP
    private PaymentResponseDTO map(PaymentEntity e) {

        PaymentResponseDTO dto = new PaymentResponseDTO();

        dto.setId(e.getId());
        dto.setBookingId(e.getBookingId());
        dto.setPaymentMethod(e.getPaymentMethod());
        dto.setPaymentStatus(e.getPaymentStatus());
        dto.setAmount(e.getAmount());
        dto.setPaymentDate(e.getPaymentDate());

        return dto;
    }
}