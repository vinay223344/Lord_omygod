package com.cognizant.payment.controller;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.payment.dto.PaymentRequestDTO;
import com.cognizant.payment.dto.PaymentResponseDTO;
import com.cognizant.payment.service.PaymentService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;





@RestController
@RequestMapping("/api/payments")
@Tag(name = "Payment API", description = "Handles payment operations")
public class PaymentController {

    private PaymentService service;

    public PaymentController(PaymentService service) {
        this.service = service;
    }

    // ✅ CREATE PAYMENT (PAY)
    @Operation(summary = "Make payment for a booking")
    @PostMapping("/pay")
    public ResponseEntity<String> createPayment(@Valid @RequestBody PaymentRequestDTO dto) {

        String response = service.createPayment(dto);
        return ResponseEntity.ok(response);
    }

    // ✅ GET PAYMENT BY ID
    @Operation(summary = "Get payment details by ID")
    @GetMapping("/{id}")
    public ResponseEntity<PaymentResponseDTO> getById(@PathVariable Long id) {

        return ResponseEntity.ok(service.getPaymentById(id));
    }

    // ✅ GET ALL PAYMENTS
    @Operation(summary = "Get all payments")
    @GetMapping
    public ResponseEntity<List<PaymentResponseDTO>> getAll() {

        return ResponseEntity.ok(service.getAllPayments());
    }

    // ✅ DELETE / CANCEL PAYMENT
    @Operation(summary = "Cancel a payment")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {

        service.deletePayment(id);
        return ResponseEntity.ok("Payment cancelled successfully");
    }
}