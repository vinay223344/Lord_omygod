package com.cognizant.payment.dto;

import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Payment response DTO")
public class PaymentResponseDTO {

    @Schema(description = "Payment ID", example = "1")
    private Long id;

    @Schema(description = "Booking ID", example = "450")
    private Long bookingId;

    @Schema(description = "Payment Method", example = "Credit Card")
    private String paymentMethod;

    @Schema(description = "Payment Status",
            example = "SUCCESS",
            allowableValues = {"PENDING", "SUCCESS", "FAILED", "CANCELLED"})
    private String paymentStatus;

    @Schema(description = "Amount", example = "1250.00")
    private Double amount;

    @Schema(description = "Payment Date", example = "2025-07-28T10:00:00")
    private LocalDateTime paymentDate;
}
