package com.cognizant.payment.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "DTO for creating a payment request")
public class PaymentRequestDTO {

    @NotNull(message = "Booking ID is required")
    @Schema(description = "Booking ID for which payment is made", example = "450")
    private Long bookingId;

    @NotBlank(message = "Payment method is required")
    @Schema(description = "Mode of payment", example = "Credit Card")
    private String paymentMethod;   
}
