package com.cognizant.payment.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.cognizant.payment.dto.BookingResponseDTO;

@FeignClient(name = "BOOKING-SERVICE")  // ✅ service name in Eureka / application.yml
public interface BookingClient {

    // GET booking details (amount, etc.)
    @GetMapping("/api/bookings/{id}")
    BookingResponseDTO getBookingById(@PathVariable Long id);

    // UPDATE booking after payment success
    @PutMapping("/api/bookings/{id}/payment-status")
    void updateBookingPaymentStatus(@PathVariable Long id,
                                   @RequestParam String paymentStatus);
}