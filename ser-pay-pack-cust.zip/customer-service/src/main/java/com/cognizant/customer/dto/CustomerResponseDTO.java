package com.cognizant.customer.dto;


import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerResponseDTO {

    @Schema(description = "Customer ID", example = "1")
    private Long id;

    @Schema(description = "First name", example = "Alex")
    private String firstName;

    @Schema(description = "Last name", example = "Smith")
    private String lastName;

    @Schema(description = "Email address", example = "alex.smith@email.com")
    private String email;

    @Schema(description = "Phone number", example = "+31 612345678")
    private String phone;

    @Schema(description = "Address", example = "456 Canal Street, Leeuwarden")
    private String address;

    @Schema(description = "Created date", example = "2025-07-28T09:30:00")
    private LocalDateTime createdAt;
}
