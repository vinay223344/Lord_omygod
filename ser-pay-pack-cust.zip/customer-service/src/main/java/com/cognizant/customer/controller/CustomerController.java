package com.cognizant.customer.controller;

import java.util.List;
import java.util.Optional;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cognizant.customer.dto.CustomerRequestDTO;
import com.cognizant.customer.dto.CustomerResponseDTO;
import com.cognizant.customer.service.CustomerService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/customers")
@Tag(name = "Customer API", description = "Operations related to Customer management")
public class CustomerController {

    private CustomerService service;

    public CustomerController(CustomerService service) {
        this.service = service;
    }

    
    @Operation(summary = "Create a new customer",
               description = "Creates a new customer record with validation and returns created customer details")
    @PostMapping("/create")
    public ResponseEntity<CustomerResponseDTO> createCustomer(
            @Valid @RequestBody CustomerRequestDTO dto) {

        CustomerResponseDTO response = service.createCustomer(dto);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    
    @Operation(summary = "Get all customers",
               description = "Fetches list of all customers")
    @GetMapping
    public ResponseEntity<List<CustomerResponseDTO>> getAllCustomers() {

        List<CustomerResponseDTO> customers = service.getAllCustomers();
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

   
    @Operation(summary = "Get customer by ID",
               description = "Fetches a customer using the given ID")
    @GetMapping("/{id}")
    public ResponseEntity<CustomerResponseDTO> getCustomerById(@PathVariable Long id) {

        Optional<CustomerResponseDTO> customer = service.getCustomerById(id);

        return customer
                .map(response -> new ResponseEntity<>(response, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    
    @Operation(summary = "Update customer",
               description = "Updates existing customer details using ID")
    @PutMapping("/{id}")
    public ResponseEntity<CustomerResponseDTO> updateCustomer(
            @PathVariable Long id,
            @Valid @RequestBody CustomerRequestDTO dto) {

        CustomerResponseDTO updated = service.updateCustomer(id, dto);

        return ResponseEntity.ok(updated);
    }

    
    @Operation(summary = "Delete customer",
               description = "Deletes a customer by ID")
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCustomer(@PathVariable Long id) {

        boolean deleted = service.deleteCustomer(id);

        if (deleted) {
            return new ResponseEntity<>("Customer deleted successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Customer not found", HttpStatus.NOT_FOUND);
        }
    }
}
