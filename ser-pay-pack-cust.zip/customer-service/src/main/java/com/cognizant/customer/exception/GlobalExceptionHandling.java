package com.cognizant.customer.exception;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandling {

@ExceptionHandler(CustomerNotFoundException.class)
    public ResponseEntity<String> handleCustomerNotFound(CustomerNotFoundException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
    }

@ExceptionHandler(DuplicateCustomerFoundException.class)
   public ResponseEntity<String> handleDuplicateCustomer(DuplicateCustomerFoundException ex) {
       return new ResponseEntity<>(ex.getMessage(), HttpStatus.CONFLICT);
   }


}
