package com.cognizant.customer.entity;

import java.time.LocalDateTime;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "customers")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CustomerEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Customer ID", example = "1")
    private Long id;

    @Column(name = "first_name", nullable = false)
    @NotBlank(message = "First name is required")
    @Schema(description = "First name", example = "Alex")
    private String firstName;

    @Column(name = "last_name", nullable = false)
    @NotBlank(message = "Last name is required")
    @Schema(description = "Last name", example = "Smith")
    private String lastName;

    @Column(nullable = false)
    @Email(message = "Invalid email")
    @NotBlank(message = "Email is required")
    @Schema(description = "Email address", example = "alex.smith@email.com")
    private String email;

    @Column(nullable = false)
    @NotBlank(message = "Phone is required")
    @Schema(description = "Phone number", example = "+31 612345678")
    private String phone;

    @Column(nullable = false)
    @NotBlank(message = "Address is required")
    @Schema(description = "Address", example = "456 Canal Street, Leeuwarden")
    private String address;

    @Column(name = "created_at", nullable = false)
    @Schema(description = "Created date", example = "2025-07-28T09:30:00")
    private LocalDateTime createdAt;
    
}