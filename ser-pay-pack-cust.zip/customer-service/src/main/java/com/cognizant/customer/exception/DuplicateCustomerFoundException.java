package com.cognizant.customer.exception;

public class DuplicateCustomerFoundException extends RuntimeException {

	
	public DuplicateCustomerFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
