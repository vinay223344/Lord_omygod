package com.cognizant.customer.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cognizant.customer.dto.CustomerRequestDTO;
import com.cognizant.customer.dto.CustomerResponseDTO;
import com.cognizant.customer.entity.CustomerEntity;
import com.cognizant.customer.exception.CustomerNotFoundException;
import com.cognizant.customer.exception.DuplicateCustomerFoundException;
import com.cognizant.customer.repository.CustomerRepository;

@Service
public class CustomerService {

    private CustomerRepository repository;

    public CustomerService(CustomerRepository repository) {
        this.repository = repository;
    }

    // ✅ Create (DTO → Entity)
    public CustomerResponseDTO createCustomer(CustomerRequestDTO dto) {


        Optional<CustomerEntity> existing = repository.findByEmail(dto.getEmail());

         if (existing.isPresent()) {
              throw new DuplicateCustomerFoundException(
               "Customer already exists with email: " + dto.getEmail());
           }

        CustomerEntity entity = new CustomerEntity();

        entity.setFirstName(dto.getFirstName());
        entity.setLastName(dto.getLastName());
        entity.setEmail(dto.getEmail());
        entity.setPhone(dto.getPhone());
        entity.setAddress(dto.getAddress());

        entity.setCreatedAt(LocalDateTime.now());

        CustomerEntity saved = repository.save(entity);

        return mapToDTO(saved);
    }

    // ✅ Get All
    public List<CustomerResponseDTO> getAllCustomers() {

    List<CustomerEntity> list = repository.findAll();

    if (list.isEmpty()) {
        throw new CustomerNotFoundException("No customers found");
    }

    List<CustomerResponseDTO> result = new java.util.ArrayList<>();

    for (CustomerEntity entity : list) {
        result.add(mapToDTO(entity));
    }

    return result;

    }

    // ✅ Get By ID
    public Optional<CustomerResponseDTO> getCustomerById(Long id) {
        return repository.findById(id)
                .map(this::mapToDTO);
    }

    // ✅ Update (DTO → Entity)
    public CustomerResponseDTO updateCustomer(Long id, CustomerRequestDTO dto) {

        CustomerEntity existing = repository.findById(id)
                .orElseThrow(() -> new CustomerNotFoundException("Customer not found"));

        existing.setFirstName(dto.getFirstName());
        existing.setLastName(dto.getLastName());
        existing.setEmail(dto.getEmail());
        existing.setPhone(dto.getPhone());
        existing.setAddress(dto.getAddress());

        CustomerEntity saved = repository.save(existing);

        return mapToDTO(saved);
    }

    // ✅ Delete
    public boolean deleteCustomer(Long id) {
        Optional<CustomerEntity> existing = repository.findById(id);

        if (existing.isPresent()) {
            repository.delete(existing.get());
            return true;
        }

        return false;
    }

    // ✅ Entity → DTO
    private CustomerResponseDTO mapToDTO(CustomerEntity entity) {
        return new CustomerResponseDTO(
                entity.getId(),
                entity.getFirstName(),
                entity.getLastName(),
                entity.getEmail(),
                entity.getPhone(),
                entity.getAddress(),
                entity.getCreatedAt()
        );
    }
}