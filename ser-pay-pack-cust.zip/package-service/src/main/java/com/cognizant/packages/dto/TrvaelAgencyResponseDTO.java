package com.cognizant.packages.dto;

import lombok.Data;

@Data
public class TrvaelAgencyResponseDTO {
    private Long id;
    private String name;
}