package com.cognizant.packages.controller;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cognizant.packages.dto.TravelPackageRequestDTO;
import com.cognizant.packages.dto.TravelPackageResponseDTO;
import com.cognizant.packages.service.TravelPackageService;

@RestController
@RequestMapping("/api/packages")
public class TravelPackageController {

    private TravelPackageService service;

    public TravelPackageController(TravelPackageService service) {
        this.service = service;
    }

    @PostMapping("/create")
    public ResponseEntity<TravelPackageResponseDTO> createPackage(
            @Valid @RequestBody TravelPackageRequestDTO dto) {

        TravelPackageResponseDTO response = service.createPackage(dto);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<TravelPackageResponseDTO>> getAllPackages() {

        return ResponseEntity.ok(service.getAllPackages());
    }

    @GetMapping("/{id}")
    public ResponseEntity<TravelPackageResponseDTO> getPackageById(
            @PathVariable Long id) {

        return ResponseEntity.ok(service.getPackageById(id));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TravelPackageResponseDTO> updatePackage(
            @PathVariable Long id,
            @Valid @RequestBody TravelPackageRequestDTO dto) {

        return ResponseEntity.ok(service.updatePackage(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePackage(@PathVariable Long id) {

        service.deletePackage(id);
        return ResponseEntity.ok("Package deleted successfully");
    }
}