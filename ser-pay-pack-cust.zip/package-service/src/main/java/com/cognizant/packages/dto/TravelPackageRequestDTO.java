package com.cognizant.packages.dto;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Travel Package Request DTO")
public class TravelPackageRequestDTO {

    
    
    @NotBlank(message = "Package name is required")
    @Schema(description = "Package name", example = "European Explorer")
    private String packageName;
    
    @NotNull
    @Schema(description = "AgencyId", example = "1")
    private Long agencyId;


    @NotBlank(message = "Description is required")
    @Schema(description = "Package description", example = "14-day guided tour across major European cities.")
    private String description;

    @NotNull(message = "Price is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Price must be greater than 0")
    @Schema(description = "Package price", example = "2150.00")
    private Double price;

    @NotNull(message = "Available from date is required")
    @Schema(description = "Available from date", example = "2025-09-01")
    private LocalDate availableFrom;

    @NotNull(message = "Available to date is required")
    @Schema(description = "Available to date", example = "2025-11-30")
    private LocalDate availableTo;
}