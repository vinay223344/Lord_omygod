package com.cognizant.packages.entity;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "travel_packages")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Travel Package Entity")
public class TravelPackageEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Package ID", example = "1")
    private Long id;

    @Column(nullable = false)
    @NotBlank(message = "Package name is required")
    @Schema(description = "Package name", example = "European Explorer")
    private String name;
    
    @Column(nullable = false)
    @NotNull
    @Schema(description = "Agency Id", example = "1")
    private Long agencyId;

    @Column(nullable = false, columnDefinition = "TEXT")
    @NotBlank(message = "Description is required")
    @Schema(description = "Package description", example = "14-day guided tour across major European cities.")
    private String description;

    @Column(nullable = false)
    @NotNull(message = "Price is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Price must be greater than 0")
    @Schema(description = "Package price", example = "2150.00")
    private Double price;

    @Column(name = "available_from", nullable = false)
    @NotNull(message = "Available from date is required")
    @Schema(description = "Available from date", example = "2025-09-01")
    private LocalDate availableFrom;

    @Column(name = "available_to", nullable = false)
    @NotNull(message = "Available to date is required")
    @Schema(description = "Available to date", example = "2025-11-30")
    private LocalDate availableTo;
}