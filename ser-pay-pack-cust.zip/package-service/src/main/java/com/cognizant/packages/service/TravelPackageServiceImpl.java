package com.cognizant.packages.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.packages.dto.TravelPackageRequestDTO;
import com.cognizant.packages.dto.TravelPackageResponseDTO;
import com.cognizant.packages.entity.TravelPackageEntity;
import com.cognizant.packages.exception.PackageNotFoundException;
import com.cognizant.packages.exception.TravelAgencyNotFoundException;
import com.cognizant.packages.feign.FeignTravelAgencyClient;
import com.cognizant.packages.repository.TravelPackageRepository;

@Service
public class TravelPackageServiceImpl implements TravelPackageService {

    private TravelPackageRepository repository;
    private FeignTravelAgencyClient agencyClient;

    public TravelPackageServiceImpl(TravelPackageRepository repository,FeignTravelAgencyClient agencyClient) {
        this.repository = repository;
        this.agencyClient=agencyClient;
    }

    @Override
    public TravelPackageResponseDTO createPackage(TravelPackageRequestDTO dto) {
    	

         try {
            agencyClient.getAgencyById(dto.getAgencyId());
        } catch (Exception e) {
            throw new TravelAgencyNotFoundException("Travel agency not found");
        }


        TravelPackageEntity entity = new TravelPackageEntity();

        entity.setName(dto.getPackageName());
        entity.setAgencyId(dto.getAgencyId());
        entity.setDescription(dto.getDescription());
        entity.setPrice(dto.getPrice());
        entity.setAvailableFrom(dto.getAvailableFrom());
        entity.setAvailableTo(dto.getAvailableTo());

        TravelPackageEntity saved = repository.save(entity);

        return mapToDTO(saved);
    }

    @Override
    public List<TravelPackageResponseDTO> getAllPackages() {

        List<TravelPackageEntity> list = repository.findAll();

        List<TravelPackageResponseDTO> result = new ArrayList<>();

        for (TravelPackageEntity entity : list) {
            result.add(mapToDTO(entity));
        }

        return result;
    }

    @Override
    public TravelPackageResponseDTO getPackageById(Long id) {

        TravelPackageEntity entity = repository.findById(id)
                .orElseThrow(() -> new PackageNotFoundException("Package not found"));

        return mapToDTO(entity);
    }

    @Override
    public TravelPackageResponseDTO updatePackage(Long id, TravelPackageRequestDTO dto) {

        TravelPackageEntity existing = repository.findById(id)
                .orElseThrow(() -> new PackageNotFoundException("Package not found"));

        existing.setName(dto.getPackageName());
        existing.setDescription(dto.getDescription());
        existing.setPrice(dto.getPrice());
        existing.setAvailableFrom(dto.getAvailableFrom());
        existing.setAvailableTo(dto.getAvailableTo());

        TravelPackageEntity updated = repository.save(existing);

        return mapToDTO(updated);
    }

    @Override
    public void deletePackage(Long id) {

        TravelPackageEntity existing = repository.findById(id)
                .orElseThrow(() -> new PackageNotFoundException("Package not found"));

        repository.delete(existing);
    }
    
    private TravelPackageResponseDTO mapToDTO(TravelPackageEntity entity) {
        return new TravelPackageResponseDTO(
                entity.getId(),
                entity.getName(),
                entity.getAgencyId(),
                entity.getDescription(),
                entity.getPrice(),
                entity.getAvailableFrom(),
                entity.getAvailableTo()
               
        );
    }
}