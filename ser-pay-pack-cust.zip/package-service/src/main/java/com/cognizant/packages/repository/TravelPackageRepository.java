package com.cognizant.packages.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.packages.entity.TravelPackageEntity;

public interface TravelPackageRepository extends JpaRepository<TravelPackageEntity, Long>{
	
	
	

}
