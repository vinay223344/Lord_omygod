package com.cognizant.packages.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cognizant.packages.dto.TrvaelAgencyResponseDTO;

@FeignClient(name = "agency-service")
public interface FeignTravelAgencyClient {

    @GetMapping("/api/agencies/{id}")
    TrvaelAgencyResponseDTO getAgencyById(@PathVariable Long id);
}
