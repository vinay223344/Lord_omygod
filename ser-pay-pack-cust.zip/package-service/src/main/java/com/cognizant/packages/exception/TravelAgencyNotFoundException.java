package com.cognizant.packages.exception;

public class TravelAgencyNotFoundException extends RuntimeException {

    public TravelAgencyNotFoundException(String message) {
        super(message);
    }
}