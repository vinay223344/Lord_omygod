package com.cognizant.packages.dto;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Travel Package Response DTO")
public class TravelPackageResponseDTO {

    @Schema(description = "Package ID", example = "1")
    private Long id;

    @Schema(description = "Package name", example = "European Explorer")
    private String packageName;
    
    @Schema(description = "AgencyId", example = "1")
    private Long agencyId;

    @Schema(description = "Package description", example = "14-day guided tour across major European cities.")
    private String description;

    @Schema(description = "Package price", example = "2150.00")
    private Double price;

    @Schema(description = "Available from date", example = "2025-09-01")
    private LocalDate availableFrom;

    @Schema(description = "Available to date", example = "2025-11-30")
    private LocalDate availableTo;
}