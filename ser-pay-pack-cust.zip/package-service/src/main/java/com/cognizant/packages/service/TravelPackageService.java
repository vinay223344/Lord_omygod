
package com.cognizant.packages.service;

import java.util.List;

import com.cognizant.packages.dto.TravelPackageRequestDTO;
import com.cognizant.packages.dto.TravelPackageResponseDTO;

public interface TravelPackageService {

    
    TravelPackageResponseDTO createPackage(TravelPackageRequestDTO dto);

    
    List<TravelPackageResponseDTO> getAllPackages();

   
    TravelPackageResponseDTO getPackageById(Long id);

   
    TravelPackageResponseDTO updatePackage(Long id, TravelPackageRequestDTO dto);

    
    void deletePackage(Long id);
}
