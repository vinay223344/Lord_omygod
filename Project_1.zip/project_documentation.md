# NetWatch System Architecture & User Guide

NetWatch is a Network Infrastructure & Network Operations Centre (NOC) Management System designed to automate fault detection, ticket logging, engineer dispatching, circuit provisioning, and capacity tracking.

---

## 1. The Core Flow & Operational Rationale

In large telecommunications networks and enterprise IT infrastructures, thousands of devices run simultaneously. NetWatch automates the end-to-end operational lifecycle of network failures to guarantee Service Level Agreements (SLAs) are maintained.

```mermaid
graph TD
    A[Telemetry exceeds limit / Link goes down] -->|Auto-Generated| B(Active Alarm Raised)
    B -->|Correlated & Logged| C(Trouble Ticket Created)
    C -->|Assigned by Dispatcher| D[NOC Engineer assigned]
    D -->|Mobilised| E[Field Engineer Dispatched to Site]
    E -->|Arrives On Site| F(Status: On Site)
    F -->|Replaces Fiber/Hardware| G(Mark Resolved)
    G -->|Auto-Triggers| H(Alarm Cleared & Ticket Closed)
```

1. **Topology Setup**: Planning engineers construct the network layout in the **Inventory Manager** by mapping physical sites, hardware elements (routers, switches), and link cables.
2. **Telemetry Monitoring**: Elements report telemetry. If a threshold is crossed (e.g., CPU load > 85%), the system flags it.
3. **Alarm Isolation**: Raw faults generate critical alarms. NOC controllers view these on the **Alarms Board** to acknowledge and isolate issues.
4. **Ticketing & Dispatch**: Incidents are converted to tickets. NOC engineers coordinate dispatching field technicians to physical coordinates to execute repairs.
5. **Circuit Mapping**: Helpdesks map affected customer lines (circuits) to see exactly which clients are offline during hardware outages.

---

## 2. Detailed Page & Element Breakdown

### 2.1 Identity & Access Management (Login / Register)
Manages user authentication and role-based permissions (RBAC).

| Field / Element | Data Type / Domain | Operational Purpose |
| :--- | :--- | :--- |
| **Email & Password** | Text / Credentials | Restricts unauthorized access to network elements. |
| **Role Select** | Enum: `NOCEngineer`, `FieldEngineer`, `PlanningEngineer`, `Admin` | Dictates screen layouts and actions (e.g., only NOC Engineers can assign tickets; only Field Engineers can mark dispatches "On Site"). |
| **Region ID** | Enum (e.g., `REG-NORTH`) | Dictates ticket routing. Outages in the North Region are routed to engineers in the North shift pool. |
| **Shift Group** | Enum (e.g., `Shift-A`) | Tracks active personnel during 24/7 rotations. |

---

### 2.2 Operations Dashboard
The centralized real-time health indicator of the network.

| Field / Element | Component Type | Operational Purpose |
| :--- | :--- | :--- |
| **Active Alarms Card** | Metric indicator | Counts active outages requiring immediate attention. |
| **P1 Outages Card** | Metric indicator | High-urgency outages representing complete customer blackout. Target is always `0`. |
| **Capacity Alerts Table** | Warning list | Proactive health alerts displaying devices close to exhaustion. |
| **Alarms by Severity** | Distribution chart | Categorizes faults (Critical, Major, Minor, Warning) to help prioritize restoration schedules. |
| **SLA Benchmarks** | Progress indicator | Measures response compliance against target performance metrics. |

---

### 2.3 Inventory Manager
Exposes and modifies the Configuration Management Database (CMDB).

#### Network Sites Tab (Physical Buildings)
* **Site Type** (*Data Centre, Exchange, Cell Tower, POP, Remote Node*): Tells field teams which environment they are entering. Data Centres require keycard access; Cell Towers require climbing gear.
* **Region & Address**: Maps the physical address for driving coordinates.

#### Network Elements Tab (Hardware)
* **IP Address**: Target IP query path for telemetry.
* **Element Type** (*Router, Switch, Firewall, OLT, BTS, Server*): Hardware classification.
* **Vendor & Model**: Used to coordinate spare parts compatibility during repairs.

#### Topology Links Tab (Physical Cabling)
* **Source & Destination Elements**: Defines connection routes.
* **Link Type** (*Fibre, Microwave, Ethernet, SDH*): Tells controllers link medium. (e.g., Microwave can be affected by weather).
* **Capacity (Mbps)**: Total bandwidth cap.

---

### 2.4 Fault Monitoring Board (Alarms)
Aggregates live traps and telemetry alerts.

* **Alarm Event Type** (*LinkDown, NodeUnreachable, HighUtilisation, PowerFailure, HardwareFault, CoolingAlert*): Root cause category.
* **Acknowledge Button**: Assigns the alarm to the active controller to prevent duplicate workflows.
* **Clear Button**: Manual override to resolve alarms once connections recover.
* **Fault Injector Form**: Simulation tool for testing alarm correlation.

---

### 2.5 Incident Tickets & Field Operations
Coordinates maintenance dispatch logistics.

* **Log Trouble Ticket Form**: Links alarms to actionable repair cases.
* **NOC Assignment**: Dropdown to select active controller.
* **Field Dispatch**: Assigns a Field Engineer to perform onsite checks.
* **Dispatch Actions** (*Arrive Site, Mark Resolved*): Tracks transit times and logs restoration summaries to close the outage.

---

### 2.6 Circuit Provisioning
Logical WAN mapping of customer lines.

* **Circuit Reference**: Billing reference code (e.g., `DIA-10G-002`).
* **Service Type** (*Leased Line, VPN, DIA Internet, Voice, MPLS*): Defines SLA priority.
* **Route Path**: String tracing device-level hops. Used to correlate which customer lines are impacted by router failures.
* **Order Request Type** (*NewActivation, BandwidthUpgrade, Suspension, Termination*): Manages billing state changes.

---

### 2.7 Maintenance & Telemetry Console
Controls planned maintenance windows and telemetry injection.

* **Schedule Window Form**: Coordinates scheduling network downtime (usually scheduled during low-traffic windows: 2 AM - 5 AM).
* **Affected Element IDs**: Device IDs targeted for downtime. Suppresses false alarms during maintenance windows.
* **Inject Telemetry Form**: Pushes resource loads. Pushing loads exceeding threshold auto-generates alarms.
