package com.ompr.Auth.requestdto;

import com.ompr.Auth.enums.UserStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class UserStatusRequest {

    @NotNull(message = "Status is required")
    private UserStatus status;
}
