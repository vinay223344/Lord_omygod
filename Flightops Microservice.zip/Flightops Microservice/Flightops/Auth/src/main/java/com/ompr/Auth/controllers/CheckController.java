package com.ompr.Auth.controllers;
import com.ompr.Auth.entities.User;
import com.ompr.Auth.services.CheckingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/internal/")
@Slf4j
public class CheckController
{

    private final CheckingService cs;
    @GetMapping("checkbyemail/{emailid}")
    public User checkUserByEmail(@PathVariable String emailid)
    {
        return cs.chekbyuseremail(emailid);
    }
}

