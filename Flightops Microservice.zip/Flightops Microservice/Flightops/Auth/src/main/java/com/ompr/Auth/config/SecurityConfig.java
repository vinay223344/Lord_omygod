package com.ompr.Auth.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                // 1. Disable CSRF because microservices use stateless JWTs
                .csrf(AbstractHttpConfigurer::disable)

                // 2. Configure endpoint permissions
                .authorizeHttpRequests(auth -> auth
                        // Allow anyone to hit login, register, and refresh routes
                        .requestMatchers("/api/auth/login", "/api/auth/register", "/api/auth/refresh","/api/internal/**").permitAll()
                        // All other management endpoints (like /api/users/**) require authentication
                        .anyRequest().authenticated()
                )

                // 3. Keep sessions completely stateless
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));

        return http.build();
    }
}