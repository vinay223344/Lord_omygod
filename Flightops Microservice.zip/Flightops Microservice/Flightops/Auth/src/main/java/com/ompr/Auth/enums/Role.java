package com.ompr.Auth.enums;

public enum Role {
    Admin,

    AirlineCoordinator,

    GroundSupervisor,

    GSEManager,

    PassengerAgent,

    RampOfficer

}
