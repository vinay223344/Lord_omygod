package com.ompr.Auth.services;

import com.ompr.Auth.entities.User;
import com.ompr.Auth.exception.ResourceNotFoundException;
import com.ompr.Auth.repositories.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class CheckingService
{
    @Autowired
    private UserRepository us;
    public User chekbyuseremail(String emailid)
    {
        User requestedBy = us.findByEmail(emailid)
                .orElseThrow(() -> {
                    log.error("Failed to create handling request. User not found: {}", emailid);
                    return new ResourceNotFoundException("User not found");
                });
        return requestedBy;

    }
}
