package com.ompr.Auth.enums;

public enum UserStatus {
    Active,
    Inactive,
    OnShift
}
