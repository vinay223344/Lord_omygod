package com.ompr.Auth.requestdto;

import lombok.Data;

@Data
public class RefreshTokenRequest {
    private String refreshToken;
}
