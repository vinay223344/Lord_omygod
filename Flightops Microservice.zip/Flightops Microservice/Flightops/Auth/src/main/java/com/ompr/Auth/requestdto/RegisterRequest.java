package com.ompr.Auth.requestdto;

import com.ompr.Auth.enums.Role;
import lombok.Data;

@Data
public class RegisterRequest {

    private String name;
    private String email;
    private String password;
    private String airportId;
    private String phone;
    private Role role;
}
