package com.ompr.Turnaround.enums;

public enum UserStatus {
    Active,
    Inactive,
    OnShift
}
