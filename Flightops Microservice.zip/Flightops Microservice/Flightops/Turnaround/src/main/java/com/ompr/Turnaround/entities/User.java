package com.ompr.Turnaround.entities;

import com.ompr.Turnaround.enums.Role;
import com.ompr.Turnaround.enums.UserStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "users")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String userId;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    @Column(nullable = false, unique = true)
    private String email;

    private String phone;
    @Column(nullable = false)
    private String airportId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private UserStatus status;
}
