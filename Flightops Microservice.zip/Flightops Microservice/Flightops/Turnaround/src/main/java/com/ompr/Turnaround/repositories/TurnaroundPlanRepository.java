package com.ompr.Turnaround.repositories;

import com.ompr.Turnaround.entities.Flight;
import com.ompr.Turnaround.entities.TurnaroundPlan;
import com.ompr.Turnaround.enums.TurnaroundStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TurnaroundPlanRepository extends JpaRepository<TurnaroundPlan, String> {

    Optional<TurnaroundPlan> findByFlight(Flight flight);

    Optional<TurnaroundPlan> findByFlight_FlightId(String flightId);

    List<TurnaroundPlan> findByStatusOrderByStatusAsc(TurnaroundStatus status);

    boolean existsByFlight(Flight flight);
}
