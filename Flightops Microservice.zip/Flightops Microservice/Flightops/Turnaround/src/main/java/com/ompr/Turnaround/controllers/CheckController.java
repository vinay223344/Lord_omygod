package com.ompr.Turnaround.controllers;

import com.ompr.Turnaround.entities.TurnaroundMilestone;
import com.ompr.Turnaround.entities.TurnaroundPlan;
import com.ompr.Turnaround.enums.MilestoneStatus;
import com.ompr.Turnaround.services.CheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.List;

@RequestMapping("/api/internal/")
@RestController
public class CheckController
{
    @Autowired
    private CheckService cs;
    @GetMapping("findingallturnarounds/")
    public List<TurnaroundPlan> findingallturnarounds()
    {
        return  cs.findingallturnarounds();
    }
    public List<TurnaroundMilestone> findingbystatus(@PathVariable MilestoneStatus e){
        return cs.findingbystatus(e);
    }
    public List<TurnaroundMilestone> findoverdues(@PathVariable("d") LocalDateTime d)
    {
        return cs.findingoverdues(d);
    }
}
