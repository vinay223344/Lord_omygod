package com.ompr.Turnaround.enums;

public enum MilestoneType {
    ChocksOn,
    DoorOpen,
    StairsDocked,
    BaggageOffload,
    Cleaning,
    Catering,
    Fuelling,
    BoardingComplete,
    DoorClose,
    PushbackClearance
}
