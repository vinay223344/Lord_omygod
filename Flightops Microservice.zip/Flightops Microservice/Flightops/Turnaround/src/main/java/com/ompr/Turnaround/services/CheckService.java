package com.ompr.Turnaround.services;

import com.ompr.Turnaround.entities.TurnaroundMilestone;
import com.ompr.Turnaround.entities.TurnaroundPlan;
import com.ompr.Turnaround.enums.MilestoneStatus;
import com.ompr.Turnaround.repositories.TurnaroundMilestoneRepository;
import com.ompr.Turnaround.repositories.TurnaroundPlanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CheckService {
    @Autowired
    private TurnaroundPlanRepository tp;
    @Autowired
    private TurnaroundMilestoneRepository tm;
    public List<TurnaroundPlan> findingallturnarounds() {
        return tp.findAll();
    }

    public List<TurnaroundMilestone> findingbystatus(MilestoneStatus e) {
        return tm.findByStatusOrderByPlannedTimeAsc(e);
    }

    public List<TurnaroundMilestone> findingoverdues(LocalDateTime d) {
        return tm.findOverdueMilestones(d);
    }
}
