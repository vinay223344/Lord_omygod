package com.ompr.Turnaround.responsedtos;

import com.ompr.Turnaround.enums.MilestoneStatus;
import com.ompr.Turnaround.enums.MilestoneType;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class TurnaroundMilestoneResponse {
    private String milestoneId;
    private String planId;
    private MilestoneType milestoneType;
    private LocalDateTime plannedTime;
    private LocalDateTime actualTime;
    private String completedById;
    private String completedByName;
    private MilestoneStatus status;
    private boolean isDelayed;
    private Long delayMinutes; // null if not delayed
}
