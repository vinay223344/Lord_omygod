package com.ompr.Turnaround.enums;

public enum FlightStatus {
    Scheduled,
    Arrived,
    Departed,
    Delayed,
    Diverted,
    Cancelled
}
