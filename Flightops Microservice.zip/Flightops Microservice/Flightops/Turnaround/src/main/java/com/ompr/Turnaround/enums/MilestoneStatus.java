package com.ompr.Turnaround.enums;

public enum MilestoneStatus {
    Pending,
    Completed,
    Skipped,
    Delayed
}
