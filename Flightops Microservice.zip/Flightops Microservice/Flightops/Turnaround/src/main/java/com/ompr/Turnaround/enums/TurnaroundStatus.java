package com.ompr.Turnaround.enums;

public enum TurnaroundStatus {
    Active,
    Completed,
    Delayed
}
