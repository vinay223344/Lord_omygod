package com.ompr.Turnaround.Feigns;

import com.ompr.Turnaround.entities.Flight;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "FLIGHT")
public interface FlightFeignClient {
    @GetMapping("api/internal/checkbyflightid/{flightid}")
    Flight checkingbyflightid(@PathVariable("flightid") String flightid);
}
