package com.ompr.Turnaround;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients(basePackages = "com.ompr.Turnaround.Feigns")

public class TurnaroundApplication {

	public static void main(String[] args) {
		SpringApplication.run(TurnaroundApplication.class, args);
	}

}
