package com.ompr.Turnaround.enums;

public enum Role {
    Admin,

    AirlineCoordinator,

    GroundSupervisor,

    GSEManager,

    PassengerAgent,

    RampOfficer

}
