package com.ompr.Turnaround;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TurnaroundApplicationTests {

	@Test
	void contextLoads() {
	}

}
