package com.ompr.PassengerHandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassengerHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
