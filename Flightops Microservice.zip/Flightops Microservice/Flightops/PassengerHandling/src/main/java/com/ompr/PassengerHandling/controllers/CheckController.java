package com.ompr.PassengerHandling.controllers;

import com.ompr.PassengerHandling.entities.SpecialAssistance;
import com.ompr.PassengerHandling.enums.AssistanceStatus;
import com.ompr.PassengerHandling.services.CheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class CheckController {
    @Autowired
    private CheckService cs;
    @GetMapping("/api/internal/findbystatus/{e}")
    public List<SpecialAssistance> findingbystatus(@PathVariable AssistanceStatus e)
    {
        return cs.findingbystatus(e);
    }
}
