package com.ompr.PassengerHandling.enums;

public enum UserStatus {
    Active,
    Inactive,
    OnShift
}
