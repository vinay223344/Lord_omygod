package com.ompr.PassengerHandling.Feigns;

import com.ompr.PassengerHandling.entities.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "AUTH")
public interface AuthFeignClient{
    @GetMapping("api/internal/checkbyemail/{emailid}")
    User checkUserByEmail(@PathVariable("emailid") String emailid);
}
