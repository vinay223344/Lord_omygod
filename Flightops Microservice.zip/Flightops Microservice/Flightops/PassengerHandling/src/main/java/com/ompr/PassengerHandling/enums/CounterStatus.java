package com.ompr.PassengerHandling.enums;

public enum CounterStatus {
    Open,
    Closed,
    Standby
}
