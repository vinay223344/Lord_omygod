package com.ompr.PassengerHandling.services;

import com.ompr.PassengerHandling.entities.SpecialAssistance;
import com.ompr.PassengerHandling.enums.AssistanceStatus;
import com.ompr.PassengerHandling.repositories.SpecialAssistanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class CheckService {
    @Autowired
    private SpecialAssistanceRepository sp;
    public List<SpecialAssistance> findingbystatus(AssistanceStatus e) {
        return sp.findByStatusOrderByStatusAsc(e);
    }
}
