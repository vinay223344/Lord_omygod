package com.ompr.PassengerHandling.repositories;

import com.ompr.PassengerHandling.entities.BoardingGate;
import com.ompr.PassengerHandling.enums.GateStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BoardingGateRepository extends JpaRepository<BoardingGate, String> {

    List<BoardingGate> findByFlight_FlightId(String flightId);

    List<BoardingGate> findAllByOrderByOpenTimeAsc();

    List<BoardingGate> findByStatus(GateStatus status);

    boolean existsByGateNumberAndStatusNot(String gateNumber, GateStatus status);
}
