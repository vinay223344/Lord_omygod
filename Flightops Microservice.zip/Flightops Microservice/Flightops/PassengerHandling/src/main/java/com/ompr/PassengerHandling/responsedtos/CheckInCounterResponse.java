package com.ompr.PassengerHandling.responsedtos;

import com.ompr.PassengerHandling.enums.CounterStatus;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class CheckInCounterResponse {
    private String counterId;
    private String counterNumber;
    private String terminal;
    private String flightId;
    private String flightNumber;
    private String assignedAgentId;
    private String assignedAgentName;
    private LocalDateTime openTime;
    private LocalDateTime closeTime;
    private CounterStatus status;
}
