package com.ompr.PassengerHandling.requestdtos;

import com.ompr.PassengerHandling.enums.GateStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class GateStatusRequest {

    @NotNull(message = "Status is required")
    private GateStatus status;
}
