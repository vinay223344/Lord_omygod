package com.ompr.PassengerHandling.enums;

public enum AssistanceType {
    WheelchairToGate,
    UnaccompaniedMinor,
    MedicalCase,
    StretcherCase
}
