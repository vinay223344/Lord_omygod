package com.ompr.PassengerHandling.repositories;

import com.ompr.PassengerHandling.entities.CheckInCounter;
import com.ompr.PassengerHandling.enums.CounterStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CheckInCounterRepository extends JpaRepository<CheckInCounter, String> {

    List<CheckInCounter> findByFlight_FlightId(String flightId);

    List<CheckInCounter> findAllByOrderByOpenTimeAsc();

    List<CheckInCounter> findByStatus(CounterStatus status);

    // Prevent assigning same physical counter number to two open flights simultaneously
    boolean existsByCounterNumberAndStatusNot(String counterNumber, CounterStatus status);
}
