package com.ompr.PassengerHandling.requestdtos;

import com.ompr.PassengerHandling.enums.CounterStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class CounterStatusRequest {

    @NotNull(message = "Status is required")
    private CounterStatus status;
}
