package com.ompr.PassengerHandling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignClient;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients(basePackages = "com.ompr.PassengerHandling.Feigns")
public class PassengerHandlingApplication {

	public static void main(String[] args) {
		SpringApplication.run(PassengerHandlingApplication.class, args);
	}

}
