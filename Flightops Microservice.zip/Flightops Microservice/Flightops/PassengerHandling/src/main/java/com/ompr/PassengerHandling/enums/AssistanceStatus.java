package com.ompr.PassengerHandling.enums;

public enum AssistanceStatus {
    Requested,
    Assigned,
    Completed
}
