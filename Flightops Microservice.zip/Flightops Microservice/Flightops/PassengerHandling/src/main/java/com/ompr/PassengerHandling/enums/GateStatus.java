package com.ompr.PassengerHandling.enums;

public enum GateStatus {
    Open,
    Boarding,
    Closed,
    HoldRoom
}
