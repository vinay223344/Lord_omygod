package com.ompr.BaggageHandling;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaggageHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
