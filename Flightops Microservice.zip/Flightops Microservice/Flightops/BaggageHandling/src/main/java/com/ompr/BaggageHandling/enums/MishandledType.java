package com.ompr.BaggageHandling.enums;

public enum MishandledType {
    Lost,
    Delayed,
    Damaged,
    PilferedContent
}
