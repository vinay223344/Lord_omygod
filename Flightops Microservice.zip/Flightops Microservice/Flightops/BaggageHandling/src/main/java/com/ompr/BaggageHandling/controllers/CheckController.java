package com.ompr.BaggageHandling.controllers;

import com.netflix.discovery.converters.Auto;
import com.ompr.BaggageHandling.entities.BaggageOperation;
import com.ompr.BaggageHandling.entities.MishandledBaggage;
import com.ompr.BaggageHandling.enums.MishandledStatus;
import com.ompr.BaggageHandling.services.CheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;
@RestController
public class CheckController {
    @Autowired
    private CheckService cs;
    @GetMapping("/api/internal/findingallbaggages")
    public List<BaggageOperation> findingallbaggages()
    {
        return cs.findingallbaggaging();

    }
    @GetMapping("/api/internal/findingbystatus")
    public List<MishandledBaggage> findingbystatus(@PathVariable MishandledStatus e)
    {
        return cs.findingbystatus(e);
    }
    @GetMapping("/api/internal/updatecount")
    public long updatecount()
    {
        return cs.findingcount();
    }
}
