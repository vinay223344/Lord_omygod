package com.ompr.BaggageHandling.services;

import com.ompr.BaggageHandling.entities.BaggageOperation;
import com.ompr.BaggageHandling.entities.MishandledBaggage;
import com.ompr.BaggageHandling.enums.MishandledStatus;
import com.ompr.BaggageHandling.repositories.BaggageOperationRepository;
import com.ompr.BaggageHandling.repositories.MishandledBaggageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CheckService {
    @Autowired
    private BaggageOperationRepository bo;
    @Autowired
    private MishandledBaggageRepository mb;
    public List<BaggageOperation> findingallbaggaging()
    {
        return bo.findAll();
    }

    public List<MishandledBaggage> findingbystatus(MishandledStatus e) {
        return mb.findByStatus(e);
    }

    public long findingcount() {
        return mb.count();
    }
}
