package com.ompr.BaggageHandling.enums;

public enum UserStatus {
    Active,
    Inactive,
    OnShift
}
