package com.ompr.BaggageHandling.enums;

public enum Direction {
    Inbound,
    Outbound
}
