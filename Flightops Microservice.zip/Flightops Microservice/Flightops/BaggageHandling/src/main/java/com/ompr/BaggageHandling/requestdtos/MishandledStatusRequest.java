package com.ompr.BaggageHandling.requestdtos;

import com.ompr.BaggageHandling.enums.MishandledStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class MishandledStatusRequest {

    @NotNull(message = "Status is required")
    private MishandledStatus status;
}
