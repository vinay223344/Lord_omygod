package com.ompr.BaggageHandling.enums;

public enum OperationStatus {
    InProgress,
    Completed,
    Discrepancy
}
