package com.ompr.BaggageHandling.enums;

public enum MishandledStatus {
    Reported,
    Traced,
    Recovered,
    Claimed,
    ClosedUnresolved
}
