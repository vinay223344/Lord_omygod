package com.ompr.MyGateway.enums;

public enum Role {
    Admin,

    AirlineCoordinator,

    GroundSupervisor,

    GSEManager,

    PassengerAgent,

    RampOfficer

}
