package com.ompr.MyGateway.enums;

public enum UserStatus {
    Active,
    Inactive,
    OnShift
}
