package com.ompr.Flight.requestdto;

import com.ompr.Flight.enums.FlightStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class FlightStatusRequest {

    @NotNull(message = "Status is required")
    private FlightStatus status;
}
