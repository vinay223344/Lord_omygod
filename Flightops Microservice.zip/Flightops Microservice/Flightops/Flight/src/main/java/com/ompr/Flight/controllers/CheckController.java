package com.ompr.Flight.controllers;

import com.ompr.Flight.entities.Flight;
import com.ompr.Flight.entities.GroundOpsReport;
import com.ompr.Flight.services.CheckingService;
import com.ompr.Flight.services.FlightService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.List;

@RestController
@Slf4j
@RequiredArgsConstructor
@RequestMapping("api/internal/")
public class CheckController
{
    @Autowired
    private CheckingService fs;
    @GetMapping("checkbyflightid/{flightid}")
    public Optional<Flight> checkingbyflightid(@PathVariable String flightid)
    {
        return fs.checkingtheflightid(flightid);
    }
    @GetMapping("todayflights/{start}/{end}")
    public List<Flight> todayflights(@PathVariable("start")LocalDateTime start,@PathVariable("end")LocalDateTime end)
    {
        return fs.givingtodayflights(start,end);
    }
    @GetMapping("saving/{g}")
    public GroundOpsReport saving(@PathVariable("g") GroundOpsReport g)
    {
        return fs.saving(g);
    }
    @GetMapping("api/internal/findingallgenerateddatedesc")
    public List<GroundOpsReport> findingallgenerateddatedesc()
    {
        return fs.findingallgenerateddatedesc();
    }
}