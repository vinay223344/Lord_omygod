package com.ompr.Flight.enums;

public enum UserStatus {
    Active,
    Inactive,
    OnShift
}
