package com.ompr.Flight.requestdto;

import com.ompr.Flight.enums.RequestStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class HandlingStatusRequest {

    @NotNull(message = "Status is required")
    private RequestStatus status;
}
