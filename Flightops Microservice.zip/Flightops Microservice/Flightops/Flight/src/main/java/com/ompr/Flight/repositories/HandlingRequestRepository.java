package com.ompr.Flight.repositories;

import com.ompr.Flight.entities.Flight;
import com.ompr.Flight.entities.HandlingRequest;
import com.ompr.Flight.enums.RequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface HandlingRequestRepository extends JpaRepository<HandlingRequest, String> {

    List<HandlingRequest> findByAirlineIdOrderByStatusAsc(String airlineId);

    List<HandlingRequest> findByStatusOrderByStatusAsc(RequestStatus status);

    Optional<HandlingRequest> findByFlight(Flight flight);

    List<HandlingRequest> findByFlight_FlightId(String flightId);

    boolean existsByFlightAndStatusNot(Flight flight, RequestStatus status);
}
