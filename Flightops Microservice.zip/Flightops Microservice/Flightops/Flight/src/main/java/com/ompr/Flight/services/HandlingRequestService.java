package com.ompr.Flight.services;

import com.ompr.Flight.Feigns.AuthFeignClient;
import com.ompr.Flight.entities.Flight;
import com.ompr.Flight.entities.HandlingRequest;
//import com.ompr.Flight.enums.NotificationCategory;
import com.ompr.Flight.entities.User;
import com.ompr.Flight.enums.RequestStatus;
//import com.ompr.Flight.enums.Role;
import com.ompr.Flight.exception.BadRequestException;
import com.ompr.Flight.exception.ConflictException;
import com.ompr.Flight.exception.ResourceNotFoundException;
import com.ompr.Flight.repositories.HandlingRequestRepository;

import com.ompr.Flight.requestdto.HandlingRequestDto;
import com.ompr.Flight.requestdto.HandlingStatusRequest;
import com.ompr.Flight.responsedto.HandlingRequestResponse;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j // 2. Added Lombok annotation to auto-generate the 'log' variable
public class HandlingRequestService {
    @Autowired
    private AuthFeignClient authFeignClient;

    private final HandlingRequestRepository handlingRequestRepository;
    private final FlightService flightService;
//    private final UserRepository userRepository;
//    private final NotificationService notificationService;

    @Transactional
    public HandlingRequestResponse create(HandlingRequestDto dto, String requestedByUserId) {
        log.info("Initiating creation of handling request for flightId: {} by user: {}", dto.getFlightId(), requestedByUserId);

        Flight flight = flightService.findById(dto.getFlightId());

        // Prevent duplicate active request for same flight
        boolean exists = handlingRequestRepository.existsByFlightAndStatusNot(
                flight, RequestStatus.Disputed);
        if (exists) {
            log.warn("Conflict detected: Active handling request already exists for flight number: {}", flight.getFlightNumber());
            throw new ConflictException("A handling request already exists for flight: "
                    + flight.getFlightNumber());
        }

        User response = authFeignClient.checkUserByEmail(requestedByUserId);


        HandlingRequest request = new HandlingRequest();
        request.setFlight(flight);
        request.setAirlineId(dto.getAirlineId());
        request.setServiceTypes(dto.getServiceTypes());
        request.setSpecialRequirements(dto.getSpecialRequirements());
        request.setRequestedBy(response);
        request.setStatus(RequestStatus.Received);

        HandlingRequest saved = handlingRequestRepository.save(request);
        log.info("Handling request successfully created with ID: {} for flight: {}", saved.getRequestId(), flight.getFlightNumber());

        // Notify supervisors
        log.debug("Dispatching notifications to Ground Supervisors for new request: {}", saved.getRequestId());
//        userRepository.findByRole(Role.GroundSupervisor).forEach(u ->
//                notificationService.sendNotification(u.getUserId(),
//                        "New handling request received for flight " + flight.getFlightNumber(),
//                        NotificationCategory.FlightSchedule));

        return toResponse(saved);
    }

    public List<HandlingRequestResponse> getAll() {
        log.debug("Fetching all handling requests");
        return handlingRequestRepository.findAll().stream().map(this::toResponse).toList();
    }

    public List<HandlingRequestResponse> getByAirline(String airlineId) {
        log.debug("Fetching handling requests for airline ID: {}", airlineId);
        return handlingRequestRepository.findByAirlineIdOrderByStatusAsc(airlineId)
                .stream().map(this::toResponse).toList();
    }

    public HandlingRequestResponse getById(String requestId) {
        log.debug("Fetching handling request details for ID: {}", requestId);
        return toResponse(findById(requestId));
    }

    public List<HandlingRequestResponse> getByFlight(String flightId) {
        log.debug("Fetching handling requests for flight ID: {}", flightId);
        return handlingRequestRepository.findByFlight_FlightId(flightId)
                .stream().map(this::toResponse).toList();
    }

    @Transactional
    public HandlingRequestResponse updateStatus(String requestId, HandlingStatusRequest statusRequest) {
        log.info("Attempting to update status of request ID: {} to {}", requestId, statusRequest.getStatus());

        HandlingRequest request = findById(requestId);

        // Guard: can't re-confirm a completed request
        if (request.getStatus() == RequestStatus.Completed) {
            log.warn("Invalid operation: Attempted to modify completed handling request ID: {}", requestId);
            throw new BadRequestException("Cannot modify a completed handling request");
        }

        RequestStatus oldStatus = request.getStatus();
        request.setStatus(statusRequest.getStatus());
        HandlingRequest saved = handlingRequestRepository.save(request);
        log.info("Successfully updated request ID: {} status from {} to {}", requestId, oldStatus, saved.getStatus());

        // Notify coordinator about confirmation/rejection
        log.debug("Notifying coordinator (User ID: {}) regarding status update to {}", saved.getRequestedBy().getUserId(), saved.getStatus());
//        notificationService.sendNotification(
//                saved.getRequestedBy().getUserId(),
//                "Your handling request for flight " + saved.getFlight().getFlightNumber()
//                        + " is now " + saved.getStatus(),
//                NotificationCategory.FlightSchedule);

        return toResponse(saved);
    }

    private HandlingRequest findById(String id) {
        return handlingRequestRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("Resource lookup failed. Handling request with ID: {} not found", id);
                    return new ResourceNotFoundException("Handling request not found: " + id);
                });
    }

    private HandlingRequestResponse toResponse(HandlingRequest h) {
        return HandlingRequestResponse.builder()
                .requestId(h.getRequestId())
                .flightId(h.getFlight().getFlightId())
                .flightNumber(h.getFlight().getFlightNumber())
                .airlineId(h.getAirlineId())
                .serviceTypes(h.getServiceTypes())
                .specialRequirements(h.getSpecialRequirements())
                .requestedById(h.getRequestedBy().getUserId())
                .requestedByName(h.getRequestedBy().getName())
                .status(h.getStatus())
                .build();
    }
}