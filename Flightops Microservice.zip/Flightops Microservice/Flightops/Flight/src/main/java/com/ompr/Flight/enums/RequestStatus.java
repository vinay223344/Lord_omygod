package com.ompr.Flight.enums;

public enum RequestStatus {
    Received,
    Confirmed,
    InProgress,
    Completed,
    Disputed
}
