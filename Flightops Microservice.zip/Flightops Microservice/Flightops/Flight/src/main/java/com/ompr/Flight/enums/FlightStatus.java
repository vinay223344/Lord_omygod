package com.ompr.Flight.enums;

public enum FlightStatus {
    Scheduled,
    Arrived,
    Departed,
    Delayed,
    Diverted,
    Cancelled
}
