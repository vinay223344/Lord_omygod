package com.ompr.Flight.services;

import com.ompr.Flight.entities.Flight;
import com.ompr.Flight.entities.GroundOpsReport;
import com.ompr.Flight.repositories.FlightRepository;
import com.ompr.Flight.repositories.GroundOpsReportRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Slf4j
public class CheckingService
{
    @Autowired
    private FlightRepository fr;
    @Autowired
    private GroundOpsReportRepository gr;
    public Optional<Flight> checkingtheflightid(String flightid)
    {
        return fr.findByFlightId(flightid);

    }
    public List<Flight> givingtodayflights(LocalDateTime start,LocalDateTime end)
    {
        return fr.findByScheduledArrivalBetweenOrderByScheduledArrivalAsc(start,end);
    }
    public GroundOpsReport saving(GroundOpsReport g)
    {
        return gr.save(g);
    }

    public List<GroundOpsReport> findingallgenerateddatedesc() {
        return gr.findAllByOrderByGeneratedDateDesc();
    }
}
