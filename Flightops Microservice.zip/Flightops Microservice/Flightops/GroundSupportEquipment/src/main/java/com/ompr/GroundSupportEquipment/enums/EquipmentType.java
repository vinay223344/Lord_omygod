package com.ompr.GroundSupportEquipment.enums;

public enum EquipmentType {
    StairsTruck,
    BaggageBelt,
    BusTractor,
    GPU,
    AirStarter,
    TowTractor,
    Catering
}
