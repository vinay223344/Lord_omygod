package com.ompr.GroundSupportEquipment.repositories;

import com.ompr.GroundSupportEquipment.entities.EquipmentMaintenance;
import com.ompr.GroundSupportEquipment.enums.MaintenanceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EquipmentMaintenanceRepository extends JpaRepository<EquipmentMaintenance, String> {

    List<EquipmentMaintenance> findByEquipment_EquipmentIdOrderByReportedDateDesc(String equipmentId);

    List<EquipmentMaintenance> findByStatusOrderByReportedDateDesc(MaintenanceStatus status);

    List<EquipmentMaintenance> findAllByOrderByReportedDateDesc();
}
