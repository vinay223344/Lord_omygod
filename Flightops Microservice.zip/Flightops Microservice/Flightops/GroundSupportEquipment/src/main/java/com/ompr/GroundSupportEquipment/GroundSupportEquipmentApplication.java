package com.ompr.GroundSupportEquipment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients(basePackages = "com.ompr.GroundSupportEquipment.Feigns")
public class GroundSupportEquipmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(GroundSupportEquipmentApplication.class, args);
	}

}
