package com.ompr.GroundSupportEquipment.enums;

public enum MaintenanceStatus {
    Reported,
    InMaintenance,
    ReturnedToService
}
