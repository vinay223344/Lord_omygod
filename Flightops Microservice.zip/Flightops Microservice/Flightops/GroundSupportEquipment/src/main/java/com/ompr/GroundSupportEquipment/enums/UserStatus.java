package com.ompr.GroundSupportEquipment.enums;

public enum UserStatus {
    Active,
    Inactive,
    OnShift
}
