package com.ompr.GroundSupportEquipment.responsedtos;

import com.ompr.GroundSupportEquipment.enums.AllocationStatus;
import com.ompr.GroundSupportEquipment.enums.EquipmentType;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class EquipmentAllocationResponse {
    private String allocationId;
    private String equipmentId;
    private String registrationNumber;
    private EquipmentType equipmentType;
    private String flightId;
    private String flightNumber;
    private String allocatedById;
    private String allocatedByName;
    private LocalDateTime allocationTime;
    private LocalDateTime releaseTime;
    private AllocationStatus status;
}
