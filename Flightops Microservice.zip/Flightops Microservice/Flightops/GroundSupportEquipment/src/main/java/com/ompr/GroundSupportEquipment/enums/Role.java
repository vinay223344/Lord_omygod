package com.ompr.GroundSupportEquipment.enums;

public enum Role {
    Admin,

    AirlineCoordinator,

    GroundSupervisor,

    GSEManager,

    PassengerAgent,

    RampOfficer

}
