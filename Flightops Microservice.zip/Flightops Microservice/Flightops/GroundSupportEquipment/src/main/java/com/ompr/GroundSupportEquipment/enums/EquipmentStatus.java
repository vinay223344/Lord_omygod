package com.ompr.GroundSupportEquipment.enums;

public enum EquipmentStatus {
    Available,
    Allocated,
    Maintenance,
    OutOfService
}
