package com.ompr.GroundSupportEquipment.enums;

public enum AllocationStatus {
    Allocated,
    Released,
    Extended
}
