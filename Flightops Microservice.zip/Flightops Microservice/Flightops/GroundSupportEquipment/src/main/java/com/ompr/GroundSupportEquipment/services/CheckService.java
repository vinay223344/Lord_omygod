package com.ompr.GroundSupportEquipment.services;

import com.ompr.GroundSupportEquipment.entities.GroundEquipment;
import com.ompr.GroundSupportEquipment.enums.EquipmentStatus;
import com.ompr.GroundSupportEquipment.repositories.GroundEquipmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CheckService {
    @Autowired
    private GroundEquipmentRepository gr;
    public long countinghere() {
        return gr.count();
    }

    public List<GroundEquipment> findingbystatus(EquipmentStatus e) {
        return gr.findByStatus(e);
    }
}
