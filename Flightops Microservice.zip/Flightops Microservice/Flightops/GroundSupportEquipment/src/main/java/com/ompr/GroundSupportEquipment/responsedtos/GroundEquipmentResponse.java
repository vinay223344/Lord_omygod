package com.ompr.GroundSupportEquipment.responsedtos;

import com.ompr.GroundSupportEquipment.enums.EquipmentStatus;
import com.ompr.GroundSupportEquipment.enums.EquipmentType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GroundEquipmentResponse {
    private String equipmentId;
    private EquipmentType type;
    private String registrationNumber;
    private String currentLocation;
    private EquipmentStatus status;
}
