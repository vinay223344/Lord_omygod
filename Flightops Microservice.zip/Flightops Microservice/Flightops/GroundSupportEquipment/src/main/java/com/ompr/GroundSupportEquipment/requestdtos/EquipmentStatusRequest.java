package com.ompr.GroundSupportEquipment.requestdtos;

import com.ompr.GroundSupportEquipment.enums.EquipmentStatus;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class EquipmentStatusRequest {

    @NotNull(message = "Status is required")
    private EquipmentStatus status;
}
