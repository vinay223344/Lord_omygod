package com.ompr.GroundSupportEquipment.responsedtos;

import com.ompr.GroundSupportEquipment.enums.MaintenanceStatus;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class EquipmentMaintenanceResponse {
    private String maintenanceId;
    private String equipmentId;
    private String registrationNumber;
    private String issue;
    private String reportedById;
    private String reportedByName;
    private LocalDateTime reportedDate;
    private LocalDateTime expectedReturnDate;
    private MaintenanceStatus status;
}
