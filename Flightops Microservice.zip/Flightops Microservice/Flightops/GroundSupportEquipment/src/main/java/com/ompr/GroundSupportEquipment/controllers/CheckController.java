package com.ompr.GroundSupportEquipment.controllers;

import com.ompr.GroundSupportEquipment.entities.GroundEquipment;
import com.ompr.GroundSupportEquipment.enums.EquipmentStatus;
import com.ompr.GroundSupportEquipment.services.CheckService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
public class CheckController {
    @Autowired
    private CheckService cs;
    @GetMapping("/api/internal/counting")
    public long countinghere()
    {
        return cs.countinghere();
    }
    public List<GroundEquipment> findingbystatus(@PathVariable("e") EquipmentStatus e)
    {
        return cs.findingbystatus(e);
    }
}
