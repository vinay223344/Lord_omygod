package com.ompr.GroundSupportEquipment.enums;

public enum FlightStatus {
    Scheduled,
    Arrived,
    Departed,
    Delayed,
    Diverted,
    Cancelled
}
