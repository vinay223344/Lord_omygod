package com.ompr.GroundSupportEquipment.repositories;

import com.ompr.GroundSupportEquipment.entities.EquipmentAllocation;
import com.ompr.GroundSupportEquipment.entities.GroundEquipment;
import com.ompr.GroundSupportEquipment.enums.AllocationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EquipmentAllocationRepository extends JpaRepository<EquipmentAllocation, String> {

    List<EquipmentAllocation> findByFlight_FlightId(String flightId);

    List<EquipmentAllocation> findByStatusOrderByAllocationTimeDesc(AllocationStatus status);

    boolean existsByEquipmentAndStatus(GroundEquipment equipment, AllocationStatus status);

    List<EquipmentAllocation> findByEquipment(GroundEquipment equipment);
}
