package com.ompr.AnalyticsAndReporting.enums;

public enum UserStatus {
    Active,
    Inactive,
    OnShift
}
