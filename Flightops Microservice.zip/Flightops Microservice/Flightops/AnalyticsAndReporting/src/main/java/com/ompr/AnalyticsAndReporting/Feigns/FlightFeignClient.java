package com.ompr.AnalyticsAndReporting.Feigns;

import com.ompr.AnalyticsAndReporting.entities.Flight;
import com.ompr.AnalyticsAndReporting.entities.GroundOpsReport;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@FeignClient(name="FLIGHT")
public interface FlightFeignClient {
    @GetMapping("api/internal/todayflights/{start}/{end}")
    List<Flight> todayflights(@PathVariable("start") LocalDateTime start, @PathVariable("end") LocalDateTime end);
    @GetMapping("/api/internal/saving/{g}")
    GroundOpsReport saving(@PathVariable("g") GroundOpsReport g);
    @GetMapping("api/internal/findingallgenerateddatedesc")
    List<GroundOpsReport> findingallgenerateddatedesc();
}
