package com.ompr.AnalyticsAndReporting.Feigns;

import com.ompr.AnalyticsAndReporting.entities.TurnaroundMilestone;
import com.ompr.AnalyticsAndReporting.entities.TurnaroundPlan;
import com.ompr.AnalyticsAndReporting.enums.MilestoneStatus;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalDateTime;
import java.util.List;

@FeignClient(name="TURNAROUND")
public interface TurnaroundFeignClient
{
    @GetMapping("api/internal/findingallturnarounds")
    public List<TurnaroundPlan> findingallturnarounds();
    @GetMapping("/api/internal/findingbystatus/{e}")
    public List<TurnaroundMilestone> findingbystatus(@PathVariable("e") MilestoneStatus e);
    @GetMapping("/api/internal/findoverdues/{d}")
    public List<TurnaroundMilestone> findoverdues(@PathVariable("d")LocalDateTime d);

}
