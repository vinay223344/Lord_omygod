package com.ompr.AnalyticsAndReporting.enums;

public enum MishandledType {
    Lost,
    Delayed,
    Damaged,
    PilferedContent
}
