package com.ompr.AnalyticsAndReporting.Feigns;

import com.ompr.AnalyticsAndReporting.entities.SpecialAssistance;
import com.ompr.AnalyticsAndReporting.enums.AssistanceStatus;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name="PASSENGERHANDLING")
public interface PassengerFeignClient
{
    @GetMapping("/api/internal/findbystatus/{e}")
    public List<SpecialAssistance> findingstatus(@PathVariable("e") AssistanceStatus e);
}
