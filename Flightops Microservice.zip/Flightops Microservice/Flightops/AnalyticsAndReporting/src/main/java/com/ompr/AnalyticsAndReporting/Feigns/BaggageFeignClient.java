package com.ompr.AnalyticsAndReporting.Feigns;

import com.ompr.AnalyticsAndReporting.entities.BaggageOperation;
import com.ompr.AnalyticsAndReporting.entities.MishandledBaggage;
import com.ompr.AnalyticsAndReporting.enums.MishandledStatus;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name = "BAGGAGEHANDLING")
public interface BaggageFeignClient {
    @GetMapping("/api/internal/findingallbaggages")
    public List<BaggageOperation> findingallbaggages();
    @GetMapping("/api/internal/findingbystatus/{e}")
    public List<MishandledBaggage> findingbystatus(@PathVariable("e") MishandledStatus e);
    @GetMapping("/api/internal/updatecount")
    public long updatecount();

}
