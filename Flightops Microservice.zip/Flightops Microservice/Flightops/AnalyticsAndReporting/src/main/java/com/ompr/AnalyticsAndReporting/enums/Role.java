package com.ompr.AnalyticsAndReporting.enums;

public enum Role {
    Admin,

    AirlineCoordinator,

    GroundSupervisor,

    GSEManager,

    PassengerAgent,

    RampOfficer

}
