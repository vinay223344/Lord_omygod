package com.ompr.AnalyticsAndReporting.enums;

public enum TurnaroundStatus {
    Active,
    Completed,
    Delayed
}
