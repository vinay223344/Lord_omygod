package com.ompr.AnalyticsAndReporting.Feigns;

import com.ompr.AnalyticsAndReporting.entities.GroundEquipment;
import com.ompr.AnalyticsAndReporting.enums.EquipmentStatus;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name="GROUNDSUPPORTEQUIPMENT")
public interface GroundSupportFeignClient
{
    @GetMapping("/api/internal/counting")
    public long countinghere();
    @GetMapping("/api/internal/findingbystatus/{e}")
    public List<GroundEquipment> findingbystatus(@PathVariable("e") EquipmentStatus e);
}
