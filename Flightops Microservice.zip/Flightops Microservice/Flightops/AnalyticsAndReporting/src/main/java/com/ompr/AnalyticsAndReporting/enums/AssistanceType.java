package com.ompr.AnalyticsAndReporting.enums;

public enum AssistanceType {
    WheelchairToGate,
    UnaccompaniedMinor,
    MedicalCase,
    StretcherCase
}
