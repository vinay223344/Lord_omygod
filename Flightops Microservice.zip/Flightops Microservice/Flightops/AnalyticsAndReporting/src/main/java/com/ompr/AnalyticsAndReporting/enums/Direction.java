package com.ompr.AnalyticsAndReporting.enums;

public enum Direction {
    Inbound,
    Outbound
}
