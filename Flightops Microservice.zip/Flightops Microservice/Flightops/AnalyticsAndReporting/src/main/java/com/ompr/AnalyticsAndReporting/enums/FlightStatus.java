package com.ompr.AnalyticsAndReporting.enums;

public enum FlightStatus {
    Scheduled,
    Arrived,
    Departed,
    Delayed,
    Diverted,
    Cancelled
}
