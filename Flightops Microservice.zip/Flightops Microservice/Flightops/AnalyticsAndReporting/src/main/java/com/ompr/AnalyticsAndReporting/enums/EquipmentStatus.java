package com.ompr.AnalyticsAndReporting.enums;

public enum EquipmentStatus {
    Available,
    Allocated,
    Maintenance,
    OutOfService
}
