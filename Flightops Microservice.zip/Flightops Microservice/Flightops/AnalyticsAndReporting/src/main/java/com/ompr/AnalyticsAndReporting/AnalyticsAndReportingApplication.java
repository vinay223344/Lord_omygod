package com.ompr.AnalyticsAndReporting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients(basePackages = "com.ompr.AnalyticsAndReporting.Feigns")
public class AnalyticsAndReportingApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnalyticsAndReportingApplication.class, args);
	}

}
