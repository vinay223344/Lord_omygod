package com.ompr.AnalyticsAndReporting.entities;

import com.ompr.AnalyticsAndReporting.enums.TurnaroundStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "turnaround_plans")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TurnaroundPlan {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String planId;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "flight_id", nullable = false, unique = true)
    private Flight flight;

    private Integer targetTurnaroundMinutes;
    private Integer actualTurnaroundMinutes;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "supervisor_id")
    private User supervisor;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TurnaroundStatus status;
}
