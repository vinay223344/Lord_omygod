package com.ompr.AnalyticsAndReporting.enums;

public enum MishandledStatus {
    Reported,
    Traced,
    Recovered,
    Claimed,
    ClosedUnresolved
}
