package com.ompr.AnalyticsAndReporting.enums;

public enum OperationStatus {
    InProgress,
    Completed,
    Discrepancy
}
