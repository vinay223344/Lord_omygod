package com.ompr.AnalyticsAndReporting.enums;

public enum MilestoneStatus {
    Pending,
    Completed,
    Skipped,
    Delayed
}
