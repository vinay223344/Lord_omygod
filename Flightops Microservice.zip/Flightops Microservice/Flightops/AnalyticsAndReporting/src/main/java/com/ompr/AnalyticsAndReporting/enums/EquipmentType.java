package com.ompr.AnalyticsAndReporting.enums;

public enum EquipmentType {
    StairsTruck,
    BaggageBelt,
    BusTractor,
    GPU,
    AirStarter,
    TowTractor,
    Catering
}
