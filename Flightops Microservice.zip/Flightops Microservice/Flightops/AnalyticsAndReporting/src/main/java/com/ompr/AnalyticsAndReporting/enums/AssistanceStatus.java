package com.ompr.AnalyticsAndReporting.enums;

public enum AssistanceStatus {
    Requested,
    Assigned,
    Completed
}
