import java.util.Arrays;
public class Anagram {
    
    public static boolean isAnagram(String str1 , String str2){

        char a[]=str1.replaceAll("//s","").toLowerCase().toCharArray();
        char b[]=str1.replaceAll("//s","").toLowerCase().toCharArray();

        Arrays.sort(a);
        Arrays.sort(b);
        return Arrays.equals(a,b);

    }
    public static void main(String args[]){
        String s1="Listen";
        String s2="silent";

        System.out.println(s1+ " and "+s2+ " are anagram ? "+ isAnagram(s1,s2));
    }
}

