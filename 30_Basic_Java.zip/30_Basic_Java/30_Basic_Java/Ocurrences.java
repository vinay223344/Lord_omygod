import java.util.*;
public class Ocurrences {
    public static void abc(String str){
        HashMap<Character , Integer> map = new HashMap<>();
         
        for(char ch : str.toCharArray()){
            if(ch!=' '){
                map.put(ch, map.getOrDefault(ch,0)+1);
            }
        }
        for(Map.Entry<Character , Integer> entry : map.entrySet()){
            System.out.println("The character "+entry.getKey()+" count "+entry.getValue());
        }
    }
    public static void main(String args[]){
        String str="Keerthana";
        abc(str);
    }
}
