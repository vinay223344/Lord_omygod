public class ToggleCase {
    public static String Toggle(String str){
        StringBuilder result = new StringBuilder();

        for( char ch : str.toCharArray()) {
            if(Character.isLowerCase(ch)){
                result.append(Character.toUpperCase(ch));
            }else if (Character.isUpperCase(ch)) {
                result.append(Character.toLowerCase(ch));    
            }else{
                result.append(ch); //leave non-alphabet character
            }
        }
        return result.toString();

    }
    public static void main(String args[]){
        String original = "KeeRthANa@1821";
        String Toggled = Toggle(original);

        System.out.println("The original string is: "+original);
        System.out.println("The toggled String is: "+Toggled);
    }
    
}
