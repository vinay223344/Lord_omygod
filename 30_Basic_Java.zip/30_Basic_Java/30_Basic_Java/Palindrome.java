public class Palindrome {
    public static void main(String args[]){
        String str="mAdam";

        String reversed = new StringBuilder(str).reverse().toString().toLowerCase();

        if(str.equals(reversed)){
            System.out.println("The given string is a palindrome");
        }else{
            System.out.println("The string is not a palindrome");
        }
    }
}
