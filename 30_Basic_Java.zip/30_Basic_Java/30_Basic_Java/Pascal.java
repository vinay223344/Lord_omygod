import java.util.*;

public class Pascal {
    public static int nCr(int n , int r){
        int result =1;
        for(int i=0;i<r;i++){
            result = result * (n-i);
            result = result / (i+1);   
        }
        return result;
    }
    public static List<List<Integer>> pascal(int n){
        List<List<Integer>> ans = new ArrayList<>();
        for(int row=1; row<=n;row++){
            List<Integer> templst= new ArrayList<>();
            for(int col=1;col<=row;col++){
                templst.add(nCr(row-1,col-1));
            } 
            ans.add(templst);
        }
        return ans;


    }
    public static void main(String args[]){
        int n=5;
        List<List<Integer>> ans = pascal(n);
        for(List<Integer> it:ans){
            for(int ele:it){
                System.out.print(ele+" ");
            }
            System.out.println();
        }
    }
}
