import java.util.*;
public class Leftrotate {
    public static void main(String args[]){
        int arr[]={1,2,3,4,5};
        int k =2;
        int n = arr.length;
        int rotated[]=new int[n];
        for(int i=0;i<n;i++){
            rotated[i]= arr[(i+k)%n];
        }
        System.out.println("The rotated array is :"+Arrays.toString(rotated));
    }
}
