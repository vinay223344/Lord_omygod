public class Even_Odd {
    public static void main(String args[]){
        int arr[]={22,34,56,7};

        int even=0;
        int odd=0;

        for(int i=0;i<arr.length;i++){
            if(arr[i]%2 == 0){
                even++;
            }else{
                odd++;
            }
        }
        System.out.println("The count of even numbers in the given array: " + even);
        System.out.println("The count of odd numbers in the given array: " + odd);
    }
}
