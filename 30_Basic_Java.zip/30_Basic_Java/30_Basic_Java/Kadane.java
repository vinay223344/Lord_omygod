public class Kadane {
    public static void main(String args[]){
        int arr[]={1,-2,3,4,-6,-2,1,3,4};
        int currentsum=arr[0];
        int maxsum=arr[0];

        for(int i=1;i<arr.length;i++){
            currentsum=Math.max(arr[i],currentsum+arr[i]);
            maxsum=Math.max(maxsum,currentsum);
        }
        System.out.println("The max of subarray is : "+maxsum);
    }
}
