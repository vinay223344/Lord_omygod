
import java.util.Arrays;

public class Movezero {
    public static void main(String args[]){
        int arr[]={1,2,0,0,0,8,7};
        int index=0;

        for(int num : arr){
            if(num!=0){
                arr[index++]=num;
            }
        }
        while(index<arr.length)
        {
            arr[index++]=0;

        }
        System.out.println("The array after the zeros moved to last will be : "+ Arrays.toString(arr));
    }
}
