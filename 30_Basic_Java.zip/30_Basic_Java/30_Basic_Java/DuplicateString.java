import java.util.HashSet;

public class DuplicateString {
    public static String Duplicate(String str){
        HashSet<Character> seen = new HashSet<>();
        StringBuilder result = new StringBuilder();
        for(char ch: str.toCharArray()){
            char character = Character.toLowerCase(ch);
            if(!seen.contains(character)){
                seen.add(character);
                result.append(character);
            }
        }
        return result.toString();
    }
    public static void main(String args[]){
        String original="ProgramMing";
        String WithoutDuplicate = Duplicate(original);
        System.out.println("The original string is: "+original);
        System.out.println("The string without duplicate is: "+WithoutDuplicate);
    }
}
