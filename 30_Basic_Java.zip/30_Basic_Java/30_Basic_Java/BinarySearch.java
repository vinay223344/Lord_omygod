import java.util.*;
public class BinarySearch {
    public static int Binary(int arr[],int key){
        int left=0; int right=arr.length - 1;

        while(left<=right){
            int mid = left + (right - left) / 2;
            if(arr[mid]==key){
                return mid;
            }else if(arr[mid]<key){
                left = mid +1;
            }else{
                right = mid -1;
            }
        }
        return -1;
    }
    public static void main(String args[]){
        int arr[]={1,7,6,4,3};
        int key = 7;
        Arrays.sort(arr);
        System.out.println("The sorted array: "+Arrays.toString(arr));
        int result = Binary(arr,key);
        System.out.println("The element found at : "+result);
    }
}
