public class Second_Largest{
    public static void main(String[] args) {
        int arr[]={34,30,21,24,50};

        System.out.print("The second largest element from the given array is : ");

        int first=0;
        int second=0;

        for(int num:arr){
            if(num>first){
                second=first;
                first = num;
                
            }else if (num > second && num!=first) {
                second=num;
                
            }
        }
        System.out.println(second);
    }
}