import java.util.*;
public class Reverse_String {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.print("The original string: ");
        String str = sc.next();

        String reversed = new StringBuilder(str).reverse().toString();
        System.out.print("The reversed string is given as : "+reversed);
    }
}
