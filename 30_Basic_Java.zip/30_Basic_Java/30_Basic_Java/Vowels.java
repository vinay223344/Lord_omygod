import java.util.*;
public class Vowels {
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the string: ");
        String str = sc.next();
        str=str.toLowerCase();
        int vowels=0;
        int consonants=0;

        for(int i=0;i<str.length();i++){
            char ch=str.charAt(i);

            if(ch>='a' && ch<='z'){
                if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u'){
                    vowels++;
                }else{
                    consonants++;
                }
            }
        }
        System.out.println("The total number of vowels are : "+vowels);
        System.out.println("The total number of consonants are : "+consonants);
    }
}
