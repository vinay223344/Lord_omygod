public class BinToDec {
    public static int Binary(String bin){
        return Integer.parseInt(bin,2);
    }
    public static void main(String args[]){
        String bin="1101";
        System.out.println("The binary to decimal value of "+bin+ " is "+Binary(bin));
       
    }
}
