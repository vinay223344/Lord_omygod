import java.util.*;
public class FrequencyCount {
    public static void main(String[] args) {
        int arr[]={1,2,1,1,3,4,4,3,2};

        HashMap<Integer,Integer> countMap=new HashMap<>();

        for(int num:arr){
            if(countMap.containsKey(num)){
                countMap.put(num,countMap.get(num)+1);

                }else{
                    countMap.put(num,1);
                }
            }
            for(int key: countMap.keySet()){
                System.out.println("Element "+ key + " occurs "+ countMap.get(key)+" times.");
            }
        }
    }

