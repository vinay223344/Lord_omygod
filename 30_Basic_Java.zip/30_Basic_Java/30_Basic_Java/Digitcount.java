public class Digitcount {
    public static int Digit(int num){
        int count=0;
        num = Math.abs(num);
        if(num==0) {
            return 1;
        }while(num>0){
            num /= 10;
            count++;
        }
        return count;
    }
    public static void main(String args[]){
        int num = 123;
        System.out.println("The total number of digits: "+Digit(num));
    }
}
