import java.util.*;

public class ArrayIntersection{
    public static void intersection(int arr1[],int arr2[]){
        Set<Integer> set = new HashSet<>();
        Set<Integer> result = new HashSet<>();
        
        for(int num : arr1) set.add(num);
        for(int num : arr2){
            if(set.contains(num)){
                result.add(num);
            }
        }
        System.out.print("Intersection: "+result);
    }
    public static void main(String args[]){
        int arr1[]={1,2,2,4,6,7,8};
        int arr2[]={2,2,4,5,7,8};
        intersection(arr1,arr2);
    }
}