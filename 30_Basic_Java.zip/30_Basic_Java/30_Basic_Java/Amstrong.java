public class Amstrong {
    public static void main(String args[]){
        int num=153;
        int sum=0;
        int original = num;

        while(num>0){
            int digit = num%10;
            sum += Math.pow(digit,3);
            num /= 10;
        }

    if(sum==original){
        System.out.println("The given number is amstrong  "+ original);
    }else{
        System.out.println("the given number is not amstrong "+ original);
    }
    }
}
