public class Dectobin{
    public static String DecimalToBinary(int value){
        return Integer.toBinaryString(value);
    }

    public static void main(String args[]){
        int value = 11;
        System.out.println("The Binary value of "+value+" is: "+DecimalToBinary(value));
    }
}
