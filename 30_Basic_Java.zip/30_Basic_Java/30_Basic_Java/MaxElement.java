public class MaxElement{
    public static void main(String args[]){

        int arr[]={7,9,5,4};

        int max=arr[0];
        for (int i = 0; i < arr.length; i++) {
           if(arr[i]>max){
            max=arr[i];
           } 
        }
        System.out.print("The maximum element in the given array is : "+ max);
    }
}