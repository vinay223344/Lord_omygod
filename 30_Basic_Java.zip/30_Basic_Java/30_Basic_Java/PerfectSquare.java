public class PerfectSquare {
    public static boolean isSquare(int num){
        int sqrt = (int) Math.sqrt(num);
        return sqrt*sqrt == num ; 
    }

    public static void main(String args[]){
        int num = 53;
        boolean result = isSquare(num);
        System.out.println(num+ " is perfect square ? " + result);
    }
}
