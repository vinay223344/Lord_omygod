import java.util.*;
public class Merge_array {
    public static void main(String args[]){
        int arr1[]={1,4,6,7,8};
        int arr2[]={1,2,3,4,5};
        int merged[]=new int[arr1.length+arr2.length];
        int i=0;int j=0;int k=0;//indices

        while(i<arr1.length && j<arr2.length){
            if(arr1[i]<arr2[j]){
                merged[k++]= arr1[i++];
            }else{
                merged[k++]=arr2[j++];
            }
        }
        while(i<arr1.length){
            merged[k++]=arr1[i++];
        }
        while(j<arr2.length){
            merged[k++]=arr2[j++];
        }

        System.out.println("The merged sorted array:"+ Arrays.toString(merged));

    }
    
}

