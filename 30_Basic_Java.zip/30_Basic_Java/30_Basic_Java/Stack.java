public class Stack {
    int maxsize;
    int stack[];
    int top;

    public Stack(int size){
         maxsize= size;
         this.stack=new int[maxsize];
         this.top = -1;
    }
    
    public void push(int value){
        if(top == maxsize-1){
            System.out.println("The is full(overflow)");
        }else{
            stack[++top]=value;
            System.out.println(value+" pushed to stack");
        }
    }
    public int peek(){
        if(top==-1){
            System.out.println("The stack is empty");
            return -1;
        }
        else{
            return stack[top];
        }
    }
    public int pop(){
        if(top==-1){
            System.out.println("The stack is empty");
            return -1;
        }
        else{
            return stack[top--];
        }
    }
    public boolean isEmpty(){
        return top==-1;
    }

    public static void main(String args[]){
      Stack s = new Stack(5);  

        s.push(10);
        s.push(20);
        s.push(30);

        System.out.println("The top element in the stack is: "+s.peek());
        System.out.println("The top element after removal: "+s.pop());
        System.out.println("Now the top element in the stack is: "+s.peek());
        System.out.println("Tis the stack empty? "+s.isEmpty());
        


    }
}
