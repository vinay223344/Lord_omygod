
import java.util.HashMap;

public class ToSum {
    public static int[] tosum(int arr[] , int target){
        HashMap<Integer , Integer> map = new HashMap<>();
        for(int i=0;i<arr.length;i++){
        int complement = target - arr[i];
        if(map.containsKey(complement)){
            return new int[] {map.get(complement),i};
        }
        map.put(arr[i],i);
    }
    return new int[] {};
}
public static void main(String args[]){
    int arr[]={2,7,6,11};
    int target=9;
    int result[] = tosum(arr,target);
    System.out.println("Indices: "+result[0]+" "+result[1]);
}
}
