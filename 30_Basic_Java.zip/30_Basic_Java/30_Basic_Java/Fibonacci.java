public class Fibonacci {
    public static void main(String args[]){
        System.out.println("The fibonacci series upto 10 is as follows: ");
        int n =10;
        int a=0;
        int b=1;
        System.out.print(a+" "+b+" " );
        for(int i=2;i<n;i++){
            int c=a+b;
            System.out.print(c+" ");
            a=b;
            b=c;
        }
    }
}
