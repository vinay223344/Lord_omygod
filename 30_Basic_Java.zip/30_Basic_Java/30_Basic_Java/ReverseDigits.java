public class ReverseDigits {
    public static void main(String args[]){
        int num =12345;
        System.out.println("The original digits are: "+num);
        int reversed=0;
        while(num>0){
            int digit = num % 10;
            reversed = reversed*10+digit;
            num /= 10;
        }
        System.out.print("The reversed digits are: "+reversed);
    }
}
