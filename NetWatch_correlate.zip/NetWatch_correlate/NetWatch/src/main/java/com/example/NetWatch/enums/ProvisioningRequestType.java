package com.example.NetWatch.enums;

public enum ProvisioningRequestType {
    NEW_ACTIVATION,
    BANDWIDTH_UPGRADE,
    SUSPENSION,
    TERMINATION
}
