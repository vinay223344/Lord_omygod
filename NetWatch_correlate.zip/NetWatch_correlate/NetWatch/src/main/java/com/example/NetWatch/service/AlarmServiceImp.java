package com.example.NetWatch.service;

import com.example.NetWatch.entity.*;
import com.example.NetWatch.enums.*;
import com.example.NetWatch.repository.AlarmRepo;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.repository.TopologyRepo;
import com.example.NetWatch.repository.TroubleTicketRepo;
import com.example.NetWatch.requestdto.NetworkAlarmRequestDTO;
import com.example.NetWatch.responsedto.NetworkAlarmResponseDTO;
import com.example.NetWatch.repository.CorrelationRepo;
import com.example.NetWatch.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class AlarmServiceImp implements AlarmService {

    @Autowired
    private AlarmRepo alarmRepo;

    @Autowired
    private TroubleTicketRepo ticketRepo;

    @Autowired
    private NetworkElementRepo elementRepo;

    @Autowired
    private AuditLogService auditService;

    @Autowired
    private CorrelationRepo correlationRepo;

    @Autowired
    private TopologyRepo linkRepo;

    @Override
    @Transactional
    public NetworkAlarmResponseDTO create(NetworkAlarmRequestDTO alarmRequest, Long creatorId) {
        NetworkAlarm alarm = mapToEntity(alarmRequest);
        alarm.setAlarmTime(LocalDateTime.now());
        alarm.setStatus(AlarmStatus.ACTIVE);

        NetworkAlarm saved = alarmRepo.save(alarm);

        //  AUTO-GENERATE TROUBLE TICKET from alarm
        autoGenerateTicket(saved);
        autoCorrelate(saved);
        auditService.log(creatorId, "CREATE_ALARM", "NetworkAlarm", saved.getAlarmId());

        return mapToResponse(saved);
    }

    //  AUTO CORRELATION
    private void autoCorrelate(NetworkAlarm newAlarm) {

        //  STEP 1: Get all connected elements (BFS)
        List<NetworkElement> elements =
                getAllConnected(newAlarm.getElement());
        List<NetworkAlarm> related = new ArrayList<>();

        //  STEP 2: FILTER alarms by topology + TIME
        List<Long> elementIds = elements.stream()
                .map(NetworkElement::getElementId)
                .collect(Collectors.toList());

        List<NetworkAlarm> alarms =
                alarmRepo.findByElement_ElementIdInAndStatus(elementIds, AlarmStatus.ACTIVE);
        for (NetworkAlarm a : alarms) {

            //  TIME WINDOW (5 minutes)
            long minutes = Math.abs(
                    ChronoUnit.MINUTES.between(
                            a.getAlarmTime(),
                            newAlarm.getAlarmTime()
                    )
            );
            if (minutes <= 5) {
                related.add(a);
            }
        }

        // remove duplicates
        related = new ArrayList<>(new HashSet<>(related));

        // STEP 3: CREATE CORRELATION GROUP
        if (!related.isEmpty()) {

            //  Convert new alarms to Set
            Set<Long> newSet = new HashSet<>();
            for (NetworkAlarm a : related) {
                newSet.add(a.getAlarmId());
            }
            for (AlarmCorrelation existing : correlationRepo.findAll()) {
                Set<Long> existingSet = parseIds(existing.getAlarmIds());
                // MAIN FIX: subset logic
                if (!existingSet.isEmpty() && newSet.containsAll(existingSet)) {
                    // MERGE alarm IDs
                    existingSet.addAll(newSet);
                    existing.setAlarmIds(existingSet.toString());
                    existing.setImpactSummary(existingSet.size() + " devices affected");
                    correlationRepo.save(existing);
                    return;
                }
            }
            AlarmCorrelation correlation = new AlarmCorrelation();
            correlation.setAlarmIds(newSet.toString());
            if(newSet.size() == 1) {
                correlation.setImpactSummary("1 device affected");
            }
            else {
                correlation.setImpactSummary(related.size() + " devices affected");
            }
            correlation.setStatus(CorrelationStatus.OPEN);
            correlationRepo.save(correlation);
        }
    }

    private Set<Long> parseIds(String ids) {
        ids = ids.replaceAll("[\\[\\]\\s]", ""); // remove [] and spaces
        Set<Long> set = new HashSet<>();
        if (ids.isEmpty()) return set;
        for (String s : ids.split(",")) {
            set.add(Long.parseLong(s));
        }
        return set;
    }

    // GRAPH TRAVERSAL (BFS)
    private List<NetworkElement> getAllConnected(NetworkElement start) {
        Set<NetworkElement> visited = new HashSet<>();
        Queue<NetworkElement> queue = new LinkedList<>();
        queue.add(start);
        visited.add(start);
        while (!queue.isEmpty()) {
            NetworkElement curr = queue.poll();
            List<TopologyLink> links =
                    linkRepo.findByElementAOrElementB(curr, curr);
            for (TopologyLink link : links) {
                NetworkElement next =
                        link.getElementA().equals(curr)
                                ? link.getElementB()
                                : link.getElementA();
                if (!visited.contains(next)) {
                    visited.add(next);
                    queue.add(next);
                }
            }
        }
        return new ArrayList<>(visited);
    }

    private void autoGenerateTicket(NetworkAlarm alarm) {
        TroubleTicket ticket = new TroubleTicket();

        // Link alarm and element/site from alarm
        ticket.setAlarm(alarm);
        ticket.setElement(alarm.getElement());

        // Map AlarmType → TroubleTicket Category
        TicketCategory category = switch (alarm.getAlarmType()) {
            case LINK_DOWN         -> TicketCategory.LINK_FAULT;
            case NODE_UNREACHABLE  -> TicketCategory.NODE_FAULT;
            case HIGH_UTILISATION  -> TicketCategory.CONGESTION;
            case POWER_FAILURE     -> TicketCategory.POWER_ISSUE;
            case HARDWARE_FAULT    -> TicketCategory.NODE_FAULT;
            case COOLING_ALERT     -> TicketCategory.NODE_FAULT;
        };
        ticket.setCategory(category);

        // Map Severity → Priority
        TicketPriority priority = switch (alarm.getSeverity()) {
            case CRITICAL -> TicketPriority.P1;
            case MAJOR    -> TicketPriority.P2;
            case MINOR    -> TicketPriority.P3;
            case WARNING  -> TicketPriority.P4;
        };
        ticket.setPriority(priority);

        // SLA based on priority
        LocalDateTime raisedAt = LocalDateTime.now();
        int slaHours = switch (priority) {
            case P1 -> 2;
            case P2 -> 4;
            case P3 -> 12;
            case P4 -> 24;
        };

        ticket.setRaisedDateTime(raisedAt);
        ticket.setRestorationSLATime(raisedAt.plusHours(slaHours));
        ticket.setStatus(TicketStatus.OPEN);

        if (alarm.getElement() != null) {
            ticket.setSite(alarm.getElement().getSite());
        }

        ticketRepo.save(ticket);
    }

    @Override
    public List<NetworkAlarmResponseDTO> getAll() {
        return alarmRepo.findAll().stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional
    public NetworkAlarmResponseDTO acknowledge(Long id, Long userId) {
        NetworkAlarm alarm = alarmRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Alarm not found: " + id));

        alarm.setStatus(AlarmStatus.ACKNOWLEDGED);
        alarm.setAcknowledgedById(userId);
        alarm.setAcknowledgedTime(String.valueOf(LocalDateTime.now()));

        NetworkAlarm saved = alarmRepo.save(alarm);
        auditService.log(userId, "ACKNOWLEDGE_ALARM", "NetworkAlarm", saved.getAlarmId());
        return mapToResponse(saved);
    }

    @Override
    @Transactional
    public NetworkAlarmResponseDTO clearAlarm(Long id, Long userId) {
        NetworkAlarm alarm = alarmRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Alarm not found: " + id));

        alarm.setStatus(AlarmStatus.CLEARED);
        alarm.setClearedTime(String.valueOf(LocalDateTime.now()));

        NetworkAlarm saved = alarmRepo.save(alarm);
        auditService.log(userId, "CLEAR_ALARM", "NetworkAlarm", saved.getAlarmId());
        return mapToResponse(saved);
    }

    private NetworkAlarm mapToEntity(NetworkAlarmRequestDTO request) {
        if (request == null) return null;
        NetworkAlarm alarm = new NetworkAlarm();
        if (request.getElementId() != null) {
            NetworkElement element = elementRepo.findById(request.getElementId()).orElse(null);
            alarm.setElement(element);
        }
        alarm.setAlarmType(request.getAlarmType());
        alarm.setSeverity(request.getSeverity());
        alarm.setStatus(request.getStatus());
        return alarm;
    }

    private NetworkAlarmResponseDTO mapToResponse(NetworkAlarm alarm) {
        if (alarm == null) return null;
        return NetworkAlarmResponseDTO.builder()
                .alarmId(alarm.getAlarmId())
                .elementId(alarm.getElement() != null ? alarm.getElement().getElementId() : null)
                .elementName(alarm.getElement() != null ? alarm.getElement().getElementName() : null)
                .alarmType(alarm.getAlarmType())
                .severity(alarm.getSeverity())
                .alarmTime(String.valueOf(alarm.getAlarmTime()))
                .acknowledgedById(alarm.getAcknowledgedById())
                .acknowledgedTime(alarm.getAcknowledgedTime())
                .clearedTime(alarm.getClearedTime())
                .status(alarm.getStatus())
                .build();
    }
}
