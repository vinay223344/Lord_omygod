package com.example.NetWatch.service;

import com.example.NetWatch.responsedto.CorrelationResponseDTO;
import java.util.List;

public interface CorrelationService {

    List<CorrelationResponseDTO> getAll();

}
