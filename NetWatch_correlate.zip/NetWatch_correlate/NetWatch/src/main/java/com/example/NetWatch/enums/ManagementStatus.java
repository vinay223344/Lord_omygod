package com.example.NetWatch.enums;

public enum ManagementStatus {
    MANAGED,
    UNMANAGED
}
