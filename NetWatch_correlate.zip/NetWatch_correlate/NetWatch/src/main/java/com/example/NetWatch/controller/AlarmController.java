package com.example.NetWatch.controller;

import com.example.NetWatch.requestdto.NetworkAlarmRequestDTO;
import com.example.NetWatch.responsedto.NetworkAlarmResponseDTO;
import com.example.NetWatch.service.AlarmService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/alarm")
public class AlarmController {

    @Autowired
    private AlarmService service;

    //  NOC Engineer manually enters an alarm → ticket auto-generated
    @PostMapping
    @PreAuthorize("hasRole('NOC_ENGINEER') or hasRole('ADMIN') or hasRole('SERVICE_DESK')" )
    public ResponseEntity<NetworkAlarmResponseDTO> create(@RequestBody NetworkAlarmRequestDTO alarmRequest, @RequestParam Long creatorId) {
        log.info("Creating new alarm: type={}, severity={}, creatorId={}", alarmRequest.getAlarmType(), alarmRequest.getSeverity(), creatorId);
        NetworkAlarmResponseDTO saved = service.create(alarmRequest, creatorId);
        log.info("Alarm created: id={}", saved.getAlarmId());
        return ResponseEntity.ok(saved);
    }

    //  Get all alarms
    @GetMapping
    @PreAuthorize("hasRole('NOC_ENGINEER') or hasRole('ADMIN') or hasRole('SERVICE_DESK') or hasRole('PLANNING_ENGINEER')")
    public ResponseEntity<List<NetworkAlarmResponseDTO>> getAll() {
        log.debug("Fetching all alarms");
        List<NetworkAlarmResponseDTO> list = service.getAll();
        return ResponseEntity.ok(list);
    }

    //  NOC Engineer acknowledges an alarm
    @PutMapping("/ack/{id}")
    @PreAuthorize("hasRole('NOC_ENGINEER') or hasRole('ADMIN')  or hasRole('SERVICE_DESK')")
    public ResponseEntity<NetworkAlarmResponseDTO> acknowledge(@PathVariable Long id, @RequestParam Long userId) {
        log.info("Acknowledging alarm id={} by userId={}", id, userId);
        NetworkAlarmResponseDTO saved = service.acknowledge(id, userId);
        return ResponseEntity.ok(saved);
    }

    //  NOC Engineer clears an alarm
    @PutMapping("/clear/{id}")
    @PreAuthorize("hasRole('NOC_ENGINEER') or hasRole('ADMIN') or hasRole('SERVICE_DESK')")
    public ResponseEntity<NetworkAlarmResponseDTO> clear(@PathVariable Long id, @RequestParam Long userId) {
        log.info("Clearing alarm id={} by userId={}", id, userId);
        NetworkAlarmResponseDTO saved = service.clearAlarm(id, userId);
        return ResponseEntity.ok(saved);
    }
}