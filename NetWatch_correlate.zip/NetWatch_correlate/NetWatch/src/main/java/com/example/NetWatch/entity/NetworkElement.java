package com.example.NetWatch.entity;

import com.example.NetWatch.enums.ElementType;
import com.example.NetWatch.enums.ElementStatus;
import com.example.NetWatch.enums.ManagementStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Entity
@Table(name = "network_element")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class NetworkElement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long elementId;

    private String elementName;

    @Enumerated(EnumType.STRING)
    private ElementType elementType;

    private String vendor;
    private String model;

    private String ipAddress;

    @Enumerated(EnumType.STRING)
    private ElementStatus status;

    @ManyToOne
    @JoinColumn(name = "site_id")
    private NetworkSite site;

    @OneToMany(mappedBy = "elementA")
    private List<TopologyLink> linksA;

    @OneToMany(mappedBy = "elementB")
    private List<TopologyLink> linksB;
}
