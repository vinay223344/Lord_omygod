package com.example.NetWatch.controller;

import com.example.NetWatch.requestdto.CapacityRecordRequestDTO;
import com.example.NetWatch.responsedto.CapacityRecordResponseDTO;
import com.example.NetWatch.requestdto.MaintenanceWindowRequestDTO;
import com.example.NetWatch.responsedto.MaintenanceWindowResponseDTO;
import com.example.NetWatch.enums.MaintenanceStatus;
import com.example.NetWatch.service.CapacityService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/capacity")
public class CapacityController {

    @Autowired
    private CapacityService capacityService;

    @PostMapping("/record")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER')")
    public ResponseEntity<CapacityRecordResponseDTO> addCapacityRecord(@RequestBody CapacityRecordRequestDTO recordRequest, @RequestParam Long creatorId) {
        log.info("Adding capacity record by creatorId={}", creatorId);
        CapacityRecordResponseDTO saved = capacityService.addCapacityRecord(recordRequest, creatorId);
        log.info("Capacity record created: id={}, status={}", saved.getCapacityId(), saved.getStatus());
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/record")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER') or hasRole('NOC_ENGINEER') or hasRole('CHANGE_MANAGER')")
    public ResponseEntity<List<CapacityRecordResponseDTO>> getAllRecords() {
        log.debug("Fetching all capacity records");
        List<CapacityRecordResponseDTO> list = capacityService.getAllCapacityRecords();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/record/breach")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER') or hasRole('NOC_ENGINEER')")
    public ResponseEntity<List<CapacityRecordResponseDTO>> getBreaches() {
        log.debug("Fetching capacity breaches");
        List<CapacityRecordResponseDTO> list = capacityService.getCapacityBreaches();
        return ResponseEntity.ok(list);
    }

    // MAINTENANCE WINDOWS

    @PostMapping("/maintenance")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER')")
    public ResponseEntity<MaintenanceWindowResponseDTO> createMaintenanceWindow(@RequestBody MaintenanceWindowRequestDTO windowRequest, @RequestParam Long creatorId) {
        log.info("Creating maintenance window by creatorId={}", creatorId);
        MaintenanceWindowResponseDTO saved = capacityService.createMaintenanceWindow(windowRequest, creatorId);
        log.info("Maintenance window created: id={}", saved.getMaintenanceId());
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/maintenance/{id}/approve")
    @PreAuthorize("hasRole('ADMIN') or hasRole('CHANGE_MANAGER')")
    public ResponseEntity<MaintenanceWindowResponseDTO> approveMaintenanceWindow(@PathVariable Long id, @RequestParam Long approverId) {
        log.info("Approving maintenance window id={} by approverId={}", id, approverId);
        MaintenanceWindowResponseDTO saved = capacityService.approveMaintenanceWindow(id, approverId);
        return ResponseEntity.ok(saved);
    }

    @PutMapping("/maintenance/{id}/status")
    @PreAuthorize("hasRole('ADMIN') or hasRole('CHANGE_MANAGER') or hasRole('PLANNING_ENGINEER')")
    public ResponseEntity<MaintenanceWindowResponseDTO> updateMaintenanceStatus(
            @PathVariable Long id,
            @RequestParam MaintenanceStatus status,
            @RequestParam Long updaterId) {
        log.info("Updating maintenance window id={} to status={} by updaterId={}", id, status, updaterId);
        MaintenanceWindowResponseDTO saved = capacityService.updateMaintenanceStatus(id, status, updaterId);
        return ResponseEntity.ok(saved);
    }

    @GetMapping("/maintenance")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER') or hasRole('NOC_ENGINEER') or hasRole('CHANGE_MANAGER')")
    public ResponseEntity<List<MaintenanceWindowResponseDTO>> getAllWindows() {
        List<MaintenanceWindowResponseDTO> list = capacityService.getAllMaintenanceWindows();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/maintenance/pending")
    @PreAuthorize("hasRole('ADMIN') or hasRole('CHANGE_MANAGER')")
    public ResponseEntity<List<MaintenanceWindowResponseDTO>> getPendingWindows() {
        List<MaintenanceWindowResponseDTO> list = capacityService.getPendingMaintenanceWindows();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/maintenance/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('PLANNING_ENGINEER') or hasRole('NOC_ENGINEER') or hasRole('CHANGE_MANAGER')")
    public ResponseEntity<MaintenanceWindowResponseDTO> getWindowById(@PathVariable Long id) {
        MaintenanceWindowResponseDTO saved = capacityService.getMaintenanceWindowById(id);
        return ResponseEntity.ok(saved);
    }
}
