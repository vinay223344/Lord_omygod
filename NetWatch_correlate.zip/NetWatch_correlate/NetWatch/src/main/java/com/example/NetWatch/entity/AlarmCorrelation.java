package com.example.NetWatch.entity;

import com.example.NetWatch.enums.CorrelationStatus;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
public class AlarmCorrelation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long correlationId;

    @Column(length = 1000)
    private String alarmIds;

    private String impactSummary;

    @Enumerated(EnumType.STRING)
    private CorrelationStatus status;

}