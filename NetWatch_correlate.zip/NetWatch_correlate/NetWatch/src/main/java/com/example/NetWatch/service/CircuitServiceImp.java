package com.example.NetWatch.service;

import com.example.NetWatch.entity.Circuit;
import com.example.NetWatch.entity.MaintenanceWindow;
import com.example.NetWatch.entity.ProvisioningRequest;
import com.example.NetWatch.repository.CircuitRepo;
import com.example.NetWatch.repository.ProvisioningRequestRepo;
import com.example.NetWatch.requestdto.CircuitRequestDTO;
import com.example.NetWatch.responsedto.CircuitResponseDTO;
import com.example.NetWatch.requestdto.ProvisioningRequestDTO;
import com.example.NetWatch.responsedto.ProvisioningResponseDTO;
import com.example.NetWatch.enums.ProvisioningStatus;
import com.example.NetWatch.enums.CircuitStatus;
import com.example.NetWatch.exception.ResourceNotFoundException;
import com.example.NetWatch.exception.InvalidStateTransitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CircuitServiceImp implements CircuitService {

    @Autowired
    private CircuitRepo circuitRepo;

    @Autowired
    private ProvisioningRequestRepo requestRepo;

    @Autowired
    private AuditLogService auditService;

    @Lazy
    @Autowired
    private CapacityService capacityService;

    // ─────────────────────────────────────────────────────────────────────────
    // CIRCUIT OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public CircuitResponseDTO createCircuit(CircuitRequestDTO circuitRequestDTO, Long creatorId) {
        Circuit circuit = mapCircuitToEntity(circuitRequestDTO);
        if (circuit.getStatus() == null) {
            circuit.setStatus(CircuitStatus.ACTIVE);
        }
        if (circuit.getActivationDate() == null) {
            circuit.setActivationDate(LocalDateTime.now());
        }
        Circuit saved = circuitRepo.save(circuit);
        auditService.log(creatorId, "CREATE_CIRCUIT", "Circuit", saved.getCircuitId());
        return mapCircuitToResponse(saved);
    }

    @Override
    @Transactional
    public CircuitResponseDTO updateCircuit(Long id, CircuitRequestDTO circuitRequestDTO, Long updaterId) {
        Circuit updatedCircuit = mapCircuitToEntity(circuitRequestDTO);
        Circuit circuit = circuitRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Circuit not found"));
        circuit.setCircuitReference(updatedCircuit.getCircuitReference());
        circuit.setServiceType(updatedCircuit.getServiceType());
        circuit.setCustomerId(updatedCircuit.getCustomerId());
        circuit.setBandwidthMbps(updatedCircuit.getBandwidthMbps());
        circuit.setRoutePath(updatedCircuit.getRoutePath());
        circuit.setStatus(updatedCircuit.getStatus());
        Circuit saved = circuitRepo.save(circuit);
        auditService.log(updaterId, "UPDATE_CIRCUIT", "Circuit", saved.getCircuitId());
        return mapCircuitToResponse(saved);
    }

    @Override
    public List<CircuitResponseDTO> getAllCircuits() {
        return circuitRepo.findAll().stream()
                .map(this::mapCircuitToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public CircuitResponseDTO getCircuitById(Long id) {
        Circuit saved = circuitRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Circuit not found"));
        return mapCircuitToResponse(saved);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PROVISIONING REQUEST OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public ProvisioningResponseDTO createProvisioningRequest(ProvisioningRequestDTO requestDto, Long creatorId) {
        ProvisioningRequest request = mapProvisionToEntity(requestDto);
        request.setRequestDate(LocalDateTime.now());
        request.setStatus(ProvisioningStatus.PENDING);

        // Resolve Circuit from DB to ensure FK integrity
        if (request.getCircuit() != null && request.getCircuit().getCircuitId() != null) {
            Circuit circuit = circuitRepo.findById(request.getCircuit().getCircuitId())
                    .orElseThrow(() -> new ResourceNotFoundException("Circuit not found"));
            request.setCircuit(circuit);
        }
        request.setRequestedById(creatorId);

        ProvisioningRequest saved = requestRepo.save(request);
        auditService.log(creatorId, "CREATE_PROVISION_REQUEST", "ProvisioningRequest", saved.getProvisionId());
        return mapProvisionToResponse(saved);
    }

    @Override
    @Transactional
    public ProvisioningResponseDTO processProvisioningRequest(Long requestId, Long processorId) {
        ProvisioningRequest request = requestRepo.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("ProvisioningRequest not found: " + requestId));

        if (request.getStatus() != ProvisioningStatus.PENDING) {
            throw new InvalidStateTransitionException(
                    "Only PENDING requests can be processed. Current status: " + request.getStatus());
        }

        String capacityResult = capacityService.checkCapacityForProvisioning(request);
        System.out.println("capacityResult" + capacityResult);

        boolean needsWindow = capacityService.requiresMaintenanceWindow(request, capacityResult);
        System.out.println("needswindow=" + capacityResult);

        if (needsWindow) {
            MaintenanceWindow window = capacityService.scheduleMaintenanceWindow(request);

            request.setStatus(ProvisioningStatus.IN_PROGRESS);
            ProvisioningRequest saved = requestRepo.save(request);

            String auditAction = capacityResult.startsWith("CRITICAL")
                    ? "PROVISION_WINDOW_SCHEDULED [" + capacityResult + "] WINDOW_ID=" + window.getMaintenanceId()
                    : "PROVISION_WINDOW_SCHEDULED_ID=" + window.getMaintenanceId();
            auditService.log(processorId, auditAction, "ProvisioningRequest", saved.getProvisionId());
            return mapProvisionToResponse(saved);
        }

        applyCircuitChange(request);

        request.setStatus(ProvisioningStatus.COMPLETED);
        request.setCompletedDate(LocalDateTime.now());
        ProvisioningRequest saved = requestRepo.save(request);
        auditService.log(processorId, "PROVISION_COMPLETED", "ProvisioningRequest", saved.getProvisionId());
        return mapProvisionToResponse(saved);
    }

    @Override
    @Transactional
    public ProvisioningResponseDTO executeAfterMaintenanceWindow(Long requestId, Long processorId) {
        ProvisioningRequest request = requestRepo.findById(requestId)
                .orElseThrow(() -> new ResourceNotFoundException("ProvisioningRequest not found: " + requestId));

        if (request.getStatus() != ProvisioningStatus.IN_PROGRESS) {
            throw new InvalidStateTransitionException(
                    "Only IN_PROGRESS requests can be executed post-maintenance. Status: " + request.getStatus());
        }

        applyCircuitChange(request);

        request.setStatus(ProvisioningStatus.COMPLETED);
        request.setCompletedDate(LocalDateTime.now());
        ProvisioningRequest saved = requestRepo.save(request);
        auditService.log(processorId, "PROVISION_EXECUTED_POST_MAINTENANCE",
                "ProvisioningRequest", saved.getProvisionId());
        return mapProvisionToResponse(saved);
    }

    private void applyCircuitChange(ProvisioningRequest request) {
        if (request.getCircuit() == null) return;

        Circuit circuit = circuitRepo.findById(request.getCircuit().getCircuitId())
                .orElseThrow(() -> new ResourceNotFoundException("Circuit not found during execution"));

        switch (request.getRequestType()) {
            case NEW_ACTIVATION -> {
                circuit.setStatus(CircuitStatus.ACTIVE);
                circuit.setActivationDate(LocalDateTime.now());
            }
            case BANDWIDTH_UPGRADE -> {
                if (request.getBandwidthMbps() != null) {
                    circuit.setBandwidthMbps(request.getCircuit().getBandwidthMbps() + request.getBandwidthMbps());
                }
            }
            case SUSPENSION    -> circuit.setStatus(CircuitStatus.SUSPENDED);
            case TERMINATION   -> circuit.setStatus(CircuitStatus.DECOMMISSIONED);
        }

        circuitRepo.save(circuit);
    }

    @Override
    public List<ProvisioningResponseDTO> getAllRequests() {
        return requestRepo.findAll().stream()
                .map(this::mapProvisionToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public ProvisioningResponseDTO getRequestById(Long id) {
        ProvisioningRequest saved = requestRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ProvisioningRequest not found: " + id));
        return mapProvisionToResponse(saved);
    }

    @Override
    public List<ProvisioningResponseDTO> getPendingRequests() {
        return requestRepo.findByStatus(ProvisioningStatus.PENDING).stream()
                .map(this::mapProvisionToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<ProvisioningResponseDTO> getInProgressRequests() {
        return requestRepo.findByStatus(ProvisioningStatus.IN_PROGRESS).stream()
                .map(this::mapProvisionToResponse)
                .collect(Collectors.toList());
    }

    // MAPPINGS

    private CircuitResponseDTO mapCircuitToResponse(Circuit circuit) {
        if (circuit == null) return null;
        return CircuitResponseDTO.builder()
                .circuitId(circuit.getCircuitId())
                .circuitReference(circuit.getCircuitReference())
                .serviceType(circuit.getServiceType())
                .customerId(circuit.getCustomerId())
                .bandwidthMbps(circuit.getBandwidthMbps())
                .routePath(circuit.getRoutePath())
                .activationDate(circuit.getActivationDate())
                .status(circuit.getStatus())
                .build();
    }

    private Circuit mapCircuitToEntity(CircuitRequestDTO request) {
        if (request == null) return null;
        Circuit circuit = new Circuit();
        circuit.setCircuitReference(request.getCircuitReference());
        circuit.setServiceType(request.getServiceType());
        circuit.setCustomerId(request.getCustomerId());
        circuit.setBandwidthMbps(request.getBandwidthMbps());
        circuit.setRoutePath(request.getRoutePath());
        circuit.setStatus(request.getStatus());
        return circuit;
    }

    private ProvisioningResponseDTO mapProvisionToResponse(ProvisioningRequest request) {
        if (request == null) return null;
        return ProvisioningResponseDTO.builder()
                .provisionId(request.getProvisionId())
                .circuitId(request.getCircuit() != null ? request.getCircuit().getCircuitId() : null)
                .circuitReference(request.getCircuit() != null ? request.getCircuit().getCircuitReference() : null)
                .requestType(request.getRequestType())
                .requestedById(request.getRequestedById())
                .requestDate(request.getRequestDate())
                .completedDate(request.getCompletedDate())
                .status(request.getStatus())
                .build();
    }

    private ProvisioningRequest mapProvisionToEntity(ProvisioningRequestDTO requestDto) {
        if (requestDto == null) return null;
        ProvisioningRequest request = new ProvisioningRequest();
        request.setRequestType(requestDto.getRequestType());
        request.setRequestedById(requestDto.getRequestedById());
        request.setBandwidthMbps(requestDto.getBandwidthMbps());
        if (requestDto.getCircuitId() != null) {
            Circuit circuit = new Circuit();
            circuit.setCircuitId(requestDto.getCircuitId());
            request.setCircuit(circuit);
        }
        return request;
    }
}
