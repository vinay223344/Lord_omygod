package com.example.NetWatch.service;

import com.example.NetWatch.entity.NetworkSite;
import com.example.NetWatch.repository.NetworkSiteRepo;
import com.example.NetWatch.requestdto.NetworkSiteRequestDTO;
import com.example.NetWatch.responsedto.NetworkSiteResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class NetworkSiteServiceImp implements NetworkSiteService {

    @Autowired
    private NetworkSiteRepo siteRepository;

    @Override
    public List<NetworkSiteResponseDTO> getAllSites() {
        return siteRepository.findAll().stream()
                .map(this::mapSiteToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public NetworkSiteResponseDTO createSite(NetworkSiteRequestDTO siteRequest) {
        NetworkSite site = mapSiteToEntity(siteRequest);
        NetworkSite saved = siteRepository.save(site);
        return mapSiteToResponse(saved);
    }

    private NetworkSiteResponseDTO mapSiteToResponse(NetworkSite site) {
        if (site == null) return null;
        return NetworkSiteResponseDTO.builder()
                .siteId(site.getSiteId())
                .siteName(site.getSiteName())
                .siteType(site.getSiteType())
                .address(site.getAddress())
                .regionId(site.getRegionId())
                .status(site.getStatus())
                .build();
    }

    private NetworkSite mapSiteToEntity(NetworkSiteRequestDTO request) {
        if (request == null) return null;
        NetworkSite site = new NetworkSite();
        site.setSiteName(request.getSiteName());
        site.setSiteType(request.getSiteType());
        site.setAddress(request.getAddress());
        site.setRegionId(request.getRegionId());
        site.setStatus(request.getStatus());
        return site;
    }
}
