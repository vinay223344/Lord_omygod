package com.example.NetWatch.service;

import com.example.NetWatch.entity.CapacityRecord;
import com.example.NetWatch.entity.Circuit;
import com.example.NetWatch.entity.MaintenanceWindow;
import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.ProvisioningRequest;
import com.example.NetWatch.repository.CapacityRecordRepo;
import com.example.NetWatch.repository.MaintenanceWindowRepo;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.requestdto.CapacityRecordRequestDTO;
import com.example.NetWatch.responsedto.CapacityRecordResponseDTO;
import com.example.NetWatch.requestdto.MaintenanceWindowRequestDTO;
import com.example.NetWatch.responsedto.MaintenanceWindowResponseDTO;
import com.example.NetWatch.enums.CapacityStatus;
import com.example.NetWatch.enums.MaintenanceStatus;
import com.example.NetWatch.enums.MaintenanceType;
import com.example.NetWatch.enums.ProvisioningRequestType;
import com.example.NetWatch.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CapacityServiceImp implements CapacityService {

    @Autowired
    private CapacityRecordRepo capacityRepo;

    @Autowired
    private MaintenanceWindowRepo maintenanceRepo;

    @Autowired
    private NetworkElementRepo elementRepo;

    @Autowired
    private AuditLogService auditService;

    // ─────────────────────────────────────────────────────────────────────────
    // CAPACITY RECORD OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public CapacityRecordResponseDTO addCapacityRecord(CapacityRecordRequestDTO recordRequest, Long creatorId) {
        CapacityRecord record = mapCapacityToEntity(recordRequest);
        record.setRecordedDate(LocalDateTime.now());

        // Link NetworkElement
        if (record.getElement() != null && record.getElement().getElementId() != null) {
            NetworkElement element = elementRepo.findById(record.getElement().getElementId())
                    .orElseThrow(() -> new ResourceNotFoundException("NetworkElement not found: " + record.getElement().getElementId()));
            record.setElement(element);
        }

        // Auto-evaluate Status based on peak/avg vs threshold
        double threshold = record.getThresholdPercent() != null ? record.getThresholdPercent() : 80.0;
        double peak = record.getPeakValue() != null ? record.getPeakValue() : 0.0;
        double avg = record.getAverageValue() != null ? record.getAverageValue() : 0.0;

        if (peak >= threshold || avg >= threshold) {
            record.setStatus(CapacityStatus.CRITICAL);
        } else if (peak >= (threshold * 0.8) || avg >= (threshold * 0.8)) {
            record.setStatus(CapacityStatus.WARNING);
        } else {
            record.setStatus(CapacityStatus.NORMAL);
        }

        CapacityRecord saved = capacityRepo.save(record);
        auditService.log(creatorId, "ADD_CAPACITY_RECORD", "CapacityRecord", saved.getCapacityId());
        return mapCapacityToResponse(saved);
    }

    @Override
    public List<CapacityRecordResponseDTO> getAllCapacityRecords() {
        return capacityRepo.findAll().stream()
                .map(this::mapCapacityToResponse)
                .collect(Collectors.toList());

    }

    @Override
    public List<CapacityRecordResponseDTO> getCapacityBreaches() {
        List<CapacityRecord> breaches = capacityRepo.findByStatus(CapacityStatus.CRITICAL);
        breaches.addAll(capacityRepo.findByStatus(CapacityStatus.WARNING));
        return breaches.stream()
                .map(this::mapCapacityToResponse)
                .collect(Collectors.toList());
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MAINTENANCE WINDOW OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public MaintenanceWindowResponseDTO createMaintenanceWindow(MaintenanceWindowRequestDTO windowRequest, Long creatorId) {
        MaintenanceWindow window = mapMaintenanceToEntity(windowRequest);
        window.setStatus(MaintenanceStatus.PENDING);
        window.setRequestedById(creatorId);
        MaintenanceWindow saved = maintenanceRepo.save(window);
        auditService.log(creatorId, "REQUEST_MAINTENANCE_WINDOW", "MaintenanceWindow", saved.getMaintenanceId());
        return mapMaintenanceToResponse(saved);
    }

    @Override
    @Transactional
    public MaintenanceWindowResponseDTO approveMaintenanceWindow(Long id, Long approverId) {
        MaintenanceWindow window = maintenanceRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("MaintenanceWindow not found: " + id));
        window.setStatus(MaintenanceStatus.APPROVED);
        window.setApprovedById(approverId);
        MaintenanceWindow saved = maintenanceRepo.save(window);
        auditService.log(approverId, "APPROVE_MAINTENANCE_WINDOW", "MaintenanceWindow", saved.getMaintenanceId());
        return mapMaintenanceToResponse(saved);
    }

    @Override
    @Transactional
    public MaintenanceWindowResponseDTO updateMaintenanceStatus(Long id, MaintenanceStatus status, Long updaterId) {
        MaintenanceWindow window = maintenanceRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("MaintenanceWindow not found: " + id));
        window.setStatus(status);
        MaintenanceWindow saved = maintenanceRepo.save(window);
        auditService.log(updaterId, "UPDATE_MAINTENANCE_STATUS", "MaintenanceWindow", saved.getMaintenanceId());
        return mapMaintenanceToResponse(saved);
    }

    @Override
    public List<MaintenanceWindowResponseDTO> getAllMaintenanceWindows() {
        return maintenanceRepo.findAll().stream()
                .map(this::mapMaintenanceToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public List<MaintenanceWindowResponseDTO> getPendingMaintenanceWindows() {
        return maintenanceRepo.findByStatus(MaintenanceStatus.PENDING).stream()
                .map(this::mapMaintenanceToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public MaintenanceWindowResponseDTO getMaintenanceWindowById(Long id) {
        MaintenanceWindow saved = maintenanceRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("MaintenanceWindow not found: " + id));
        return mapMaintenanceToResponse(saved);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CROSS-SERVICE METHODS — called by CircuitService / ProvisioningService
    // ─────────────────────────────────────────────────────────────────────────

    private static final double DEFAULT_LINK_CAPACITY_MBPS = 1000.0;
    private static final double CAPACITY_THRESHOLD_PERCENT = 80.0;

    @Override
    public String checkCapacityForProvisioning(ProvisioningRequest request) {
        if (request.getRequestType() != ProvisioningRequestType.BANDWIDTH_UPGRADE) {
            return "OK";
        }

        Circuit circuit = request.getCircuit();
        if (circuit == null || circuit.getBandwidthMbps() == null) {
            return "OK";
        }

        double requestedBandwidth = circuit.getBandwidthMbps() + request.getBandwidthMbps();
        double thresholdMbps = DEFAULT_LINK_CAPACITY_MBPS * (CAPACITY_THRESHOLD_PERCENT / 100.0);

        if (requestedBandwidth > thresholdMbps) {
            return "CRITICAL: Requested bandwidth " + requestedBandwidth
                    + " Mbps exceeds capacity threshold " + thresholdMbps
                    + " Mbps (link capacity: " + DEFAULT_LINK_CAPACITY_MBPS
                    + " Mbps, threshold: " + CAPACITY_THRESHOLD_PERCENT + "%)."
                    + " Hardware upgrade and site visit required.";
        }

        return "OK";
    }

    @Override
    public boolean requiresMaintenanceWindow(ProvisioningRequest request, String capacityResult) {
        boolean isCritical = capacityResult.startsWith("CRITICAL");
        return switch (request.getRequestType()) {
            case NEW_ACTIVATION    -> true;
            case BANDWIDTH_UPGRADE -> isCritical;
            case SUSPENSION, TERMINATION -> false;
        };
    }

    @Override
    @Transactional
    public MaintenanceWindow scheduleMaintenanceWindow(ProvisioningRequest request) {
        MaintenanceWindow window = new MaintenanceWindow();

        String circuitRef = request.getCircuit() != null
                ? request.getCircuit().getCircuitReference()
                : "Unknown Circuit";

        window.setTitle("Auto: " + request.getRequestType().name()
                + " for Circuit [" + circuitRef + "]");
        window.setMaintenanceType(MaintenanceType.PLANNED);
        window.setStartDateTime(LocalDateTime.now().plusHours(2));
        window.setEndDateTime(LocalDateTime.now().plusHours(3));
        window.setRequestedById(request.getRequestedById());
        window.setStatus(MaintenanceStatus.PENDING);
        window.setRollbackPlan("Revert circuit configuration to previous state if change fails.");

        if (request.getCircuit() != null) {
            window.setAffectedElementIds("circuit:" + request.getCircuit().getCircuitId());
        }

        return maintenanceRepo.save(window);
    }

    // MAPPINGS

    private CapacityRecordResponseDTO mapCapacityToResponse(CapacityRecord record) {
        if (record == null) return null;
        return CapacityRecordResponseDTO.builder()
                .capacityId(record.getCapacityId())
                .elementId(record.getElement() != null ? record.getElement().getElementId() : null)
                .elementName(record.getElement() != null ? record.getElement().getElementName() : null)
                .metricType(record.getMetricType())
                .peakValue(record.getPeakValue())
                .averageValue(record.getAverageValue())
                .thresholdPercent(record.getThresholdPercent())
                .recordedDate(record.getRecordedDate())
                .status(record.getStatus())
                .build();
    }

    private CapacityRecord mapCapacityToEntity(CapacityRecordRequestDTO request) {
        if (request == null) return null;
        CapacityRecord record = new CapacityRecord();
        if (request.getElementId() != null) {
            NetworkElement el = new NetworkElement();
            el.setElementId(request.getElementId());
            record.setElement(el);
        }
        record.setMetricType(request.getMetricType());
        record.setPeakValue(request.getPeakValue());
        record.setAverageValue(request.getAverageValue());
        record.setThresholdPercent(request.getThresholdPercent());
        return record;
    }

    private MaintenanceWindowResponseDTO mapMaintenanceToResponse(MaintenanceWindow window) {
        if (window == null) return null;
        return MaintenanceWindowResponseDTO.builder()
                .maintenanceId(window.getMaintenanceId())
                .title(window.getTitle())
                .affectedElementIds(window.getAffectedElementIds())
                .maintenanceType(window.getMaintenanceType())
                .startDateTime(window.getStartDateTime())
                .endDateTime(window.getEndDateTime())
                .requestedById(window.getRequestedById())
                .approvedById(window.getApprovedById())
                .rollbackPlan(window.getRollbackPlan())
                .status(window.getStatus())
                .build();
    }

    private MaintenanceWindow mapMaintenanceToEntity(MaintenanceWindowRequestDTO request) {
        if (request == null) return null;
        MaintenanceWindow window = new MaintenanceWindow();
        window.setTitle(request.getTitle());
        window.setAffectedElementIds(request.getAffectedElementIds());
        window.setMaintenanceType(request.getMaintenanceType());
        window.setStartDateTime(request.getStartDateTime());
        window.setEndDateTime(request.getEndDateTime());
        window.setRollbackPlan(request.getRollbackPlan());
        window.setStatus(request.getStatus());
        return window;
    }
}
