package com.example.NetWatch.service;

import com.example.NetWatch.entity.AlarmCorrelation;
import com.example.NetWatch.repository.CorrelationRepo;
import com.example.NetWatch.responsedto.CorrelationResponseDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class CorrelationServiceImp implements CorrelationService {

    @Autowired
    private CorrelationRepo repo;


    @Override
    public List<CorrelationResponseDTO> getAll() {
        return repo.findAll()
                .stream()
                .map(this::mapToResponse)
                .collect(Collectors.toList());
    }

    //  Mapper method (Entity → DTO)
    private CorrelationResponseDTO mapToResponse(AlarmCorrelation correlation) {
        if (correlation == null) {
            return null;
        }

        return CorrelationResponseDTO.builder()
                .correlationId(correlation.getCorrelationId())
                .alarmIds(parseIds(correlation.getAlarmIds()))
                .impactSummary(correlation.getImpactSummary())
                .status(correlation.getStatus())
                .build();
    }


    private List<Long> parseIds(String ids) {
        ids = ids.replaceAll("[\\[\\]\\s]", "");

        if (ids.isEmpty()) return List.of();

        List<Long> list = new ArrayList<>();
        for (String s : ids.split(",")) {
            list.add(Long.parseLong(s));
        }

        return list;
    }
}