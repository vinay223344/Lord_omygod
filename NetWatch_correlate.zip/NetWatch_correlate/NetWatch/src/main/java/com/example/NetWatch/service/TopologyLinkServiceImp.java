package com.example.NetWatch.service;

import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.TopologyLink;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.repository.TopologyRepo;
import com.example.NetWatch.requestdto.TopologyLinkRequestDTO;
import com.example.NetWatch.responsedto.TopologyLinkResponseDTO;
import com.example.NetWatch.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class TopologyLinkServiceImp implements TopologyLinkService {

    @Autowired
    private TopologyRepo linkRepository;

    @Autowired
    private NetworkElementRepo elementRepo;

    @Override
    public List<TopologyLinkResponseDTO> getAllLinks() {
        return linkRepository.findAll().stream()
                .map(this::mapLinkToResponse)
                .collect(Collectors.toList());
    }

    @Override
    public TopologyLinkResponseDTO createLink(TopologyLinkRequestDTO linkRequest) {
        TopologyLink link = mapLinkToEntity(linkRequest);

        Long elementAId = link.getElementA().getElementId();
        Long elementBId = link.getElementB().getElementId();

        NetworkElement elementA = elementRepo.findById(elementAId)
                .orElseThrow(() -> new ResourceNotFoundException("Element A not found: " + elementAId));

        NetworkElement elementB = elementRepo.findById(elementBId)
                .orElseThrow(() -> new ResourceNotFoundException("Element B not found: " + elementBId));

        link.setElementA(elementA);
        link.setElementB(elementB);

        TopologyLink saved = linkRepository.save(link);
        return mapLinkToResponse(saved);
    }

    private TopologyLinkResponseDTO mapLinkToResponse(TopologyLink link) {
        if (link == null) return null;
        return TopologyLinkResponseDTO.builder()
                .linkId(link.getLinkId())
                .linkType(link.getLinkType())
                .capacityMbps(link.getCapacityMbps())
                .utilisationPercent(link.getUtilisationPercent())
                .status(link.getStatus())
                .elementAId(link.getElementA() != null ? link.getElementA().getElementId() : null)
                .elementAName(link.getElementA() != null ? link.getElementA().getElementName() : null)
                .elementBId(link.getElementB() != null ? link.getElementB().getElementId() : null)
                .elementBName(link.getElementB() != null ? link.getElementB().getElementName() : null)
                .build();
    }

    private TopologyLink mapLinkToEntity(TopologyLinkRequestDTO request) {
        if (request == null) return null;
        TopologyLink link = new TopologyLink();
        link.setLinkType(request.getLinkType());
        link.setCapacityMbps(request.getCapacityMbps());
        link.setUtilisationPercent(request.getUtilisationPercent());
        link.setStatus(request.getStatus());
        if (request.getElementAId() != null) {
            NetworkElement elA = new NetworkElement();
            elA.setElementId(request.getElementAId());
            link.setElementA(elA);
        }
        if (request.getElementBId() != null) {
            NetworkElement elB = new NetworkElement();
            elB.setElementId(request.getElementBId());
            link.setElementB(elB);
        }
        return link;
    }
}
