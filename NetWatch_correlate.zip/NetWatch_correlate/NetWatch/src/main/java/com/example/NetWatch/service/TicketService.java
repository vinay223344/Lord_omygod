package com.example.NetWatch.service;

import com.example.NetWatch.requestdto.TroubleTicketRequestDTO;
import com.example.NetWatch.responsedto.TroubleTicketResponseDTO;
import com.example.NetWatch.responsedto.FieldDispatchResponseDTO;
import com.example.NetWatch.enums.DispatchStatus;
import com.example.NetWatch.security.CustomUserDetails;

import java.util.List;

public interface TicketService {
    List<TroubleTicketResponseDTO> getAllTickets();
    TroubleTicketResponseDTO getTicketById(Long id);
    TroubleTicketResponseDTO closeTicket(Long id, Long updaterId);
    TroubleTicketResponseDTO escalateTicket(Long id, Long updaterId);
    FieldDispatchResponseDTO createDispatch(Long ticketId, Long fieldEngineerId, Long creatorId);
    List<FieldDispatchResponseDTO> getAllDispatches();
    List<FieldDispatchResponseDTO> getDispatchesForEngineer(Long fieldEngineerId);
    FieldDispatchResponseDTO getDispatchById(Long id);
    FieldDispatchResponseDTO updateDispatchStatus(Long id, DispatchStatus status, String resolutionSummary, Long engineerId);
    List<TroubleTicketResponseDTO> getTicketsForFieldEngineer(Long engineerId);
    CustomUserDetails getCurrentUser();
    boolean isFieldEngineer(CustomUserDetails user);

}
