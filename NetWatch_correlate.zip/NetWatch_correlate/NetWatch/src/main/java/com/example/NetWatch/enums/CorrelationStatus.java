package com.example.NetWatch.enums;

public enum CorrelationStatus {
    OPEN, RESOLVED
}
