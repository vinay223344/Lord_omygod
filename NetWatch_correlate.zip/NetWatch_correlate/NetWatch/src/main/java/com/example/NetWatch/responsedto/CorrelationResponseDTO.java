package com.example.NetWatch.responsedto;

import com.example.NetWatch.enums.CorrelationStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CorrelationResponseDTO {

    private Long correlationId;

    private List<Long> alarmIds;

    private String impactSummary;

    private CorrelationStatus status;
}
