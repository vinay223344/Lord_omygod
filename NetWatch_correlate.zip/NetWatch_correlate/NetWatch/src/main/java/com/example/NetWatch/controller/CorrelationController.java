package com.example.NetWatch.controller;

import com.example.NetWatch.responsedto.CorrelationResponseDTO;
import com.example.NetWatch.service.CorrelationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/correlation")
public class CorrelationController {

    @Autowired
    private CorrelationService service;

    //  Get all correlations (Display purpose only)
    @GetMapping
    @PreAuthorize("hasRole('NOC_ENGINEER') or hasRole('ADMIN') or hasRole('SERVICE_DESK')")
    public ResponseEntity<List<CorrelationResponseDTO>> getAll() {
        log.info("Fetching all alarms");

        List<CorrelationResponseDTO> list = service.getAll();

        log.info("Fetched {} alarm records", list.size());

        return ResponseEntity.ok(list);
    }
}