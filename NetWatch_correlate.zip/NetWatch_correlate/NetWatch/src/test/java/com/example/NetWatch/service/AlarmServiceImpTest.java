package com.example.NetWatch.service;

import com.example.NetWatch.entity.AlarmCorrelation;
import com.example.NetWatch.entity.NetworkAlarm;
import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.TroubleTicket;
import com.example.NetWatch.enums.AlarmType;
import com.example.NetWatch.enums.Severity;
import com.example.NetWatch.enums.AlarmStatus;
import com.example.NetWatch.repository.*;
import com.example.NetWatch.requestdto.NetworkAlarmRequestDTO;
import com.example.NetWatch.responsedto.NetworkAlarmResponseDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class AlarmServiceImpTest {

    @Mock
    private AlarmRepo alarmRepo;

    @Mock
    private TopologyRepo linkRepo;

    @Mock
    private CorrelationRepo correlationRepo;

    @Mock
    private TroubleTicketRepo ticketRepo;

    @Mock
    private NetworkElementRepo elementRepo;

    @Mock
    private AuditLogService auditService;

    @InjectMocks
    private AlarmServiceImp alarmService;

    private NetworkAlarmRequestDTO alarmRequest;
    private NetworkAlarm alarm;
    private NetworkElement element;

    @BeforeEach
    public void setUp() {

        element = new NetworkElement();
        element.setElementId(1L);
        element.setElementName("Router-01");

        alarmRequest = NetworkAlarmRequestDTO.builder()
                .elementId(1L)
                .alarmType(AlarmType.LINK_DOWN)
                .severity(Severity.CRITICAL)
                .status(AlarmStatus.ACTIVE)
                .build();

        alarm = new NetworkAlarm();
        alarm.setAlarmId(10L);
        alarm.setElement(element);
        alarm.setAlarmType(AlarmType.LINK_DOWN);
        alarm.setSeverity(Severity.CRITICAL);
        alarm.setStatus(AlarmStatus.ACTIVE);

        //  FIX HERE
        alarm.setAlarmTime(java.time.LocalDateTime.now());
    }

    @Test
    public void testCreateAlarm_AutoTicket() {
        when(elementRepo.findById(1L)).thenReturn(Optional.of(element));
        when(alarmRepo.save(any(NetworkAlarm.class))).thenReturn(alarm);
        when(linkRepo.findByElementAOrElementB(any(), any()))
                .thenReturn(List.of());

        when(alarmRepo.findByElement_ElementIdInAndStatus(anyList(), eq(AlarmStatus.ACTIVE)))
                .thenReturn(List.of(alarm));

        when(correlationRepo.findAll())
                .thenReturn(List.of());

        when(correlationRepo.save(any()))
                .thenReturn(new AlarmCorrelation());

        NetworkAlarmResponseDTO response = alarmService.create(alarmRequest, 100L);

        assertNotNull(response);
        assertEquals(10L, response.getAlarmId());
        assertEquals(AlarmStatus.ACTIVE, response.getStatus());

        verify(alarmRepo, times(1)).save(any(NetworkAlarm.class));
        verify(ticketRepo, times(1)).save(any(TroubleTicket.class));
        verify(auditService, times(1)).log(eq(100L), any(String.class), eq("NetworkAlarm"), eq(10L));
    }

    @Test
    public void testAutoCorrelation_CreateNewGroup() {

        // GIVEN
        when(elementRepo.findById(1L)).thenReturn(Optional.of(element));
        when(alarmRepo.save(any(NetworkAlarm.class))).thenReturn(alarm);

        // Mock topology (no connections → only itself)
        when(linkRepo.findByElementAOrElementB(any(), any()))
                .thenReturn(List.of());

        // Mock existing alarms (same element)
        alarm.setAlarmTime(java.time.LocalDateTime.now());

        when(alarmRepo.findByElement_ElementIdInAndStatus(anyList(), eq(AlarmStatus.ACTIVE)))
                .thenReturn(List.of(alarm));

        // No existing correlation groups
        when(correlationRepo.findAll()).thenReturn(List.of());

        // capture saved correlation
        when(correlationRepo.save(any(AlarmCorrelation.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // WHEN
        alarmService.create(alarmRequest, 100L);

        // THEN
        verify(correlationRepo, times(1)).save(any(AlarmCorrelation.class));
    }

    @Test
    public void testAutoCorrelation_MergeExistingGroup() {

        when(elementRepo.findById(1L)).thenReturn(Optional.of(element));
        when(alarmRepo.save(any(NetworkAlarm.class))).thenReturn(alarm);

        when(linkRepo.findByElementAOrElementB(any(), any()))
                .thenReturn(List.of());

        alarm.setAlarmTime(java.time.LocalDateTime.now());

        when(alarmRepo.findByElement_ElementIdInAndStatus(anyList(), eq(AlarmStatus.ACTIVE)))
                .thenReturn(List.of(alarm));

        // Existing correlation
        AlarmCorrelation existing = new AlarmCorrelation();
        existing.setAlarmIds("[10]");

        when(correlationRepo.findAll()).thenReturn(List.of(existing));

        when(correlationRepo.save(any(AlarmCorrelation.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // WHEN
        alarmService.create(alarmRequest, 100L);

        // THEN
        verify(correlationRepo, atLeastOnce()).save(any(AlarmCorrelation.class));
    }

    @Test
    public void testGetAll() {
        when(alarmRepo.findAll()).thenReturn(List.of(alarm));

        List<NetworkAlarmResponseDTO> list = alarmService.getAll();

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals(10L, list.get(0).getAlarmId());
    }

    @Test
    public void testAcknowledge() {
        when(alarmRepo.findById(10L)).thenReturn(Optional.of(alarm));
        when(alarmRepo.save(any(NetworkAlarm.class))).thenReturn(alarm);

        NetworkAlarmResponseDTO response = alarmService.acknowledge(10L, 100L);

        assertNotNull(response);
        verify(auditService, times(1)).log(eq(100L), eq("ACKNOWLEDGE_ALARM"), eq("NetworkAlarm"), eq(10L));
    }

    @Test
    public void testClearAlarm() {
        when(alarmRepo.findById(10L)).thenReturn(Optional.of(alarm));
        when(alarmRepo.save(any(NetworkAlarm.class))).thenReturn(alarm);

        NetworkAlarmResponseDTO response = alarmService.clearAlarm(10L, 100L);

        assertNotNull(response);
        verify(auditService, times(1)).log(eq(100L), eq("CLEAR_ALARM"), eq("NetworkAlarm"), eq(10L));
    }
}
