package com.example.NetWatch.service;

import com.example.NetWatch.entity.AlarmCorrelation;
import com.example.NetWatch.enums.CorrelationStatus;
import com.example.NetWatch.repository.CorrelationRepo;
import com.example.NetWatch.responsedto.CorrelationResponseDTO;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CorrelationServiceImpTest {

    @Mock
    private CorrelationRepo repo;

    @InjectMocks
    private CorrelationServiceImp service;

    @Test
    public void testGetAll() {
        //  Arrange
        AlarmCorrelation correlation = new AlarmCorrelation();
        correlation.setCorrelationId(1L);
        correlation.setAlarmIds("[1, 2, 3]");
        correlation.setImpactSummary("High impact");
        correlation.setStatus(CorrelationStatus.OPEN);

        when(repo.findAll()).thenReturn(List.of(correlation));

        //  Act
        List<CorrelationResponseDTO> result = service.getAll();

        //  Assert
        assertNotNull(result);
        assertEquals(1, result.size());

        CorrelationResponseDTO dto = result.get(0);
        assertEquals(1L, dto.getCorrelationId());
        assertEquals(3, dto.getAlarmIds().size());
        assertEquals("High impact", dto.getImpactSummary());
        assertEquals(CorrelationStatus.OPEN, dto.getStatus());

        verify(repo, times(1)).findAll();
    }

    @Test
    public void testGetAll_EmptyList() {
        when(repo.findAll()).thenReturn(List.of());

        List<CorrelationResponseDTO> result = service.getAll();

        assertNotNull(result);
        assertTrue(result.isEmpty());

        verify(repo, times(1)).findAll();
    }
}