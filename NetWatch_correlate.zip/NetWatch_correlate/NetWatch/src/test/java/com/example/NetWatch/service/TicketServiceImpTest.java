package com.example.NetWatch.service;

import com.example.NetWatch.entity.FieldDispatch;
import com.example.NetWatch.entity.NetworkAlarm;
import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.NetworkSite;
import com.example.NetWatch.entity.TroubleTicket;
import com.example.NetWatch.repository.AlarmRepo;
import com.example.NetWatch.repository.FieldDispatchRepo;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.repository.NetworkSiteRepo;
import com.example.NetWatch.repository.TroubleTicketRepo;
import com.example.NetWatch.requestdto.TroubleTicketRequestDTO;
import com.example.NetWatch.responsedto.TroubleTicketResponseDTO;
import com.example.NetWatch.responsedto.FieldDispatchResponseDTO;
import com.example.NetWatch.enums.TicketPriority;
import com.example.NetWatch.enums.TicketStatus;
import com.example.NetWatch.enums.DispatchStatus;
import com.example.NetWatch.enums.TicketCategory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TicketServiceImpTest {

    @Mock private TroubleTicketRepo ticketRepo;
    @Mock private FieldDispatchRepo dispatchRepo;
    @Mock private AlarmRepo alarmRepo;
    @Mock private NetworkElementRepo elementRepo;
    @Mock private NetworkSiteRepo siteRepo;
    @Mock private AuditLogService auditService;

    @InjectMocks
    private TicketServiceImp ticketService;

    private TroubleTicketRequestDTO ticketRequest;
    private TroubleTicket ticket;
    private FieldDispatch dispatch;
    private NetworkAlarm alarm;
    private NetworkElement element;
    private NetworkSite site;

    @BeforeEach
    public void setUp() {
        alarm = new NetworkAlarm();
        alarm.setAlarmId(5L);

        element = new NetworkElement();
        element.setElementId(2L);
        element.setElementName("Switch-01");

        site = new NetworkSite();
        site.setSiteId(3L);
        site.setSiteName("Site-A");

        ticketRequest = TroubleTicketRequestDTO.builder()
                .alarmId(5L)
                .elementId(2L)
                .siteId(3L)
                .category(TicketCategory.NODE_FAULT)
                .priority(TicketPriority.P1)
                .build();

        ticket = new TroubleTicket();
        ticket.setTicketId(100L);
        ticket.setAlarm(alarm);
        ticket.setElement(element);
        ticket.setSite(site);
        ticket.setCategory(TicketCategory.NODE_FAULT);
        ticket.setPriority(TicketPriority.P1);
        ticket.setStatus(TicketStatus.OPEN);
        ticket.setRaisedDateTime(LocalDateTime.now());
        ticket.setRestorationSLATime(LocalDateTime.now().plusHours(2));

        dispatch = new FieldDispatch();
        dispatch.setDispatchId(200L);
        dispatch.setTicket(ticket);
        dispatch.setFieldEngineerId(50L);
        dispatch.setDispatchTime(LocalDateTime.now());
        dispatch.setStatus(DispatchStatus.DISPATCHED);
    }

    // ─── TICKET TESTS ────────────────────────────────────────────────────────

    @Test
    public void testGetAllTickets() {
        when(ticketRepo.findAll()).thenReturn(List.of(ticket));

        List<TroubleTicketResponseDTO> list = ticketService.getAllTickets();

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals(100L, list.get(0).getTicketId());
    }

    @Test
    public void testGetTicketById() {
        when(ticketRepo.findById(100L)).thenReturn(Optional.of(ticket));

        TroubleTicketResponseDTO response = ticketService.getTicketById(100L);

        assertNotNull(response);
        assertEquals(100L, response.getTicketId());
    }


    @Test
    public void testCloseTicket() {
        when(ticketRepo.findById(100L)).thenReturn(Optional.of(ticket));
        when(ticketRepo.save(any(TroubleTicket.class))).thenReturn(ticket);

        TroubleTicketResponseDTO response = ticketService.closeTicket(100L, 1L);

        assertNotNull(response);
        assertEquals(TicketStatus.CLOSED, ticket.getStatus());
        verify(auditService, times(1)).log(1L, "CLOSE_TICKET", "TroubleTicket", 100L);
    }

    @Test
    public void testEscalateTicket() {
        when(ticketRepo.findById(100L)).thenReturn(Optional.of(ticket));
        when(ticketRepo.save(any(TroubleTicket.class))).thenReturn(ticket);

        TroubleTicketResponseDTO response = ticketService.escalateTicket(100L, 1L);

        assertNotNull(response);
        assertEquals(TicketStatus.ESCALATED, ticket.getStatus());
        verify(auditService, times(1)).log(1L, "ESCALATE_TICKET", "TroubleTicket", 100L);
    }

    // ─── DISPATCH TESTS ───────────────────────────────────────────────────────

    @Test
    public void testCreateDispatch() {
        when(ticketRepo.findById(100L)).thenReturn(Optional.of(ticket));
        when(dispatchRepo.save(any(FieldDispatch.class))).thenReturn(dispatch);
        when(ticketRepo.save(any(TroubleTicket.class))).thenReturn(ticket);

        FieldDispatchResponseDTO response = ticketService.createDispatch(100L, 50L, 1L);

        assertNotNull(response);
        assertEquals(200L, response.getDispatchId());
        assertEquals(DispatchStatus.DISPATCHED, response.getStatus());
        assertEquals(TicketStatus.FIELD_DISPATCHED, ticket.getStatus());
        verify(auditService, times(1)).log(1L, "CREATE_DISPATCH", "FieldDispatch", 200L);
    }

    @Test
    public void testUpdateDispatchStatus_OnSite() {
        when(dispatchRepo.findById(200L)).thenReturn(Optional.of(dispatch));
        when(dispatchRepo.save(any(FieldDispatch.class))).thenReturn(dispatch);

        FieldDispatchResponseDTO response = ticketService.updateDispatchStatus(200L, DispatchStatus.ON_SITE, null, 50L);

        assertNotNull(response);
        assertEquals(DispatchStatus.ON_SITE, dispatch.getStatus());
        assertNotNull(dispatch.getSiteArrivalTime());
        verify(auditService, times(1)).log(50L, "UPDATE_DISPATCH_STATUS", "FieldDispatch", 200L);
    }

    @Test
    public void testUpdateDispatchStatus_Resolved_ClosesTicket() {
        when(dispatchRepo.findById(200L)).thenReturn(Optional.of(dispatch));
        when(dispatchRepo.save(any(FieldDispatch.class))).thenReturn(dispatch);
        when(ticketRepo.save(any(TroubleTicket.class))).thenReturn(ticket);

        FieldDispatchResponseDTO response = ticketService.updateDispatchStatus(
                200L, DispatchStatus.RESOLVED, "Fixed the cable", 50L);

        assertNotNull(response);
        assertEquals(DispatchStatus.RESOLVED, dispatch.getStatus());
        assertNotNull(dispatch.getRestorationTime());
        assertEquals("Fixed the cable", dispatch.getResolutionSummary());
        assertEquals(TicketStatus.RESOLVED, ticket.getStatus());
        assertNotNull(ticket.getRestoredDateTime());
        verify(ticketRepo, times(1)).save(ticket);
        verify(auditService, times(1)).log(50L, "UPDATE_DISPATCH_STATUS", "FieldDispatch", 200L);
    }

    @Test
    public void testGetAllDispatches() {
        when(dispatchRepo.findAll()).thenReturn(List.of(dispatch));

        List<FieldDispatchResponseDTO> list = ticketService.getAllDispatches();

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals(200L, list.get(0).getDispatchId());
    }

    @Test
    public void testGetDispatchesForEngineer() {
        when(dispatchRepo.findByFieldEngineerId(50L)).thenReturn(List.of(dispatch));

        List<FieldDispatchResponseDTO> list = ticketService.getDispatchesForEngineer(50L);

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals(50L, list.get(0).getFieldEngineerId());
    }

    @Test
    public void testGetDispatchById() {
        when(dispatchRepo.findById(200L)).thenReturn(Optional.of(dispatch));

        FieldDispatchResponseDTO response = ticketService.getDispatchById(200L);

        assertNotNull(response);
        assertEquals(200L, response.getDispatchId());
    }
}
