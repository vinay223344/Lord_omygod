package com.example.NetWatch.service;

import com.example.NetWatch.entity.CapacityRecord;
import com.example.NetWatch.entity.Circuit;
import com.example.NetWatch.entity.MaintenanceWindow;
import com.example.NetWatch.entity.NetworkElement;
import com.example.NetWatch.entity.ProvisioningRequest;
import com.example.NetWatch.repository.CapacityRecordRepo;
import com.example.NetWatch.repository.MaintenanceWindowRepo;
import com.example.NetWatch.repository.NetworkElementRepo;
import com.example.NetWatch.requestdto.CapacityRecordRequestDTO;
import com.example.NetWatch.responsedto.CapacityRecordResponseDTO;
import com.example.NetWatch.requestdto.MaintenanceWindowRequestDTO;
import com.example.NetWatch.responsedto.MaintenanceWindowResponseDTO;
import com.example.NetWatch.enums.CapacityStatus;
import com.example.NetWatch.enums.MaintenanceStatus;
import com.example.NetWatch.enums.MaintenanceType;
import com.example.NetWatch.enums.ProvisioningRequestType;
import com.example.NetWatch.enums.MetricType;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CapacityServiceImpTest {

    @Mock
    private CapacityRecordRepo capacityRepo;

    @Mock
    private MaintenanceWindowRepo maintenanceRepo;

    @Mock
    private NetworkElementRepo elementRepo;

    @Mock
    private AuditLogService auditService;

    @InjectMocks
    private CapacityServiceImp capacityService;

    private NetworkElement element;
    private CapacityRecordRequestDTO recordRequest;
    private CapacityRecord record;

    @BeforeEach
    public void setUp() {
        element = new NetworkElement();
        element.setElementId(1L);
        element.setElementName("Element-1");

        recordRequest = CapacityRecordRequestDTO.builder()
                .elementId(1L)
                .metricType(MetricType.LINK_UTILISATION)
                .peakValue(85.0)
                .averageValue(75.0)
                .thresholdPercent(80.0)
                .build();

        record = new CapacityRecord();
        record.setCapacityId(10L);
        record.setElement(element);
        record.setMetricType(MetricType.LINK_UTILISATION);
        record.setPeakValue(85.0);
        record.setAverageValue(75.0);
        record.setThresholdPercent(80.0);
        record.setStatus(CapacityStatus.CRITICAL);
        record.setRecordedDate(LocalDateTime.now());
    }

    @Test
    public void testAddCapacityRecord_Critical() {
        when(elementRepo.findById(1L)).thenReturn(Optional.of(element));
        when(capacityRepo.save(any(CapacityRecord.class))).thenAnswer(invocation -> {
            CapacityRecord saved = invocation.getArgument(0);
            saved.setCapacityId(10L);
            return saved;
        });

        CapacityRecordResponseDTO response = capacityService.addCapacityRecord(recordRequest, 100L);

        assertNotNull(response);
        assertEquals(10L, response.getCapacityId());
        assertEquals(CapacityStatus.CRITICAL, response.getStatus());
        verify(capacityRepo, times(1)).save(any(CapacityRecord.class));
        verify(auditService, times(1)).log(100L, "ADD_CAPACITY_RECORD", "CapacityRecord", 10L);
    }

    @Test
    public void testAddCapacityRecord_Warning() {
        recordRequest.setPeakValue(65.0);
        recordRequest.setAverageValue(65.0); // 65% is >= 80% * 0.8 (64%)
        when(elementRepo.findById(1L)).thenReturn(Optional.of(element));
        when(capacityRepo.save(any(CapacityRecord.class))).thenAnswer(invocation -> {
            CapacityRecord saved = invocation.getArgument(0);
            saved.setCapacityId(11L);
            return saved;
        });

        CapacityRecordResponseDTO response = capacityService.addCapacityRecord(recordRequest, 100L);

        assertNotNull(response);
        assertEquals(11L, response.getCapacityId());
        assertEquals(CapacityStatus.WARNING, response.getStatus());
    }

    @Test
    public void testAddCapacityRecord_Normal() {
        recordRequest.setPeakValue(50.0);
        recordRequest.setAverageValue(40.0);
        when(elementRepo.findById(1L)).thenReturn(Optional.of(element));
        when(capacityRepo.save(any(CapacityRecord.class))).thenAnswer(invocation -> {
            CapacityRecord saved = invocation.getArgument(0);
            saved.setCapacityId(12L);
            return saved;
        });

        CapacityRecordResponseDTO response = capacityService.addCapacityRecord(recordRequest, 100L);

        assertNotNull(response);
        assertEquals(12L, response.getCapacityId());
        assertEquals(CapacityStatus.NORMAL, response.getStatus());
    }

    @Test
    public void testGetAllCapacityRecords() {
        when(capacityRepo.findAll()).thenReturn(List.of(record));

        List<CapacityRecordResponseDTO> list = capacityService.getAllCapacityRecords();

        assertNotNull(list);
        assertEquals(1, list.size());
        assertEquals(10L, list.get(0).getCapacityId());
    }

    @Test
    public void testGetCapacityBreaches() {
        CapacityRecord warningRecord = new CapacityRecord();
        warningRecord.setStatus(CapacityStatus.WARNING);

        when(capacityRepo.findByStatus(CapacityStatus.CRITICAL)).thenReturn(new ArrayList<>(List.of(record)));
        when(capacityRepo.findByStatus(CapacityStatus.WARNING)).thenReturn(new ArrayList<>(List.of(warningRecord)));

        List<CapacityRecordResponseDTO> list = capacityService.getCapacityBreaches();

        assertNotNull(list);
        assertEquals(2, list.size());
    }

    @Test
    public void testCreateMaintenanceWindow() {
        MaintenanceWindowRequestDTO request = MaintenanceWindowRequestDTO.builder()
                .title("Maint Title")
                .maintenanceType(MaintenanceType.PLANNED)
                .startDateTime(LocalDateTime.now())
                .endDateTime(LocalDateTime.now().plusHours(2))
                .rollbackPlan("Rollback")
                .build();

        MaintenanceWindow window = new MaintenanceWindow();
        window.setMaintenanceId(50L);
        window.setTitle("Maint Title");
        window.setMaintenanceType(MaintenanceType.PLANNED);
        window.setStatus(MaintenanceStatus.PENDING);

        when(maintenanceRepo.save(any(MaintenanceWindow.class))).thenReturn(window);

        MaintenanceWindowResponseDTO response = capacityService.createMaintenanceWindow(request, 100L);

        assertNotNull(response);
        assertEquals(50L, response.getMaintenanceId());
        assertEquals(MaintenanceStatus.PENDING, response.getStatus());
        verify(auditService, times(1)).log(100L, "REQUEST_MAINTENANCE_WINDOW", "MaintenanceWindow", 50L);
    }

    @Test
    public void testApproveMaintenanceWindow() {
        MaintenanceWindow window = new MaintenanceWindow();
        window.setMaintenanceId(50L);
        window.setStatus(MaintenanceStatus.PENDING);

        when(maintenanceRepo.findById(50L)).thenReturn(Optional.of(window));
        when(maintenanceRepo.save(any(MaintenanceWindow.class))).thenReturn(window);

        MaintenanceWindowResponseDTO response = capacityService.approveMaintenanceWindow(50L, 100L);

        assertNotNull(response);
        assertEquals(MaintenanceStatus.APPROVED, response.getStatus());
        assertEquals(100L, window.getApprovedById());
        verify(auditService, times(1)).log(100L, "APPROVE_MAINTENANCE_WINDOW", "MaintenanceWindow", 50L);
    }

    @Test
    public void testUpdateMaintenanceStatus() {
        MaintenanceWindow window = new MaintenanceWindow();
        window.setMaintenanceId(50L);
        window.setStatus(MaintenanceStatus.PENDING);

        when(maintenanceRepo.findById(50L)).thenReturn(Optional.of(window));
        when(maintenanceRepo.save(any(MaintenanceWindow.class))).thenReturn(window);

        MaintenanceWindowResponseDTO response = capacityService.updateMaintenanceStatus(50L, MaintenanceStatus.COMPLETED, 100L);

        assertNotNull(response);
        assertEquals(MaintenanceStatus.COMPLETED, response.getStatus());
        verify(auditService, times(1)).log(100L, "UPDATE_MAINTENANCE_STATUS", "MaintenanceWindow", 50L);
    }

    @Test
    public void testGetAllMaintenanceWindows() {
        MaintenanceWindow window = new MaintenanceWindow();
        when(maintenanceRepo.findAll()).thenReturn(List.of(window));

        List<MaintenanceWindowResponseDTO> list = capacityService.getAllMaintenanceWindows();

        assertNotNull(list);
        assertEquals(1, list.size());
    }

    @Test
    public void testGetPendingMaintenanceWindows() {
        MaintenanceWindow window = new MaintenanceWindow();
        when(maintenanceRepo.findByStatus(MaintenanceStatus.PENDING)).thenReturn(List.of(window));

        List<MaintenanceWindowResponseDTO> list = capacityService.getPendingMaintenanceWindows();

        assertNotNull(list);
        assertEquals(1, list.size());
    }

    @Test
    public void testGetMaintenanceWindowById() {
        MaintenanceWindow window = new MaintenanceWindow();
        window.setMaintenanceId(50L);

        when(maintenanceRepo.findById(50L)).thenReturn(Optional.of(window));

        MaintenanceWindowResponseDTO response = capacityService.getMaintenanceWindowById(50L);

        assertNotNull(response);
        assertEquals(50L, response.getMaintenanceId());
    }

    @Test
    public void testCheckCapacityForProvisioning() {
        ProvisioningRequest request = new ProvisioningRequest();
        request.setRequestType(ProvisioningRequestType.BANDWIDTH_UPGRADE);
        request.setBandwidthMbps(300.0);

        Circuit circuit = new Circuit();
        circuit.setBandwidthMbps(600.0);
        request.setCircuit(circuit);

        // Requested bandwidth = 600 + 300 = 900.
        // Threshold is 1000 * 0.8 = 800.
        // So 900 > 800 -> should return CRITICAL
        String result = capacityService.checkCapacityForProvisioning(request);
        assertTrue(result.startsWith("CRITICAL"));

        // Test normal scenario
        request.setBandwidthMbps(100.0); // 600 + 100 = 700 <= 800 -> should return OK
        assertEquals("OK", capacityService.checkCapacityForProvisioning(request));

        // Test non-bandwidth upgrade type

    }

    @Test
    public void testRequiresMaintenanceWindow() {
        ProvisioningRequest request = new ProvisioningRequest();

        request.setRequestType(ProvisioningRequestType.BANDWIDTH_UPGRADE);
        assertTrue(capacityService.requiresMaintenanceWindow(request, "CRITICAL: exceeds"));
        assertFalse(capacityService.requiresMaintenanceWindow(request, "OK"));

        request.setRequestType(ProvisioningRequestType.SUSPENSION);
        assertFalse(capacityService.requiresMaintenanceWindow(request, "OK"));
    }


}
