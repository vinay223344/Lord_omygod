// Demonstration of Default and Static Methods in Interfaces (Java 8)
//2503714
interface Payment {
 void pay(double amount);
 
 // Default method: reusable behavior for all implementations
 default void generateReceipt(double amount) {
 System.out.println("Receipt: Payment of $" + amount + " processed.");
 }
 
 // Static method: utility/helper function belonging to the interface itself
 static boolean validateAmount(double amount) {
 return amount > 0;
 }
 }
 
class CreditCardPayment implements Payment {
 @Override
 public void pay(double amount) {
 if (Payment.validateAmount(amount)) { // Using static method
 System.out.println("Paid $" + amount + " via Credit Card.");
 generateReceipt(amount); // Using default method
 } else {
 System.out.println("Invalid payment amount!");
 }
 }
 }
 
class UpiPayment implements Payment {
 @Override
 public void pay(double amount) {
 if (Payment.validateAmount(amount)) {
 System.out.println("Paid $" + amount + " via UPI.");
 generateReceipt(amount);
 } else {
 System.out.println("Invalid payment amount!");
 }
 }
 }
 
public class PaymentDemo {
 public static void main(String[] args) {
 Payment card = new CreditCardPayment();
 card.pay(250.75);
 
 Payment upi = new UpiPayment();
 upi.pay(-50); // Invalid case to show static validation
 }
 }
 
 