//2503614
package com.cognizant.training.javafeatures;
//if a value is found missing in the java box,instead of returning null or throwing error it returns a optional value

import java.util.Optional;

class User {
    private String name;
    private String email; // email might be missing (null)

    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }

    // Return Optional instead of raw String
    // This way, if email is null, we safely wrap it in Optional
    public Optional<String> getEmail() {
        return Optional.ofNullable(email);
    }

    public String getName() {
        return name;
    }
}

public class RealWorldOptional {
    public static void main(String[] args) {
        // Alice has an email
        User user1 = new User("Alice", "alice@example.com");
        // Bob did not provide an email (null)
        User user2 = new User("Bob", null);

        // Safe handling of email using orElse
        // If email is present, print it; otherwise print "No email provided"
        System.out.println("Alice's email: " + user1.getEmail().orElse("No email provided"));
        System.out.println("Bob's email: " + user2.getEmail().orElse("No email provided"));

        // Send a welcome message only if email exists
        // ifPresent executes the code only when the value is present
        user1.getEmail().ifPresent(email -> System.out.println("Sending welcome mail to " + email));
        user2.getEmail().ifPresent(email -> System.out.println("Sending welcome mail to " + email));
    }
}
