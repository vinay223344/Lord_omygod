//Emp ID- 2503713

package com.cognizant.training.javafeatures;



import java.util.*;
import java.util.stream.*;

class Employee {
  int id;
  String name;
  String department;
  double salary;

  Employee(int id, String name, String department, double salary) {
      this.id = id;
      this.name = name;
      this.department = department;
      this.salary = salary;
  }
}

public class StreamFilterExample {
  public static void main(String[] args) {
      List<Employee> employees = Arrays.asList(
          new Employee(1, "Surendar", "IT", 60000),
          new Employee(2, "Dinesh", "HR", 45000),
          new Employee(3, "Santhiya", "IT", 75000),
          new Employee(4, "Faheem", "Finance", 50000),
          new Employee(5, "Santhosh", "IT", 40000)
      );

      List<Employee> filteredEmployees = employees.stream()
          .filter(emp -> emp.department.equals("IT"))
          .filter(emp -> emp.salary > 50000)
          .collect(Collectors.toList());

      filteredEmployees.forEach(emp ->
          System.out.println(emp.name + " - " + emp.salary)
      );
  }
}