//2503716

package com.cognizant.training.javafeatures;


public class TextConverter  {
	 public static void main(String[] args) throws Exception {
		
	        String text = "Hello Java";
	
	        // Encoding (String → bytes)
	        byte[] encoded = text.getBytes("UTF-8");
	
	        System.out.println("Encoded bytes:");
	        //printing the byte code of  each character
	        for (byte b : encoded) {
	            System.out.print(b + " ");
	        }
	
	        System.out.println();
	
	        // Decoding (bytes → String)
	        String decoded = new String(encoded, "UTF-8");
	
	        System.out.println("Decoded text: " + decoded);
	    }
	}

