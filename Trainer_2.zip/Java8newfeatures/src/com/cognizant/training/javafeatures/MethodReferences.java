//2503712
package com.cognizant.training.javafeatures;


import java.util.*;

class MethodReferences {
  public static void main(String[] args) {
      List<String> names = Arrays.asList("Length", "Breadth", "Height", "Volume");

      // 1. Print each name (instance method reference)
      names.forEach(System.out::println);

      // 2. Convert to uppercase (class method reference)
      List<String> upperNames = names.stream()
              .map(String::toUpperCase)
              .toList();
      System.out.println("Uppercase: " + upperNames);

      // 3. Sort names (class method reference)
      List<String> sortedNames = names.stream()
              .sorted(String::compareTo)
              .toList();
      System.out.println("Sorted: " + sortedNames);

      // 4. Create Student objects (constructor reference)
      List<Student> students = names.stream()
              .map(Student::new)
              .toList();

      // 5. Print student names (instance method reference)
      students.forEach(Student::printName);

      // 6. Convert strings to integers (static method reference)
      List<Integer> intNumbers = Arrays.asList("10", "20", "30").stream()
              .map(Integer::parseInt)
              .toList();
      System.out.println("Parsed Integers: " + intNumbers);
  }
}

class Student {
  String name;
  Student(String n) { name = n; }
  void printName() { System.out.println("Student: " + name); }
}
