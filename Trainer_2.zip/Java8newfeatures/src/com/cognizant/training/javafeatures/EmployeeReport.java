//Emp Id : 2503701

package com.cognizant.training.javafeatures;


import java.time.LocalDate;

public class EmployeeReport {
  public static void main(String[] args) {

      // Employee details
      String name = "Dinesh";
      LocalDate joinDate = LocalDate.of(2021, 3, 15);
      LocalDate today = LocalDate.now();

      // Calculate experience in years
      int experience = today.getYear() - joinDate.getYear();
      if (today.getMonthValue() < joinDate.getMonthValue() ||
         (today.getMonthValue() == joinDate.getMonthValue() &&
          today.getDayOfMonth() < joinDate.getDayOfMonth()))
          experience--;

      // Project end date and status check
      LocalDate projectEnd = LocalDate.of(2026, 6, 30);
      String status = today.isAfter(projectEnd) ? "DELAYED" : "IN PROGRESS";

      // Employee report output
      System.out.println("Employee Name : " + name);
      System.out.println("Joining Date  : " + joinDate);
      System.out.println("Experience    : " + experience + " years");
      System.out.println("Project Status: " + status);
  }
}