//2503715
package com.cognizant.training.javafeatures;




import java.util.*;

class Student implements Comparable<Student>{
	String name;
	int rollno;
	int age;
	Student(String name,int rollno,int age){
		this.name=name;
		this.rollno=rollno;
		this.age=age;
	}
	
	// Comparable: sort by roll number
	@Override
	public int compareTo(Student s) {
		return this.rollno-s.rollno;
	}
}
class NameComparator implements Comparator<Student> {
	@Override
	// Comparator: sort by name length by subtracting the length of the string
	public int compare(Student s1,Student s2) {
		return s1.name.length()-s2.name.length();
	}
	
}
public class StudentList {
	public static void main(String args[]) {
		List<Student> list=new ArrayList<>();
		//adding the list of student
		 list.add(new  Student("Gobinath",2,14));
	     list.add(new Student("John",1,15));
	     list.add(new Student("Ram",3,15));
	     // Comparable sorting using inbuilt method
	     Collections.sort(list);
	     System.out.println("Sorted by rollno by comparable");

    for (Student s : list) {
        System.out.println("rolno="+s.rollno + " , name=" + s.name + " ,age=" + s.age);
    }
     System.out.println();
  // Comparator sorting
    Collections.sort(list, new NameComparator());
    System.out.println("Sorted by Name by comparator");
    for(Student s:list) {
    	 System.out.println("rollno="+s.rollno + " ,name=" + s.name + " ,age=" + s.age);
    }
	     
	}

}
