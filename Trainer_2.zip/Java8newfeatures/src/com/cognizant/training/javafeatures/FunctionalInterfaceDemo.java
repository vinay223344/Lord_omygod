//2503616
package com.cognizant.training.javafeatures;


@FunctionalInterface
interface Calculator {
  int operate(int a, int b); // single abstract method
}

public class FunctionalInterfaceDemo {
  public static void main(String[] args) {
      // Lambda expressions
      Calculator add = (a, b) -> a + b;
      Calculator multiply = (a, b) -> a * b;

      System.out.println("Addition: " + add.operate(10, 5));
      System.out.println("Multiplication: " + multiply.operate(10, 5));

      // Method reference to a static method
      Calculator subtract = FunctionalInterfaceDemo::subtract;
      System.out.println("Subtraction: " + subtract.operate(10, 5));

      // Method reference to an instance method
      FunctionalInterfaceDemo demo = new FunctionalInterfaceDemo();
      Calculator divide = demo::divide;
      System.out.println("Division: " + divide.operate(10, 5));
  }

  // Static method for subtraction
  public static int subtract(int a, int b) {
      return a - b;
  }

  // Instance method for division
  public int divide(int a, int b) {
      return a / b;
  }
}