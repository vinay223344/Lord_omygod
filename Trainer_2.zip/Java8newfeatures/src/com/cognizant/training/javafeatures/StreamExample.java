package com.cognizant.training.javafeatures;

//Emp Id - 2503711
import java.util.*;
import java.util.stream.Collectors;
public class StreamExample {
 public static void main(String[] args) {
     // Sample list of integers
     List<Integer> numbers = Arrays.asList(5, 2, 8, 1, 3, 10, 4, 7);
     // Using Java 8 Streams to process the list
     List<Integer> processedNumbers = numbers.stream()
             .filter(n -> n % 2 == 0)          // Keep only even numbers
             .map(n -> n * n)                  // Square each number
             .sorted()                         // Sort in ascending order
             .collect(Collectors.toList());    // Collect into a new list
     // Display original list
     System.out.println("Original List: " + numbers);
     // Display processed list
     System.out.println("Processed List (Even, Squared, Sorted): " + processedNumbers);
 }
}