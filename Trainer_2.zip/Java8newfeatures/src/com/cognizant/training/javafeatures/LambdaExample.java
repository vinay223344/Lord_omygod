
//Emp Id - 2503718
package com.cognizant.training.javafeatures;

@FunctionalInterface
interface MathOperation {
int operate(int a, int b);
}

public class LambdaExample {
public static void main(String[] args) {
   // Lambda for addition
   MathOperation add = (a, b) -> a + b;

   // Lambda for multiplication
   MathOperation multiply = (a, b) -> a * b;

   // Lambda for subtraction
   MathOperation sub = (a, b) -> a - b;

   // Lambda for division
   MathOperation div = (a, b) -> a / b;

   System.out.println("Sum: " + add.operate(5, 3));
   System.out.println("Product: " + multiply.operate(5, 3));
   System.out.println("Subtraction: " + sub.operate(5, 3));
   System.out.println("Division: " + div.operate(5, 3));

}
}

