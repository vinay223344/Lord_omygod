package com.example.annotation;

import org.junit.Test;
import static org.junit.Assert.*;

public class GreetingServiceTest {
    @Test
    public void greetReturnsExpected() {
        GreetingService svc = new GreetingService();
        assertEquals("Hello, Tester (from annotation-demo)", svc.greet("Tester"));
    }
}
