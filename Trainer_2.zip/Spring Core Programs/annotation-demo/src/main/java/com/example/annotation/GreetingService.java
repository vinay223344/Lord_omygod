package com.example.annotation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Simple service that produces greeting messages.
public class GreetingService {
    // Logger for diagnostics in the service
    private static final Logger logger = LoggerFactory.getLogger(GreetingService.class);
    public String greet(String name) {
        // Build a greeting string for the provided name
        String msg = "Hello, " + name + " (from annotation-demo)";
        logger.debug("greet() called with name={}", name);
        return msg;
    }
}
