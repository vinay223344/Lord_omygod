package com.example.annotation;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Entry point for the annotation-based demo. Loads the context via Java configuration.
public class MainApp {
    // Logger for application-level diagnostics
    private static final Logger logger = LoggerFactory.getLogger(MainApp.class);

    public static void main(String[] args) {
        // Wrap context lifecycle and main logic in a try/catch to handle unexpected exceptions
        try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class)) {
            GreetingService svc = ctx.getBean(GreetingService.class);
            // Print greeting to stdout (happy-path)
            System.out.println(svc.greet("World"));
        } catch (Exception ex) {
            // Log full stack and exit with non-zero status
            logger.error("Unhandled error in MainApp", ex);
            System.err.println("Application failed: " + ex.getMessage());
            System.exit(1);
        }
    }
}
