package com.example.annotation;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Configuration
public class AppConfig {

    // Logger for this configuration class
    private static final Logger logger = LoggerFactory.getLogger(AppConfig.class);

    @Bean
    public GreetingService greetingService() {
        // Instantiate and return the GreetingService bean
        logger.debug("Creating GreetingService bean");
        return new GreetingService();
    }
}
