annotation-demo

A tiny Spring annotation-based example using Java configuration.

Build and run:

mvn -f annotation-demo\pom.xml clean package
java -cp annotation-demo\target\annotation-demo-0.0.1-SNAPSHOT.jar com.example.annotation.MainApp
