package com.example.classpath;

import org.junit.Test;
import static org.junit.Assert.*;

public class MessageServiceTest {
    @Test
    public void messageReturnsExpected() {
        MessageService svc = new MessageService();
        assertEquals("Hello from classpath-demo", svc.message());
    }
}
