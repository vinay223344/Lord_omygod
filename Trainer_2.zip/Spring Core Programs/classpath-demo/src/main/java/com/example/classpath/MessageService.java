package com.example.classpath;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Simple message-producing service used by the classpath XML demo.
public class MessageService {
    private static final Logger logger = LoggerFactory.getLogger(MessageService.class);

    /**
     * Return a constant message. In a real service this might query a repository or perform business logic.
     */
    public String message() {
        logger.debug("message() called");
        return "Hello from classpath-demo";
    }
}
