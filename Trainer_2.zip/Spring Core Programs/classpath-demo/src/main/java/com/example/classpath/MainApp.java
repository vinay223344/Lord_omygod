package com.example.classpath;

import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Entry point for the classpath XML demo. Loads beans.xml from classpath.
public class MainApp {
    private static final Logger logger = LoggerFactory.getLogger(MainApp.class);

    public static void main(String[] args) {
        // Protect the application lifecycle to log and handle any exceptions that may occur during context load
        try (ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("beans.xml")) {
            MessageService svc = (MessageService) ctx.getBean("messageService");
            System.out.println(svc.message());
        } catch (Exception ex) {
            logger.error("Failed to start classpath-demo application", ex);
            System.err.println("Application error: " + ex.getMessage());
            System.exit(1);
        }
    }
}
