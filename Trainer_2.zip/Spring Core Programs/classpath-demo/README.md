classpath-demo

A tiny Spring classpath XML example.

Build and run:

mvn -f classpath-demo\pom.xml clean package
java -cp classpath-demo\target\classpath-demo-0.0.1-SNAPSHOT.jar com.example.classpath.MainApp
