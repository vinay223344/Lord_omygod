profiles-demo

A Spring profiles example. Activate profiles with -Dspring.profiles.active=dev or prod.

Build and run:

mvn -f profiles-demo\pom.xml clean package
java -Dspring.profiles.active=prod -cp profiles-demo\target\profiles-demo-0.0.1-SNAPSHOT.jar com.example.profiles.MainApp
