package com.example.profiles;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MainApp {
    private static final Logger logger = LoggerFactory.getLogger(MainApp.class);

    public static void main(String[] args) {
        // Activate profile via system property or pass -Dspring.profiles.active=dev
        String active = System.getProperty("spring.profiles.active", "dev");
        // Protect initialization and runtime logic so we can log issues and exit cleanly
        try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext()) {
            ctx.getEnvironment().setActiveProfiles(active);
            ctx.register(ProfileConfig.class);
            ctx.refresh();

            ProfileService svc = ctx.getBean(ProfileService.class);
            System.out.println("Active: " + active + " -> " + svc.who());
        } catch (Exception ex) {
            logger.error("Profiles-demo failed to start or run", ex);
            System.err.println("Profiles-demo error: " + ex.getMessage());
            System.exit(1);
        }
    }
}
