package com.example.profiles;

// Abstraction for different profile-based implementations. Implementations should identify themselves.
public interface ProfileService {
    /**
     * Return a short identifier describing the implementation (e.g. 'development service').
     */
    String who();
}
