package com.example.profiles;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Implementation of ProfileService used for the 'prod' profile.
public class ProdProfileService implements ProfileService {
    private static final Logger logger = LoggerFactory.getLogger(ProdProfileService.class);

    /**
     * Identify this implementation as the production service.
     */
    public String who() {
        logger.debug("ProdProfileService.who() called");
        return "production service";
    }
}
