package com.example.profiles;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// Implementation of ProfileService used for the 'dev' profile.
public class DevProfileService implements ProfileService {
    private static final Logger logger = LoggerFactory.getLogger(DevProfileService.class);

    /**
     * Identify this implementation as the development service.
     */
    public String who() {
        logger.debug("DevProfileService.who() called");
        return "development service";
    }
}
