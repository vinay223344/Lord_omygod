package com.example.profiles;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
public class ProfileConfig {

    @Bean
    @Profile("dev")
    public ProfileService devService() {
        // Provide the dev profile implementation
        return new DevProfileService();
    }

    @Bean
    @Profile("prod")
    public ProfileService prodService() {
        // Provide the prod profile implementation
        return new ProdProfileService();
    }
}
