package com.example.profiles;

import org.junit.Test;
import static org.junit.Assert.*;

public class ProfileServiceTest {
    @Test
    public void defaultProfileProducesService() {
        ProfileService svc = new DevProfileService();
        assertEquals("development service", svc.who());
    }
}
