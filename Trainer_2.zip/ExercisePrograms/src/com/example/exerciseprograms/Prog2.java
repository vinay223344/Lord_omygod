package com.example.exerciseprograms;
import java.util.*;
public class Prog2 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        ArrayList<Integer> a=new ArrayList<>();
        int n=sc.nextInt();
        for(int i=0;i<n;i++)
        {
            a.add(sc.nextInt());
        }
        ArrayList<Integer> ans=new ArrayList<>();
        for(int i=0;i<a.size();i++)
        {
            if(Collections.frequency(a,a.get(i))>1 && Collections.frequency(ans,a.get(i))<1)
            {
                ans.add(a.get(i));
            }
        }
        System.out.println(ans);
    }
}
