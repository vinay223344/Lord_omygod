package com.example.exerciseprograms;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        char[] s=sc.next().toCharArray();
        for(int i=0;i<s.length;i++)
        {
            int flag=0;
            for(int j=0;j<s.length;j++)
            {
                if(i!=j)
                {
                    if(s[i]==s[j]) {
                        flag=1;
                        break;
                    }
                }
            }
            if(flag==0)
            {
                System.out.print(s[i]);
                break;
            }
        }
    }
}
