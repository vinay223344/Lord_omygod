package com.sample.example;
import java.util.*;
public class ProgramTest {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        ArrayList<Integer> a=new ArrayList<>();
        for(int i=0;i<n;i++)
        {
            a.add(sc.nextInt());
        }
        Collections.sort(a);
        System.out.println("The second Highest salary is "+a.get(n-2));

    }
}
