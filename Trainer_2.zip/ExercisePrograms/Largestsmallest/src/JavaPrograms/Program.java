package JavaPrograms;
public class Program {

}
