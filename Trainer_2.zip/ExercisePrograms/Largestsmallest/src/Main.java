//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int[] a=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        int largest=a[0], smallest=a[0];
        for(int i=0;i<n;i++)
        {
            if(a[i]>largest)
            {
                largest=a[i];
            }
            if(a[i]<smallest)
            {
                smallest=a[i];
            }
        }
        System.out.println("Largest: "+largest+" Smallest: "+smallest);
    }
}