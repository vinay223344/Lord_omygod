import { format, parseISO } from 'date-fns';

export const formatDate = (dateStr: string | null | undefined): string => {
  if (!dateStr) return 'N/A';
  try {
    const date = typeof dateStr === 'string' ? parseISO(dateStr) : dateStr;
    return format(date, 'yyyy-MM-dd HH:mm:ss');
  } catch (err) {
    console.error('Error formatting date:', dateStr, err);
    return String(dateStr);
  }
};
