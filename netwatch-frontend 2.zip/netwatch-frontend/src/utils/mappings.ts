import {
  ElementStatus as FrontendElementStatus,
  SiteStatus as FrontendSiteStatus,
  SiteType as FrontendSiteType,
  LinkType as FrontendLinkType,
  LinkStatus as FrontendLinkStatus,
  ProvisioningRequestType as FrontendProvType,
  MetricType as FrontendMetricType,
  ServiceType as FrontendServiceType,
} from '../types';

// ==========================================
// 1. Network Element Status
// ==========================================
// Frontend and backend now share the same element status vocabulary
// (ACTIVE, INACTIVE, MAINTENANCE, DECOMMISSIONED), so these are pass-through.
export const mapElementStatusToBackend = (status: FrontendElementStatus): string => status;

export const mapElementStatusToFrontend = (status: string | undefined): FrontendElementStatus => {
  switch ((status || '').toUpperCase()) {
    case 'ACTIVE': return 'ACTIVE';
    case 'INACTIVE': return 'INACTIVE';
    case 'MAINTENANCE': return 'MAINTENANCE';
    case 'DECOMMISSIONED': return 'DECOMMISSIONED';
    default: return 'ACTIVE';
  }
};

// ==========================================
// 2. Network Site Status & Type
// ==========================================
export const mapSiteStatusToBackend = (status: FrontendSiteStatus): string => {
  switch (status) {
    case 'OPERATIONAL': return 'ACTIVE';
    case 'UNDER_MAINTENANCE': return 'ACTIVE'; // or another status, ACTIVE is standard operational
    case 'DOWN': return 'INACTIVE';
    default: return 'ACTIVE';
  }
};

export const mapSiteStatusToFrontend = (status: string | undefined): FrontendSiteStatus => {
  if (!status) return 'OPERATIONAL';
  switch (status.toUpperCase()) {
    case 'ACTIVE': return 'OPERATIONAL';
    case 'INACTIVE': return 'DOWN';
    default: return 'OPERATIONAL';
  }
};

export const mapSiteTypeToBackend = (type: FrontendSiteType): string => {
  switch (type) {
    case 'CORE_POP':
    case 'REGIONAL_POP':
    case 'EDGE_POP': return 'POP';
    case 'DATACENTER': return 'DATACENTRE';
    case 'CELL_TOWER': return 'TOWER';
    default: return 'POP';
  }
};

export const mapSiteTypeToFrontend = (type: string | undefined): FrontendSiteType => {
  if (!type) return 'CORE_POP';
  switch (type.toUpperCase()) {
    case 'POP': return 'CORE_POP';
    case 'DATACENTRE': return 'DATACENTER';
    case 'TOWER': return 'CELL_TOWER';
    case 'EXCHANGE': return 'REGIONAL_POP';
    case 'REMOTE_NODE': return 'EDGE_POP';
    default: return 'CORE_POP';
  }
};

// ==========================================
// 3. Topology Link Status & Type
// ==========================================
export const mapLinkTypeToBackend = (type: FrontendLinkType): string => {
  switch (type) {
    case 'FIBER': return 'FIBRE';
    case 'MICROWAVE': return 'MICROWAVE';
    case 'SATELLITE': return 'SDH';
    default: return 'FIBRE';
  }
};

export const mapLinkTypeToFrontend = (type: string | undefined): FrontendLinkType => {
  if (!type) return 'FIBER';
  switch (type.toUpperCase()) {
    case 'FIBRE': return 'FIBER';
    case 'MICROWAVE': return 'MICROWAVE';
    case 'ETHERNET':
    case 'SDH': return 'FIBER';
    default: return 'FIBER';
  }
};

export const mapLinkStatusToBackend = (status: FrontendLinkStatus): string => {
  switch (status) {
    case 'UP': return 'ACTIVE';
    case 'DOWN': return 'DOWN';
    case 'MAINTENANCE': return 'DEGRADED';
    default: return 'ACTIVE';
  }
};

export const mapLinkStatusToFrontend = (status: string | undefined): FrontendLinkStatus => {
  if (!status) return 'UP';
  switch (status.toUpperCase()) {
    case 'ACTIVE': return 'UP';
    case 'DOWN': return 'DOWN';
    case 'DEGRADED': return 'MAINTENANCE';
    default: return 'UP';
  }
};

// ==========================================
// 4. Provisioning Request Type
// ==========================================
// Frontend and backend now share the same provisioning request type values
// (BANDWIDTH_UPGRADE, SUSPENSION, TERMINATION), so these are pass-through.
export const mapProvTypeToBackend = (type: FrontendProvType): string => type;

export const mapProvTypeToFrontend = (type: string | undefined): FrontendProvType => {
  switch ((type || '').toUpperCase()) {
    case 'BANDWIDTH_UPGRADE': return 'BANDWIDTH_UPGRADE';
    case 'SUSPENSION': return 'SUSPENSION';
    case 'TERMINATION': return 'TERMINATION';
    default: return 'BANDWIDTH_UPGRADE';
  }
};

// ==========================================
// 5. Capacity Record Metric Type
// ==========================================
export const mapMetricTypeToBackend = (type: FrontendMetricType): string => {
  switch (type) {
    case 'CPU_UTIL': return 'CPU_LOAD';
    case 'MEM_UTIL': return 'MEMORY_USAGE';
    case 'BANDWIDTH_UTIL': return 'LINK_UTILISATION';
    case 'TEMP_C': return 'STORAGE_USAGE';
    default: return 'CPU_LOAD';
  }
};

export const mapMetricTypeToFrontend = (type: string | undefined): FrontendMetricType => {
  if (!type) return 'CPU_UTIL';
  switch (type.toUpperCase()) {
    case 'CPU_LOAD': return 'CPU_UTIL';
    case 'MEMORY_USAGE': return 'MEM_UTIL';
    case 'LINK_UTILISATION': return 'BANDWIDTH_UTIL';
    case 'STORAGE_USAGE': return 'TEMP_C';
    default: return 'CPU_UTIL';
  }
};

// ==========================================
// 6. Circuit Service Type
// ==========================================
export const mapServiceTypeToBackend = (type: FrontendServiceType): string => {
  switch (type) {
    case 'MPLS': return 'MPLS';
    case 'DIA': return 'INTERNET';
    case 'DARK_FIBER': return 'LEASED_LINE';
    case 'SDWAN': return 'VPN';
    case 'IP_TRANSIT': return 'INTERNET';
    default: return 'INTERNET';
  }
};

export const mapServiceTypeToFrontend = (type: string | undefined): FrontendServiceType => {
  if (!type) return 'DIA';
  switch (type.toUpperCase()) {
    case 'MPLS': return 'MPLS';
    case 'INTERNET': return 'DIA';
    case 'LEASED_LINE': return 'DARK_FIBER';
    case 'VPN': return 'SDWAN';
    case 'VOICE': return 'DIA';
    default: return 'DIA';
  }
};

