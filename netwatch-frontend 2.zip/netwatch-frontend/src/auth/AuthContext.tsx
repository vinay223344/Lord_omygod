import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types';
import { authApi } from '../api/auth';
import { usersApi } from '../api/users';

interface AuthContextType {
  user: User | null;
  token: string | null;
  login: (email: string, password?: string) => any;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<String | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    // Initial load from localStorage
    const storedToken = localStorage.getItem('netwatch_token');
    const storedUser = localStorage.getItem('netwatch_user');
    if (storedToken && storedUser) {
      setToken(storedToken);
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password?: string) => {
    // Start each login attempt from a clean slate so a stale/invalid token from a
    // previous session cannot be attached to requests and trigger a 403.
    localStorage.removeItem('netwatch_token');
    setToken(null);

    try {
      let response;
      try {
        response = await authApi.login({ email, password });
      } catch (err: any) {
        console.warn('Backend login failed, attempting frontend mock login fallback:', err);
        
        // Frontend mock login fallback:
        // Find user by email in the mock list
        const allUsers = await usersApi.getAll();
        const mockUser = allUsers.find((u) => u.email.toLowerCase() === email.toLowerCase());
        
        if (mockUser) {
          // If password is not provided or matches a default pattern
          // For admin@gmail.com, we must validate the password is 'admin@123'
          if (email.toLowerCase() === 'admin@gmail.com' && password !== 'admin@123') {
            throw new Error('Invalid credentials');
          }
          
          // Generate a fake token for local session
          const fakeToken = `mock-jwt-token-for-${mockUser.userId}`;
          localStorage.setItem('netwatch_token', fakeToken);
          setToken(fakeToken);
          localStorage.setItem('netwatch_user', JSON.stringify(mockUser));
          setUser(mockUser);
          return;
        } else {
          throw new Error('Invalid credentials or user not found');
        }
      }
      
      if (response.success && response.token) {
        localStorage.setItem('netwatch_token', response.token);
        setToken(response.token);

        // Fetch full user details using email
        const allUsers = await usersApi.getAll();
        let fullUser = allUsers.find((u) => u.email.toLowerCase() === email.toLowerCase());

        if (!fullUser) {
          // Fallback if user doesn't exist in our mock list yet
          fullUser = {
            userId: 99,
            name: response.username || 'System User',
            email: response.email || email,
            role: (response.role || 'FIELD_ENGINEER') as UserRole,
            status: 'ACTIVE',
          };
          // Add fallback user to mock list
          await usersApi.create(fullUser);
        }

        localStorage.setItem('netwatch_user', JSON.stringify(fullUser));
        setUser(fullUser);
      } else {
        throw new Error(response.message || 'Login failed');
      }
    } catch (err) {
      console.error('Login error in AuthContext:', err);
      throw err;
    }
  };

  const logout = () => {
    localStorage.removeItem('netwatch_token');
    localStorage.removeItem('netwatch_user');
    setToken(null);
    setUser(null);
    window.location.href = '/login';
  };

  return (
    <AuthContext.Provider value={{ user, token: token as string | null, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
