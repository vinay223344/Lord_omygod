import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';
import { UserRole } from '../types';
import { ROLE_HOMES } from './roles';

interface ProtectedRouteProps {
  children: React.ReactElement;
  allowedRoles?: UserRole[];
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRoles }) => {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', fontStyle: 'italic', color: '#64748b' }}>
        Loading Session...
      </div>
    );
  }

  if (!user) {
    // Redirect to login but save the current location they were trying to access
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    // If authenticated but role not allowed, send to their default home page
    const homePath = ROLE_HOMES[user.role] || '/';
    console.warn(`Access denied for role ${user.role} on ${location.pathname}. Redirecting to default home: ${homePath}`);
    return <Navigate to={homePath} replace />;
  }

  return children;
};

export default ProtectedRoute;
