import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { AuthProvider, useAuth } from './auth/AuthContext';
import ProtectedRoute from './auth/ProtectedRoute';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import Login from './pages/login/Login';
import Register from './pages/register/Register';
import NocDashboard from './pages/noc-dashboard/NocDashboard';
import Alarms from './pages/alarms/Alarms';
import Tickets from './pages/tickets/Tickets';
import FieldDispatchPage from './pages/field-dispatch/FieldDispatchPage';
import NetworkElements from './pages/network-elements/NetworkElements';
import Sites from './pages/sites/Sites';
import Topology from './pages/topology/Topology';
import Circuits from './pages/circuits/Circuits';
import Provisioning from './pages/provisioning/Provisioning';
import Capacity from './pages/capacity/Capacity';
import Maintenance from './pages/maintenance/Maintenance';
import Analytics from './pages/analytics/Analytics';
import UserManagement from './pages/admin/users/UserManagement';
import AuditLog from './pages/admin/audit-log/AuditLog';

// Root Layout Wrapper incorporating Left Navigation Sidebar and Topbar Header
const AppLayout: React.FC = () => {
  const { user } = useAuth();
  const [mobileNavOpen, setMobileNavOpen] = React.useState(false);

  if (!user) return <Outlet />;

  return (
    <div className="app-container">
      <Sidebar isOpen={mobileNavOpen} onClose={() => setMobileNavOpen(false)} />
      <div className="main-content">
        <Topbar onMenuClick={() => setMobileNavOpen((open) => !open)} />
        <div style={{ flex: 1, overflowY: 'auto' }}>
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* Public login Route */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />

          {/* Protected Application Routes */}
          <Route element={<AppLayout />}>
            {/* Catch-all redirect to login or dashboard */}
            <Route path="/" element={<Navigate to="/login" replace />} />

            {/* NOC Engineer Routes */}
            <Route
              path="/noc-dashboard"
              element={
                <ProtectedRoute allowedRoles={['NOC_ENGINEER', 'ADMIN']}>
                  <NocDashboard />
                </ProtectedRoute>
              }
            />
            <Route
              path="/alarms"
              element={
                <ProtectedRoute allowedRoles={['NOC_ENGINEER', 'SERVICE_DESK', 'ADMIN']}>
                  <Alarms />
                </ProtectedRoute>
              }
            />
            
            {/* Trouble Tickets */}
            <Route
              path="/tickets"
              element={
                <ProtectedRoute allowedRoles={['NOC_ENGINEER', 'SERVICE_DESK', 'FIELD_ENGINEER', 'ADMIN']}>
                  <Tickets />
                </ProtectedRoute>
              }
            />

            {/* Field Engineer Dispatches */}
            <Route
              path="/field-dispatches"
              element={
                <ProtectedRoute allowedRoles={['FIELD_ENGINEER', 'ADMIN']}>
                  <FieldDispatchPage />
                </ProtectedRoute>
              }
            />

            {/* Planning & Network Elements */}
            <Route
              path="/network-elements"
              element={
                <ProtectedRoute allowedRoles={['ADMIN', 'CHANGE_MANAGER']}>
                  <NetworkElements />
                </ProtectedRoute>
              }
            />
            <Route
              path="/sites"
              element={
                <ProtectedRoute allowedRoles={['ADMIN']}>
                  <Sites />
                </ProtectedRoute>
              }
            />
            <Route
              path="/topology"
              element={
                <ProtectedRoute allowedRoles={['PLANNING_ENGINEER', 'ADMIN']}>
                  <Topology />
                </ProtectedRoute>
              }
            />

            {/* Circuits & Provisioning */}
            <Route
              path="/circuits"
              element={
                <ProtectedRoute allowedRoles={['ADMIN', 'PLANNING_ENGINEER']}>
                  <Circuits />
                </ProtectedRoute>
              }
            />
            <Route
              path="/provisioning"
              element={
                <ProtectedRoute allowedRoles={['PLANNING_ENGINEER', 'ADMIN', 'CHANGE_MANAGER']}>
                  <Provisioning />
                </ProtectedRoute>
              }
            />

            {/* Capacity & Maintenance Windows */}
            <Route
              path="/capacity"
              element={
                <ProtectedRoute allowedRoles={['CHANGE_MANAGER', 'NOC_ENGINEER', 'ADMIN']}>
                  <Capacity />
                </ProtectedRoute>
              }
            />
            <Route
              path="/maintenance"
              element={
                <ProtectedRoute allowedRoles={['CHANGE_MANAGER', 'ADMIN', 'PLANNING_ENGINEER']}>
                  <Maintenance />
                </ProtectedRoute>
              }
            />

            {/* General Routes */}
            <Route
              path="/analytics"
              element={
                <ProtectedRoute allowedRoles={['CHANGE_MANAGER', 'ADMIN']}>
                  <Analytics />
                </ProtectedRoute>
              }
            />

            {/* Admin Console Routes */}
            <Route
              path="/admin/users"
              element={
                <ProtectedRoute allowedRoles={['ADMIN']}>
                  <UserManagement />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin/audit-log"
              element={
                <ProtectedRoute allowedRoles={['ADMIN', 'CHANGE_MANAGER']}>
                  <AuditLog />
                </ProtectedRoute>
              }
            />

            {/* Fallback route */}
            <Route path="*" element={<Navigate to="/login" replace />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
};

export default App;
