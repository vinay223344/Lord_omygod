import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useAuth } from '../../auth/AuthContext';
import { ROLE_HOMES } from '../../auth/roles';
import styles from './Login.module.css';
import { GitBranch } from 'lucide-react';

const loginSchema = z.object({
  email: z.string().min(1, 'Email is required').email('Invalid email address'),
  password: z.string().min(1, 'Password is required'),
});

type LoginFields = z.infer<typeof loginSchema>;

export const Login: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginFields>({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = async (data: LoginFields) => {
    setErrorMsg(null);
    setLoading(true);
    try {
      await login(data.email, data.password);
      
      // Successfully logged in! Determine redirection
      const storedUser = localStorage.getItem('netwatch_user');
      if (storedUser) {
        const u = JSON.parse(storedUser);
        const defaultHome = (ROLE_HOMES as any)[u.role] || '/';
        const from = (location.state as any)?.from?.pathname || defaultHome;
        navigate(from, { replace: true });
      } else {
        navigate('/', { replace: true });
      }
    } catch (err: any) {
      const status = err.response?.status;
      const backendMsg = err.response?.data?.message;
      if (backendMsg) {
        setErrorMsg(backendMsg);
      } else if (status === 401 || status === 403) {
        // Failed authentication — show a clear message instead of the raw
        // "Request failed with status code 403" axios default.
        setErrorMsg('Invalid Credentials');
      } else {
        setErrorMsg('Invalid credentials or connection error.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles['login-page']}>
      <div className={styles['login-card']}>
        <div className={styles.header}>
          <div className={styles['logo-icon']}>
            <GitBranch size={36} />
          </div>
          <h1 className={styles.title}>NetWatch</h1>
          <p className={styles.subtitle}>Network Operations & NOC Management</p>
        </div>

        <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
          {errorMsg && <div className={styles['form-error']}>{errorMsg}</div>}

          <div className={styles['form-group']}>
            <label className={styles.label}>Email Address</label>
            <input
              type="email"
              className={styles.input}
              placeholder="e.g. engineer@netwatch.com"
              {...register('email')}
            />
            {errors.email && (
              <span className={styles['error-text']}>{errors.email.message}</span>
            )}
          </div>

          <div className={styles['form-group']}>
            <label className={styles.label}>Security Password</label>
            <input
              type="password"
              className={styles.input}
              placeholder="••••••••"
              {...register('password')}
            />
            {errors.password && (
              <span className={styles['error-text']}>{errors.password.message}</span>
            )}
          </div>

          <button type="submit" className={styles['submit-btn']} disabled={loading}>
            {loading ? 'Authenticating...' : 'Sign In'}
          </button>
        </form>

        <div style={{ marginTop: '1.5rem', textAlign: 'center', fontSize: '0.8125rem', color: 'var(--text-muted)' }}>
          <span>Don't have an operational account? </span>
          <Link to="/register" style={{ color: 'var(--primary)', fontWeight: 600 }}>Register Account</Link>
        </div>
      </div>
    </div>
  );
};

export default Login;
