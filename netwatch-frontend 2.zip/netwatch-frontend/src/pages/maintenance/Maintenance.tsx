import React, { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import axios from 'axios';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import { StatCard, StatGrid } from '../../components/StatCard';
import { useAuth } from '../../auth/AuthContext';
import { capacityApi } from '../../api/capacity';
import { elementsApi } from '../../api/elements';
import { MaintenanceWindow, NetworkElement, MaintenanceType } from '../../types';
import { formatDate } from '../../utils/date';
import { statusColor } from '../../theme/statusColors';
import styles from './Maintenance.module.css';
import { Activity, Calendar, CheckCircle, Clock, Eye, XCircle } from 'lucide-react';

const maintenanceSchema = z
  .object({
    title: z.string().min(1, 'Maintenance title is required'),
    maintenanceType: z.enum(['SCHEDULED', 'EMERGENCY', 'UPGRADE']),
    startDateTime: z.string().min(1, 'Start date & time is required'),
    endDateTime: z.string().min(1, 'End date & time is required'),
    rollbackPlan: z.string().min(1, 'Rollback plan description is required'),
    affectedElementIds: z.array(z.string()).min(1, 'At least one affected element must be selected'),
  })
  .refine((data) => new Date(data.startDateTime) < new Date(data.endDateTime), {
    message: 'Start time must be before end time',
    path: ['endDateTime'],
  });

type MaintenanceFields = z.infer<typeof maintenanceSchema>;

export const Maintenance: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'all' | 'pending'>('all');
  const [windows, setWindows] = useState<MaintenanceWindow[]>([]);
  const [pendingWindows, setPendingWindows] = useState<MaintenanceWindow[]>([]);
  const [elements, setElements] = useState<NetworkElement[]>([]);
  
  // Modals state
  const [isRequestModalOpen, setIsRequestModalOpen] = useState(false);
  const [selectedWindow, setSelectedWindow] = useState<MaintenanceWindow | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionError, setActionError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    reset,
    formState: { errors },
  } = useForm<MaintenanceFields>({
    resolver: zodResolver(maintenanceSchema),
    defaultValues: {
      affectedElementIds: [],
    },
  });

  const selectedElements = watch('affectedElementIds') || [];

  const loadData = async () => {
    setLoading(true);
    try {
      const [allWindows, allPending, allElements] = await axios.all<any>([
        capacityApi.getAllWindows(),
        capacityApi.getPendingWindows().catch(() => [] as MaintenanceWindow[]),
        elementsApi.getAll().catch(() => [] as NetworkElement[]),
      ]) as [MaintenanceWindow[], MaintenanceWindow[], NetworkElement[]];
      setWindows(allWindows);
      setPendingWindows(allPending);
      setElements(allElements);
    } catch (err) {
      console.error('Failed to load maintenance logs:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRequestWindow = async (data: MaintenanceFields) => {
    if (!user) return;
    try {
      const payload: Partial<MaintenanceWindow> = {
        title: data.title,
        maintenanceType: data.maintenanceType as MaintenanceType,
        startDateTime: new Date(data.startDateTime).toISOString(),
        endDateTime: new Date(data.endDateTime).toISOString(),
        rollbackPlan: data.rollbackPlan,
        affectedElementIds: data.affectedElementIds.join(','),
      };

      await capacityApi.createWindow(payload, user.userId);
      setIsRequestModalOpen(false);
      reset();
      loadData();
    } catch (err) {
      console.error('Failed to raise maintenance window request:', err);
    }
  };

  const handleApprove = async (id: number) => {
    if (!user) return;
    setActionError(null);
    try {
      await capacityApi.approveWindow(id, user.userId);
      setSelectedWindow(null);
      loadData();
    } catch (err: any) {
      console.error('Failed to approve window:', err);
      setActionError(err?.response?.data?.message || 'Failed to approve maintenance window.');
    }
  };

  const handleReject = async (id: number) => {
    if (!user) return;
    setActionError(null);
    try {
      await capacityApi.updateWindowStatus(id, 'CANCELLED', user.userId);
      setSelectedWindow(null);
      loadData();
    } catch (err: any) {
      console.error('Failed to reject window:', err);
      setActionError(err?.response?.data?.message || 'Failed to reject maintenance window.');
    }
  };

  const handleElementCheck = (elId: string, checked: boolean) => {
    if (checked) {
      setValue('affectedElementIds', [...selectedElements, elId]);
    } else {
      setValue('affectedElementIds', selectedElements.filter((id) => id !== elId));
    }
  };

  const getElementNames = (idString: string) => {
    if (!idString) return 'None';
    return idString
      .split(',')
      .map((id) => {
        const found = elements.find((e) => e.elementId === Number(id));
        return found ? found.elementName : `Element #${id}`;
      })
      .join(', ');
  };

  // ── Derived summary data (from windows already in state) ──
  const kpis = useMemo(
    () => ({
      pending: windows.filter((w) => w.status === 'PENDING').length,
      approved: windows.filter((w) => w.status === 'APPROVED').length,
      inProgress: windows.filter((w) => w.status === 'IN_PROGRESS').length,
      total: windows.length,
    }),
    [windows]
  );

  // Chronological feed (most recent window first) for the timeline panel.
  const timeline = useMemo(
    () =>
      [...windows].sort(
        (a, b) => new Date(b.startDateTime).getTime() - new Date(a.startDateTime).getTime()
      ),
    [windows]
  );

  const columns: Column<MaintenanceWindow>[] = [
    { key: 'maintenanceId', header: 'ID', sortable: true },
    { key: 'title', header: 'Window Title', sortable: true },
    { key: 'maintenanceType', header: 'Category', sortable: true },
    { key: 'startDateTime', header: 'Start Time', sortable: true, render: (row) => formatDate(row.startDateTime) },
    { key: 'endDateTime', header: 'End Time', sortable: true, render: (row) => formatDate(row.endDateTime) },
    { key: 'affectedElementIds', header: 'Affected elements', render: (row) => getElementNames(row.affectedElementIds) },
    { key: 'status', header: 'Status', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
  ];

  if (activeTab === 'pending') {
    columns.push({
      key: 'actions',
      header: 'Actions',
      render: (row) => (
        <button className={styles.btn} onClick={() => setSelectedWindow(row)} style={{ padding: '0.25rem 0.5rem', background: '#f1f5f9', border: '1px solid var(--border-color)', color: 'var(--text-main)' }}>
          <Eye size={12} /> View
        </button>
      ),
    });
  }

  return (
    <div className="page-container">
      <PageHeader
        title="Scheduled Maintenance Windows"
        description="Verify network scheduling blackout windows, review emergency configurations, and approve rolling scripts."
      />

      {/* Summary: status KPIs + maintenance timeline (from windows already in state) */}
      {!loading && (
        <div className={styles.summary}>
          <StatGrid>
            <StatCard label="Pending" value={kpis.pending} icon={<Clock size={20} />} variant="warning" />
            <StatCard label="Approved" value={kpis.approved} icon={<CheckCircle size={20} />} variant="success" />
            <StatCard label="In Progress" value={kpis.inProgress} icon={<Activity size={20} />} variant="info" />
            <StatCard label="Total Windows" value={kpis.total} icon={<Calendar size={20} />} variant="primary" />
          </StatGrid>

          <div className="card">
            <div className={styles['panel-header']}>
              <h3 className={styles['panel-title']}>
                <Calendar size={15} /> Maintenance Timeline
              </h3>
            </div>
            {timeline.length > 0 ? (
              <div className={styles.timeline}>
                {timeline.map((w) => {
                  const affectedCount = w.affectedElementIds
                    ? w.affectedElementIds.split(',').filter(Boolean).length
                    : 0;
                  return (
                    <div
                      key={w.maintenanceId}
                      className={styles['timeline-item']}
                      onClick={() => setSelectedWindow(w)}
                    >
                      <div className={styles['timeline-rail']}>
                        <span
                          className={styles['timeline-dot']}
                          style={{ backgroundColor: statusColor(w.status) }}
                        />
                        <span className={styles['timeline-line']} />
                      </div>
                      <div className={styles['timeline-content']}>
                        <div className={styles['timeline-head']}>
                          <span className={styles['timeline-id']}>{w.title}</span>
                          <StatusBadge status={w.status} />
                        </div>
                        <span className={styles['timeline-meta']}>
                          {w.maintenanceType} · {affectedCount} element{affectedCount === 1 ? '' : 's'}
                        </span>
                        <span className={styles['timeline-time']}>
                          {formatDate(w.startDateTime)} → {formatDate(w.endDateTime)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className={styles['timeline-empty']}>No maintenance windows to display.</div>
            )}
          </div>
        </div>
      )}

      {/* Tabs list (ChangeManager / Admin only) */}
      {(user?.role === 'CHANGE_MANAGER' || user?.role === 'ADMIN') && (
        <div className={styles.tabs}>
          <button
            className={`${styles.tab} ${activeTab === 'all' ? styles['active-tab'] : ''}`}
            onClick={() => setActiveTab('all')}
          >
            Maintenance Calendar
          </button>
          <button
            className={`${styles.tab} ${activeTab === 'pending' ? styles['active-tab'] : ''}`}
            onClick={() => setActiveTab('pending')}
          >
            Pending Approvals ({pendingWindows.length})
          </button>
        </div>
      )}

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading maintenance windows...</div>
      ) : (
        <div className="card">
          <DataTable
            columns={columns}
            data={activeTab === 'all' ? windows.filter(w => w.status !== 'PENDING') : pendingWindows}
            searchPlaceholder="Search maintenance windows..."
            searchKey="title"
          />
        </div>
      )}

      {/* Request Maintenance Modal */}
      <Modal isOpen={isRequestModalOpen} onClose={() => setIsRequestModalOpen(false)} title="Request Maintenance Window">
        <form className={styles.form} onSubmit={handleSubmit(handleRequestWindow)}>
          <div className={styles['form-group']}>
            <label className={styles.label}>Maintenance Title</label>
            <input type="text" className={styles.input} placeholder="e.g. CORE-RT-01 IOS Firmware Upgrade" {...register('title')} />
            {errors.title && <span className={styles['error-text']}>{errors.title.message}</span>}
          </div>

          <div className={styles['form-row']}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Start Time</label>
              <input type="datetime-local" className={styles.input} {...register('startDateTime')} />
              {errors.startDateTime && <span className={styles['error-text']}>{errors.startDateTime.message}</span>}
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>End Time</label>
              <input type="datetime-local" className={styles.input} {...register('endDateTime')} />
              {errors.endDateTime && <span className={styles['error-text']}>{errors.endDateTime.message}</span>}
            </div>
          </div>

          <div className={styles['form-row']}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Maintenance Category</label>
              <select className={styles.select} {...register('maintenanceType')}>
                <option value="SCHEDULED">SCHEDULED</option>
                <option value="EMERGENCY">EMERGENCY</option>
                <option value="UPGRADE">UPGRADE</option>
              </select>
            </div>
          </div>

          <div className={styles['form-group']}>
            <label className={styles.label}>Affected Routing Elements (Check all that apply)</label>
            <div className={styles['elements-checklist']}>
              {elements.map((el) => {
                const idStr = String(el.elementId);
                return (
                  <label key={el.elementId} className={styles['checkbox-label']}>
                    <input
                      type="checkbox"
                      checked={selectedElements.includes(idStr)}
                      onChange={(e) => handleElementCheck(idStr, e.target.checked)}
                    />
                    {el.elementName} ({el.ipAddress})
                  </label>
                );
              })}
            </div>
            {errors.affectedElementIds && <span className={styles['error-text']}>{errors.affectedElementIds.message}</span>}
          </div>

          <div className={styles['form-group']}>
            <label className={styles.label}>Rollback & Disaster Mitigation Plan</label>
            <textarea
              className={styles.textarea}
              placeholder="Describe step-by-step restoration flow if upgrades fail (e.g. TFTP reload old config)"
              rows={3}
              {...register('rollbackPlan')}
            />
            {errors.rollbackPlan && <span className={styles['error-text']}>{errors.rollbackPlan.message}</span>}
          </div>

          <button type="submit" className={`${styles.btn} ${styles['btn-primary']}`} style={{ width: '100%', marginTop: '0.5rem', padding: '0.625rem' }}>
            Submit Window Request
          </button>
        </form>
      </Modal>

      {/* View Maintenance Window Details Modal */}
      <Modal isOpen={selectedWindow !== null} onClose={() => { setSelectedWindow(null); setActionError(null); }} title="Maintenance Window Details">
        {selectedWindow && (
          <div className={styles['window-detail']}>
            <div className={styles['detail-row']}>
              <span className={styles['detail-label']}>Task Title</span>
              <span className={styles['detail-value']} style={{ fontWeight: 'bold' }}>{selectedWindow.title}</span>
            </div>

            <div className={styles['detail-row']}>
              <span className={styles['detail-label']}>Category / Type</span>
              <StatusBadge status={selectedWindow.maintenanceType} />
            </div>

            <div className={styles['detail-row']}>
              <span className={styles['detail-label']}>Time Window</span>
              <span className={styles['detail-value']} style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <Clock size={14} /> {formatDate(selectedWindow.startDateTime)} to {formatDate(selectedWindow.endDateTime)}
              </span>
            </div>

            <div className={styles['detail-row']}>
              <span className={styles['detail-label']}>Affected Elements</span>
              <div className={styles.pills}>
                {selectedWindow.affectedElementIds.split(',').map((id) => (
                  <span key={id} className={styles.pill}>
                    {elements.find((e) => e.elementId === Number(id))?.elementName || `Element #${id}`}
                  </span>
                ))}
              </div>
            </div>

            <div className={styles['detail-row']}>
              <span className={styles['detail-label']}>Rollback Script</span>
              <p style={{ background: '#f1f5f9', padding: '0.5rem', borderRadius: '4px', fontStyle: 'italic', color: 'var(--text-muted)' }}>
                "{selectedWindow.rollbackPlan}"
              </p>
            </div>

            <div className={styles['detail-row']}>
              <span className={styles['detail-label']}>Approval Status</span>
              <StatusBadge status={selectedWindow.status} />
            </div>

            {actionError && (
              <div className={styles['error-text']} style={{ marginTop: '0.5rem' }}>{actionError}</div>
            )}

            {/* Approval Controls */}
            {selectedWindow.status === 'PENDING' && (user?.role === 'CHANGE_MANAGER' || user?.role === 'ADMIN') && (
              <div className={styles['btn-group']}>
                <button
                  className={`${styles.btn} ${styles['btn-danger']}`}
                  onClick={() => handleReject(selectedWindow.maintenanceId)}
                  style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.35rem' }}
                >
                  <XCircle size={14} /> Reject Request
                </button>
                <button
                  className={`${styles.btn} ${styles['btn-primary']}`}
                  onClick={() => handleApprove(selectedWindow.maintenanceId)}
                  style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.35rem', backgroundColor: '#166534' }}
                >
                  <CheckCircle size={14} /> Approve Window
                </button>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default Maintenance;
