import React, { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import { StatCard, StatGrid } from '../../components/StatCard';
import { useAuth } from '../../auth/AuthContext';
import { circuitsApi } from '../../api/circuits';
import { elementsApi } from '../../api/elements';
import { Circuit, ServiceType, CircuitStatus, NetworkElement } from '../../types';
import { formatDate } from '../../utils/date';
import styles from './Circuits.module.css';
import { Cable, CheckCircle, Clock, Edit, Gauge, PlusCircle } from 'lucide-react';

const circuitSchema = z.object({
  circuitReference: z.string().min(1, 'Circuit reference is required'),
  serviceType: z.enum(['MPLS', 'DIA', 'DARK_FIBER', 'SDWAN', 'IP_TRANSIT']),
  customerId: z.string().min(1, 'Customer ID is required'),
  bandwidthMbps: z.coerce.number().positive('Bandwidth must be a positive number'),
  status: z.enum(['ACTIVE', 'SUSPENDED', 'DECOMMISSIONED']),
});

type CircuitFormFields = z.infer<typeof circuitSchema>;

export const Circuits: React.FC = () => {
  const { user } = useAuth();
  const [circuits, setCircuits] = useState<Circuit[]>([]);
  const [elements, setElements] = useState<NetworkElement[]>([]);
  const [hops, setHops] = useState<number[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCircuit, setEditingCircuit] = useState<Circuit | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm<any>({
    resolver: zodResolver(circuitSchema),
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [circuitsData, elementsData] = await Promise.all([
        circuitsApi.getAllCircuits(),
        elementsApi.getAll().catch(() => [] as NetworkElement[]),
      ]);
      setCircuits(circuitsData);
      setElements(elementsData);
    } catch (err) {
      console.error('Failed to retrieve data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  const openCreateModal = () => {
    setEditingCircuit(null);
    setErrorMsg(null);
    reset();
    // New circuits are always provisioned as ACTIVE (status is not user-editable
    // on creation), so seed the form value the fixed display relies on.
    setValue('status', 'ACTIVE');
    setHops([]);
    setIsModalOpen(true);
  };

  const openEditModal = (circuit: Circuit) => {
    setEditingCircuit(circuit);
    setErrorMsg(null);
    setValue('circuitReference', circuit.circuitReference);
    setValue('serviceType', circuit.serviceType);
    setValue('customerId', circuit.customerId);
    setValue('bandwidthMbps', circuit.bandwidthMbps);
    setValue('status', circuit.status);
    setHops(circuit.routeElementIds || []);
    setIsModalOpen(true);
  };

  const addHop = () => {
    setHops([...hops, 0]);
  };

  const removeHop = (index: number) => {
    setHops(hops.filter((_, i) => i !== index));
  };

  const handleHopChange = (index: number, val: string) => {
    const newHops = [...hops];
    newHops[index] = Number(val);
    setHops(newHops);
  };

  const getGeneratedRoutePath = (hopIds: number[]) => {
    const selectedElements = hopIds
      .map((id) => elements.find((el) => el.elementId === id))
      .filter((el): el is NetworkElement => !!el);
    return selectedElements.map((el) => `${el.elementName} (${el.ipAddress})`).join(' -> ');
  };

  const onSubmit = async (data: CircuitFormFields) => {
    if (!user) return;
    setErrorMsg(null);

    const validHops = hops.filter((id) => id > 0);

    if (validHops.length < 2) {
      setErrorMsg('A circuit route must include at least 2 network elements.');
      return;
    }

    try {
      const generatedPath = getGeneratedRoutePath(validHops);
      const payload: Partial<Circuit> = {
        circuitReference: data.circuitReference,
        serviceType: data.serviceType as ServiceType,
        customerId: data.customerId,
        bandwidthMbps: data.bandwidthMbps,
        routePath: generatedPath,
        status: data.status as CircuitStatus,
        routeElementIds: validHops,
      };

      if (editingCircuit) {
        await circuitsApi.updateCircuit(editingCircuit.circuitId, payload, user.userId);
      } else {
        await circuitsApi.createCircuit(payload, user.userId);
      }
      setIsModalOpen(false);
      loadData();
    } catch (err: any) {
      console.error('Failed to save customer circuit:', err);
      const rawMsg = err.response?.data?.message || err.message || 'Failed to save customer circuit';
      // Show the element name only — strip the internal "(ID=5)" identifier from backend messages.
      const errMsg = rawMsg.replace(/\s*\(ID=\d+\)/g, '');
      setErrorMsg(errMsg);
    }
  };

  // ── Derived summary data (from circuits already in state) ──
  const kpis = useMemo(() => {
    return {
      active: circuits.filter((c) => c.status === 'ACTIVE').length,
      suspended: circuits.filter((c) => c.status === 'SUSPENDED').length,
      decommissioned: circuits.filter((c) => c.status === 'DECOMMISSIONED').length,
      total: circuits.length,
    };
  }, [circuits]);

  const columns: Column<Circuit>[] = [
    { key: 'circuitId', header: 'ID', sortable: true },
    { key: 'circuitReference', header: 'Circuit Ref', sortable: true },
    { key: 'serviceType', header: 'Service Type', sortable: true },
    { key: 'customerId', header: 'Customer ID', sortable: true },
    { key: 'bandwidthMbps', header: 'Bandwidth (Mbps)', sortable: true },
    { key: 'routePath', header: 'Route Path', sortable: true },
    {
      key: 'routeElementIds',
      header: 'Route Element IDs',
      render: (row) =>
        row.routeElementIds && row.routeElementIds.length > 0 ? row.routeElementIds.join(', ') : 'None',
    },
    { key: 'activationDate', header: 'Activation Date', sortable: true, render: (row) => formatDate(row.activationDate) },
    { key: 'status', header: 'Status', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
    {
      key: 'actions',
      header: 'Actions',
      render: (row) => (
        <button
          className={styles.btn}
          onClick={() => openEditModal(row)}
          style={{
            padding: '0.25rem 0.5rem',
            background: '#f1f5f9',
            border: '1px solid var(--border-color)',
            color: 'var(--text-main)',
          }}
        >
          <Edit size={12} /> Edit
        </button>
      ),
    },
  ];

  const previewHops = hops.filter((id) => id > 0);

  return (
    <div className="page-container">
      <PageHeader
        title="Circuit Inventory & Service Registry"
        description="Verify provisioned customer lines (MPLS, DIA, Dark Fiber) and active routing hops."
        action={
          <button className={`${styles.btn} ${styles['btn-primary']}`} onClick={openCreateModal}>
            <PlusCircle size={14} /> Add Customer Circuit
          </button>
        }
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading circuits...</div>
      ) : (
        <div className={styles['page-body']}>
          {/* KPI summary cards */}
          <StatGrid>
            <StatCard label="Active" value={kpis.active} icon={<CheckCircle size={20} />} variant="success" />
            <StatCard label="Suspended" value={kpis.suspended} icon={<Clock size={20} />} variant="info" />
            <StatCard
              label="Decommissioned"
              value={kpis.decommissioned}
              icon={<Gauge size={20} />}
              variant="neutral"
            />
            <StatCard label="Total Circuits" value={kpis.total} icon={<Cable size={20} />} variant="primary" />
          </StatGrid>


          <div className="card">
            <DataTable
              columns={columns}
              data={circuits}
              searchPlaceholder="Search circuits by customer reference or ID..."
              searchKey={(row) => `${row.circuitReference} ${row.customerId}`}
            />
          </div>
        </div>
      )}

      {/* Create / Edit Circuit Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingCircuit ? `Edit Circuit Reference #${editingCircuit.circuitId}` : 'Add Customer Circuit'}
      >
        <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
          {errorMsg && (
            <div
              style={{
                background: '#fee2e2',
                border: '1px solid #fecaca',
                color: '#991b1b',
                padding: '0.75rem',
                borderRadius: '4px',
                fontSize: '0.875rem',
                marginBottom: '1rem',
              }}
            >
              {errorMsg}
            </div>
          )}

          <div className={styles['form-group']}>
            <label className={styles.label}>Circuit Reference</label>
            <input type="text" className={styles.input} placeholder="e.g. AS-DIA-10G-019" {...register('circuitReference')} />
            {errors.circuitReference && (
              <span className={styles['error-text']}>{errors.circuitReference.message?.toString()}</span>
            )}
          </div>

          <div className={styles['form-row']}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Service Type</label>
              <select className={styles.select} {...register('serviceType')}>
                <option value="MPLS">MPLS</option>
                <option value="DIA">DIA</option>
                <option value="DARK_FIBER">DARK_FIBER</option>
                <option value="SDWAN">SDWAN</option>
                <option value="IP_TRANSIT">IP_TRANSIT</option>
              </select>
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>Customer ID</label>
              <input type="text" className={styles.input} placeholder="e.g. CUST-G-881" {...register('customerId')} />
              {errors.customerId && <span className={styles['error-text']}>{errors.customerId.message?.toString()}</span>}
            </div>
          </div>

          <div className={styles['form-row']}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Bandwidth (Mbps)</label>
              <input type="number" className={styles.input} placeholder="e.g. 1000" {...register('bandwidthMbps')} />
              {errors.bandwidthMbps && (
                <span className={styles['error-text']}>{errors.bandwidthMbps.message?.toString()}</span>
              )}
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>Status</label>
              {editingCircuit ? (
                <select className={styles.select} {...register('status')}>
                  <option value="ACTIVE">ACTIVE</option>
                  <option value="SUSPENDED">SUSPENDED</option>
                  <option value="DECOMMISSIONED">DECOMMISSIONED</option>
                </select>
              ) : (
                // On creation the status is fixed to ACTIVE — show it as a
                // read-only field instead of an editable dropdown.
                <input className={styles.input} value="ACTIVE" readOnly />
              )}
            </div>
          </div>

          {/* Interactive Hop Builder */}
          <div
            className={styles['form-group']}
            style={{ borderTop: '1px solid var(--border-color)', paddingTop: '1rem', marginTop: '1rem' }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
              <label className={styles.label} style={{ marginBottom: 0 }}>
                Route Path Elements (Hops)
              </label>
              <button
                type="button"
                className={`${styles.btn} ${styles['btn-primary']}`}
                style={{ padding: '0.25rem 0.5rem', fontSize: '0.75rem', height: 'auto', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                onClick={addHop}
              >
                <PlusCircle size={12} /> Add Hop
              </button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              {hops.map((hopId, index) => (
                <div key={index} style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                  <span style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', width: '3.5rem' }}>
                    Hop #{index + 1}
                  </span>
                  <select
                    className={styles.select}
                    value={hopId}
                    style={{ flex: 1 }}
                    onChange={(e) => handleHopChange(index, e.target.value)}
                  >
                    <option value="0">-- Select Element --</option>
                    {elements.map((el) => (
                      <option key={el.elementId} value={el.elementId}>
                        {el.elementName} ({el.ipAddress}) - {el.status}
                      </option>
                    ))}
                  </select>
                  <button
                    type="button"
                    className={styles.btn}
                    style={{
                      padding: '0.375rem 0.5rem',
                      background: '#fee2e2',
                      border: '1px solid #fecaca',
                      color: '#991b1b',
                    }}
                    onClick={() => removeHop(index)}
                  >
                    Remove
                  </button>
                </div>
              ))}
              {hops.length === 0 && (
                <div style={{ fontSize: '0.8125rem', color: 'var(--text-muted)', fontStyle: 'italic' }}>
                  No hops configured. Click "+ Add Hop" to begin mapping the circuit route path.
                </div>
              )}
            </div>

            {previewHops.length > 0 && (
              <div
                style={{
                  marginTop: '0.75rem',
                  padding: '0.5rem 0.75rem',
                  background: '#f8fafc',
                  border: '1px solid var(--border-color)',
                  borderRadius: '4px',
                  fontSize: '0.75rem',
                  lineHeight: 1.4,
                  wordBreak: 'break-all',
                }}
              >
                <strong>Preview Path:</strong> {getGeneratedRoutePath(previewHops)}
              </div>
            )}
          </div>

          <button
            type="submit"
            className={`${styles.btn} ${styles['btn-primary']}`}
            style={{ width: '100%', marginTop: '1.25rem', padding: '0.625rem' }}
          >
            {editingCircuit ? 'Apply Changes' : 'Provision Circuit'}
          </button>
        </form>
      </Modal>
    </div>
  );
};

export default Circuits;
