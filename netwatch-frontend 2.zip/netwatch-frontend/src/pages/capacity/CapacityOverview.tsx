import React, { useMemo } from 'react';
import { Server, CheckCircle, AlertTriangle, AlertOctagon } from 'lucide-react';
import { CapacityRecord } from '../../types';
import { StatCard, StatGrid } from '../../components/StatCard';

interface CapacityOverviewProps {
  records: CapacityRecord[];
}

/**
 * Capacity Overview — dashboard-style summary cards derived from the capacity
 * records already held in the page's state. Purely presentational: it reads the
 * records prop and displays counts by CapacityStatus. No data fetching here.
 */
export const CapacityOverview: React.FC<CapacityOverviewProps> = ({ records }) => {
  // Derive the status counts from the records already in state (no extra API call).
  const counts = useMemo(() => {
    return records.reduce(
      (acc, record) => {
        acc.total += 1;
        if (record.status === 'NORMAL') acc.normal += 1;
        else if (record.status === 'WARNING') acc.warning += 1;
        else if (record.status === 'CRITICAL') acc.critical += 1;
        return acc;
      },
      { total: 0, normal: 0, warning: 0, critical: 0 }
    );
  }, [records]);

  return (
    <StatGrid>
      <StatCard
        label="Total Capacity Records"
        value={counts.total}
        icon={<Server size={20} />}
        variant="primary"
      />
      <StatCard
        label="Normal"
        value={counts.normal}
        icon={<CheckCircle size={20} />}
        variant="success"
      />
      <StatCard
        label="Warning"
        value={counts.warning}
        icon={<AlertTriangle size={20} />}
        variant="warning"
      />
      <StatCard
        label="Critical"
        value={counts.critical}
        icon={<AlertOctagon size={20} />}
        variant="critical"
      />
    </StatGrid>
  );
};

export default CapacityOverview;
