import React, { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import { StatCard, StatGrid } from '../../components/StatCard';
import { sitesApi } from '../../api/sites';
import { useAuth } from '../../auth/AuthContext';
import { NetworkSite, SiteType, SiteStatus } from '../../types';
import styles from './Sites.module.css';
import { CheckCircle, Edit, MapPin, PlusCircle, XCircle } from 'lucide-react';

const siteSchema = z.object({
  siteName: z.string().min(1, 'Site name is required'),
  siteType: z.enum(['CORE_POP', 'REGIONAL_POP', 'EDGE_POP', 'DATACENTER', 'CELL_TOWER']),
  address: z.string().min(1, 'Address location is required'),
  status: z.enum(['OPERATIONAL', 'UNDER_MAINTENANCE', 'DOWN']),
});

type SiteFormFields = z.infer<typeof siteSchema>;

export const Sites: React.FC = () => {
  const { user } = useAuth();
  const [sites, setSites] = useState<NetworkSite[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSite, setEditingSite] = useState<NetworkSite | null>(null);
  const [loading, setLoading] = useState(true);

  const isPlanningEngineer = user?.role === 'PLANNING_ENGINEER';

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm<SiteFormFields>({
    resolver: zodResolver(siteSchema),
  });

  const loadSites = async () => {
    setLoading(true);
    try {
      const data = await sitesApi.getAll();
      setSites(data);
    } catch (err) {
      console.error('Failed to load POP site lists:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSites();
  }, [user]);

  const openCreateModal = () => {
    setEditingSite(null);
    reset();
    setIsModalOpen(true);
  };

  const openEditModal = (site: NetworkSite) => {
    setEditingSite(site);
    setValue('siteName', site.siteName);
    setValue('siteType', site.siteType);
    setValue('address', site.address);
    setValue('status', site.status);
    setIsModalOpen(true);
  };

  const onSubmit = async (data: SiteFormFields) => {
    try {
      const payload: Partial<NetworkSite> = {
        siteName: data.siteName,
        siteType: data.siteType as SiteType,
        address: data.address,
        status: data.status as SiteStatus,
      };

      if (editingSite) {
        await sitesApi.update(editingSite.siteId, payload);
      } else {
        await sitesApi.create(payload);
      }
      setIsModalOpen(false);
      loadSites();
    } catch (err) {
      console.error('Failed to save network site details:', err);
    }
  };

  // ── Derived summary data (from sites already in state) ──
  const kpis = useMemo(
    () => ({
      operational: sites.filter((s) => s.status === 'OPERATIONAL').length,
      down: sites.filter((s) => s.status === 'DOWN').length,
      total: sites.length,
    }),
    [sites]
  );

  const columns: Column<NetworkSite>[] = [
    { key: 'siteId', header: 'ID', sortable: true },
    { key: 'siteName', header: 'Site Name', sortable: true },
    { key: 'siteType', header: 'Type', sortable: true },
    { key: 'address', header: 'Location Address', sortable: true },
    { key: 'status', header: 'Operational Status', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
  ];

  if (!isPlanningEngineer) {
    columns.push({
      key: 'actions',
      header: 'Actions',
      render: (row) => (
        <button className={styles.btn} onClick={() => openEditModal(row)} style={{ padding: '0.25rem 0.5rem', background: '#f1f5f9', border: '1px solid var(--border-color)', color: 'var(--text-main)' }}>
          <Edit size={12} /> Edit
        </button>
      ),
    });
  }

  return (
    <div className="page-container">
      <PageHeader
        title="Network Sites & POP Registry"
        description="Configure infrastructure facility centers, regional offices, and core data center POP locations."
        action={!isPlanningEngineer ? (
          <button className={`${styles.btn} ${styles['btn-primary']}`} onClick={openCreateModal}>
            <PlusCircle size={14} /> Add Network Site
          </button>
        ) : undefined}
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading network sites...</div>
      ) : (
        <div className={styles['page-body']}>
          {/* KPI summary cards */}
          <StatGrid>
            <StatCard label="Operational" value={kpis.operational} icon={<CheckCircle size={20} />} variant="success" />
            <StatCard label="Down" value={kpis.down} icon={<XCircle size={20} />} variant="critical" />
            <StatCard label="Total Sites" value={kpis.total} icon={<MapPin size={20} />} variant="primary" />
          </StatGrid>

          <div className="card">
            <DataTable
              columns={columns}
              data={sites}
              searchPlaceholder="Search sites by name or address..."
              searchKey={(row) => `${row.siteName} ${row.address}`}
            />
          </div>
        </div>
      )}

      {/* Create / Edit Site Modal */}
      {!isPlanningEngineer && (
        <Modal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          title={editingSite ? `Edit Network Site #${editingSite.siteId}` : 'Add Network Site'}
        >
          <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Site Location Name</label>
              <input type="text" className={styles.input} placeholder="e.g. DAL-DC-01" {...register('siteName')} />
              {errors.siteName && <span className={styles['error-text']}>{errors.siteName.message}</span>}
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>Facility Type</label>
              <select className={styles.select} {...register('siteType')}>
                <option value="CORE_POP">CORE_POP</option>
                <option value="REGIONAL_POP">REGIONAL_POP</option>
                <option value="EDGE_POP">EDGE_POP</option>
                <option value="DATACENTER">DATACENTER</option>
                <option value="CELL_TOWER">CELL_TOWER</option>
              </select>
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>Location Address</label>
              <input type="text" className={styles.input} placeholder="e.g. 100 Main St, Dallas, TX" {...register('address')} />
              {errors.address && <span className={styles['error-text']}>{errors.address.message}</span>}
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>Operational Status</label>
              <select className={styles.select} {...register('status')}>
                <option value="OPERATIONAL">OPERATIONAL</option>
                <option value="UNDER_MAINTENANCE">UNDER_MAINTENANCE</option>
                <option value="DOWN">DOWN</option>
              </select>
            </div>

            <button type="submit" className={`${styles.btn} ${styles['btn-primary']}`} style={{ width: '100%', marginTop: '0.5rem', padding: '0.625rem' }}>
              {editingSite ? 'Apply Changes' : 'Register Site POP'}
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
};

export default Sites;
