import React, { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import axios from 'axios';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import { StatCard, StatGrid } from '../../components/StatCard';
import { topologyApi } from '../../api/topology';
import { elementsApi } from '../../api/elements';
import { useAuth } from '../../auth/AuthContext';
import { TopologyLink, NetworkElement, LinkType, LinkStatus } from '../../types';
import styles from './Topology.module.css';
import { CheckCircle, Edit, Link2, PlusCircle, Wrench, XCircle } from 'lucide-react';

const topologySchema = z
  .object({
    elementAId: z.string().min(1, 'Source element A is required'),
    elementBId: z.string().min(1, 'Destination element B is required'),
    linkType: z.enum(['FIBER', 'MICROWAVE', 'SATELLITE']),
    capacityMbps: z.coerce.number().positive('Capacity must be a positive number'),
    utilisationPercent: z.coerce.number().min(0, 'Min utilisation is 0%').max(100, 'Max utilisation is 100%'),
    status: z.enum(['UP', 'DOWN', 'MAINTENANCE']),
  })
  .refine((data) => data.elementAId !== data.elementBId, {
    message: 'Source and destination elements cannot be the same',
    path: ['elementBId'],
  });

type TopologyFormFields = z.infer<typeof topologySchema>;

export const Topology: React.FC = () => {
  const { user } = useAuth();
  const [links, setLinks] = useState<TopologyLink[]>([]);
  const [elements, setElements] = useState<NetworkElement[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingLink, setEditingLink] = useState<TopologyLink | null>(null);
  const [loading, setLoading] = useState(true);

  const isPlanningEngineer = user?.role === 'PLANNING_ENGINEER';

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm<any>({
    resolver: zodResolver(topologySchema),
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [allLinks, allElements] = await axios.all<any>([
        topologyApi.getAll(),
        elementsApi.getAll().catch(() => [] as NetworkElement[]),
      ]) as [TopologyLink[], NetworkElement[]];
      setLinks(allLinks);
      setElements(allElements);
    } catch (err) {
      console.error('Failed to load topology link registry details:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  const openCreateModal = () => {
    setEditingLink(null);
    reset();
    setIsModalOpen(true);
  };

  const openEditModal = (link: TopologyLink) => {
    setEditingLink(link);
    setValue('elementAId', String(link.elementAId));
    setValue('elementBId', String(link.elementBId));
    setValue('linkType', link.linkType);
    setValue('capacityMbps', link.capacityMbps);
    setValue('utilisationPercent', link.utilisationPercent);
    setValue('status', link.status);
    setIsModalOpen(true);
  };

  const onSubmit = async (data: TopologyFormFields) => {
    try {
      const payload: Partial<TopologyLink> = {
        elementAId: Number(data.elementAId),
        elementBId: Number(data.elementBId),
        linkType: data.linkType as LinkType,
        capacityMbps: data.capacityMbps,
        utilisationPercent: data.utilisationPercent,
        status: data.status as LinkStatus,
      };

      if (editingLink) {
        await topologyApi.update(editingLink.linkId, payload);
      } else {
        await topologyApi.create(payload);
      }
      setIsModalOpen(false);
      loadData();
    } catch (err) {
      console.error('Failed to save topology link:', err);
    }
  };

  // elementId → current element status, used to reflect provisioning outcomes
  // (suspension / termination / maintenance) onto the links that use those elements.
  const elementStatusMap = useMemo(() => {
    const map = new Map<number, NetworkElement['status']>();
    elements.forEach((el) => map.set(el.elementId, el.status));
    return map;
  }, [elements]);

  // Effective link status: if either connected element is suspended (INACTIVE) or
  // terminated (DECOMMISSIONED) the link is treated as DOWN; if either element is in
  // MAINTENANCE the link shows MAINTENANCE. Otherwise the link's own stored status wins.
  const linkDisplayStatus = (link: TopologyLink): LinkStatus => {
    const a = elementStatusMap.get(link.elementAId);
    const b = elementStatusMap.get(link.elementBId);
    const isDown = (s?: NetworkElement['status']) => s === 'INACTIVE' || s === 'DECOMMISSIONED';
    const isMaintenance = (s?: NetworkElement['status']) => s === 'MAINTENANCE';
    if (isDown(a) || isDown(b)) return 'DOWN';
    if (isMaintenance(a) || isMaintenance(b)) return 'MAINTENANCE';
    return link.status;
  };

  // ── Derived summary data (uses the effective, element-aware link status) ──
  const kpis = useMemo(() => {
    const statuses = links.map((l) => linkDisplayStatus(l));
    return {
      up: statuses.filter((s) => s === 'UP').length,
      down: statuses.filter((s) => s === 'DOWN').length,
      maintenance: statuses.filter((s) => s === 'MAINTENANCE').length,
      total: links.length,
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [links, elementStatusMap]);

  // Render utilization progress bar helper
  const renderUtilisationBar = (percent: number) => {
    let styleClass = styles['progress-normal'];
    if (percent >= 85) styleClass = styles['progress-critical'];
    else if (percent >= 70) styleClass = styles['progress-warning'];

    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
        <div className={styles['progress-bar-container']}>
          <div
            className={`${styles['progress-bar-fill']} ${styleClass}`}
            style={{ width: `${percent}%` }}
          />
        </div>
        <span style={{ fontWeight: 600, fontSize: '0.75rem' }}>{percent}%</span>
      </div>
    );
  };

  const columns: Column<TopologyLink>[] = [
    { key: 'linkId', header: 'ID', sortable: true },
    { key: 'elementAName', header: 'Source Element (A)', sortable: true, render: (row) => row.elementAName || `Element ${row.elementAId}` },
    { key: 'elementBName', header: 'Destination Element (B)', sortable: true, render: (row) => row.elementBName || `Element ${row.elementBId}` },
    { key: 'linkType', header: 'Media Type', sortable: true },
    { key: 'capacityMbps', header: 'Capacity (Mbps)', sortable: true },
    { key: 'utilisationPercent', header: 'Link Utilisation', sortable: true, render: (row) => renderUtilisationBar(row.utilisationPercent) },
    { key: 'status', header: 'Status', sortable: true, render: (row) => <StatusBadge status={linkDisplayStatus(row)} /> },
  ];

  if (!isPlanningEngineer) {
    columns.push({
      key: 'actions',
      header: 'Actions',
      render: (row) => (
        <button className={styles.btn} onClick={() => openEditModal(row)} style={{ padding: '0.25rem 0.5rem', background: '#f1f5f9', border: '1px solid var(--border-color)', color: 'var(--text-main)' }}>
          <Edit size={12} /> Edit
        </button>
      ),
    });
  }

  return (
    <div className="page-container">
      <PageHeader
        title="Network Topology Links Manager"
        description="Inspect physical link interconnections, bandwidth capacities, and active utilization alarms."
        action={!isPlanningEngineer ? (
          <button className={`${styles.btn} ${styles['btn-primary']}`} onClick={openCreateModal}>
            <PlusCircle size={14} /> Create Topology Link
          </button>
        ) : undefined}
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading topology links...</div>
      ) : (
        <div className={styles['page-body']}>
          {/* KPI summary cards */}
          <StatGrid>
            <StatCard label="Links Up" value={kpis.up} icon={<CheckCircle size={20} />} variant="success" />
            <StatCard label="Links Down" value={kpis.down} icon={<XCircle size={20} />} variant="critical" />
            <StatCard label="Maintenance" value={kpis.maintenance} icon={<Wrench size={20} />} variant="neutral" />
            <StatCard label="Total Links" value={kpis.total} icon={<Link2 size={20} />} variant="primary" />
          </StatGrid>

          <div className="card">
            <DataTable
              columns={columns}
              data={links}
              searchPlaceholder="Search links by node name or type..."
              searchKey={(row) => `${row.elementAName} ${row.elementBName} ${row.linkType}`}
            />
          </div>
        </div>
      )}

      {/* Create / Edit Link Modal */}
      {!isPlanningEngineer && (
        <Modal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          title={editingLink ? `Edit Topology Link #${editingLink.linkId}` : 'Create Topology Link'}
        >
          <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Source Network Element (A)</label>
              <select className={styles.select} {...register('elementAId')}>
                <option value="">-- Choose Element A --</option>
                {elements.map((el) => (
                  <option key={el.elementId} value={el.elementId}>
                    {el.elementName} ({el.ipAddress})
                  </option>
                ))}
              </select>
              {errors.elementAId && <span className={styles['error-text']}>{errors.elementAId.message?.toString()}</span>}
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>Destination Network Element (B)</label>
              <select className={styles.select} {...register('elementBId')}>
                <option value="">-- Choose Element B --</option>
                {elements.map((el) => (
                  <option key={el.elementId} value={el.elementId}>
                    {el.elementName} ({el.ipAddress})
                  </option>
                ))}
              </select>
              {errors.elementBId && <span className={styles['error-text']}>{errors.elementBId.message?.toString()}</span>}
            </div>

            <div className={styles['form-row']}>
              <div className={styles['form-group']}>
                <label className={styles.label}>Link Transmission Media</label>
                <select className={styles.select} {...register('linkType')}>
                  <option value="FIBER">FIBER</option>
                  <option value="MICROWAVE">MICROWAVE</option>
                  <option value="SATELLITE">SATELLITE</option>
                </select>
              </div>

              <div className={styles['form-group']}>
                <label className={styles.label}>Status</label>
                <select className={styles.select} {...register('status')}>
                  <option value="UP">UP</option>
                  <option value="DOWN">DOWN</option>
                  <option value="MAINTENANCE">MAINTENANCE</option>
                </select>
              </div>
            </div>

            <div className={styles['form-row']}>
              <div className={styles['form-group']}>
                <label className={styles.label}>Capacity (Mbps)</label>
                <input type="number" className={styles.input} placeholder="e.g. 1000" {...register('capacityMbps')} />
                {errors.capacityMbps && <span className={styles['error-text']}>{errors.capacityMbps.message?.toString()}</span>}
              </div>

              <div className={styles['form-group']}>
                <label className={styles.label}>Current Utilisation (%)</label>
                <input type="number" step="0.1" className={styles.input} placeholder="e.g. 45.2" {...register('utilisationPercent')} />
                {errors.utilisationPercent && <span className={styles['error-text']}>{errors.utilisationPercent.message?.toString()}</span>}
              </div>
            </div>

            <button type="submit" className={`${styles.btn} ${styles['btn-primary']}`} style={{ width: '100%', marginTop: '0.5rem', padding: '0.625rem' }}>
              {editingLink ? 'Apply Changes' : 'Provision Link'}
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
};

export default Topology;
