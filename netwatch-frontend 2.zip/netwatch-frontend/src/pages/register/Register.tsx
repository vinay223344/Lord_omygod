import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { usersApi } from '../../api/users';
import { authApi } from '../../api/auth';
import { UserRole } from '../../types';
import styles from './Register.module.css';
import { GitBranch, UserPlus, Info } from 'lucide-react';

// Reusable phone rule — accepts ONLY digits (0-9) and must be exactly 10 of
// them. Alphabets, special characters (+ - _ ( ) spaces …) and wrong lengths
// are each reported with their own dedicated message.
const phoneField = z
  .string()
  .min(1, 'Phone number is required')
  .superRefine((value, ctx) => {
    if (/[a-zA-Z]/.test(value)) {
      ctx.addIssue({
        code: 'custom',
        message: 'Only numeric digits (0-9) are allowed.',
      });
      return;
    }
    if (/[^0-9]/.test(value)) {
      ctx.addIssue({
        code: 'custom',
        message: 'Special characters are not allowed. Enter digits only.',
      });
      return;
    }
    if (value.length !== 10) {
      ctx.addIssue({
        code: 'custom',
        message: 'Phone number must contain exactly 10 digits.',
      });
    }
  });

const registerSchema = z.object({
  name: z.string().trim().min(2, 'Name must be at least 2 characters').max(100, 'Name is too long'),
  email: z.string().min(1, 'Email is required').email('Invalid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  confirmPassword: z.string().min(1, 'Please confirm your password'),
  phone: phoneField,
  role: z.enum(['NOC_ENGINEER', 'FIELD_ENGINEER', 'PLANNING_ENGINEER', 'SERVICE_DESK', 'CHANGE_MANAGER']),
  region: z.string().optional(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
}).refine((data) => data.role !== 'FIELD_ENGINEER' || (!!data.region && data.region.length > 0), {
  message: "Region is required for Field Engineers",
  path: ["region"],
});

type RegisterFields = z.infer<typeof registerSchema>;

export const Register: React.FC = () => {
  const navigate = useNavigate();
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [regions, setRegions] = useState<string[]>([]);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<RegisterFields>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      role: 'NOC_ENGINEER',
    }
  });

  const selectedRole = watch('role');

  // Registered once so the sanitising onChange below can still forward the
  // event to react-hook-form's own handler.
  const phoneReg = register('phone');

  // Load the list of operational regions available in the project. This uses a
  // public endpoint (derived from the network sites) so it works on the
  // unauthenticated registration page.
  useEffect(() => {
    let active = true;
    authApi
      .getRegions()
      .then((data) => {
        if (!active) return;
        setRegions(data);
      })
      .catch(() => {
        // Silently ignore; the region dropdown will simply have no options to choose from.
      });
    return () => {
      active = false;
    };
  }, []);

  const onSubmit = async (data: RegisterFields) => {
    setErrorMsg(null);
    setSuccessMsg(null);
    setLoading(true);
    try {
      // Build registration payload
      const payload = {
        name: data.name,
        email: data.email,
        password: data.password,
        role: data.role as UserRole,
        phone: data.phone || '',
        status: 'ACTIVE' as const,
        // Region only applies to Field Engineers (region-based login).
        ...(data.role === 'FIELD_ENGINEER' && data.region ? { region: data.region } : {}),
      };

      await usersApi.create(payload);
      
      setSuccessMsg('Account registered successfully! Redirecting to sign in page...');
      setTimeout(() => {
        navigate('/login');
      }, 2000);
    } catch (err: any) {
      setErrorMsg(err.response?.data?.message || err.message || 'Registration failed. Please check your network connection.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles['register-page']}>
      <div className={styles['register-card']}>
        <div className={styles.header}>
          <div className={styles['logo-icon']}>
            <GitBranch size={36} />
          </div>
          <h1 className={styles.title}>NetWatch</h1>
          <p className={styles.subtitle}>Network Operations & NOC Management</p>
        </div>

        <div className={styles['card-title-row']}>
          <UserPlus size={18} className={styles['title-icon']} />
          <h2 className={styles['card-title']}>Create Operational Account</h2>
        </div>

        <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
          {errorMsg && <div className={styles['form-error']}>{errorMsg}</div>}
          {successMsg && <div className={styles['form-success']}>{successMsg}</div>}

          <div className={styles['form-group']}>
            <label className={styles.label}>Full Name</label>
            <input
              type="text"
              className={styles.input}
              placeholder="e.g. Alex Johnson"
              {...register('name')}
            />
            {errors.name && (
              <span className={styles['error-text']}>{errors.name.message}</span>
            )}
          </div>

          <div className={styles['form-group']}>
            <label className={styles.label}>Corporate Email</label>
            <input
              type="email"
              className={styles.input}
              placeholder="e.g. alex.j@netwatch.com"
              {...register('email')}
            />
            {errors.email && (
              <span className={styles['error-text']}>{errors.email.message}</span>
            )}
          </div>

          <div className={styles['form-row']}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Password</label>
              <input
                type="password"
                className={styles.input}
                placeholder="••••••••"
                {...register('password')}
              />
              {errors.password && (
                <span className={styles['error-text']}>{errors.password.message}</span>
              )}
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>Confirm Password</label>
              <input
                type="password"
                className={styles.input}
                placeholder="••••••••"
                {...register('confirmPassword')}
              />
              {errors.confirmPassword && (
                <span className={styles['error-text']}>{errors.confirmPassword.message}</span>
              )}
            </div>
          </div>

          <div className={styles['form-group']}>
            <label className={styles.label}>Operational Role</label>
            <select className={styles.select} {...register('role')}>
              <option value="NOC_ENGINEER">NOC Engineer</option>
              <option value="FIELD_ENGINEER">Field Engineer</option>
              <option value="PLANNING_ENGINEER">Planning Engineer</option>
              <option value="SERVICE_DESK">Service Desk</option>
              <option value="CHANGE_MANAGER">Change Manager</option>
            </select>
            {errors.role && (
              <span className={styles['error-text']}>{errors.role.message}</span>
            )}
          </div>

          {selectedRole === 'FIELD_ENGINEER' && (
            <div className={styles['form-group']}>
              <label className={styles.label}>Region</label>
              <select className={styles.select} defaultValue="" {...register('region')}>
                <option value="" disabled>Select a region</option>
                {regions.map((region) => (
                  <option key={region} value={region}>{region}</option>
                ))}
              </select>
              {errors.region && (
                <span className={styles['error-text']}>{errors.region.message}</span>
              )}
            </div>
          )}

          <div className={styles['form-group']}>
            <label className={styles.label}>Direct Phone</label>
            <input
              type="text"
              inputMode="numeric"
              maxLength={10}
              className={styles.input}
              placeholder="e.g. 9876543210"
              {...phoneReg}
              onChange={(e) => {
                // Strip everything that isn't a digit and cap at 10 digits so
                // invalid characters never make it into form state.
                e.target.value = e.target.value.replace(/\D/g, '').slice(0, 10);
                phoneReg.onChange(e);
              }}
            />
            {errors.phone && (
              <span className={styles['error-text']}>{errors.phone.message}</span>
            )}
          </div>

          <div className={styles['info-box']}>
            <Info size={14} className={styles['info-icon']} />
            <span>Newly registered accounts will default to an <strong>ACTIVE</strong> status and require matching backend seeding configuration.</span>
          </div>

          <button type="submit" className={styles['submit-btn']} disabled={loading}>
            {loading ? 'Registering Account...' : 'Register Account'}
          </button>
        </form>

        <div className={styles.footer}>
          <span>Already have an operational account? </span>
          <Link to="/login" className={styles['login-link']}>Sign In</Link>
        </div>
      </div>
    </div>
  );
};

export default Register;
