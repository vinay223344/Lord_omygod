import React, { useState, useEffect, useMemo } from 'react';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import { StatCard, StatGrid } from '../../components/StatCard';
import { useAuth } from '../../auth/AuthContext';
import { ticketsApi } from '../../api/tickets';
import { FieldDispatch, DispatchStatus } from '../../types';
import { formatDate } from '../../utils/date';
import { statusColor } from '../../theme/statusColors';
import styles from './FieldDispatchPage.module.css';
import { CheckCircle, Clock, MapPin, Truck, XCircle } from 'lucide-react';

export const FieldDispatchPage: React.FC = () => {
  const { user } = useAuth();
  const [dispatches, setDispatches] = useState<FieldDispatch[]>([]);
  const [selectedDispatch, setSelectedDispatch] = useState<FieldDispatch | null>(null);
  const [resolutionSummary, setResolutionSummary] = useState('');
  const [loading, setLoading] = useState(true);
  const [errorText, setErrorText] = useState<string | null>(null);

  const loadDispatches = async () => {
    if (!user) return;
    setLoading(true);
    try {
      let data: FieldDispatch[] = [];
      if (user.role === 'FIELD_ENGINEER') {
        data = await ticketsApi.getDispatchesForEngineer(user.userId);
      } else {
        // Admin or NOC sees all dispatches
        data = await ticketsApi.getAllDispatches();
      }
      setDispatches(data);
      
      // Keep selected dispatch details in sync if already selected
      if (selectedDispatch) {
        const refreshed = data.find((d) => d.dispatchId === selectedDispatch.dispatchId);
        if (refreshed) setSelectedDispatch(refreshed);
      }
    } catch (err) {
      console.error('Failed to load dispatch entries:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDispatches();
  }, [user]);

  const handleUpdateStatus = async (status: DispatchStatus) => {
    if (!selectedDispatch) return;
    setErrorText(null);

    if ((status === 'RESOLVED' || status === 'CANNOT_REPAIR') && !resolutionSummary.trim()) {
      setErrorText('Resolution summary description is required.');
      return;
    }

    try {
      await ticketsApi.updateDispatchStatus(selectedDispatch.dispatchId, status, resolutionSummary);
      setResolutionSummary('');
      loadDispatches();
    } catch (err: any) {
      console.error('Failed to update dispatch status:', err);
      setErrorText(err.response?.data?.message || 'Error occurred while updating status.');
    }
  };

  // ── Derived summary data (from dispatches already in state) ──
  const kpis = useMemo(
    () => ({
      dispatched: dispatches.filter((d) => d.status === 'DISPATCHED').length,
      onSite: dispatches.filter((d) => d.status === 'ON_SITE').length,
      resolved: dispatches.filter((d) => d.status === 'RESOLVED').length,
      cannotRepair: dispatches.filter((d) => d.status === 'CANNOT_REPAIR').length,
    }),
    [dispatches]
  );

  // Chronological feed (newest dispatch first) for the timeline panel.
  const timeline = useMemo(
    () =>
      [...dispatches].sort(
        (a, b) => new Date(b.dispatchTime).getTime() - new Date(a.dispatchTime).getTime()
      ),
    [dispatches]
  );

  const columns: Column<FieldDispatch>[] = [
    { key: 'dispatchId', header: 'Dispatch ID', sortable: true },
    { key: 'ticketId', header: 'Ticket ID', sortable: true },
    { key: 'fieldEngineerId', header: 'Engineer ID', sortable: true },
    { key: 'siteId', header: 'Site ID', sortable: true, render: (row) => row.siteId !== undefined && row.siteId !== null ? `#${row.siteId}` : 'N/A' },
    { key: 'category', header: 'Issue Category', sortable: true, render: (row) => row.category || 'N/A' },
    { key: 'priority', header: 'Priority', sortable: true, render: (row) => (row.priority ? <StatusBadge status={row.priority} /> : 'N/A') },
    { key: 'siteAddress', header: 'Site Address', sortable: true, render: (row) => row.siteAddress || 'N/A' },
    { key: 'elementDetails', header: 'Element Details', sortable: true, render: (row) => row.elementDetails || 'N/A' },
    { key: 'resolutionSummary', header: 'Resolution Summary', sortable: true, render: (row) => row.resolutionSummary || 'N/A' },
    { key: 'dispatchTime', header: 'Time Dispatched', sortable: true, render: (row) => formatDate(row.dispatchTime) },
    { key: 'status', header: 'Status', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
  ];

  return (
    <div className="page-container">
      <PageHeader
        title="Field Dispatch & Operations Queue"
        description="Technicians review assigned dispatches, update site arrival details, and input incident resolution summaries."
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading dispatches queue...</div>
      ) : (
        <div className={styles['page-body']}>
          {/* KPI summary cards */}
          <StatGrid>
            <StatCard label="Dispatched" value={kpis.dispatched} icon={<Truck size={20} />} variant="info" />
            <StatCard label="On-Site" value={kpis.onSite} icon={<MapPin size={20} />} variant="warning" />
            <StatCard label="Resolved" value={kpis.resolved} icon={<CheckCircle size={20} />} variant="success" />
            <StatCard label="Cannot Repair" value={kpis.cannotRepair} icon={<XCircle size={20} />} variant="critical" />
          </StatGrid>

          {/* Dispatch activity timeline */}
          <div className="card">
            <div className={styles['panel-header']}>
              <h3 className={styles['panel-title']}>
                <Clock size={15} /> Dispatch Timeline
              </h3>
            </div>
            {timeline.length > 0 ? (
              <div className={styles.timeline}>
                {timeline.map((d) => (
                  <div
                    key={d.dispatchId}
                    className={styles['timeline-item']}
                    onClick={() => {
                      setSelectedDispatch(d);
                      setErrorText(null);
                    }}
                  >
                    <div className={styles['timeline-rail']}>
                      <span className={styles['timeline-dot']} style={{ backgroundColor: statusColor(d.status) }} />
                      <span className={styles['timeline-line']} />
                    </div>
                    <div className={styles['timeline-content']}>
                      <div className={styles['timeline-head']}>
                        <span className={styles['timeline-id']}>Dispatch #{d.dispatchId}</span>
                        <StatusBadge status={d.status} />
                      </div>
                      <span className={styles['timeline-meta']}>
                        Ticket #{d.ticketId}
                        {d.siteAddress
                          ? ` · ${d.siteAddress}`
                          : d.siteId !== undefined && d.siteId !== null
                          ? ` · Site #${d.siteId}`
                          : ''}
                      </span>
                      <span className={styles['timeline-time']}>
                        Dispatched {formatDate(d.dispatchTime)}
                        {d.restorationTime
                          ? ` · Restored ${formatDate(d.restorationTime)}`
                          : d.siteArrivalTime
                          ? ` · On-site ${formatDate(d.siteArrivalTime)}`
                          : ''}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className={styles['timeline-empty']}>No dispatch activity to display.</div>
            )}
          </div>

          <div className={styles.layout}>
          {/* Left Panel: Table */}
          <div className={styles['table-panel']}>
            <div className="card">
              <DataTable
                columns={columns}
                data={dispatches}
                searchPlaceholder="Search dispatches by ticket ID or engineer ID..."
                searchKey={(row) => `${row.ticketId} ${row.fieldEngineerId}`}
                onRowClick={(row) => {
                  setSelectedDispatch(row);
                  setErrorText(null);
                }}
              />
            </div>
          </div>

          {/* Right Panel: Selected Dispatch Updates */}
          {selectedDispatch && (
            <div className={styles['update-panel']}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 className={styles['section-title']} style={{ margin: 0, border: 'none' }}>
                  Dispatch Details
                </h3>
                <button
                  style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontWeight: 'bold', fontSize: '0.8rem' }}
                  onClick={() => setSelectedDispatch(null)}
                >
                  ✕ Close panel
                </button>
              </div>

              <div className={styles['info-list']}>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Dispatch Ref:</span>
                  <span className={styles['info-value']}>#{selectedDispatch.dispatchId}</span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Ticket ID:</span>
                  <span className={styles['info-value']}>#{selectedDispatch.ticketId}</span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Issue Category:</span>
                  <span className={styles['info-value']}>{selectedDispatch.category || 'N/A'}</span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Priority:</span>
                  <span>
                    {selectedDispatch.priority ? <StatusBadge status={selectedDispatch.priority} /> : 'N/A'}
                  </span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Time Dispatched:</span>
                  <span className={styles['info-value']}>{formatDate(selectedDispatch.dispatchTime)}</span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Arrival Time:</span>
                  <span className={styles['info-value']}>
                    {selectedDispatch.siteArrivalTime ? formatDate(selectedDispatch.siteArrivalTime) : 'Pending Arrival'}
                  </span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Restoration Time:</span>
                  <span className={styles['info-value']}>
                    {selectedDispatch.restorationTime ? formatDate(selectedDispatch.restorationTime) : 'Ongoing Repair'}
                  </span>
                </div>
                {selectedDispatch.siteId !== undefined && selectedDispatch.siteId !== null && (
                  <div className={styles['info-item']}>
                    <span className={styles['info-label']}>Site ID:</span>
                    <span className={styles['info-value']}>#{selectedDispatch.siteId}</span>
                  </div>
                )}
                {selectedDispatch.siteAddress && (
                  <div className={styles['info-item']}>
                    <span className={styles['info-label']}>Site Address:</span>
                    <span className={styles['info-value']}>{selectedDispatch.siteAddress}</span>
                  </div>
                )}
                {selectedDispatch.elementDetails && (
                  <div className={styles['info-item']}>
                    <span className={styles['info-label']}>Element Details:</span>
                    <span className={styles['info-value']}>{selectedDispatch.elementDetails}</span>
                  </div>
                )}
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Current Status:</span>
                  <span>
                    <StatusBadge status={selectedDispatch.status} />
                  </span>
                </div>
              </div>

              {/* Status Update Forms (for assigned field engineer or admin only) */}
              {(user?.role === 'FIELD_ENGINEER' || user?.role === 'ADMIN') && (
                <div style={{ marginTop: '0.5rem' }}>
                  <h3 className={styles['section-title']}>Update Status</h3>
                  
                  {errorText && <div className={styles['error-text']} style={{ marginBottom: '0.5rem' }}>{errorText}</div>}

                  {selectedDispatch.status === 'DISPATCHED' && (
                    <button
                      className={`${styles.btn} ${styles['btn-primary']}`}
                      onClick={() => handleUpdateStatus('ON_SITE')}
                      style={{ width: '100%' }}
                    >
                      <MapPin size={14} /> Confirm On-Site Arrival
                    </button>
                  )}

                  {selectedDispatch.status === 'ON_SITE' && (
                    <div className={styles.form}>
                      <div className={styles['form-group']}>
                        <label className={styles.label}>Resolution Summary</label>
                        <textarea
                          className={styles.textarea}
                          placeholder="Provide details about the resolution or reason for unable to repair"
                          value={resolutionSummary}
                          onChange={(e) => setResolutionSummary(e.target.value)}
                        />
                      </div>
                      <div style={{ display: 'flex', gap: '0.5rem' }}>
                        <button
                          className={`${styles.btn}`}
                          onClick={() => handleUpdateStatus('CANNOT_REPAIR')}
                          style={{ flex: 1, backgroundColor: '#dc2626', color: 'white' }}
                        >
                          ✕ Cannot Repair
                        </button>
                        <button
                          className={`${styles.btn} ${styles['btn-success']}`}
                          onClick={() => handleUpdateStatus('RESOLVED')}
                          style={{ flex: 1 }}
                        >
                          <CheckCircle size={14} /> Mark as Resolved
                        </button>
                      </div>
                    </div>
                  )}

                  {(selectedDispatch.status === 'RESOLVED' || selectedDispatch.status === 'CANNOT_REPAIR') && (
                    <div style={{ padding: '0.5rem', background: '#f1f5f9', borderRadius: '4px', border: '1px solid var(--border-color)' }}>
                      <span className={styles['info-label']} style={{ fontSize: '0.7rem', display: 'block', textTransform: 'uppercase' }}>
                        Resolution Summary Archive
                      </span>
                      <p style={{ fontSize: '0.8rem', color: 'var(--text-main)', marginTop: '0.25rem', fontStyle: 'italic' }}>
                        "{selectedDispatch.resolutionSummary || 'No summary was provided.'}"
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          </div>
        </div>
      )}
    </div>
  );
};

export default FieldDispatchPage;
