import React, { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import axios from 'axios';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import { StatCard, StatGrid } from '../../components/StatCard';
import { useAuth } from '../../auth/AuthContext';
import { circuitsApi } from '../../api/circuits';
import { elementsApi } from '../../api/elements';
import { ProvisioningRequest, Circuit, NetworkElement, ProvisioningRequestType } from '../../types';
import { formatDate } from '../../utils/date';
import styles from './Provisioning.module.css';
import { CheckCircle, ClipboardList, Clock, Play, PlusCircle, RefreshCw } from 'lucide-react';

const provisioningSchema = z
  .object({
    circuitId: z.string().min(1, 'Circuit is required'),
    elementId: z.string().min(1, 'Routing network element is required'),
    requestType: z.enum(['BANDWIDTH_UPGRADE', 'SUSPENSION', 'TERMINATION']),
    bandwidthMbps: z.any(),
  })
  .refine(
    (data) => {
      if (data.requestType === 'BANDWIDTH_UPGRADE') {
        const val = Number(data.bandwidthMbps);
        return !isNaN(val) && val > 0;
      }
      return true;
    },
    {
      message: 'Bandwidth must be a positive number',
      path: ['bandwidthMbps'],
    }
  );

export const Provisioning: React.FC = () => {
  const { user } = useAuth();
  const [requests, setRequests] = useState<ProvisioningRequest[]>([]);
  const [circuits, setCircuits] = useState<Circuit[]>([]);
  const [elements, setElements] = useState<NetworkElement[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const {
    register,
    handleSubmit,
    watch,
    reset,
    setValue,
    formState: { errors },
  } = useForm<any>({
    resolver: zodResolver(provisioningSchema),
  });

  const selectedRequestType = watch('requestType');
  const selectedCircuitId = watch('circuitId');

  // Only elements that belong to the selected circuit's route may be targeted.
  const circuitElements = useMemo(() => {
    if (!selectedCircuitId) return [];
    const circuit = circuits.find((c) => String(c.circuitId) === String(selectedCircuitId));
    const routeIds = circuit?.routeElementIds || [];
    return elements.filter((el) => routeIds.includes(el.elementId));
  }, [selectedCircuitId, circuits, elements]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [allRequests, allCircuits, allElements] = await axios.all<any>([
        circuitsApi.getAllRequests(),
        circuitsApi.getAllCircuits().catch(() => [] as Circuit[]),
        elementsApi.getAll().catch(() => [] as NetworkElement[]),
      ]) as [ProvisioningRequest[], Circuit[], NetworkElement[]];
      setRequests(allRequests);
      setCircuits(allCircuits);
      setElements(allElements);
    } catch (err) {
      console.error('Failed to load provisioning request queue details:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  // Clear a previously chosen element whenever the circuit selection changes.
  useEffect(() => {
    setValue('elementId', '');
  }, [selectedCircuitId, setValue]);

  const handleCreateRequest = async (data: any) => {
    if (!user) return;
    try {
      const payload: Partial<ProvisioningRequest> = {
        circuitId: Number(data.circuitId),
        elementId: Number(data.elementId),
        requestType: data.requestType as ProvisioningRequestType,
        bandwidthMbps: data.bandwidthMbps ? Number(data.bandwidthMbps) : undefined,
      };

      await circuitsApi.createProvisioningRequest(payload, user.userId);
      setIsModalOpen(false);
      reset();
      loadData();
    } catch (err) {
      console.error('Failed to submit provisioning request:', err);
    }
  };

  const handleProcess = async (id: number) => {
    if (!user) return;
    try {
      await circuitsApi.processRequest(id, user.userId);
      loadData();
    } catch (err) {
      console.error('Failed to run capacity check step:', err);
    }
  };

  const handleExecute = async (id: number) => {
    if (!user) return;
    try {
      await circuitsApi.executeAfterMaintenance(id, user.userId);
      loadData();
    } catch (err) {
      console.error('Failed to execute provisioning change after maintenance:', err);
    }
  };

  // ── Derived summary data (from requests already in state) ──
  const kpis = useMemo(
    () => ({
      pending: requests.filter((r) => r.status === 'PENDING').length,
      inProgress: requests.filter((r) => r.status === 'IN_PROGRESS').length,
      completed: requests.filter((r) => r.status === 'COMPLETED').length,
      total: requests.length,
    }),
    [requests]
  );

  const columns: Column<ProvisioningRequest>[] = [
    { key: 'provisionId', header: 'Request ID', sortable: true },
    { key: 'circuitReference', header: 'Circuit Reference', sortable: true, render: (row) => row.circuitReference || `ID ${row.circuitId}` },
    { key: 'elementName', header: 'Affected Element', sortable: true, render: (row) => row.elementName || `ID ${row.elementId}` },
    { key: 'requestType', header: 'Provision Type', sortable: true },
    { key: 'bandwidthMbps', header: 'Bandwidth (Mbps)', sortable: true },
    { key: 'requestDate', header: 'Date Raised', sortable: true, render: (row) => formatDate(row.requestDate) },
    { key: 'status', header: 'Request Status', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
    {
      key: 'actions',
      header: 'Operations Flow',
      render: (row) => {
        const canProcess = row.status === 'PENDING';
        const canExecute = row.status === 'IN_PROGRESS';
        
        return (
          <div style={{ display: 'flex' }}>
            {canProcess && (user?.role === 'PLANNING_ENGINEER' || user?.role === 'ADMIN') && (
              <button
                className={`${styles.btn} ${styles['btn-primary']}`}
                onClick={() => handleProcess(row.provisionId)}
                style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', padding: '0.25rem 0.5rem', fontSize: '0.75rem' }}
              >
                <Play size={12} /> Process Check
              </button>
            )}
            {canExecute && (user?.role === 'CHANGE_MANAGER' || user?.role === 'ADMIN' || user?.role === 'PLANNING_ENGINEER') && (
              <button
                className={`${styles.btn} ${styles['btn-primary']}`}
                onClick={() => handleExecute(row.provisionId)}
                style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', padding: '0.25rem 0.5rem', fontSize: '0.75rem', backgroundColor: '#166534' }}
              >
                <CheckCircle size={12} /> Execute Change
              </button>
            )}
            {!canProcess && !canExecute && (
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontStyle: 'italic', paddingLeft: '0.5rem' }}>No Actions Pending</span>
            )}
          </div>
        );
      },
    },
  ];

  return (
    <div className="page-container">
      <PageHeader
        title="Circuit Provisioning & Capacity Operations Queue"
        description="Raise service activations or bandwidth upgrades, and review deferred post-maintenance execution triggers."
        action={
          (user?.role === 'PLANNING_ENGINEER' || user?.role === 'ADMIN') && (
            <button className={`${styles.btn} ${styles['btn-primary']}`} onClick={() => setIsModalOpen(true)}>
              <PlusCircle size={14} /> Raise Provisioning Request
            </button>
          )
        }
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading requests queue...</div>
      ) : (
        <div className={styles['page-body']}>
          {/* KPI summary cards */}
          <StatGrid>
            <StatCard label="Pending" value={kpis.pending} icon={<Clock size={20} />} variant="warning" />
            <StatCard label="In Progress" value={kpis.inProgress} icon={<RefreshCw size={20} />} variant="info" />
            <StatCard label="Completed" value={kpis.completed} icon={<CheckCircle size={20} />} variant="success" />
            <StatCard label="Total Requests" value={kpis.total} icon={<ClipboardList size={20} />} variant="primary" />
          </StatGrid>


          <div className="card">
            <DataTable
              columns={columns}
              data={requests}
              searchPlaceholder="Search requests by circuit or status..."
              searchKey={(row) => `${row.circuitReference} ${row.status}`}
            />
          </div>
        </div>
      )}

      {/* Raise Provisioning Modal */}
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Raise Circuit Provisioning Request">
        <form className={styles.form} onSubmit={handleSubmit(handleCreateRequest)}>
          <div className={styles['form-group']}>
            <label className={styles.label}>Select Circuit</label>
            <select className={styles.select} {...register('circuitId')}>
              <option value="">-- Choose Circuit Reference --</option>
              {circuits.map((c) => (
                <option key={c.circuitId} value={c.circuitId}>
                  {c.circuitReference} (Current BW: {c.bandwidthMbps} Mbps)
                </option>
              ))}
            </select>
            {errors.circuitId && <span className={styles['error-text']}>{errors.circuitId.message?.toString()}</span>}
          </div>

          <div className={styles['form-group']}>
            <label className={styles.label}>Affecting Core Router Element</label>
            <select className={styles.select} {...register('elementId')} disabled={!selectedCircuitId}>
              <option value="">
                {selectedCircuitId ? '-- Choose Target Element --' : '-- Select a circuit first --'}
              </option>
              {circuitElements.map((el) => (
                <option key={el.elementId} value={el.elementId}>
                  {el.elementName} ({el.ipAddress})
                </option>
              ))}
            </select>
            {selectedCircuitId && circuitElements.length === 0 && (
              <span className={styles['error-text']}>No elements are associated with this circuit's route.</span>
            )}
            {errors.elementId && <span className={styles['error-text']}>{errors.elementId.message?.toString()}</span>}
          </div>

          <div className={styles['form-row']}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Provisioning Request Type</label>
              <select className={styles.select} {...register('requestType')}>
                <option value="BANDWIDTH_UPGRADE">BANDWIDTH_UPGRADE</option>
                <option value="SUSPENSION">SUSPENSION</option>
                <option value="TERMINATION">TERMINATION</option>
              </select>
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>
                Requested Bandwidth (Mbps) {selectedRequestType === 'BANDWIDTH_UPGRADE' && <span style={{ color: 'red' }}>*</span>}
              </label>
              <input
                type="number"
                className={styles.input}
                placeholder={selectedRequestType === 'BANDWIDTH_UPGRADE' ? "e.g. 5000 (Required)" : "Optional"}
                {...register('bandwidthMbps')}
              />
              {errors.bandwidthMbps && <span className={styles['error-text']}>{errors.bandwidthMbps.message?.toString()}</span>}
            </div>
          </div>

          <button type="submit" className={`${styles.btn} ${styles['btn-primary']}`} style={{ width: '100%', marginTop: '0.5rem', padding: '0.625rem' }}>
            Submit Provisioning Request
          </button>
        </form>
      </Modal>
    </div>
  );
};

export default Provisioning;
