import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import PageHeader from '../../../components/PageHeader';
import DataTable, { Column } from '../../../components/DataTable';
import StatusBadge from '../../../components/StatusBadge';
import Modal from '../../../components/Modal';
import { usersApi } from '../../../api/users';
import { User, UserRole, UserStatus } from '../../../types';
import styles from './UserManagement.module.css';
import { Edit, ShieldAlert, ShieldCheck } from 'lucide-react';

const userSchema = z.object({
  name: z.string().trim().min(2, 'User name must be at least 2 characters'),
  email: z.string().min(1, 'Email address is required').email('Must be a valid email'),
  // Optional in the schema so editing without changing the password is allowed;
  // creation-time "required" is enforced in onSubmit. When present it must be valid.
  password: z
    .string()
    .optional()
    .refine((v) => !v || v.length >= 6, 'Password must be at least 6 characters'),
  phone: z
    .string()
    .min(1, 'Phone number is required')
    .regex(/^\+?[0-9\s()-]+$/, 'Phone number can only contain digits and + - ( ) characters')
    .refine((v) => {
      const digits = v.replace(/\D/g, '');
      return digits.length >= 10 && digits.length <= 15;
    }, 'Enter a valid phone number (10 to 15 digits)'),
  role: z.enum(['ADMIN', 'NOC_ENGINEER', 'FIELD_ENGINEER', 'PLANNING_ENGINEER', 'SERVICE_DESK', 'CHANGE_MANAGER']),
  status: z.enum(['ACTIVE', 'DEACTIVATED']),
});

type UserFormFields = z.infer<typeof userSchema>;

export const UserManagement: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const {
    register,
    handleSubmit,
    setValue,
    setError,
    formState: { errors },
  } = useForm<UserFormFields>({
    resolver: zodResolver(userSchema),
  });

  const loadUsers = async () => {
    setLoading(true);
    try {
      const data = await usersApi.getAll();
      setUsers(data);
    } catch (err) {
      console.error('Failed to load system user directories:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const openEditModal = (u: User) => {
    setEditingUser(u);
    setValue('name', u.name);
    setValue('email', u.email);
    setValue('phone', u.phone || '');
    setValue('role', u.role);
    setValue('status', u.status);
    setValue('password', ''); // clear password input field
    setIsModalOpen(true);
  };

  const toggleStatus = async (u: User) => {
    try {
      if (u.status === 'ACTIVE') {
        await usersApi.deactivate(u.userId);
      } else {
        await usersApi.activate(u.userId);
      }
      loadUsers();
    } catch (err) {
      console.error('Failed to update user security status:', err);
    }
  };

  const onSubmit = async (data: UserFormFields) => {
    try {
      const payload: Partial<User> = {
        name: data.name,
        email: data.email,
        phone: data.phone,
        role: data.role as UserRole,
        status: data.status as UserStatus,
      };

      if (data.password) {
        payload.password = data.password;
      }

      if (editingUser) {
        await usersApi.update(editingUser.userId, payload);
      } else {
        // Enforce password on new creations — shown as an inline field error.
        if (!data.password) {
          setError('password', { type: 'manual', message: 'Password is required for new accounts' });
          return;
        }
        await usersApi.create(payload);
      }
      setIsModalOpen(false);
      loadUsers();
    } catch (err) {
      console.error('Failed to save user security details:', err);
    }
  };

  const columns: Column<User>[] = [
    { key: 'userId', header: 'ID', sortable: true },
    { key: 'name', header: 'Staff Name', sortable: true },
    { key: 'email', header: 'Corporate Email', sortable: true },
    { key: 'role', header: 'Role Authorization', sortable: true, render: (row) => <span style={{ fontWeight: 'bold' }}>{row.role}</span> },
    { key: 'phone', header: 'Direct Phone', sortable: true, render: (row) => row.phone || 'N/A' },
    { key: 'status', header: 'Account Status', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
    {
      key: 'actions',
      header: 'Operations Controls',
      render: (row) => {
        const isActive = row.status === 'ACTIVE';
        return (
          <div style={{ display: 'flex', gap: '0.25rem' }}>
            <button className={styles.btn} onClick={() => openEditModal(row)} style={{ padding: '0.25rem 0.5rem', background: '#f1f5f9', border: '1px solid var(--border-color)', color: 'var(--text-main)' }}>
              <Edit size={12} /> Edit
            </button>
            <button
              className={`${styles.btn} ${isActive ? styles['btn-danger'] : styles['btn-success']}`}
              onClick={() => toggleStatus(row)}
              style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', padding: '0.25rem 0.5rem', fontSize: '0.75rem' }}
            >
              {isActive ? <ShieldAlert size={12} /> : <ShieldCheck size={12} />}
              {isActive ? 'Deactivate' : 'Activate'}
            </button>
          </div>
        );
      },
    },
  ];

  return (
    <div className="page-container">
      <PageHeader
        title="Admin User Management Portal"
        description="Verify system access credentials, modify staff functional roles, and toggle account activity status."
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading users database...</div>
      ) : (
        <div className="card">
          <DataTable
            columns={columns}
            data={users}
            searchPlaceholder="Search accounts by name or email..."
            searchKey={(row) => `${row.name} ${row.email}`}
          />
        </div>
      )}

      {/* Create / Edit User Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingUser ? `Edit Account Credentials #${editingUser.userId}` : 'Register New Account'}
      >
        <form className={styles.form} onSubmit={handleSubmit(onSubmit)}>
          <div className={styles['form-group']}>
            <label className={styles.label}>Corporate Name</label>
            <input type="text" className={styles.input} placeholder="e.g. John Doe" {...register('name')} />
            {errors.name && <span className={styles['error-text']}>{errors.name.message}</span>}
          </div>

          <div className={styles['form-row']}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Corporate Email</label>
              <input type="email" className={styles.input} placeholder="e.g. jdoe@netwatch.com" {...register('email')} />
              {errors.email && <span className={styles['error-text']}>{errors.email.message}</span>}
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>{editingUser ? 'New Password (Optional)' : 'Password'}</label>
              <input type="password" className={styles.input} placeholder="••••••••" {...register('password')} />
              {errors.password && <span className={styles['error-text']}>{errors.password.message}</span>}
            </div>
          </div>

          <div className={styles['form-group']}>
            <label className={styles.label}>Direct Telephone</label>
            <input type="text" className={styles.input} placeholder="e.g. +91 98765 43210" {...register('phone')} />
            {errors.phone && <span className={styles['error-text']}>{errors.phone.message}</span>}
          </div>

          <div className={styles['form-row']}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Operational Role</label>
              <select className={styles.select} {...register('role')}>
                <option value="ADMIN">ADMIN</option>
                <option value="NOC_ENGINEER">NOC_ENGINEER</option>
                <option value="FIELD_ENGINEER">FIELD_ENGINEER</option>
                <option value="PLANNING_ENGINEER">PLANNING_ENGINEER</option>
                <option value="SERVICE_DESK">SERVICE_DESK</option>
                <option value="CHANGE_MANAGER">CHANGE_MANAGER</option>
              </select>
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>Account Status</label>
              <select className={styles.select} {...register('status')}>
                <option value="ACTIVE">ACTIVE</option>
                <option value="DEACTIVATED">DEACTIVATED</option>
              </select>
            </div>
          </div>

          <button type="submit" className={`${styles.btn} ${styles['btn-primary']}`} style={{ width: '100%', marginTop: '0.5rem', padding: '0.625rem' }}>
            {editingUser ? 'Save Credentials' : 'Register Account'}
          </button>
        </form>
      </Modal>
    </div>
  );
};

export default UserManagement;
