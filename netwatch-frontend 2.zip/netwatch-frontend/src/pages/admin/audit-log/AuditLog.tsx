import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import PageHeader from '../../../components/PageHeader';
import DataTable, { Column } from '../../../components/DataTable';
import { auditApi } from '../../../api/audit';
import { usersApi } from '../../../api/users';
import { AuditLog as AuditLogType, User } from '../../../types';
import { formatDate } from '../../../utils/date';
import styles from './AuditLog.module.css';

export const AuditLog: React.FC = () => {
  const [logs, setLogs] = useState<AuditLogType[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters State
  const [selectedUser, setSelectedUser] = useState<string>('ALL');
  const [entityType, setEntityType] = useState<string>('ALL');

  const loadData = async () => {
    setLoading(true);
    try {
      const [allLogs, allUsers] = await axios.all<any>([
        auditApi.getAll(),
        usersApi.getAll().catch(() => [] as User[]),
      ]) as [AuditLogType[], User[]];
      setLogs(allLogs);
      setUsers(allUsers);
    } catch (err) {
      console.error('Failed to load system audit trails:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Distinct entity types present in the logs, for the Entity Type dropdown.
  const entityTypes = useMemo(
    () => Array.from(new Set(logs.map((log) => log.entityType).filter(Boolean))).sort(),
    [logs]
  );

  // Filter logs locally based on selected options (operator and/or entity type).
  const filteredLogs = useMemo(() => {
    return logs.filter((log) => {
      // Filter by operator (user)
      if (selectedUser !== 'ALL' && log.userId !== Number(selectedUser)) {
        return false;
      }

      // Filter by entity type (exact match)
      if (entityType !== 'ALL' && log.entityType !== entityType) {
        return false;
      }

      return true;
    });
  }, [logs, selectedUser, entityType]);

  const columns: Column<AuditLogType>[] = [
    { key: 'auditId', header: 'Audit ID', sortable: true },
    {
      key: 'userId',
      header: 'Operator Staff',
      sortable: true,
      render: (row) => {
        const found = users.find((u) => u.userId === row.userId);
        return found ? `${found.name} (ID ${row.userId})` : `User #${row.userId}`;
      },
    },
    { key: 'action', header: 'Action Executed', sortable: true },
    { key: 'entityType', header: 'Affected Model', sortable: true },
    { key: 'recordId', header: 'Record Primary ID', sortable: true },
    { key: 'timestamp', header: 'Action Timestamp', sortable: true, render: (row) => formatDate(row.timestamp) },
  ];

  return (
    <div className="page-container">
      <PageHeader
        title="Operations Audit Log Viewer"
        description="Review chronological operators actions, registry additions, ticket escalations, and credential modifications."
      />

      {/* Audit Log Filters Bar */}
      <div className={styles['filter-bar']}>
        <div className={styles['filter-group']}>
          <span className={styles['filter-label']}>Operator</span>
          <select className={styles.select} value={selectedUser} onChange={(e) => setSelectedUser(e.target.value)}>
            <option value="ALL">All Staff</option>
            {users.map((u) => (
              <option key={u.userId} value={u.userId}>
                {u.name}
              </option>
            ))}
          </select>
        </div>

        <div className={styles['filter-group']}>
          <span className={styles['filter-label']}>Entity Type</span>
          <select className={styles.select} value={entityType} onChange={(e) => setEntityType(e.target.value)}>
            <option value="ALL">All Entities</option>
            {entityTypes.map((et) => (
              <option key={et} value={et}>
                {et}
              </option>
            ))}
          </select>
        </div>
      </div>

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading audit trail database...</div>
      ) : (
        <div className="card">
          <DataTable
            columns={columns}
            data={filteredLogs}
            searchPlaceholder="Filter audit trails by action summary..."
            searchKey="action"
          />
        </div>
      )}
    </div>
  );
};

export default AuditLog;
