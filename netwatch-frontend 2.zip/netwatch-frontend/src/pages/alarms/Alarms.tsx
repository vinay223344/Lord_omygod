import React, { useState, useEffect, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import axios from 'axios';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import { StatCard, StatGrid } from '../../components/StatCard';
import { useAuth } from '../../auth/AuthContext';
import { alarmsApi } from '../../api/alarms';
import { elementsApi } from '../../api/elements';
import { NetworkAlarm, NetworkElement, AlarmSeverity, AlarmType } from '../../types';
import { formatDate } from '../../utils/date';
import styles from './Alarms.module.css';
import { Activity, AlertTriangle, Bell, CheckCircle, PlusCircle } from 'lucide-react';

const alarmSchema = z.object({
  elementId: z.string().min(1, 'Network element is required'),
  alarmType: z.enum(['LINK_DOWN', 'NODE_UNREACHABLE', 'HIGH_UTILISATION', 'POWER_FAILURE', 'HARDWARE_FAULT', 'COOLING_ALERT']),
  severity: z.enum(['CRITICAL', 'MAJOR', 'MINOR', 'WARNING']),
});

type AlarmFormFields = z.infer<typeof alarmSchema>;

export const Alarms: React.FC = () => {
  const { user } = useAuth();
  const [alarms, setAlarms] = useState<NetworkAlarm[]>([]);
  const [elements, setElements] = useState<NetworkElement[]>([]);
  const [loading, setLoading] = useState(true);

  const isServiceDeskOrAdmin = user?.role === 'SERVICE_DESK' || user?.role === 'ADMIN';

  // Modals state
  const [isAlarmModalOpen, setIsAlarmModalOpen] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<AlarmFormFields>({
    resolver: zodResolver(alarmSchema),
  });

  const loadData = async () => {
    setLoading(true);
    try {
      if (isServiceDeskOrAdmin) {
        const [allAlarms, allElements] = await axios.all<any>([
          alarmsApi.getAllAlarms(),
          elementsApi.getAll().catch(() => [] as NetworkElement[]), // fallback if empty
        ]) as [NetworkAlarm[], NetworkElement[]];
        setAlarms(allAlarms);
        setElements(allElements);
      } else {
        const allAlarms = await alarmsApi.getAllAlarms();
        setAlarms(allAlarms);
      }
    } catch (err) {
      console.error('Failed to retrieve alarm feed details:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [user]);

  const handleRaiseAlarm = async (data: AlarmFormFields) => {
    if (!user) return;
    try {
      const payload: Partial<NetworkAlarm> = {
        elementId: Number(data.elementId),
        alarmType: data.alarmType as AlarmType,
        severity: data.severity as AlarmSeverity,
        alarmTime: new Date().toISOString(),
        status: 'ACTIVE',
      };
      await alarmsApi.createAlarm(payload, user.userId);
      setIsAlarmModalOpen(false);
      reset();
      loadData();
    } catch (err) {
      console.error('Failed to raise manual network alarm:', err);
    }
  };

  const handleAcknowledge = async (alarmId: number) => {
    if (!user) return;
    try {
      await alarmsApi.acknowledgeAlarm(alarmId, user.userId);
      loadData();
    } catch (err) {
      console.error('Error acknowledging alarm:', err);
    }
  };

  const handleClear = async (alarmId: number) => {
    if (!user) return;
    try {
      await alarmsApi.clearAlarm(alarmId, user.userId);
      loadData();
    } catch (err) {
      console.error('Error clearing alarm:', err);
    }
  };

  // ── Derived summary data (from alarms already in state) ──
  const kpis = useMemo(
    () => ({
      active: alarms.filter((a) => a.status === 'ACTIVE').length,
      acknowledged: alarms.filter((a) => a.status === 'ACKNOWLEDGED').length,
      cleared: alarms.filter((a) => a.status === 'CLEARED').length,
      total: alarms.length,
    }),
    [alarms]
  );

  // Severity-coded row indicator for the table.
  const severityRowClass = (row: NetworkAlarm) => {
    switch (row.severity) {
      case 'CRITICAL':
        return styles['row-critical'];
      case 'MAJOR':
        return styles['row-major'];
      case 'MINOR':
        return styles['row-minor'];
      case 'WARNING':
        return styles['row-warning'];
      default:
        return '';
    }
  };

  // Define Columns for Alarms Table
  const alarmColumns: Column<NetworkAlarm>[] = [
    { key: 'alarmId', header: 'Alarm ID', sortable: true },
    { key: 'alarmType', header: 'Alarm Type', sortable: true },
    { key: 'elementName', header: 'Network Element', sortable: true, render: (row) => row.elementName || `ID ${row.elementId}` },
    { key: 'severity', header: 'Severity', sortable: true, render: (row) => <StatusBadge status={row.severity} /> },
    { key: 'alarmTime', header: 'Time Raised', sortable: true, render: (row) => formatDate(row.alarmTime) },
    { key: 'status', header: 'Status', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
  ];

  if (isServiceDeskOrAdmin) {
    alarmColumns.push({
      key: 'actions',
      header: 'Operations',
      render: (row) => {
        const canAck = row.status === 'ACTIVE';
        const canClear = row.status === 'ACKNOWLEDGED';
        
        return (
          <div style={{ display: 'flex', gap: '0.25rem' }}>
            {canAck && (
              <button className={styles['action-btn']} onClick={() => handleAcknowledge(row.alarmId)}>
                Acknowledge
              </button>
            )}
            {canClear && (
              <button className={styles['action-btn']} onClick={() => handleClear(row.alarmId)}>
                Clear
              </button>
            )}
          </div>
        );
      },
    });
  }

  return (
    <div className="page-container">
      <PageHeader
        title="Alarms Board"
        description="Monitor active physical element faults."
        action={isServiceDeskOrAdmin ? (
          <button
            className={`${styles['action-btn']} ${styles['action-btn-primary']}`}
            onClick={() => setIsAlarmModalOpen(true)}
            style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}
          >
            <PlusCircle size={14} /> Raise Manual Alarm
          </button>
        ) : undefined}
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading network faults...</div>
      ) : (
        <>
          {/* KPI summary cards */}
          <StatGrid>
            <StatCard label="Active" value={kpis.active} icon={<AlertTriangle size={20} />} variant="warning" />
            <StatCard label="Acknowledged" value={kpis.acknowledged} icon={<Bell size={20} />} variant="info" />
            <StatCard label="Cleared" value={kpis.cleared} icon={<CheckCircle size={20} />} variant="success" />
            <StatCard label="Total Alarms" value={kpis.total} icon={<Activity size={20} />} variant="primary" />
          </StatGrid>

          <div className="card">
            <DataTable
              columns={alarmColumns}
              data={alarms}
              rowClassName={severityRowClass}
              searchPlaceholder="Search alarms by type or severity..."
              searchKey={(row) => `${row.alarmType} ${row.severity}`}
            />
          </div>
        </>
      )}

      {isServiceDeskOrAdmin && (
        <Modal isOpen={isAlarmModalOpen} onClose={() => setIsAlarmModalOpen(false)} title="Raise Manual Network Alarm">
          <form className={styles.form} onSubmit={handleSubmit(handleRaiseAlarm)}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Network Element</label>
              <select className={styles.select} {...register('elementId')}>
                <option value="">-- Select Element --</option>
                {elements.map((el) => (
                  <option key={el.elementId} value={el.elementId}>
                    {el.elementName} ({el.ipAddress})
                  </option>
                ))}
              </select>
              {errors.elementId && (
                <span className={styles['error-text']}>{errors.elementId.message}</span>
              )}
            </div>

            <div className={styles['form-row']}>
              <div className={styles['form-group']}>
                <label className={styles.label}>Fault Type</label>
                <select className={styles.select} {...register('alarmType')}>
                  <option value="LINK_DOWN">LINK_DOWN</option>
                  <option value="NODE_UNREACHABLE">NODE_UNREACHABLE</option>
                  <option value="HIGH_UTILISATION">HIGH_UTILISATION</option>
                  <option value="POWER_FAILURE">POWER_FAILURE</option>
                  <option value="HARDWARE_FAULT">HARDWARE_FAULT</option>
                  <option value="COOLING_ALERT">COOLING_ALERT</option>
                </select>
              </div>

              <div className={styles['form-group']}>
                <label className={styles.label}>Severity</label>
                <select className={styles.select} {...register('severity')}>
                  <option value="CRITICAL">CRITICAL</option>
                  <option value="MAJOR">MAJOR</option>
                  <option value="MINOR">MINOR</option>
                  <option value="WARNING">WARNING</option>
                </select>
              </div>
            </div>

            <button type="submit" className={`${styles['action-btn']} ${styles['action-btn-primary']}`} style={{ width: '100%', marginTop: '0.5rem', padding: '0.625rem' }}>
              Submit Alarm Event
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
};

export default Alarms;
