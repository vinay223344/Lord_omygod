import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import axios from 'axios';
import PageHeader from '../../components/PageHeader';
import DataTable, { Column } from '../../components/DataTable';
import StatusBadge from '../../components/StatusBadge';
import Modal from '../../components/Modal';
import { StatCard, StatGrid } from '../../components/StatCard';
import { useAuth } from '../../auth/AuthContext';
import { ticketsApi } from '../../api/tickets';
import { usersApi } from '../../api/users';
import { elementsApi } from '../../api/elements';
import { sitesApi } from '../../api/sites';
import { TroubleTicket, User, NetworkElement, NetworkSite, TicketCategory, TicketPriority } from '../../types';
import { formatDate } from '../../utils/date';
import styles from './Tickets.module.css';
import { AlertCircle, CheckCircle, Flame, Ticket, Users } from 'lucide-react';

const ticketSchema = z.object({
  elementId: z.string().min(1, 'Network element is required'),
  siteId: z.string().min(1, 'Network site is required'),
  category: z.enum(['HARDWARE_FAULT', 'SOFTWARE_FAULT', 'FIBER_CUT', 'POWER_ISSUE', 'BGP_FLAP', 'OTHER']),
  priority: z.enum(['P1', 'P2', 'P3', 'P4']),
  alarmId: z.string().optional(),
});

type TicketFormFields = z.infer<typeof ticketSchema>;


export const Tickets: React.FC = () => {
  const { user } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();
  const [tickets, setTickets] = useState<TroubleTicket[]>([]);
  const [engineers, setEngineers] = useState<User[]>([]);
  const [elements, setElements] = useState<NetworkElement[]>([]);
  const [sites, setSites] = useState<NetworkSite[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<TroubleTicket | null>(null);
  const [loading, setLoading] = useState(true);

  // Modals / forms state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [dispatchedEngineerId, setDispatchedEngineerId] = useState<string>('');

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors },
  } = useForm<TicketFormFields>({
    resolver: zodResolver(ticketSchema),
  });

  const loadData = async () => {
    setLoading(true);
    try {
      const [allTickets, allUsers, allElements, allSites] = await axios.all<any>([
        ticketsApi.getAllTickets(),
        usersApi.getAll(),
        elementsApi.getAll().catch(() => [] as NetworkElement[]),
        sitesApi.getAll().catch(() => [] as NetworkSite[]),
      ]) as [TroubleTicket[], User[], NetworkElement[], NetworkSite[]];
      
      setTickets(allTickets);
      setEngineers(allUsers.filter((u) => u.role === 'FIELD_ENGINEER' && u.status === 'ACTIVE'));
      setElements(allElements);
      setSites(allSites);

      // Handle direct ticket ID selection from query params (e.g. from Dashboard or Alarms redirection)
      const queryId = searchParams.get('id');
      if (queryId) {
        const found = allTickets.find((t) => t.ticketId === Number(queryId));
        if (found) setSelectedTicket(found);
      }
    } catch (err) {
      console.error('Failed to load tickets inventory details:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    // Check if redirecting from alarm board to create a ticket
    const createQuery = searchParams.get('create');
    const alarmQuery = searchParams.get('alarmId');
    const elementQuery = searchParams.get('elementId');
    if (createQuery === 'true') {
      setIsCreateModalOpen(true);
      if (alarmQuery) setValue('alarmId', alarmQuery);
      if (elementQuery) setValue('elementId', elementQuery);
    }
  }, [searchParams]);

  const handleCreateTicket = async (data: TicketFormFields) => {
    try {
      const selectedEl = elements.find((e) => e.elementId === Number(data.elementId));
      const selectedSite = sites.find((s) => s.siteId === Number(data.siteId));

      const payload: Partial<TroubleTicket> = {
        alarmId: data.alarmId ? Number(data.alarmId) : null,
        elementId: Number(data.elementId),
        elementName: selectedEl?.elementName || `Element ${data.elementId}`,
        siteId: Number(data.siteId),
        siteName: selectedSite?.siteName || `Site ${data.siteId}`,
        category: data.category as TicketCategory,
        priority: data.priority as TicketPriority,
      };

      const newTicket = await ticketsApi.createTicket(payload);
      setIsCreateModalOpen(false);
      reset();
      
      // Clean query params
      setSearchParams({});
      
      loadData();
      setSelectedTicket(newTicket);
    } catch (err) {
      console.error('Failed to create trouble ticket:', err);
    }
  };

  const handleEscalate = async (id: number) => {
    try {
      const updated = await ticketsApi.escalateTicket(id);
      setSelectedTicket(updated);
      loadData();
    } catch (err) {
      console.error('Failed to escalate ticket:', err);
    }
  };

  const handleClose = async (id: number) => {
    try {
      const updated = await ticketsApi.closeTicket(id);
      setSelectedTicket(updated);
      loadData();
    } catch (err) {
      console.error('Failed to close ticket:', err);
    }
  };

  const handleDispatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !dispatchedEngineerId) return;

    try {
      await ticketsApi.createDispatch(selectedTicket.ticketId, Number(dispatchedEngineerId));
      setDispatchedEngineerId('');
      
      // Refresh current ticket view details
      const refreshed = await ticketsApi.getTicketById(selectedTicket.ticketId);
      setSelectedTicket(refreshed);
      loadData();
    } catch (err) {
      console.error('Failed to dispatch engineer:', err);
    }
  };

  // ── Derived summary data (from tickets already in state) ──
  const kpis = useMemo(
    () => ({
      open: tickets.filter(
        (t) => t.status === 'OPEN' || t.status === 'ASSIGNED' || t.status === 'FIELD_DISPATCHED'
      ).length,
      escalated: tickets.filter((t) => t.status === 'ESCALATED').length,
      resolved: tickets.filter((t) => t.status === 'RESOLVED' || t.status === 'CLOSED').length,
      total: tickets.length,
    }),
    [tickets]
  );

  // Region (city) of the currently selected ticket's site. Derived from the
  // site address (e.g. "Bangalore, Karnataka" -> "Bangalore"), falling back to
  // the site name (e.g. "Bangalore POP" -> "Bangalore") when the site record
  // isn't available locally.
  const selectedTicketRegion = useMemo(() => {
    if (!selectedTicket) return '';
    const site = sites.find((s) => s.siteId === selectedTicket.siteId);
    if (site?.address) return site.address.split(',')[0].trim();
    return (selectedTicket.siteName || '')
      .replace(/\s+(POP|Data\s?Cent(er|re)|DC)\b.*$/i, '')
      .trim();
  }, [selectedTicket, sites]);

  // Only field engineers whose registered region matches the ticket's site
  // region may be dispatched — this enforces location-based assignment.
  const eligibleEngineers = useMemo(
    () =>
      engineers.filter(
        (e) => (e.region || '').trim().toLowerCase() === selectedTicketRegion.toLowerCase()
      ),
    [engineers, selectedTicketRegion]
  );

  const ticketColumns: Column<TroubleTicket>[] = [
    { key: 'ticketId', header: 'Ticket ID', sortable: true },
    { key: 'category', header: 'Category', sortable: true },
    { key: 'elementName', header: 'Network Element', sortable: true, render: (row) => row.elementName || `ID ${row.elementId}` },
    { key: 'priority', header: 'Priority', sortable: true, render: (row) => <StatusBadge status={row.priority} /> },
    { key: 'raisedDateTime', header: 'Timestamp Raised', sortable: true, render: (row) => formatDate(row.raisedDateTime) },
    { key: 'resolutionSummary', header: 'Resolution Summary', sortable: true, render: (row) => row.resolutionSummary || 'N/A' },
    { key: 'status', header: 'Process State', sortable: true, render: (row) => <StatusBadge status={row.status} /> },
  ];

  return (
    <div className="page-container">
      <PageHeader
        title="Trouble Ticket Operations Queue"
        description="Review active incident tickets, inspect restoration SLA clocks, and dispatch field technicians."
      />

      {loading ? (
        <div style={{ fontStyle: 'italic', color: 'var(--text-muted)' }}>Loading tickets database...</div>
      ) : (
        <div className={styles['page-body']}>
          {/* KPI summary cards */}
          <StatGrid>
            <StatCard label="Open" value={kpis.open} icon={<AlertCircle size={20} />} variant="info" />
            <StatCard label="Escalated" value={kpis.escalated} icon={<Flame size={20} />} variant="escalated" />
            <StatCard label="Resolved / Closed" value={kpis.resolved} icon={<CheckCircle size={20} />} variant="success" />
            <StatCard label="Total Tickets" value={kpis.total} icon={<Ticket size={20} />} variant="primary" />
          </StatGrid>

          <div className={styles.layout}>
          {/* Left Panel: Tickets Table */}
          <div className={styles['table-panel']}>
            <div className="card">
              <DataTable
                columns={ticketColumns}
                data={tickets}
                searchPlaceholder="Search tickets by element, priority, or category..."
                searchKey={(row) => `${row.elementName} ${row.priority} ${row.category}`}
                onRowClick={(row) => setSelectedTicket(row)}
              />
            </div>
          </div>

          {/* Right Panel: Incident Details Side-bar */}
          {selectedTicket && (
            <div className={styles['details-panel']}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <h3 className={styles['section-title']} style={{ margin: 0, border: 'none' }}>
                  Incident #{selectedTicket.ticketId}
                </h3>
                <button
                  style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontWeight: 'bold', fontSize: '0.8rem' }}
                  onClick={() => setSelectedTicket(null)}
                >
                  ✕ Close panel
                </button>
              </div>


              <div className={styles['info-grid']}>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Priority Grade:</span>
                  <span className={styles['info-value']}>
                    <StatusBadge status={selectedTicket.priority} />
                  </span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Ticket Category:</span>
                  <span className={styles['info-value']}>{selectedTicket.category}</span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Linked Alarm ID:</span>
                  <span className={styles['info-value']}>
                    {selectedTicket.alarmId ? `#${selectedTicket.alarmId}` : 'None'}
                  </span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Incident Element:</span>
                  <span className={styles['info-value']}>{selectedTicket.elementName}</span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Incident Location Site:</span>
                  <span className={styles['info-value']}>{selectedTicket.siteName}</span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Time Opened:</span>
                  <span className={styles['info-value']}>{formatDate(selectedTicket.raisedDateTime)}</span>
                </div>
                <div className={styles['info-item']}>
                  <span className={styles['info-label']}>Lifecycle Status:</span>
                  <span className={styles['info-value']}>
                    <StatusBadge status={selectedTicket.status} />
                  </span>
                </div>
              </div>

              {/* Dispatch form section (NOC/Admin only) */}
              {(user?.role === 'NOC_ENGINEER' || user?.role === 'ADMIN') &&
                (selectedTicket.status === 'OPEN' || selectedTicket.status === 'ESCALATED') && (
                  <form className={styles['dispatch-form']} onSubmit={handleDispatch}>
                    <span className={styles['form-title']}>
                      <Users size={12} /> Dispatch Field Engineer
                      {selectedTicketRegion && <> · {selectedTicketRegion}</>}
                    </span>
                    <select
                      className={styles.select}
                      value={dispatchedEngineerId}
                      onChange={(e) => setDispatchedEngineerId(e.target.value)}
                      required
                      disabled={eligibleEngineers.length === 0}
                    >
                      <option value="">-- Choose Active Engineer --</option>
                      {eligibleEngineers.map((eng) => (
                        <option key={eng.userId} value={eng.userId}>
                          {eng.name} — {eng.region}
                        </option>
                      ))}
                    </select>
                    {eligibleEngineers.length === 0 ? (
                      <span className={styles['error-text']} style={{ fontSize: '0.7rem' }}>
                        No field engineer registered for the {selectedTicketRegion || 'this'} region.
                      </span>
                    ) : (
                      <button type="submit" className={`${styles.btn} ${styles['btn-primary']}`} style={{ padding: '0.25rem 0.5rem', fontSize: '0.75rem' }}>
                        Dispatch Tech
                      </button>
                    )}
                  </form>
                )}

              {/* Action Operations */}
              {(user?.role === 'NOC_ENGINEER' || user?.role === 'ADMIN') && (
                <div className={styles['actions-section']}>
                  {selectedTicket.status !== 'ESCALATED' &&
                    selectedTicket.status !== 'CLOSED' &&
                    selectedTicket.status !== 'RESOLVED' && (
                      <button className={styles.btn} onClick={() => handleEscalate(selectedTicket.ticketId)}>
                        <Flame size={14} color="#f97316" /> Escalate Incident
                      </button>
                    )}
                  {selectedTicket.status !== 'CLOSED' && (
                    <button
                      className={`${styles.btn} ${styles['btn-danger']}`}
                      onClick={() => handleClose(selectedTicket.ticketId)}
                    >
                      <CheckCircle size={14} /> Close Ticket Case
                    </button>
                  )}
                </div>
              )}
            </div>
          )}
          </div>
        </div>
      )}

      {/* Manual Trouble Ticket Creator Modal */}
      <Modal isOpen={isCreateModalOpen} onClose={() => setIsCreateModalOpen(false)} title="Raise Trouble Incident Ticket">
        <form className={styles.form} onSubmit={handleSubmit(handleCreateTicket)}>
          <div className={styles['form-group']}>
            <label className={styles.label}>Associated Alarm ID (Optional)</label>
            <input
              type="text"
              className={styles.input}
              placeholder="e.g. 101"
              readOnly={!!searchParams.get('alarmId')}
              {...register('alarmId')}
            />
          </div>

          <div className={styles['form-group']}>
            <label className={styles.label}>Affected Network Element</label>
            <select className={styles.select} disabled={!!searchParams.get('elementId')} {...register('elementId')}>
              <option value="">-- Select Element --</option>
              {elements.map((el) => (
                <option key={el.elementId} value={el.elementId}>
                  {el.elementName} ({el.ipAddress})
                </option>
              ))}
            </select>
            {errors.elementId && (
              <span className={styles['error-text']}>{errors.elementId.message}</span>
            )}
          </div>

          <div className={styles['form-group']}>
            <label className={styles.label}>Location Site</label>
            <select className={styles.select} {...register('siteId')}>
              <option value="">-- Select Location POP --</option>
              {sites.map((s) => (
                <option key={s.siteId} value={s.siteId}>
                  {s.siteName} ({s.siteType})
                </option>
              ))}
            </select>
            {errors.siteId && (
              <span className={styles['error-text']}>{errors.siteId.message}</span>
            )}
          </div>

          <div className={styles['form-row']}>
            <div className={styles['form-group']}>
              <label className={styles.label}>Category</label>
              <select className={styles.select} {...register('category')}>
                <option value="HARDWARE_FAULT">HARDWARE_FAULT</option>
                <option value="SOFTWARE_FAULT">SOFTWARE_FAULT</option>
                <option value="FIBER_CUT">FIBER_CUT</option>
                <option value="POWER_ISSUE">POWER_ISSUE</option>
                <option value="BGP_FLAP">BGP_FLAP</option>
                <option value="OTHER">OTHER</option>
              </select>
            </div>

            <div className={styles['form-group']}>
              <label className={styles.label}>Priority SLA Grade</label>
              <select className={styles.select} {...register('priority')}>
                <option value="P1">P1 (Critical)</option>
                <option value="P2">P2 (Major)</option>
                <option value="P3">P3 (Medium)</option>
                <option value="P4">P4 (Minor)</option>
              </select>
            </div>
          </div>

          <button type="submit" className={`${styles.btn} ${styles['btn-primary']}`} style={{ width: '100%', marginTop: '0.5rem', padding: '0.625rem' }}>
            Submit Incident Case
          </button>
        </form>
      </Modal>
    </div>
  );
};

export default Tickets;
