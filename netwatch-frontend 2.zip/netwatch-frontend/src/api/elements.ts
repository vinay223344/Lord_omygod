import apiClient from './apiClient';
import { NetworkElement } from '../types';
import { mapElementStatusToBackend, mapElementStatusToFrontend } from '../utils/mappings';

export const elementsApi = {
  getAll: async () => {
    const response = await apiClient.get<any[]>('/element');
    return response.data.map((item) => ({
      ...item,
      status: mapElementStatusToFrontend(item.status),
    }));
  },

  create: async (element: Partial<NetworkElement>) => {
    const payload = {
      ...element,
      status: element.status ? mapElementStatusToBackend(element.status) : undefined,
    };
    const response = await apiClient.post<any>('/element', payload);
    return {
      ...response.data,
      status: mapElementStatusToFrontend(response.data.status),
    };
  },

  update: async (id: number, element: Partial<NetworkElement>) => {
    const payload = {
      ...element,
      status: element.status ? mapElementStatusToBackend(element.status) : undefined,
    };
    const response = await apiClient.put<any>(`/element/${id}`, payload);
    return {
      ...response.data,
      status: mapElementStatusToFrontend(response.data.status),
    };
  },
};

