import apiClient from './apiClient';
import { User } from '../types';

export interface LoginRequest {
  email: string;
  password?: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  token: string;
  username: string;
  role: string;
  email: string;
  status: string;
}

export const authApi = {
  login: async (credentials: LoginRequest) => {
    const response = await apiClient.post<LoginResponse>('/auth/login', credentials);
    return response.data;
  },

  register: async (userData: Partial<User>) => {
    const response = await apiClient.post<User>('/auth/register', userData);
    return response.data;
  },

  // Public list of operational regions (derived from network sites) used to
  // populate the region selector on the registration page.
  getRegions: async () => {
    const response = await apiClient.get<string[]>('/auth/regions');
    return response.data;
  },
};
