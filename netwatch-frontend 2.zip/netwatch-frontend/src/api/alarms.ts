import apiClient from './apiClient';
import { NetworkAlarm } from '../types';

export const alarmsApi = {
  getAllAlarms: async () => {
    try {
      const response = await apiClient.get<NetworkAlarm[]>('/alarm');
      return response.data;
    } catch (err) {
      console.warn('Backend Alarm retrieval failed, using empty list:', err);
      return [];
    }
  },

  createAlarm: async (alarm: Partial<NetworkAlarm>, creatorId: number) => {
    const response = await apiClient.post<NetworkAlarm>('/alarm', alarm, {
      params: { creatorId },
    });
    return response.data;
  },

  acknowledgeAlarm: async (alarmId: number, userId: number) => {
    const response = await apiClient.put<NetworkAlarm>(`/alarm/ack/${alarmId}`, null, {
      params: { userId },
    });
    return response.data;
  },

  clearAlarm: async (alarmId: number, userId: number) => {
    const response = await apiClient.put<NetworkAlarm>(`/alarm/clear/${alarmId}`, null, {
      params: { userId },
    });
    return response.data;
  },
};
