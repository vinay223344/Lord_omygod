import apiClient from './apiClient';
import { Circuit, ProvisioningRequest } from '../types';
import {
  mapProvTypeToBackend,
  mapProvTypeToFrontend,
  mapServiceTypeToBackend,
  mapServiceTypeToFrontend,
} from '../utils/mappings';

export const circuitsApi = {
  // ─── Circuit Endpoints ─────────────────────────────────────────────────────
  
  getAllCircuits: async () => {
    const response = await apiClient.get<any[]>('/circuit');
    return response.data.map((item) => ({
      ...item,
      serviceType: mapServiceTypeToFrontend(item.serviceType),
    }));
  },

  createCircuit: async (circuit: Partial<Circuit>, creatorId: number) => {
    const payload = {
      ...circuit,
      serviceType: circuit.serviceType ? mapServiceTypeToBackend(circuit.serviceType) : undefined,
    };
    const response = await apiClient.post<any>('/circuit', payload, {
      params: { creatorId },
    });
    return {
      ...response.data,
      serviceType: mapServiceTypeToFrontend(response.data.serviceType),
    };
  },

  updateCircuit: async (id: number, circuit: Partial<Circuit>, updaterId: number) => {
    const payload = {
      ...circuit,
      serviceType: circuit.serviceType ? mapServiceTypeToBackend(circuit.serviceType) : undefined,
    };
    const response = await apiClient.put<any>(`/circuit/${id}`, payload, {
      params: { updaterId },
    });
    return {
      ...response.data,
      serviceType: mapServiceTypeToFrontend(response.data.serviceType),
    };
  },

  // ─── Provisioning Endpoints ────────────────────────────────────────────────
  
  getAllRequests: async () => {
    const response = await apiClient.get<any[]>('/circuit/request');
    return response.data.map((item) => ({
      ...item,
      requestType: mapProvTypeToFrontend(item.requestType),
    }));
  },

  createProvisioningRequest: async (request: Partial<ProvisioningRequest>, creatorId: number) => {
    const payload = {
      ...request,
      requestType: request.requestType ? mapProvTypeToBackend(request.requestType) : undefined,
    };
    const response = await apiClient.post<any>('/circuit/request', payload, {
      params: { creatorId },
    });
    return {
      ...response.data,
      requestType: mapProvTypeToFrontend(response.data.requestType),
    };
  },

  processRequest: async (id: number, processorId: number) => {
    const response = await apiClient.put<any>(`/circuit/request/${id}/process`, null, {
      params: { processorId },
    });
    return {
      ...response.data,
      requestType: mapProvTypeToFrontend(response.data.requestType),
    };
  },

  executeAfterMaintenance: async (id: number, processorId: number) => {
    const response = await apiClient.put<any>(`/circuit/request/${id}/execute`, null, {
      params: { processorId },
    });
    return {
      ...response.data,
      requestType: mapProvTypeToFrontend(response.data.requestType),
    };
  },
};
