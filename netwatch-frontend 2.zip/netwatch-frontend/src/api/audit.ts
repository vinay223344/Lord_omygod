import apiClient from './apiClient';
import { AuditLog } from '../types';

export const auditApi = {
  getAll: async () => {
    try {
      const response = await apiClient.get<AuditLog[]>('/audit');
      return response.data;
    } catch (err) {
      console.warn('Backend Audit Log fetch failed, returning empty list:', err);
      return [];
    }
  },
};
