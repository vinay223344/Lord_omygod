import apiClient from './apiClient';
import { TroubleTicket, FieldDispatch, DispatchStatus } from '../types';

const LOCAL_TICKETS_KEY = 'netwatch_local_tickets';

const getLocalTickets = (): TroubleTicket[] => {
  const data = localStorage.getItem(LOCAL_TICKETS_KEY);
  return data ? JSON.parse(data) : [];
};

const saveLocalTickets = (tickets: TroubleTicket[]) => {
  localStorage.setItem(LOCAL_TICKETS_KEY, JSON.stringify(tickets));
};

export const ticketsApi = {
  getAllTickets: async () => {
    try {
      const response = await apiClient.get<TroubleTicket[]>('/ticket');
      const backendTickets = response.data;
      const localTickets = getLocalTickets();
      
      // Merge: return local tickets first (if any) and then backend tickets, filtering duplicates by ticketId
      const all = [...localTickets, ...backendTickets];
      const unique = all.filter((item, index, self) =>
        index === self.findIndex((t) => t.ticketId === item.ticketId)
      );
      return unique;
    } catch (err) {
      console.warn('Backend tickets fetch failed, falling back to local database:', err);
      return getLocalTickets();
    }
  },

  getTicketById: async (ticketId: number) => {
    const local = getLocalTickets().find((t) => t.ticketId === ticketId);
    if (local) return local;

    const response = await apiClient.get<TroubleTicket>(`/ticket/${ticketId}`);
    return response.data;
  },

  createTicket: async (ticketData: Partial<TroubleTicket>) => {
    // Generate a new ticket ID that doesn't conflict with database IDs
    const localTickets = getLocalTickets();
    const newId = localTickets.reduce((max, t) => Math.max(max, t.ticketId), 1000) + 1;
    
    // Default Restoration time is 4 hours from now for SLA
    const raised = new Date();
    const sla = new Date(raised.getTime() + 4 * 60 * 60 * 1000);

    const newTicket: TroubleTicket = {
      ticketId: newId,
      alarmId: ticketData.alarmId || null,
      elementId: ticketData.elementId || 0,
      elementName: ticketData.elementName || 'Unknown Element',
      siteId: ticketData.siteId || 0,
      siteName: ticketData.siteName || 'Unknown Site',
      category: ticketData.category || 'OTHER',
      priority: ticketData.priority || 'P3',
      raisedDateTime: raised.toISOString(),
      restorationSLATime: sla.toISOString(),
      status: 'OPEN',
    };

    localTickets.push(newTicket);
    saveLocalTickets(localTickets);
    return newTicket;
  },

  closeTicket: async (ticketId: number) => {
    // Update local state if the ticket is local
    const locals = getLocalTickets();
    const localIdx = locals.findIndex((t) => t.ticketId === ticketId);
    if (localIdx !== -1) {
      locals[localIdx].status = 'CLOSED';
      locals[localIdx].restoredDateTime = new Date().toISOString();
      saveLocalTickets(locals);
      return locals[localIdx];
    }

    const response = await apiClient.put<TroubleTicket>(`/ticket/${ticketId}/close`);
    return response.data;
  },

  escalateTicket: async (ticketId: number) => {
    // Update local state if local
    const locals = getLocalTickets();
    const localIdx = locals.findIndex((t) => t.ticketId === ticketId);
    if (localIdx !== -1) {
      locals[localIdx].status = 'ESCALATED';
      saveLocalTickets(locals);
      return locals[localIdx];
    }

    const response = await apiClient.put<TroubleTicket>(`/ticket/${ticketId}/escalate`);
    return response.data;
  },

  // ─── Dispatch Operations ───────────────────────────────────────────────────

  createDispatch: async (ticketId: number, fieldEngineerId: number) => {
    const response = await apiClient.post<FieldDispatch>('/ticket/dispatch', null, {
      params: { ticketId, fieldEngineerId },
    });

    // Update local ticket status to FIELD_DISPATCHED if the ticket is local
    const locals = getLocalTickets();
    const localIdx = locals.findIndex((t) => t.ticketId === ticketId);
    if (localIdx !== -1) {
      locals[localIdx].status = 'FIELD_DISPATCHED';
      saveLocalTickets(locals);
    }

    return response.data;
  },

  getAllDispatches: async () => {
    const response = await apiClient.get<FieldDispatch[]>('/ticket/dispatch');
    return response.data;
  },

  getDispatchesForEngineer: async (fieldEngineerId: number) => {
    const response = await apiClient.get<FieldDispatch[]>(`/ticket/dispatch/engineer/${fieldEngineerId}`);
    return response.data;
  },

  updateDispatchStatus: async (
    dispatchId: number,
    status: DispatchStatus,
    resolutionSummary?: string
  ) => {
    const response = await apiClient.put<FieldDispatch>(`/ticket/dispatch/${dispatchId}/status`, null, {
      params: {
        status,
        resolutionSummary: resolutionSummary || '',
      },
    });

    // If dispatch status is RESOLVED, we automatically resolve local tickets linked to it
    if (status === 'RESOLVED') {
      const locals = getLocalTickets();
      const linkedTicketId = response.data.ticketId;
      const localIdx = locals.findIndex((t) => t.ticketId === linkedTicketId);
      if (localIdx !== -1) {
        locals[localIdx].status = 'RESOLVED';
        locals[localIdx].restoredDateTime = new Date().toISOString();
        saveLocalTickets(locals);
      }
    }

    return response.data;
  },
};
