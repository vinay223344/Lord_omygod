import apiClient from './apiClient';
import { NetworkSite } from '../types';
import {
  mapSiteStatusToBackend,
  mapSiteStatusToFrontend,
  mapSiteTypeToBackend,
  mapSiteTypeToFrontend,
} from '../utils/mappings';

export const sitesApi = {
  getAll: async () => {
    const response = await apiClient.get<any[]>('/site');
    return response.data.map((item) => ({
      ...item,
      status: mapSiteStatusToFrontend(item.status),
      siteType: mapSiteTypeToFrontend(item.siteType),
    }));
  },

  create: async (site: Partial<NetworkSite>) => {
    const payload = {
      ...site,
      status: site.status ? mapSiteStatusToBackend(site.status) : undefined,
      siteType: site.siteType ? mapSiteTypeToBackend(site.siteType) : undefined,
    };
    const response = await apiClient.post<any>('/site', payload);
    return {
      ...response.data,
      status: mapSiteStatusToFrontend(response.data.status),
      siteType: mapSiteTypeToFrontend(response.data.siteType),
    };
  },

  update: async (id: number, site: Partial<NetworkSite>) => {
    const payload = {
      ...site,
      status: site.status ? mapSiteStatusToBackend(site.status) : undefined,
      siteType: site.siteType ? mapSiteTypeToBackend(site.siteType) : undefined,
    };
    const response = await apiClient.put<any>(`/site/${id}`, payload);
    return {
      ...response.data,
      status: mapSiteStatusToFrontend(response.data.status),
      siteType: mapSiteTypeToFrontend(response.data.siteType),
    };
  },
};

