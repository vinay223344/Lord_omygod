import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8090';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Public endpoints that must never carry an Authorization header. Sending a
// stale/invalid token to /auth/login causes the backend to reject it with 403.
const PUBLIC_PATHS = ['/auth/login', '/auth/register', '/auth/regions'];

// Request Interceptor: Attach JWT Token from localStorage
apiClient.interceptors.request.use(
  (config) => {
    const url = config.url || '';
    const isPublic = PUBLIC_PATHS.some((path) => url.startsWith(path));
    const token = localStorage.getItem('netwatch_token');
    if (token && !isPublic && config.headers) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    throw error;
  }
);

// Response Interceptor: Catch 401 and redirect to Login
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      console.warn('Unauthorized! Redirecting to login...');
      localStorage.removeItem('netwatch_token');
      localStorage.removeItem('netwatch_user');
      // If we are not already on the login page, redirect
      if (!window.location.pathname.endsWith('/login')) {
        window.location.href = '/login';
      }
    }
    throw error;
  }
);
export default apiClient;
