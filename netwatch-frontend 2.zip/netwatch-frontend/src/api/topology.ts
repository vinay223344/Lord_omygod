import apiClient from './apiClient';
import { TopologyLink } from '../types';
import {
  mapLinkStatusToBackend,
  mapLinkStatusToFrontend,
  mapLinkTypeToBackend,
  mapLinkTypeToFrontend,
} from '../utils/mappings';

export const topologyApi = {
  getAll: async () => {
    const response = await apiClient.get<any[]>('/link');
    return response.data.map((item) => ({
      ...item,
      status: mapLinkStatusToFrontend(item.status),
      linkType: mapLinkTypeToFrontend(item.linkType),
    }));
  },

  create: async (link: Partial<TopologyLink>) => {
    const payload = {
      ...link,
      status: link.status ? mapLinkStatusToBackend(link.status) : undefined,
      linkType: link.linkType ? mapLinkTypeToBackend(link.linkType) : undefined,
    };
    const response = await apiClient.post<any>('/link', payload);
    return {
      ...response.data,
      status: mapLinkStatusToFrontend(response.data.status),
      linkType: mapLinkTypeToFrontend(response.data.linkType),
    };
  },

  update: async (id: number, link: Partial<TopologyLink>) => {
    const payload = {
      ...link,
      status: link.status ? mapLinkStatusToBackend(link.status) : undefined,
      linkType: link.linkType ? mapLinkTypeToBackend(link.linkType) : undefined,
    };
    const response = await apiClient.put<any>(`/link/${id}`, payload);
    return {
      ...response.data,
      status: mapLinkStatusToFrontend(response.data.status),
      linkType: mapLinkTypeToFrontend(response.data.linkType),
    };
  },
};

