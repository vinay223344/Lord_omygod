import React from 'react';
import { useAuth } from '../auth/AuthContext';
import styles from './Topbar.module.css';
import { LogOut, Menu } from 'lucide-react';

interface TopbarProps {
  /** Toggles the mobile navigation drawer. Only surfaced on small screens. */
  onMenuClick?: () => void;
}

export const Topbar: React.FC<TopbarProps> = ({ onMenuClick }) => {
  const { user, logout } = useAuth();

  if (!user) return null;

  return (
    <header className={styles.topbar}>
      <div className={styles['left-section']}>
        <button
          className={styles['menu-btn']}
          onClick={onMenuClick}
          title="Toggle navigation menu"
          aria-label="Toggle navigation menu"
        >
          <Menu size={20} />
        </button>
      </div>

      <div className={styles['right-section']}>
        {/* User profile section */}
        <div className={styles['user-profile']}>
          <div className={styles['user-details']}>
            <span className={styles['user-name']}>{user.name}</span>
            <div className={styles['user-meta']}>
              <span className={styles['role-badge']}>{user.role}</span>
            </div>
          </div>
          
          <button className={styles['logout-btn']} onClick={logout} title="Sign Out">
            <LogOut size={16} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Topbar;
