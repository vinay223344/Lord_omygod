import React from 'react';
import styles from './StatCard.module.css';

export type StatVariant =
  | 'primary'
  | 'success'
  | 'warning'
  | 'critical'
  | 'escalated'
  | 'info'
  | 'neutral';

interface StatCardProps {
  label: string;
  value: React.ReactNode;
  icon?: React.ReactNode;
  variant?: StatVariant;
  /** Optional small line beneath the value (e.g. a percentage or context hint). */
  sublabel?: React.ReactNode;
  /**
   * Optional explicit accent color (hex). When set it overrides the variant's
   * palette for this card only — the accent bar, icon, and tinted backgrounds
   * are all derived from it, keeping the card structure identical.
   */
  color?: string;
}

/**
 * Shared KPI/summary card used across all dashboard pages so every page's
 * cards look identical (radius, shadow, spacing, accent bar, icon box, hover
 * lift). Colors come from the variant, which maps to existing design tokens.
 */
export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  icon,
  variant = 'neutral',
  sublabel,
  color,
}) => {
  // When an explicit color is provided, derive the accent bar, icon, and the
  // soft tinted card/icon backgrounds from it using hex alpha suffixes so the
  // look matches the existing pastel variants while staying fully distinct.
  const colorStyle = color
    ? ({
        '--accent-bar': color,
        '--icon-fg': color,
        '--icon-bg': `${color}22`,
        '--card-bg': `${color}12`,
      } as React.CSSProperties)
    : undefined;

  return (
    <div className={`${styles.card} ${styles[variant]}`} style={colorStyle}>
      <div className={styles.details}>
        <span className={styles.label}>{label}</span>
        <span className={styles.value}>{value}</span>
        {sublabel && <span className={styles.sublabel}>{sublabel}</span>}
      </div>
      {icon && <div className={styles.icon}>{icon}</div>}
    </div>
  );
};

interface StatGridProps {
  children: React.ReactNode;
  /** Minimum card width (px) before wrapping to the next row. Default 210. */
  minCardWidth?: number;
}

/**
 * Responsive grid wrapper for StatCards. Uses auto-fit so any number of cards
 * (4, 5, 6…) wraps cleanly across desktop, tablet, and mobile.
 */
export const StatGrid: React.FC<StatGridProps> = ({ children, minCardWidth = 210 }) => {
  return (
    <div
      className={styles.grid}
      style={{ gridTemplateColumns: `repeat(auto-fit, minmax(${minCardWidth}px, 1fr))` }}
    >
      {children}
    </div>
  );
};

export default StatCard;
