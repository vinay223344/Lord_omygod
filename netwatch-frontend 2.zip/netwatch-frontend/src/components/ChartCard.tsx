import React from 'react';
import styles from './ChartCard.module.css';

interface ChartCardProps {
  title: string;
  /** Optional element rendered on the right of the header (e.g. a legend note). */
  action?: React.ReactNode;
  /** Height (px) of the chart body area. Default 280. */
  height?: number;
  children: React.ReactNode;
}

/**
 * Shared titled card wrapper for charts. Provides consistent card chrome and a
 * fixed-height body; the caller places a Recharts <ResponsiveContainer
 * width="100%" height="100%"> inside so charts stay responsive.
 */
export const ChartCard: React.FC<ChartCardProps> = ({ title, action, height = 280, children }) => {
  return (
    <div className={styles.card}>
      <div className={styles.header}>
        <h3 className={styles.title}>{title}</h3>
        {action && <div className={styles.action}>{action}</div>}
      </div>
      <div className={styles.body} style={{ height }}>
        {children}
      </div>
    </div>
  );
};

export default ChartCard;
