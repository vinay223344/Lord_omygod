import React, { useState, useMemo } from 'react';
import styles from './DataTable.module.css';

export interface Column<T> {
  key: string;
  header: string;
  /**
   * @deprecated Column sorting has been removed. This prop is accepted for
   * backwards compatibility but no longer has any effect.
   */
  sortable?: boolean;
  render?: (row: T) => React.ReactNode;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[];
  searchPlaceholder?: string;
  searchKey?: keyof T | ((row: T) => string);
  onRowClick?: (row: T) => void;
  pageSize?: number;
  rowClassName?: (row: T) => string;
}

export function DataTable<T extends Record<string, any>>({
  columns,
  data,
  searchPlaceholder = 'Search...',
  searchKey,
  onRowClick,
  pageSize = 10,
  rowClassName,
}: DataTableProps<T>) {
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  // Filter data based on search query
  const filteredData = useMemo(() => {
    if (!searchQuery.trim() || !searchKey) return data;
    
    return data.filter((row) => {
      let value = '';
      if (typeof searchKey === 'function') {
        value = searchKey(row);
      } else {
        const val = row[searchKey];
        value = val !== undefined && val !== null ? String(val) : '';
      }
      return value.toLowerCase().includes(searchQuery.toLowerCase());
    });
  }, [data, searchQuery, searchKey]);

  // Paginated data
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredData.slice(start, start + pageSize);
  }, [filteredData, currentPage, pageSize]);

  const totalPages = Math.ceil(filteredData.length / pageSize) || 1;

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  return (
    <div className={styles['table-container']}>
      {searchKey && (
        <div className={styles['table-header-actions']}>
          <input
            type="text"
            className={styles['search-input']}
            placeholder={searchPlaceholder}
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
          />
          <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Showing {filteredData.length} records
          </div>
        </div>
      )}

      <div className={styles['table-wrapper']}>
        <table className={styles.table}>
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col.key} className={styles.th}>
                  {col.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {paginatedData.length > 0 ? (
              paginatedData.map((row, rIdx) => {
                const trClass = `${onRowClick ? styles['tr-clickable'] : ''} ${rowClassName ? rowClassName(row) : ''}`;
                return (
                  <tr
                    key={row.id ?? row.auditId ?? row.provisionId ?? row.capacityId ?? row.maintenanceId ?? row.dispatchId ?? row.linkId ?? row.ticketId ?? row.circuitId ?? row.alarmId ?? row.elementId ?? row.siteId ?? row.userId ?? rIdx}
                    className={trClass}
                    onClick={() => onRowClick && onRowClick(row)}
                  >
                    {columns.map((col) => (
                      <td key={col.key} className={styles.td}>
                        {col.render ? col.render(row) : row[col.key]}
                      </td>
                    ))}
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={columns.length} className={styles['no-data']}>
                  No matching records found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className={styles.pagination}>
          <div>
            Showing Page {currentPage} of {totalPages}
          </div>
          <div className={styles['pagination-buttons']}>
            <button
              className={styles['page-btn']}
              disabled={currentPage === 1}
              onClick={() => handlePageChange(currentPage - 1)}
            >
              Previous
            </button>
            <button
              className={styles['page-btn']}
              disabled={currentPage === totalPages}
              onClick={() => handlePageChange(currentPage + 1)}
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default DataTable;
