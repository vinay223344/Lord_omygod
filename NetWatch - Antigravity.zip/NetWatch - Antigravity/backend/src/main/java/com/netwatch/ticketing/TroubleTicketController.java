package com.netwatch.ticketing;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/tickets")
@RequiredArgsConstructor
public class TroubleTicketController {
    private final TroubleTicketService service;

    @GetMapping
    public ResponseEntity<List<TroubleTicket>> getAllTickets() {
        return ResponseEntity.ok(service.getAllTickets());
    }

    @PostMapping
    public ResponseEntity<TroubleTicket> createTicket(@RequestBody TroubleTicket ticket) {
        return ResponseEntity.ok(service.createTicket(ticket));
    }

    @PostMapping("/dispatch")
    public ResponseEntity<FieldDispatch> dispatchEngineer(@RequestBody FieldDispatch dispatch) {
        return ResponseEntity.ok(service.dispatchEngineer(dispatch));
    }

    @PostMapping("/{ticketId}/assign")
    public ResponseEntity<TroubleTicket> assignTicket(@PathVariable Long ticketId, @RequestParam Long userId) {
        return ResponseEntity.ok(service.assignTicket(ticketId, userId));
    }

    @PostMapping("/{ticketId}/status")
    public ResponseEntity<TroubleTicket> updateTicketStatus(
            @PathVariable Long ticketId,
            @RequestParam String status,
            @RequestParam(required = false) String summary) {
        return ResponseEntity.ok(service.updateTicketStatus(ticketId, status, summary));
    }

    @GetMapping("/dispatches")
    public ResponseEntity<List<FieldDispatch>> getAllDispatches() {
        return ResponseEntity.ok(service.getAllDispatches());
    }

    @PostMapping("/dispatches/{dispatchId}/status")
    public ResponseEntity<FieldDispatch> updateDispatchStatus(
            @PathVariable Long dispatchId,
            @RequestParam String status,
            @RequestParam(required = false) String summary) {
        return ResponseEntity.ok(service.updateDispatchStatus(dispatchId, status, summary));
    }
}
