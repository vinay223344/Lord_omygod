package com.netwatch.ticketing;

import com.netwatch.auth.User;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "field_dispatches")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FieldDispatch {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long dispatchId;

    @ManyToOne
    @JoinColumn(name = "ticket_id")
    private TroubleTicket ticket;

    @ManyToOne
    @JoinColumn(name = "field_engineer_id")
    private User fieldEngineer;

    private LocalDateTime dispatchTime;
    private LocalDateTime siteArrivalTime;
    private LocalDateTime restorationTime;
    private String resolutionSummary;

    @Enumerated(EnumType.STRING)
    private DispatchStatus status;

    public enum DispatchStatus {
        Dispatched, OnSite, Resolved, CannotRepair
    }

    @PrePersist
    protected void onCreate() {
        if (dispatchTime == null) {
            dispatchTime = LocalDateTime.now();
        }
        if (status == null) {
            status = DispatchStatus.Dispatched;
        }
    }
}
