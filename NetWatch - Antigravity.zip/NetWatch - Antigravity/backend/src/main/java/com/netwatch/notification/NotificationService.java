package com.netwatch.notification;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationService {
    private final NotificationRepository notificationRepository;

    public List<Notification> getUserNotifications(Long userId) {
        return notificationRepository.findAll().stream()
                .filter(n -> n.getUser() == null || n.getUser().getUserId().equals(userId))
                .toList();
    }

    public Notification createNotification(Notification notification) {
        if (notification.getStatus() == null) {
            notification.setStatus(Notification.NotificationStatus.Unread);
        }
        if (notification.getCreatedDate() == null) {
            notification.setCreatedDate(java.time.LocalDateTime.now());
        }
        return notificationRepository.save(notification);
    }

    public Notification markAsRead(Long id) {
        Notification notification = notificationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Notification not found: " + id));
        notification.setStatus(Notification.NotificationStatus.Read);
        return notificationRepository.save(notification);
    }

    public void markAllAsRead(Long userId) {
        List<Notification> unread = notificationRepository.findAll().stream()
                .filter(n -> n.getUser() != null && n.getUser().getUserId().equals(userId) && n.getStatus() == Notification.NotificationStatus.Unread)
                .toList();
        
        for (Notification n : unread) {
            n.setStatus(Notification.NotificationStatus.Read);
            notificationRepository.save(n);
        }
    }
}
