package com.netwatch.ticketing;

import com.netwatch.alarm.NetworkAlarm;
import com.netwatch.auth.User;
import com.netwatch.inventory.NetworkElement;
import com.netwatch.inventory.NetworkSite;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "trouble_tickets")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TroubleTicket {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long ticketId;

    @ManyToOne
    @JoinColumn(name = "alarm_id")
    private NetworkAlarm alarm;

    @ManyToOne
    @JoinColumn(name = "element_id")
    private NetworkElement element;

    @ManyToOne
    @JoinColumn(name = "site_id")
    private NetworkSite site;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TicketCategory category;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Priority priority;

    @ManyToOne
    @JoinColumn(name = "assigned_noc_engineer_id")
    private User assignedNocEngineer;

    private LocalDateTime raisedDateTime;
    private LocalDateTime restorationSLATime;
    private LocalDateTime restoredDateTime;

    @Enumerated(EnumType.STRING)
    private TicketStatus status;

    public enum TicketCategory {
        LinkFault, NodeFault, PowerIssue, Congestion, ConfigError
    }

    public enum Priority {
        P1, P2, P3, P4
    }

    public enum TicketStatus {
        Open, Assigned, FieldDispatched, Resolved, Closed, Escalated
    }

    @PrePersist
    protected void onCreate() {
        if (raisedDateTime == null) {
            raisedDateTime = LocalDateTime.now();
        }
        if (status == null) {
            status = TicketStatus.Open;
        }
    }
}
