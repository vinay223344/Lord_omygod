package com.netwatch.provisioning;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProvisioningService {
    private final CircuitRepository circuitRepository;
    private final ProvisioningRequestRepository requestRepository;

    public List<Circuit> getAllCircuits() {
        return circuitRepository.findAll();
    }

    public Circuit createCircuit(Circuit circuit) {
        if (circuit.getStatus() == null) {
            circuit.setStatus(Circuit.CircuitStatus.Active);
        }
        return circuitRepository.save(circuit);
    }

    public List<ProvisioningRequest> getAllRequests() {
        return requestRepository.findAll();
    }

    public ProvisioningRequest createRequest(ProvisioningRequest request) {
        if (request.getRequestDate() == null) {
            request.setRequestDate(java.time.LocalDateTime.now());
        }
        if (request.getStatus() == null) {
            request.setStatus(ProvisioningRequest.ProvisionStatus.Pending);
        }
        return requestRepository.save(request);
    }

    public ProvisioningRequest completeRequest(Long provisionId) {
        ProvisioningRequest request = requestRepository.findById(provisionId)
                .orElseThrow(() -> new RuntimeException("Request not found: " + provisionId));
        
        request.setStatus(ProvisioningRequest.ProvisionStatus.Completed);
        request.setCompletedDate(java.time.LocalDateTime.now());
        
        Circuit circuit = request.getCircuit();
        if (request.getRequestType() == ProvisioningRequest.RequestType.NewActivation) {
            circuit.setStatus(Circuit.CircuitStatus.Active);
        } else if (request.getRequestType() == ProvisioningRequest.RequestType.Suspension) {
            circuit.setStatus(Circuit.CircuitStatus.Suspended);
        } else if (request.getRequestType() == ProvisioningRequest.RequestType.Termination) {
            circuit.setStatus(Circuit.CircuitStatus.Decommissioned);
        }
        
        circuitRepository.save(circuit);
        return requestRepository.save(request);
    }
}
