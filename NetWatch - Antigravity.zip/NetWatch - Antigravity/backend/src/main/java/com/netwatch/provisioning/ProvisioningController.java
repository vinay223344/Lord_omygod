package com.netwatch.provisioning;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/provisioning")
@RequiredArgsConstructor
public class ProvisioningController {
    private final ProvisioningService service;

    @GetMapping("/circuits")
    public ResponseEntity<List<Circuit>> getAllCircuits() {
        return ResponseEntity.ok(service.getAllCircuits());
    }

    @PostMapping("/circuits")
    public ResponseEntity<Circuit> createCircuit(@RequestBody Circuit circuit) {
        return ResponseEntity.ok(service.createCircuit(circuit));
    }

    @GetMapping("/requests")
    public ResponseEntity<List<ProvisioningRequest>> getAllRequests() {
        return ResponseEntity.ok(service.getAllRequests());
    }

    @PostMapping("/requests")
    public ResponseEntity<ProvisioningRequest> createRequest(@RequestBody ProvisioningRequest request) {
        return ResponseEntity.ok(service.createRequest(request));
    }

    @PostMapping("/requests/{id}/complete")
    public ResponseEntity<ProvisioningRequest> completeRequest(@PathVariable Long id) {
        return ResponseEntity.ok(service.completeRequest(id));
    }
}
