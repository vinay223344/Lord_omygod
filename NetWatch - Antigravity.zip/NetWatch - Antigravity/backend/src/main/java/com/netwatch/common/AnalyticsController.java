package com.netwatch.common;

import com.netwatch.alarm.NetworkAlarm;
import com.netwatch.alarm.NetworkAlarmRepository;
import com.netwatch.inventory.NetworkElementRepository;
import com.netwatch.inventory.TopologyLink;
import com.netwatch.inventory.TopologyLinkRepository;
import com.netwatch.maintenance.CapacityRecord;
import com.netwatch.maintenance.CapacityRecordRepository;
import com.netwatch.provisioning.Circuit;
import com.netwatch.provisioning.CircuitRepository;
import com.netwatch.ticketing.TroubleTicket;
import com.netwatch.ticketing.TroubleTicketRepository;
import lombok.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/analytics")
@RequiredArgsConstructor
public class AnalyticsController {

    private final NetworkAlarmRepository alarmRepository;
    private final TroubleTicketRepository ticketRepository;
    private final NetworkElementRepository elementRepository;
    private final CircuitRepository circuitRepository;
    private final TopologyLinkRepository linkRepository;
    private final CapacityRecordRepository capacityRepository;

    @GetMapping("/dashboard")
    public ResponseEntity<DashboardMetrics> getDashboardMetrics() {
        List<NetworkAlarm> alarms = alarmRepository.findAll();
        List<TroubleTicket> tickets = ticketRepository.findAll();
        List<TopologyLink> links = linkRepository.findAll();
        List<CapacityRecord> capacities = capacityRepository.findAll();

        long activeAlarms = alarms.stream()
                .filter(a -> a.getStatus() == NetworkAlarm.AlarmStatus.Active || a.getStatus() == NetworkAlarm.AlarmStatus.Acknowledged)
                .count();

        long criticalTickets = tickets.stream()
                .filter(t -> t.getPriority() == TroubleTicket.Priority.P1 && t.getStatus() != TroubleTicket.TicketStatus.Closed && t.getStatus() != TroubleTicket.TicketStatus.Resolved)
                .count();

        long totalElements = elementRepository.count();

        long activeCircuits = circuitRepository.findAll().stream()
                .filter(c -> c.getStatus() == Circuit.CircuitStatus.Active)
                .count();

        long utilisedLinks = links.stream()
                .filter(l -> l.getUtilisationPercent() != null && l.getUtilisationPercent().compareTo(BigDecimal.valueOf(80.00)) > 0)
                .count();

        Map<String, Long> severityDist = new HashMap<>();
        for (NetworkAlarm.Severity s : NetworkAlarm.Severity.values()) {
            long count = alarms.stream().filter(a -> a.getSeverity() == s).count();
            severityDist.put(s.name(), count);
        }

        Map<String, Long> ticketDist = new HashMap<>();
        for (TroubleTicket.TicketStatus s : TroubleTicket.TicketStatus.values()) {
            long count = tickets.stream().filter(t -> t.getStatus() == s).count();
            ticketDist.put(s.name(), count);
        }

        List<CapacityRecord> warnings = capacities.stream()
                .filter(c -> c.getStatus() == CapacityRecord.CapacityStatus.Warning || c.getStatus() == CapacityRecord.CapacityStatus.Critical)
                .toList();

        DashboardMetrics metrics = DashboardMetrics.builder()
                .activeAlarmsCount(activeAlarms)
                .criticalTicketsCount(criticalTickets)
                .totalElementsCount(totalElements)
                .activeCircuitsCount(activeCircuits)
                .utilisedLinksCount(utilisedLinks)
                .severityDistribution(severityDist)
                .ticketStatusDistribution(ticketDist)
                .capacityWarnings(warnings)
                .build();

        return ResponseEntity.ok(metrics);
    }

    @Data
    @Builder
    @AllArgsConstructor
    @NoArgsConstructor
    public static class DashboardMetrics {
        private long activeAlarmsCount;
        private long criticalTicketsCount;
        private long totalElementsCount;
        private long activeCircuitsCount;
        private long utilisedLinksCount;
        private Map<String, Long> severityDistribution;
        private Map<String, Long> ticketStatusDistribution;
        private List<CapacityRecord> capacityWarnings;
    }
}
