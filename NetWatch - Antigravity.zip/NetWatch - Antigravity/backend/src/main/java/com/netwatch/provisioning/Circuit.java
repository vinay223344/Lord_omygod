package com.netwatch.provisioning;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "circuits")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Circuit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long circuitId;

    @Column(unique = true, nullable = false)
    private String circuitReference;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ServiceType serviceType;

    private String customerId;
    private Integer bandwidthMbps;
    private String routePath;
    private LocalDate activationDate;

    @Enumerated(EnumType.STRING)
    private CircuitStatus status;

    public enum ServiceType {
        LeasedLine, VPN, Internet, Voice, MPLS
    }

    public enum CircuitStatus {
        Active, Suspended, Decommissioned
    }
}
