package com.netwatch.alarm;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/alarms")
@RequiredArgsConstructor
public class AlarmController {
    private final AlarmService service;

    @GetMapping
    public ResponseEntity<List<NetworkAlarm>> getActiveAlarms() {
        return ResponseEntity.ok(service.getActiveAlarms());
    }

    @PostMapping("/{alarmId}/acknowledge")
    public ResponseEntity<NetworkAlarm> acknowledgeAlarm(
            @PathVariable Long alarmId,
            @RequestParam Long userId
    ) {
        return ResponseEntity.ok(service.acknowledgeAlarm(alarmId, userId));
    }

    @PostMapping("/{alarmId}/clear")
    public ResponseEntity<NetworkAlarm> clearAlarm(@PathVariable Long alarmId) {
        return ResponseEntity.ok(service.clearAlarm(alarmId));
    }

    @PostMapping
    public ResponseEntity<NetworkAlarm> createAlarm(@RequestBody NetworkAlarm alarm) {
        return ResponseEntity.ok(service.createAlarm(alarm));
    }
}
