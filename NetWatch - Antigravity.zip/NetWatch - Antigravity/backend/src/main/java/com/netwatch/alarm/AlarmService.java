package com.netwatch.alarm;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

import com.netwatch.auth.UserRepository;
import com.netwatch.auth.User;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AlarmService {
    private final NetworkAlarmRepository alarmRepository;
    private final UserRepository userRepository;

    public List<NetworkAlarm> getActiveAlarms() {
        return alarmRepository.findAll();
    }

    public NetworkAlarm acknowledgeAlarm(Long alarmId, Long userId) {
        NetworkAlarm alarm = alarmRepository.findById(alarmId)
                .orElseThrow(() -> new RuntimeException("Alarm not found: " + alarmId));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found: " + userId));

        alarm.setAcknowledgedBy(user);
        alarm.setAcknowledgedTime(LocalDateTime.now());
        alarm.setStatus(NetworkAlarm.AlarmStatus.Acknowledged);
        return alarmRepository.save(alarm);
    }

    public NetworkAlarm clearAlarm(Long alarmId) {
        NetworkAlarm alarm = alarmRepository.findById(alarmId)
                .orElseThrow(() -> new RuntimeException("Alarm not found: " + alarmId));
        alarm.setClearedTime(LocalDateTime.now());
        alarm.setStatus(NetworkAlarm.AlarmStatus.Cleared);
        return alarmRepository.save(alarm);
    }

    public NetworkAlarm createAlarm(NetworkAlarm alarm) {
        if (alarm.getStatus() == null) {
            alarm.setStatus(NetworkAlarm.AlarmStatus.Active);
        }
        if (alarm.getAlarmTime() == null) {
            alarm.setAlarmTime(LocalDateTime.now());
        }
        return alarmRepository.save(alarm);
    }
}
