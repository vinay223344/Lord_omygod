package com.netwatch.provisioning;

import com.netwatch.auth.User;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "provisioning_requests")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProvisioningRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long provisionId;

    @ManyToOne
    @JoinColumn(name = "circuit_id")
    private Circuit circuit;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RequestType requestType;

    @ManyToOne
    @JoinColumn(name = "requested_by_id")
    private User requestedBy;

    private LocalDateTime requestDate;
    private LocalDateTime completedDate;

    @Enumerated(EnumType.STRING)
    private ProvisionStatus status;

    public enum RequestType {
        NewActivation, BandwidthUpgrade, Suspension, Termination
    }

    public enum ProvisionStatus {
        Pending, InProgress, Completed, Rejected
    }

    @PrePersist
    protected void onCreate() {
        if (requestDate == null) {
            requestDate = LocalDateTime.now();
        }
        if (status == null) {
            status = ProvisionStatus.Pending;
        }
    }
}
