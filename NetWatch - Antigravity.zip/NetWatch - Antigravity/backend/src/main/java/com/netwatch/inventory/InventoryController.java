package com.netwatch.inventory;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/inventory")
@RequiredArgsConstructor
public class InventoryController {
    private final InventoryService service;

    @GetMapping("/sites")
    public ResponseEntity<List<NetworkSite>> getAllSites() {
        return ResponseEntity.ok(service.getAllSites());
    }

    @PostMapping("/sites")
    public ResponseEntity<NetworkSite> createSite(@RequestBody NetworkSite site) {
        return ResponseEntity.ok(service.createSite(site));
    }

    @GetMapping("/elements")
    public ResponseEntity<List<NetworkElement>> getAllElements() {
        return ResponseEntity.ok(service.getAllElements());
    }

    @PostMapping("/elements")
    public ResponseEntity<NetworkElement> createElement(@RequestBody NetworkElement element) {
        return ResponseEntity.ok(service.createElement(element));
    }

    @GetMapping("/links")
    public ResponseEntity<List<TopologyLink>> getAllLinks() {
        return ResponseEntity.ok(service.getAllLinks());
    }

    @PostMapping("/links")
    public ResponseEntity<TopologyLink> createLink(@RequestBody TopologyLink link) {
        return ResponseEntity.ok(service.createLink(link));
    }
}
