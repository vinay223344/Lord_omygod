package com.netwatch.inventory;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Entity
@Table(name = "topology_links")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TopologyLink {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long linkId;

    @ManyToOne
    @JoinColumn(name = "element_a_id")
    private NetworkElement elementA;

    @ManyToOne
    @JoinColumn(name = "element_b_id")
    private NetworkElement elementB;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private LinkType linkType;

    private Integer capacityMbps;

    @Column(precision = 5, scale = 2)
    private BigDecimal utilisationPercent;

    @Enumerated(EnumType.STRING)
    private LinkStatus status;

    public enum LinkType {
        Fibre, Microwave, Ethernet, SDH
    }

    public enum LinkStatus {
        Active, Degraded, Down
    }
}
