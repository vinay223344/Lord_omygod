package com.netwatch.maintenance;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class CapacityService {
    private final CapacityRecordRepository capacityRepository;

    public List<CapacityRecord> getAllCapacityRecords() {
        return capacityRepository.findAll();
    }

    public CapacityRecord createCapacityRecord(CapacityRecord record) {
        return capacityRepository.save(record);
    }
}
