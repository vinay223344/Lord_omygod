package com.netwatch.maintenance;

import com.netwatch.inventory.NetworkElement;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "capacity_records")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CapacityRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long capacityId;

    @ManyToOne
    @JoinColumn(name = "element_id")
    private NetworkElement element;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private MetricType metricType;

    private BigDecimal peakValue;
    private BigDecimal averageValue;
    private BigDecimal thresholdPercent;
    private LocalDate recordedDate;

    @Enumerated(EnumType.STRING)
    private CapacityStatus status;

    public enum MetricType {
        LinkUtilisation, CPULoad, MemoryUsage, StorageUsage
    }

    public enum CapacityStatus {
        Normal, Warning, Critical
    }
}
