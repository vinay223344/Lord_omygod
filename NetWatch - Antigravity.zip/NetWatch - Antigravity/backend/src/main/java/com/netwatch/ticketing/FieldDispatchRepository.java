package com.netwatch.ticketing;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FieldDispatchRepository extends JpaRepository<FieldDispatch, Long> {
}
