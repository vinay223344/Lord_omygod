package com.netwatch.ticketing;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

import com.netwatch.auth.UserRepository;
import com.netwatch.auth.User;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class TroubleTicketService {
    private final TroubleTicketRepository ticketRepository;
    private final FieldDispatchRepository dispatchRepository;
    private final UserRepository userRepository;

    public List<TroubleTicket> getAllTickets() {
        return ticketRepository.findAll();
    }

    public TroubleTicket createTicket(TroubleTicket ticket) {
        if (ticket.getStatus() == null) {
            ticket.setStatus(TroubleTicket.TicketStatus.Open);
        }
        if (ticket.getRaisedDateTime() == null) {
            ticket.setRaisedDateTime(LocalDateTime.now());
        }
        return ticketRepository.save(ticket);
    }

    public TroubleTicket assignTicket(Long ticketId, Long userId) {
        TroubleTicket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new RuntimeException("Ticket not found: " + ticketId));
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found: " + userId));

        ticket.setAssignedNocEngineer(user);
        ticket.setStatus(TroubleTicket.TicketStatus.Assigned);
        return ticketRepository.save(ticket);
    }

    public FieldDispatch dispatchEngineer(FieldDispatch dispatch) {
        if (dispatch.getDispatchTime() == null) {
            dispatch.setDispatchTime(LocalDateTime.now());
        }
        if (dispatch.getStatus() == null) {
            dispatch.setStatus(FieldDispatch.DispatchStatus.Dispatched);
        }
        
        FieldDispatch savedDispatch = dispatchRepository.save(dispatch);

        // Update ticket status
        TroubleTicket ticket = ticketRepository.findById(dispatch.getTicket().getTicketId())
                .orElseThrow(() -> new RuntimeException("Ticket not found"));
        ticket.setStatus(TroubleTicket.TicketStatus.FieldDispatched);
        ticketRepository.save(ticket);

        return savedDispatch;
    }

    public FieldDispatch updateDispatchStatus(Long dispatchId, String status, String summary) {
        FieldDispatch dispatch = dispatchRepository.findById(dispatchId)
                .orElseThrow(() -> new RuntimeException("Dispatch not found: " + dispatchId));
        
        FieldDispatch.DispatchStatus newStatus = FieldDispatch.DispatchStatus.valueOf(status);
        dispatch.setStatus(newStatus);
        
        if (newStatus == FieldDispatch.DispatchStatus.OnSite) {
            dispatch.setSiteArrivalTime(LocalDateTime.now());
        } else if (newStatus == FieldDispatch.DispatchStatus.Resolved) {
            dispatch.setRestorationTime(LocalDateTime.now());
            dispatch.setResolutionSummary(summary);
            
            // Also resolve ticket
            TroubleTicket ticket = dispatch.getTicket();
            ticket.setStatus(TroubleTicket.TicketStatus.Resolved);
            ticket.setRestoredDateTime(LocalDateTime.now());
            ticketRepository.save(ticket);
        }

        return dispatchRepository.save(dispatch);
    }

    public TroubleTicket updateTicketStatus(Long ticketId, String status, String resolutionSummary) {
        TroubleTicket ticket = ticketRepository.findById(ticketId)
                .orElseThrow(() -> new RuntimeException("Ticket not found: " + ticketId));
        
        TroubleTicket.TicketStatus newStatus = TroubleTicket.TicketStatus.valueOf(status);
        ticket.setStatus(newStatus);
        
        if (newStatus == TroubleTicket.TicketStatus.Resolved || newStatus == TroubleTicket.TicketStatus.Closed) {
            ticket.setRestoredDateTime(LocalDateTime.now());
        }
        
        return ticketRepository.save(ticket);
    }

    public List<FieldDispatch> getAllDispatches() {
        return dispatchRepository.findAll();
    }
}
