package com.netwatch.provisioning;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProvisioningRequestRepository extends JpaRepository<ProvisioningRequest, Long> {
}
