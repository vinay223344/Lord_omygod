package com.netwatch.inventory;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class InventoryService {
    private final NetworkSiteRepository siteRepository;
    private final NetworkElementRepository elementRepository;
    private final TopologyLinkRepository linkRepository;

    public List<NetworkSite> getAllSites() {
        return siteRepository.findAll();
    }

    public NetworkSite createSite(NetworkSite site) {
        return siteRepository.save(site);
    }

    public List<NetworkElement> getAllElements() {
        return elementRepository.findAll();
    }

    public NetworkElement createElement(NetworkElement element) {
        return elementRepository.save(element);
    }

    public List<TopologyLink> getAllLinks() {
        return linkRepository.findAll();
    }

    public TopologyLink createLink(TopologyLink link) {
        return linkRepository.save(link);
    }
}
