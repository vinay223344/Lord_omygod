package com.netwatch.alarm;

import com.netwatch.auth.User;
import com.netwatch.inventory.NetworkElement;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "network_alarms")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NetworkAlarm {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long alarmId;

    @ManyToOne
    @JoinColumn(name = "element_id")
    private NetworkElement element;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AlarmType alarmType;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Severity severity;

    private LocalDateTime alarmTime;

    @ManyToOne
    @JoinColumn(name = "acknowledged_by_id")
    private User acknowledgedBy;

    private LocalDateTime acknowledgedTime;
    private LocalDateTime clearedTime;

    @Enumerated(EnumType.STRING)
    private AlarmStatus status;

    public enum AlarmType {
        LinkDown, NodeUnreachable, HighUtilisation, PowerFailure, HardwareFault, CoolingAlert
    }

    public enum Severity {
        Critical, Major, Minor, Warning
    }

    public enum AlarmStatus {
        Active, Acknowledged, Cleared, Suppressed
    }

    @PrePersist
    protected void onCreate() {
        if (alarmTime == null) {
            alarmTime = LocalDateTime.now();
        }
        if (status == null) {
            status = AlarmStatus.Active;
        }
    }
}
