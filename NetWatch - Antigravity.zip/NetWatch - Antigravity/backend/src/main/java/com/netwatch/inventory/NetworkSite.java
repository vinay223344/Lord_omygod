package com.netwatch.inventory;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "network_sites")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NetworkSite {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long siteId;

    @Column(nullable = false)
    private String siteName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SiteType siteType;

    private String address;
    private String regionId;

    @Enumerated(EnumType.STRING)
    private SiteStatus status;

    public enum SiteType {
        DataCentre, Exchange, Tower, POP, RemoteNode
    }

    public enum SiteStatus {
        Active, Inactive
    }
}
