package com.netwatch.maintenance;

import com.netwatch.auth.User;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "maintenance_windows")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MaintenanceWindow {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long maintenanceId;

    @Column(nullable = false)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String affectedElementIds;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private MaintenanceType maintenanceType;

    private LocalDateTime startDateTime;
    private LocalDateTime endDateTime;

    @ManyToOne
    @JoinColumn(name = "requested_by_id")
    private User requestedBy;

    @ManyToOne
    @JoinColumn(name = "approved_by_id")
    private User approvedBy;

    @Column(columnDefinition = "TEXT")
    private String rollbackPlan;

    @Enumerated(EnumType.STRING)
    private MaintenanceStatus status;

    public enum MaintenanceType {
        Planned, Emergency
    }

    public enum MaintenanceStatus {
        Pending, Approved, InProgress, Completed, Cancelled
    }
}
