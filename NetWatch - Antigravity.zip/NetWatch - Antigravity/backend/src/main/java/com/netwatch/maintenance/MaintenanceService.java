package com.netwatch.maintenance;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

import com.netwatch.auth.UserRepository;
import com.netwatch.auth.User;

@Service
@RequiredArgsConstructor
public class MaintenanceService {
    private final MaintenanceWindowRepository maintenanceRepository;
    private final UserRepository userRepository;

    public List<MaintenanceWindow> getAllWindows() {
        return maintenanceRepository.findAll();
    }

    public MaintenanceWindow createWindow(MaintenanceWindow window) {
        if (window.getStatus() == null) {
            window.setStatus(MaintenanceWindow.MaintenanceStatus.Pending);
        }
        return maintenanceRepository.save(window);
    }

    public MaintenanceWindow approveWindow(Long id, Long approverId) {
        MaintenanceWindow window = maintenanceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Window not found: " + id));
        User user = userRepository.findById(approverId)
                .orElseThrow(() -> new RuntimeException("User not found: " + approverId));
        
        window.setApprovedBy(user);
        window.setStatus(MaintenanceWindow.MaintenanceStatus.Approved);
        return maintenanceRepository.save(window);
    }

    public MaintenanceWindow updateWindowStatus(Long id, String status) {
        MaintenanceWindow window = maintenanceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Window not found: " + id));
        
        window.setStatus(MaintenanceWindow.MaintenanceStatus.valueOf(status));
        return maintenanceRepository.save(window);
    }
}
