package com.netwatch.common;

public enum Role {
    NOCEngineer,
    FieldEngineer,
    PlanningEngineer,
    ServiceDesk,
    ChangeManager,
    Admin
}
