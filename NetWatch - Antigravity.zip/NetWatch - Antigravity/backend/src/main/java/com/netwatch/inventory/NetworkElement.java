package com.netwatch.inventory;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "network_elements")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NetworkElement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long elementId;

    @Column(nullable = false)
    private String elementName;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ElementType elementType;

    private String vendor;
    private String model;
    private String ipAddress;

    @ManyToOne
    @JoinColumn(name = "site_id")
    private NetworkSite site;

    private String regionId;

    @Enumerated(EnumType.STRING)
    private ManagementStatus managementStatus;

    @Enumerated(EnumType.STRING)
    private ElementStatus status;

    public enum ElementType {
        Router, Switch, Firewall, OLT, BTS, Transmission, Server
    }

    public enum ManagementStatus {
        Managed, Unmanaged
    }

    public enum ElementStatus {
        Active, Maintenance, Decommissioned
    }
}
