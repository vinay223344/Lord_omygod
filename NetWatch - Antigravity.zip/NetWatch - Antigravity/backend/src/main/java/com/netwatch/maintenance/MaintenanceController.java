package com.netwatch.maintenance;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/v1/maintenance")
@RequiredArgsConstructor
public class MaintenanceController {
    private final MaintenanceService maintenanceService;
    private final CapacityService capacityService;

    @GetMapping("/windows")
    public ResponseEntity<List<MaintenanceWindow>> getAllWindows() {
        return ResponseEntity.ok(maintenanceService.getAllWindows());
    }

    @PostMapping("/windows")
    public ResponseEntity<MaintenanceWindow> createWindow(@RequestBody MaintenanceWindow window) {
        return ResponseEntity.ok(maintenanceService.createWindow(window));
    }

    @PostMapping("/windows/{id}/approve")
    public ResponseEntity<MaintenanceWindow> approveWindow(@PathVariable Long id, @RequestParam Long approverId) {
        return ResponseEntity.ok(maintenanceService.approveWindow(id, approverId));
    }

    @PostMapping("/windows/{id}/status")
    public ResponseEntity<MaintenanceWindow> updateWindowStatus(@PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(maintenanceService.updateWindowStatus(id, status));
    }

    @GetMapping("/capacity")
    public ResponseEntity<List<CapacityRecord>> getAllCapacityRecords() {
        return ResponseEntity.ok(capacityService.getAllCapacityRecords());
    }

    @PostMapping("/capacity")
    public ResponseEntity<CapacityRecord> createCapacityRecord(@RequestBody CapacityRecord record) {
        return ResponseEntity.ok(capacityService.createCapacityRecord(record));
    }
}
