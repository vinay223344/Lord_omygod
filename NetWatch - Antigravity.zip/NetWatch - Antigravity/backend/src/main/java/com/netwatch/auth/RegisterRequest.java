package com.netwatch.auth;

import com.netwatch.common.Role;
import com.netwatch.common.UserStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequest {
    private String name;
    private String email;
    private String password;
    private Role role;
    private UserStatus status;
    private String regionId;
    private String phone;
    private String shiftGroup;
}
