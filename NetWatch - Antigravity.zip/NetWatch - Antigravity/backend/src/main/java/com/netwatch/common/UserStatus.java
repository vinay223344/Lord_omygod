package com.netwatch.common;

public enum UserStatus {
    Active,
    Inactive,
    OnShift
}
