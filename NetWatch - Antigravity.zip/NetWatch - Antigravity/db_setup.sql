-- NetWatch Database Setup Script
CREATE DATABASE IF NOT EXISTS netwatch;
USE netwatch;

-- User Table
CREATE TABLE users (
    user_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    role ENUM('NOCEngineer', 'FieldEngineer', 'PlanningEngineer', 'ServiceDesk', 'ChangeManager', 'Admin') NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    region_id VARCHAR(50),
    shift_group VARCHAR(50),
    status ENUM('Active', 'Inactive', 'OnShift') DEFAULT 'Active',
    password VARCHAR(255) NOT NULL
);

-- Network Site
CREATE TABLE network_sites (
    site_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    site_name VARCHAR(255) NOT NULL,
    site_type ENUM('DataCentre', 'Exchange', 'Tower', 'POP', 'RemoteNode') NOT NULL,
    address TEXT,
    region_id VARCHAR(50),
    status ENUM('Active', 'Inactive') DEFAULT 'Active'
);

-- Network Element
CREATE TABLE network_elements (
    element_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    element_name VARCHAR(255) NOT NULL,
    element_type ENUM('Router', 'Switch', 'Firewall', 'OLT', 'BTS', 'Transmission', 'Server') NOT NULL,
    vendor VARCHAR(100),
    model VARCHAR(100),
    ip_address VARCHAR(45),
    site_id BIGINT,
    region_id VARCHAR(50),
    management_status ENUM('Managed', 'Unmanaged') DEFAULT 'Managed',
    status ENUM('Active', 'Maintenance', 'Decommissioned') DEFAULT 'Active',
    FOREIGN KEY (site_id) REFERENCES network_sites(site_id)
);

-- Topology Link
CREATE TABLE topology_links (
    link_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    element_a_id BIGINT,
    element_b_id BIGINT,
    link_type ENUM('Fibre', 'Microwave', 'Ethernet', 'SDH') NOT NULL,
    capacity_mbps INT,
    utilisation_percent DECIMAL(5,2),
    status ENUM('Active', 'Degraded', 'Down') DEFAULT 'Active',
    FOREIGN KEY (element_a_id) REFERENCES network_elements(element_id),
    FOREIGN KEY (element_b_id) REFERENCES network_elements(element_id)
);

-- Network Alarm
CREATE TABLE network_alarms (
    alarm_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    element_id BIGINT,
    alarm_type ENUM('LinkDown', 'NodeUnreachable', 'HighUtilisation', 'PowerFailure', 'HardwareFault', 'CoolingAlert') NOT NULL,
    severity ENUM('Critical', 'Major', 'Minor', 'Warning') NOT NULL,
    alarm_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    acknowledged_by_id BIGINT,
    acknowledged_time TIMESTAMP NULL,
    cleared_time TIMESTAMP NULL,
    status ENUM('Active', 'Acknowledged', 'Cleared', 'Suppressed') DEFAULT 'Active',
    FOREIGN KEY (element_id) REFERENCES network_elements(element_id),
    FOREIGN KEY (acknowledged_by_id) REFERENCES users(user_id)
);

-- Trouble Ticket
CREATE TABLE trouble_tickets (
    ticket_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    alarm_id BIGINT,
    element_id BIGINT,
    site_id BIGINT,
    category ENUM('LinkFault', 'NodeFault', 'PowerIssue', 'Congestion', 'ConfigError') NOT NULL,
    priority ENUM('P1', 'P2', 'P3', 'P4') NOT NULL,
    assigned_noc_engineer_id BIGINT,
    raised_date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    restoration_sla_time TIMESTAMP NULL,
    restored_date_time TIMESTAMP NULL,
    status ENUM('Open', 'Assigned', 'FieldDispatched', 'Resolved', 'Closed', 'Escalated') DEFAULT 'Open',
    FOREIGN KEY (alarm_id) REFERENCES network_alarms(alarm_id),
    FOREIGN KEY (element_id) REFERENCES network_elements(element_id),
    FOREIGN KEY (site_id) REFERENCES network_sites(site_id),
    FOREIGN KEY (assigned_noc_engineer_id) REFERENCES users(user_id)
);

-- Field Dispatch
CREATE TABLE field_dispatches (
    dispatch_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    ticket_id BIGINT,
    field_engineer_id BIGINT,
    dispatch_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    site_arrival_time TIMESTAMP NULL,
    restoration_time TIMESTAMP NULL,
    resolution_summary TEXT,
    status ENUM('Dispatched', 'OnSite', 'Resolved', 'CannotRepair') DEFAULT 'Dispatched',
    FOREIGN KEY (ticket_id) REFERENCES trouble_tickets(ticket_id),
    FOREIGN KEY (field_engineer_id) REFERENCES users(user_id)
);

-- Circuit
CREATE TABLE circuits (
    circuit_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    circuit_reference VARCHAR(100) UNIQUE NOT NULL,
    service_type ENUM('Leased Line', 'VPN', 'Internet', 'Voice', 'MPLS') NOT NULL,
    customer_id VARCHAR(100),
    bandwidth_mbps INT,
    route_path TEXT,
    activation_date DATE,
    status ENUM('Active', 'Suspended', 'Decommissioned') DEFAULT 'Active'
);

-- Provisioning Request
CREATE TABLE provisioning_requests (
    provision_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    circuit_id BIGINT,
    request_type ENUM('NewActivation', 'BandwidthUpgrade', 'Suspension', 'Termination') NOT NULL,
    requested_by_id BIGINT,
    request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_date TIMESTAMP NULL,
    status ENUM('Pending', 'InProgress', 'Completed', 'Rejected') DEFAULT 'Pending',
    FOREIGN KEY (circuit_id) REFERENCES circuits(circuit_id),
    FOREIGN KEY (requested_by_id) REFERENCES users(user_id)
);

-- Capacity Record
CREATE TABLE capacity_records (
    capacity_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    element_id BIGINT,
    metric_type ENUM('LinkUtilisation', 'CPULoad', 'MemoryUsage', 'StorageUsage') NOT NULL,
    peak_value DECIMAL(10,2),
    average_value DECIMAL(10,2),
    threshold_percent DECIMAL(5,2),
    recorded_date DATE,
    status ENUM('Normal', 'Warning', 'Critical') DEFAULT 'Normal',
    FOREIGN KEY (element_id) REFERENCES network_elements(element_id)
);

-- Maintenance Window
CREATE TABLE maintenance_windows (
    maintenance_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    affected_element_ids TEXT, -- Comma separated IDs
    maintenance_type ENUM('Planned', 'Emergency') NOT NULL,
    start_date_time TIMESTAMP NOT NULL,
    end_date_time TIMESTAMP NOT NULL,
    requested_by_id BIGINT,
    approved_by_id BIGINT,
    rollback_plan TEXT,
    status ENUM('Pending', 'Approved', 'InProgress', 'Completed', 'Cancelled') DEFAULT 'Pending',
    FOREIGN KEY (requested_by_id) REFERENCES users(user_id),
    FOREIGN KEY (approved_by_id) REFERENCES users(user_id)
);

-- Notifications
CREATE TABLE notifications (
    notification_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT,
    message TEXT NOT NULL,
    category ENUM('Alarm', 'Ticket', 'Dispatch', 'Maintenance', 'Capacity', 'SLA') NOT NULL,
    status ENUM('Unread', 'Read', 'Dismissed') DEFAULT 'Unread',
    created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Audit Log
CREATE TABLE audit_logs (
    audit_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT,
    action VARCHAR(255) NOT NULL,
    entity_type VARCHAR(100),
    record_id BIGINT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);
