import React, { useEffect, useState } from 'react';
import API from '../api';
import { AlertTriangle, Radio } from 'lucide-react';

export default function Alarms() {
  const [alarms, setAlarms] = useState<any[]>([]);
  const [elements, setElements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Inject mock alarm state
  const [selectedElementId, setSelectedElementId] = useState('');
  const [alarmType, setAlarmType] = useState('LinkDown');
  const [severity, setSeverity] = useState('Critical');

  // Load current user
  const user = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    fetchAlarmsAndElements();
    const interval = setInterval(fetchAlarms, 8000);
    return () => clearInterval(interval);
  }, []);

  const fetchAlarms = async () => {
    try {
      const response = await API.get('/api/v1/alarms');
      setAlarms(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchAlarmsAndElements = async () => {
    setLoading(true);
    try {
      const [alarmRes, elRes] = await Promise.all([
        API.get('/api/v1/alarms'),
        API.get('/api/v1/inventory/elements')
      ]);
      setAlarms(alarmRes.data);
      setElements(elRes.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleAcknowledge = async (alarmId: number) => {
    try {
      await API.post(`/api/v1/alarms/${alarmId}/acknowledge?userId=${user.userId}`);
      fetchAlarms();
    } catch (error) {
      console.error(error);
      alert('Failed to acknowledge alarm');
    }
  };

  const handleClear = async (alarmId: number) => {
    try {
      await API.post(`/api/v1/alarms/${alarmId}/clear`);
      fetchAlarms();
    } catch (error) {
      console.error(error);
      alert('Failed to clear alarm');
    }
  };

  const handleSimulateAlarm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedElementId) {
      alert('Please select an element');
      return;
    }

    try {
      await API.post('/api/v1/alarms', {
        element: { elementId: parseInt(selectedElementId) },
        alarmType,
        severity,
        status: 'Active'
      });
      fetchAlarms();
      // Send notification alert to system mock
      await API.post('/api/v1/notifications', {
        user: user.userId ? { userId: user.userId } : null,
        message: `SYSTEM ALERT: [${severity}] ${alarmType} raised on element #${selectedElementId}`,
        category: 'Alarm',
        status: 'Unread'
      });
      setSelectedElementId('');
    } catch (error) {
      console.error(error);
      alert('Failed to inject simulated alarm');
    }
  };

  if (loading) {
    return <div style={{ display: 'flex', justifyContent: 'center', padding: '3rem' }}>Loading Network Alarms...</div>;
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '2.5fr 1fr', gap: '1.5rem' }}>
      
      {/* Alarm list */}
      <div className="glass-panel">
        <div className="glass-panel-title">
          <span>Live Fault Monitoring Board</span>
          <span style={{ fontSize: '0.85rem', color: 'var(--accent-red)', animation: 'pulse 1.5s infinite' }}>
            <Radio size={14} style={{ marginRight: '0.25rem', verticalAlign: 'middle' }} /> Active Feeds
          </span>
        </div>

        <div className="table-container">
          <table className="glass-table">
            <thead>
              <tr>
                <th>Severity</th>
                <th>Element</th>
                <th>IP Address</th>
                <th>Alarm Type</th>
                <th>Raised Time</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {alarms.map((alarm) => {
                let sevClass = 'status-warning';
                if (alarm.severity === 'Critical') sevClass = 'status-critical';
                if (alarm.severity === 'Minor' || alarm.severity === 'Warning') sevClass = 'status-warning';

                return (
                  <tr key={alarm.alarmId}>
                    <td>
                      <span className={`status-pill ${sevClass}`}>
                        {alarm.severity}
                      </span>
                    </td>
                    <td style={{ fontWeight: 600 }}>{alarm.element?.elementName}</td>
                    <td>{alarm.element?.ipAddress}</td>
                    <td>{alarm.alarmType}</td>
                    <td>{new Date(alarm.alarmTime).toLocaleString()}</td>
                    <td>
                      <span className={`status-pill ${alarm.status === 'Active' ? 'status-critical' : alarm.status === 'Acknowledged' ? 'status-acknowledged' : 'status-active'}`}>
                        {alarm.status}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: '0.5rem' }}>
                        {alarm.status === 'Active' && (
                          <button onClick={() => handleAcknowledge(alarm.alarmId)} className="btn-secondary" style={{ padding: '0.3rem 0.6rem', fontSize: '0.75rem', borderColor: 'var(--accent-blue)', color: 'var(--accent-blue)' }}>
                            Acknowledge
                          </button>
                        )}
                        {alarm.status !== 'Cleared' && (
                          <button onClick={() => handleClear(alarm.alarmId)} className="btn-secondary" style={{ padding: '0.3rem 0.6rem', fontSize: '0.75rem', borderColor: 'var(--accent-green)', color: 'var(--accent-green)' }}>
                            Clear
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {alarms.length === 0 && (
                <tr>
                  <td colSpan={7} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                    No alarms reported in this monitoring cycle. Uptime is nominal.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Simulator Panel */}
      <div className="glass-panel">
        <div className="glass-panel-title">
          <AlertTriangle size={18} style={{ marginRight: '0.5rem', color: 'var(--accent-red)' }} /> Fault Injector
        </div>
        <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '1.25rem' }}>
          Inject a mock alarm incident to test NOC correlation, ticket triggers, and in-app updates.
        </p>

        <form onSubmit={handleSimulateAlarm} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <div className="form-group">
            <label>Target Element</label>
            <select className="glass-select" required value={selectedElementId} onChange={(e) => setSelectedElementId(e.target.value)}>
              <option value="">-- Select Element --</option>
              {elements.map((el) => (
                <option key={el.elementId} value={el.elementId}>
                  {el.elementName} ({el.ipAddress})
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Alarm Event Type</label>
            <select className="glass-select" value={alarmType} onChange={(e) => setAlarmType(e.target.value)}>
              <option value="LinkDown">Link Down</option>
              <option value="NodeUnreachable">Node Unreachable</option>
              <option value="HighUtilisation">High Utilisation</option>
              <option value="PowerFailure">Power Failure</option>
              <option value="HardwareFault">Hardware Fault</option>
              <option value="CoolingAlert">Cooling Alert</option>
            </select>
          </div>

          <div className="form-group">
            <label>Severity Level</label>
            <select className="glass-select" value={severity} onChange={(e) => setSeverity(e.target.value)}>
              <option value="Critical">Critical Outage</option>
              <option value="Major">Major Degradation</option>
              <option value="Minor">Minor Incident</option>
              <option value="Warning">Warning Flag</option>
            </select>
          </div>

          <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: '0.5rem', background: 'linear-gradient(135deg, var(--accent-orange), var(--accent-red))' }}>
            Trigger Incident
          </button>
        </form>
      </div>

    </div>
  );
}
