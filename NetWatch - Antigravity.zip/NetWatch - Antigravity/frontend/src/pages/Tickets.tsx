import { useEffect, useState } from 'react';
import API from '../api';
import { Plus, UserCheck, Send, Wrench } from 'lucide-react';

export default function Tickets() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [dispatches, setDispatches] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [elements, setElements] = useState<any[]>([]);
  const [sites, setSites] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal / Form state
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedElementId, setSelectedElementId] = useState('');
  const [selectedSiteId, setSelectedSiteId] = useState('');
  const [category, setCategory] = useState('NodeFault');
  const [priority, setPriority] = useState('P2');

  // Assignee states
  const [assignNocId, setAssignNocId] = useState<Record<number, string>>({});
  const [dispatchEngId, setDispatchEngId] = useState<Record<number, string>>({});

  useEffect(() => {
    fetchTicketsAndUsers();
  }, []);

  const fetchTicketsAndUsers = async () => {
    setLoading(true);
    try {
      const [ticketsRes, usersRes, elementsRes, sitesRes, dispatchesRes] = await Promise.all([
        API.get('/api/v1/tickets'),
        API.get('/api/v1/users'),
        API.get('/api/v1/inventory/elements'),
        API.get('/api/v1/inventory/sites'),
        API.get('/api/v1/tickets/dispatches'),
      ]);
      setTickets(ticketsRes.data);
      setUsers(usersRes.data);
      setElements(elementsRes.data);
      setSites(sitesRes.data);
      setDispatches(dispatchesRes.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await API.post('/api/v1/tickets', {
        element: selectedElementId ? { elementId: parseInt(selectedElementId) } : null,
        site: selectedSiteId ? { siteId: parseInt(selectedSiteId) } : null,
        category,
        priority,
        status: 'Open',
      });
      setShowCreateForm(false);
      fetchTicketsAndUsers();
    } catch (error) {
      console.error(error);
      alert('Error creating ticket');
    }
  };

  const handleAssignNoc = async (ticketId: number) => {
    const userId = assignNocId[ticketId];
    if (!userId) return;

    try {
      await API.post(`/api/v1/tickets/${ticketId}/assign?userId=${userId}`);
      fetchTicketsAndUsers();
    } catch (error) {
      console.error(error);
      alert('Error assigning ticket');
    }
  };

  const handleDispatchField = async (ticketId: number) => {
    const engId = dispatchEngId[ticketId];
    if (!engId) return;

    try {
      await API.post('/api/v1/tickets/dispatch', {
        ticket: { ticketId },
        fieldEngineer: { userId: parseInt(engId) },
        status: 'Dispatched',
      });
      fetchTicketsAndUsers();
    } catch (error) {
      console.error(error);
      alert('Error dispatching engineer');
    }
  };

  const handleUpdateDispatchStatus = async (dispatchId: number, status: string, summary?: string) => {
    try {
      await API.post(`/api/v1/tickets/dispatches/${dispatchId}/status?status=${status}&summary=${summary || ''}`);
      fetchTicketsAndUsers();
    } catch (error) {
      console.error(error);
      alert('Error updating status');
    }
  };

  const nocEngineers = users.filter((u) => u.role === 'NOCEngineer' || u.role === 'Admin');
  const fieldEngineers = users.filter((u) => u.role === 'FieldEngineer');

  if (loading) {
    return <div style={{ display: 'flex', justifyContent: 'center', padding: '3rem' }}>Loading Ticket Board...</div>;
  }

  return (
    <div>
      {/* Title */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
        <h2>Incident Tickets & Field Operations</h2>
        <button onClick={() => setShowCreateForm(!showCreateForm)} className="btn-primary">
          <Plus size={16} /> Log Trouble Ticket
        </button>
      </div>

      {/* Manual Create form */}
      {showCreateForm && (
        <div className="glass-panel" style={{ maxWidth: '600px', marginBottom: '2rem' }}>
          <div className="glass-panel-title">Log New Ticket</div>
          <form onSubmit={handleCreateTicket} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div className="form-grid">
              <div className="form-group">
                <label>Affected Element</label>
                <select className="glass-select" value={selectedElementId} onChange={(e) => setSelectedElementId(e.target.value)}>
                  <option value="">-- None --</option>
                  {elements.map((el) => (
                    <option key={el.elementId} value={el.elementId}>
                      {el.elementName} ({el.ipAddress})
                    </option>
                  ))}
                </select>
              </div>

              <div className="form-group">
                <label>Affected Site</label>
                <select className="glass-select" value={selectedSiteId} onChange={(e) => setSelectedSiteId(e.target.value)}>
                  <option value="">-- None --</option>
                  {sites.map((site) => (
                    <option key={site.siteId} value={site.siteId}>
                      {site.siteName}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="form-grid">
              <div className="form-group">
                <label>Category</label>
                <select className="glass-select" value={category} onChange={(e) => setCategory(e.target.value)}>
                  <option value="LinkFault">Link Fault</option>
                  <option value="NodeFault">Node Fault</option>
                  <option value="PowerIssue">Power Issue</option>
                  <option value="Congestion">Congestion</option>
                  <option value="ConfigError">Config Error</option>
                </select>
              </div>

              <div className="form-group">
                <label>Priority</label>
                <select className="glass-select" value={priority} onChange={(e) => setPriority(e.target.value)}>
                  <option value="P1">P1 (Critical Outage)</option>
                  <option value="P2">P2 (Major Fault)</option>
                  <option value="P3">P3 (Minor Issue)</option>
                  <option value="P4">P4 (General Request)</option>
                </select>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
              <button type="submit" className="btn-primary">
                Log Ticket
              </button>
              <button type="button" onClick={() => setShowCreateForm(false)} className="btn-secondary">
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tables layout */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '1.5rem' }}>
        
        {/* Ticket Board */}
        <div className="glass-panel">
          <div className="glass-panel-title">Tickets Queue</div>
          <div className="table-container">
            <table className="glass-table">
              <thead>
                <tr>
                  <th>Ticket</th>
                  <th>Category</th>
                  <th>Priority</th>
                  <th>Element/Site</th>
                  <th>NOC Assigned</th>
                  <th>Logged Date</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {tickets.map((t) => {
                  let priClass = 'status-warning';
                  if (t.priority === 'P1') priClass = 'status-critical';
                  if (t.priority === 'P2') priClass = 'status-warning';
                  if (t.priority === 'P3' || t.priority === 'P4') priClass = 'status-active';

                  return (
                    <tr key={t.ticketId}>
                      <td style={{ fontWeight: 600 }}>TKT-{t.ticketId}</td>
                      <td>{t.category}</td>
                      <td>
                        <span className={`status-pill ${priClass}`}>
                          {t.priority}
                        </span>
                      </td>
                      <td>
                        {t.element ? `${t.element.elementName} (${t.element.ipAddress})` : ''}
                        {t.site ? ` @ ${t.site.siteName}` : ''}
                      </td>
                      <td>{t.assignedNocEngineer?.name || 'Unassigned'}</td>
                      <td>{new Date(t.raisedDateTime).toLocaleString()}</td>
                      <td>
                        <span className={`status-pill ${t.status === 'Open' ? 'status-critical' : t.status === 'Resolved' || t.status === 'Closed' ? 'status-active' : 'status-acknowledged'}`}>
                          {t.status}
                        </span>
                      </td>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                          {t.status === 'Open' && (
                            <div style={{ display: 'flex', gap: '0.25rem' }}>
                              <select
                                className="glass-select"
                                style={{ padding: '0.2rem 0.5rem', width: '130px', fontSize: '0.8rem' }}
                                value={assignNocId[t.ticketId] || ''}
                                onChange={(e) => setAssignNocId({ ...assignNocId, [t.ticketId]: e.target.value })}
                              >
                                <option value="">-- Assign NOC --</option>
                                {nocEngineers.map((u) => (
                                  <option key={u.userId} value={u.userId}>
                                    {u.name}
                                  </option>
                                ))}
                              </select>
                              <button onClick={() => handleAssignNoc(t.ticketId)} className="btn-secondary" style={{ padding: '0.3rem' }}>
                                <UserCheck size={14} />
                              </button>
                            </div>
                          )}

                          {t.status === 'Assigned' && (
                            <div style={{ display: 'flex', gap: '0.25rem' }}>
                              <select
                                className="glass-select"
                                style={{ padding: '0.2rem 0.5rem', width: '130px', fontSize: '0.8rem' }}
                                value={dispatchEngId[t.ticketId] || ''}
                                onChange={(e) => setDispatchEngId({ ...dispatchEngId, [t.ticketId]: e.target.value })}
                              >
                                <option value="">-- Dispatch Field --</option>
                                {fieldEngineers.map((u) => (
                                  <option key={u.userId} value={u.userId}>
                                    {u.name}
                                  </option>
                                ))}
                              </select>
                              <button onClick={() => handleDispatchField(t.ticketId)} className="btn-secondary" style={{ padding: '0.3rem', borderColor: 'var(--accent-purple)', color: 'var(--accent-purple)' }}>
                                <Send size={14} />
                              </button>
                            </div>
                          )}
                          
                          {t.status === 'Resolved' && (
                            <button onClick={() => API.post(`/api/v1/tickets/${t.ticketId}/status?status=Closed`).then(fetchTicketsAndUsers)} className="btn-secondary" style={{ padding: '0.3rem 0.6rem', fontSize: '0.75rem', borderColor: 'var(--accent-green)', color: 'var(--accent-green)' }}>
                              Close Ticket
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Dispatch Logs */}
        <div className="glass-panel">
          <div className="glass-panel-title">
            <Wrench size={18} style={{ marginRight: '0.5rem', color: 'var(--accent-purple)' }} /> Field Dispatch Tracking
          </div>
          <div className="table-container">
            <table className="glass-table">
              <thead>
                <tr>
                  <th>Dispatch ID</th>
                  <th>Ticket</th>
                  <th>Field Engineer</th>
                  <th>Dispatched Time</th>
                  <th>Arrival Time</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {dispatches.map((d) => (
                  <tr key={d.dispatchId}>
                    <td>#DSP-{d.dispatchId}</td>
                    <td>TKT-{d.ticket?.ticketId}</td>
                    <td style={{ fontWeight: 600 }}>{d.fieldEngineer?.name}</td>
                    <td>{new Date(d.dispatchTime).toLocaleString()}</td>
                    <td>{d.siteArrivalTime ? new Date(d.siteArrivalTime).toLocaleString() : 'En-route'}</td>
                    <td>
                      <span className={`status-pill ${d.status === 'Dispatched' ? 'status-critical' : d.status === 'OnSite' ? 'status-warning' : 'status-active'}`}>
                        {d.status}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: '0.5rem' }}>
                        {d.status === 'Dispatched' && (
                          <button onClick={() => handleUpdateDispatchStatus(d.dispatchId, 'OnSite')} className="btn-secondary" style={{ padding: '0.3rem 0.6rem', fontSize: '0.75rem' }}>
                            Arrive Site
                          </button>
                        )}
                        {d.status === 'OnSite' && (
                          <button onClick={() => handleUpdateDispatchStatus(d.dispatchId, 'Resolved', 'Replaced faulty fiber patch cord.')} className="btn-secondary" style={{ padding: '0.3rem 0.6rem', fontSize: '0.75rem', borderColor: 'var(--accent-green)', color: 'var(--accent-green)' }}>
                            Mark Resolved
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
                {dispatches.length === 0 && (
                  <tr>
                    <td colSpan={7} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                      No active field dispatch operations currently.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
}
