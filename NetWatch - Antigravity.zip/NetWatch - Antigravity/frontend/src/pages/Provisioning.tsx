import React, { useEffect, useState } from 'react';
import API from '../api';
import { Plus, Check, Link2 } from 'lucide-react';

export default function Provisioning() {
  const [circuits, setCircuits] = useState<any[]>([]);
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Form states
  const [circuitRef, setCircuitRef] = useState('');
  const [serviceType, setServiceType] = useState('LeasedLine');
  const [customerId, setCustomerId] = useState('');
  const [bandwidthMbps, setBandwidthMbps] = useState(100);
  const [routePath, setRoutePath] = useState('');

  const [selectedCircuitId, setSelectedCircuitId] = useState('');
  const [requestType, setRequestType] = useState('NewActivation');

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    fetchProvisioning();
  }, []);

  const fetchProvisioning = async () => {
    setLoading(true);
    try {
      const [circuitsRes, requestsRes] = await Promise.all([
        API.get('/api/v1/provisioning/circuits'),
        API.get('/api/v1/provisioning/requests'),
      ]);
      setCircuits(circuitsRes.data);
      setRequests(requestsRes.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCircuit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await API.post('/api/v1/provisioning/circuits', {
        circuitReference: circuitRef,
        serviceType,
        customerId,
        bandwidthMbps,
        routePath,
        status: 'Active',
      });
      setCircuits([...circuits, response.data]);
      setCircuitRef('');
      setCustomerId('');
      setRoutePath('');
    } catch (error) {
      console.error(error);
      alert('Error registering circuit');
    }
  };

  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await API.post('/api/v1/provisioning/requests', {
        circuit: { circuitId: parseInt(selectedCircuitId) },
        requestType,
        requestedBy: currentUser.userId ? { userId: currentUser.userId } : null,
        status: 'Pending',
      });
      setRequests([...requests, response.data]);
      setSelectedCircuitId('');
      fetchProvisioning();
    } catch (error) {
      console.error(error);
      alert('Error creating provisioning request');
    }
  };

  const handleCompleteRequest = async (id: number) => {
    try {
      await API.post(`/api/v1/provisioning/requests/${id}/complete`);
      fetchProvisioning();
    } catch (error) {
      console.error(error);
      alert('Error completing provisioning request');
    }
  };

  if (loading) {
    return <div style={{ display: 'flex', justifyContent: 'center', padding: '3rem' }}>Loading Service Provisioning...</div>;
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem' }}>
      
      {/* Circuits & Requests Lists */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        
        {/* Circuits list */}
        <div className="glass-panel">
          <div className="glass-panel-title">Active Customer Services (Circuits)</div>
          <div className="table-container">
            <table className="glass-table">
              <thead>
                <tr>
                  <th>Circuit Ref</th>
                  <th>Customer ID</th>
                  <th>Service Type</th>
                  <th>Bandwidth</th>
                  <th>Route Path</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {circuits.map((c) => (
                  <tr key={c.circuitId}>
                    <td style={{ fontWeight: 600 }}>{c.circuitReference}</td>
                    <td>{c.customerId}</td>
                    <td>{c.serviceType}</td>
                    <td>{c.bandwidthMbps} Mbps</td>
                    <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{c.routePath}</td>
                    <td>
                      <span className={`status-pill ${c.status === 'Active' ? 'status-active' : c.status === 'Suspended' ? 'status-warning' : 'status-critical'}`}>
                        {c.status}
                      </span>
                    </td>
                  </tr>
                ))}
                {circuits.length === 0 && (
                  <tr>
                    <td colSpan={6} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                      No customer service circuits found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Provisioning Requests list */}
        <div className="glass-panel">
          <div className="glass-panel-title">Provisioning Orders queue</div>
          <div className="table-container">
            <table className="glass-table">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Circuit Ref</th>
                  <th>Order Type</th>
                  <th>Requested By</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {requests.map((r) => (
                  <tr key={r.provisionId}>
                    <td>#ORD-{r.provisionId}</td>
                    <td style={{ fontWeight: 600 }}>{r.circuit?.circuitReference}</td>
                    <td>{r.requestType}</td>
                    <td>{r.requestedBy?.name || 'Self-Service Portal'}</td>
                    <td>{new Date(r.requestDate).toLocaleString()}</td>
                    <td>
                      <span className={`status-pill ${r.status === 'Completed' ? 'status-active' : r.status === 'Pending' ? 'status-pending' : 'status-critical'}`}>
                        {r.status}
                      </span>
                    </td>
                    <td>
                      {r.status === 'Pending' && (
                        <button onClick={() => handleCompleteRequest(r.provisionId)} className="btn-secondary" style={{ padding: '0.3rem 0.6rem', fontSize: '0.75rem', borderColor: 'var(--accent-green)', color: 'var(--accent-green)' }}>
                          <Check size={12} style={{ marginRight: '0.2rem' }} /> Provision
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
                {requests.length === 0 && (
                  <tr>
                    <td colSpan={7} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                      No pending provisioning orders.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>

      {/* Right Side: Setup Forms */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        
        {/* Add Circuit */}
        <div className="glass-panel">
          <div className="glass-panel-title">
            <Link2 size={18} style={{ marginRight: '0.5rem', color: 'var(--accent-blue)' }} /> Define Circuit
          </div>
          <form onSubmit={handleCreateCircuit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div className="form-group">
              <label>Circuit Reference</label>
              <input
                type="text"
                className="glass-input"
                required
                value={circuitRef}
                onChange={(e) => setCircuitRef(e.target.value)}
                placeholder="e.g. LON-NY-10G-001"
              />
            </div>
            <div className="form-group">
              <label>Customer ID</label>
              <input
                type="text"
                className="glass-input"
                required
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value)}
                placeholder="e.g. Goldman Sachs"
              />
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label>Service Type</label>
                <select className="glass-select" value={serviceType} onChange={(e) => setServiceType(e.target.value)}>
                  <option value="LeasedLine">Leased Line</option>
                  <option value="VPN">IP-VPN</option>
                  <option value="Internet">DIA Internet</option>
                  <option value="Voice">SIP Voice</option>
                  <option value="MPLS">MPLS L2/L3</option>
                </select>
              </div>
              <div className="form-group">
                <label>Bandwidth (Mbps)</label>
                <input
                  type="number"
                  className="glass-input"
                  required
                  value={bandwidthMbps}
                  onChange={(e) => setBandwidthMbps(parseInt(e.target.value))}
                />
              </div>
            </div>
            <div className="form-group">
              <label>Route Path / Hops</label>
              <input
                type="text"
                className="glass-input"
                value={routePath}
                onChange={(e) => setRoutePath(e.target.value)}
                placeholder="London-RT-01 -> NYC-RT-02"
              />
            </div>
            <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
              <Plus size={16} /> Deploy Circuit
            </button>
          </form>
        </div>

        {/* Submit Order */}
        <div className="glass-panel">
          <div className="glass-panel-title">Order Service Change</div>
          <form onSubmit={handleCreateRequest} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div className="form-group">
              <label>Target Circuit</label>
              <select className="glass-select" required value={selectedCircuitId} onChange={(e) => setSelectedCircuitId(e.target.value)}>
                <option value="">-- Select Circuit --</option>
                {circuits.map((c) => (
                  <option key={c.circuitId} value={c.circuitId}>
                    {c.circuitReference} ({c.customerId})
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Order Request Type</label>
              <select className="glass-select" value={requestType} onChange={(e) => setRequestType(e.target.value)}>
                <option value="NewActivation">New Activation</option>
                <option value="BandwidthUpgrade">Bandwidth Upgrade</option>
                <option value="Suspension">Suspend Service</option>
                <option value="Termination">Terminate Service</option>
              </select>
            </div>
            <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center', background: 'linear-gradient(135deg, var(--accent-purple), var(--accent-blue))' }}>
              Submit Provision Order
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}
