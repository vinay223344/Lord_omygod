import { useEffect, useState } from 'react';
import API from '../api';
import { Calendar, Zap } from 'lucide-react';

export default function Maintenance() {
  const [windows, setWindows] = useState<any[]>([]);
  const [capacityRecords, setCapacityRecords] = useState<any[]>([]);
  const [elements, setElements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Form states
  const [title, setTitle] = useState('');
  const [affectedElementIds, setAffectedElementIds] = useState('');
  const [maintenanceType, setMaintenanceType] = useState('Planned');
  const [startDateTime, setStartDateTime] = useState('');
  const [endDateTime, setEndDateTime] = useState('');
  const [rollbackPlan, setRollbackPlan] = useState('');

  // Capacity Form
  const [capacityElementId, setCapacityElementId] = useState('');
  const [metricType, setMetricType] = useState('CPULoad');
  const [peakValue, setPeakValue] = useState(50);
  const [averageValue, setAverageValue] = useState(40);
  const [thresholdPercent, setThresholdPercent] = useState(85);

  const currentUser = JSON.parse(localStorage.getItem('user') || '{}');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [windowsRes, capacityRes, elementsRes] = await Promise.all([
        API.get('/api/v1/maintenance/windows'),
        API.get('/api/v1/maintenance/capacity'),
        API.get('/api/v1/inventory/elements'),
      ]);
      setWindows(windowsRes.data);
      setCapacityRecords(capacityRes.data);
      setElements(elementsRes.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateWindow = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await API.post('/api/v1/maintenance/windows', {
        title,
        affectedElementIds,
        maintenanceType,
        startDateTime: new Date(startDateTime).toISOString(),
        endDateTime: new Date(endDateTime).toISOString(),
        requestedBy: currentUser.userId ? { userId: currentUser.userId } : null,
        rollbackPlan,
        status: 'Pending',
      });
      setTitle('');
      setAffectedElementIds('');
      setRollbackPlan('');
      fetchData();
    } catch (error) {
      console.error(error);
      alert('Error creating maintenance window');
    }
  };

  const handleApprove = async (id: number) => {
    try {
      await API.post(`/api/v1/maintenance/windows/${id}/approve?approverId=${currentUser.userId || 1}`);
      fetchData();
    } catch (error) {
      console.error(error);
      alert('Error approving window');
    }
  };

  const handleUpdateStatus = async (id: number, status: string) => {
    try {
      await API.post(`/api/v1/maintenance/windows/${id}/status?status=${status}`);
      fetchData();
    } catch (error) {
      console.error(error);
      alert('Error updating status');
    }
  };

  const handleCreateCapacity = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      let capStatus = 'Normal';
      if (peakValue >= thresholdPercent) {
        capStatus = 'Critical';
      } else if (peakValue >= thresholdPercent - 15) {
        capStatus = 'Warning';
      }

      await API.post('/api/v1/maintenance/capacity', {
        element: { elementId: parseInt(capacityElementId) },
        metricType,
        peakValue,
        averageValue,
        thresholdPercent,
        recordedDate: new Date().toISOString().split('T')[0],
        status: capStatus,
      });

      // Raise alarm if critical
      if (capStatus === 'Critical') {
        await API.post('/api/v1/alarms', {
          element: { elementId: parseInt(capacityElementId) },
          alarmType: metricType === 'LinkUtilisation' ? 'HighUtilisation' : 'HardwareFault',
          severity: 'Critical',
          status: 'Active',
        });
      }

      setCapacityElementId('');
      fetchData();
    } catch (error) {
      console.error(error);
      alert('Error logging capacity record');
    }
  };

  if (loading) {
    return <div style={{ display: 'flex', justifyContent: 'center', padding: '3rem' }}>Loading Maintenance Console...</div>;
  }

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem' }}>
      
      {/* Maintenance windows & Capacity grids */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        
        {/* Maintenance Windows */}
        <div className="glass-panel">
          <div className="glass-panel-title">Planned & Emergency Maintenance Windows</div>
          <div className="table-container">
            <table className="glass-table">
              <thead>
                <tr>
                  <th>Window ID</th>
                  <th>Title</th>
                  <th>Affected Elements</th>
                  <th>Type</th>
                  <th>Schedule</th>
                  <th>Approver</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {windows.map((w) => (
                  <tr key={w.maintenanceId}>
                    <td>#CR-{w.maintenanceId}</td>
                    <td style={{ fontWeight: 600 }}>{w.title}</td>
                    <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{w.affectedElementIds}</td>
                    <td>
                      <span className={`status-pill ${w.maintenanceType === 'Planned' ? 'status-acknowledged' : 'status-critical'}`}>
                        {w.maintenanceType}
                      </span>
                    </td>
                    <td style={{ fontSize: '0.8rem' }}>
                      Start: {new Date(w.startDateTime).toLocaleString()}<br />
                      End: {new Date(w.endDateTime).toLocaleString()}
                    </td>
                    <td>{w.approvedBy?.name || 'Pending Approval'}</td>
                    <td>
                      <span className={`status-pill ${w.status === 'Completed' ? 'status-active' : w.status === 'Approved' ? 'status-acknowledged' : w.status === 'InProgress' ? 'status-warning' : 'status-pending'}`}>
                        {w.status}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', gap: '0.25rem' }}>
                        {w.status === 'Pending' && (
                          <button onClick={() => handleApprove(w.maintenanceId)} className="btn-secondary" style={{ padding: '0.3rem 0.5rem', fontSize: '0.75rem', borderColor: 'var(--accent-blue)', color: 'var(--accent-blue)' }}>
                            Approve
                          </button>
                        )}
                        {w.status === 'Approved' && (
                          <button onClick={() => handleUpdateStatus(w.maintenanceId, 'InProgress')} className="btn-secondary" style={{ padding: '0.3rem 0.5rem', fontSize: '0.75rem' }}>
                            Start
                          </button>
                        )}
                        {w.status === 'InProgress' && (
                          <button onClick={() => handleUpdateStatus(w.maintenanceId, 'Completed')} className="btn-secondary" style={{ padding: '0.3rem 0.5rem', fontSize: '0.75rem', borderColor: 'var(--accent-green)', color: 'var(--accent-green)' }}>
                            Complete
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
                {windows.length === 0 && (
                  <tr>
                    <td colSpan={8} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                      No scheduled maintenance windows found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Capacity Tracking */}
        <div className="glass-panel">
          <div className="glass-panel-title">Resource Load & Capacity Tracking</div>
          <div className="table-container">
            <table className="glass-table">
              <thead>
                <tr>
                  <th>Element</th>
                  <th>Metric Type</th>
                  <th>Average Value</th>
                  <th>Peak Value</th>
                  <th>Load Bar</th>
                  <th>Threshold</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {capacityRecords.map((r) => {
                  let barColor = 'capacity-green';
                  if (r.status === 'Warning') barColor = 'capacity-yellow';
                  if (r.status === 'Critical') barColor = 'capacity-red';

                  return (
                    <tr key={r.capacityId}>
                      <td style={{ fontWeight: 600 }}>{r.element?.elementName} ({r.element?.ipAddress})</td>
                      <td>{r.metricType}</td>
                      <td>{r.averageValue}%</td>
                      <td>{r.peakValue}%</td>
                      <td>
                        <div className="capacity-bar-bg">
                          <div className={`capacity-bar-fill ${barColor}`} style={{ width: `${r.peakValue}%` }}></div>
                        </div>
                      </td>
                      <td>{r.thresholdPercent}%</td>
                      <td>
                        <span className={`status-pill ${r.status === 'Normal' ? 'status-active' : r.status === 'Warning' ? 'status-warning' : 'status-critical'}`}>
                          {r.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
                {capacityRecords.length === 0 && (
                  <tr>
                    <td colSpan={7} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>
                      No capacity telemetry logs recorded yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

      </div>

      {/* Right Side: Setup forms */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        
        {/* Request Maintenance */}
        <div className="glass-panel">
          <div className="glass-panel-title">
            <Calendar size={18} style={{ marginRight: '0.5rem', color: 'var(--accent-blue)' }} /> Schedule Window
          </div>
          <form onSubmit={handleCreateWindow} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div className="form-group">
              <label>Window Title</label>
              <input
                type="text"
                className="glass-input"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Core Router OS Upgrade"
              />
            </div>
            <div className="form-group">
              <label>Affected Element IDs (comma separated)</label>
              <input
                type="text"
                className="glass-input"
                required
                value={affectedElementIds}
                onChange={(e) => setAffectedElementIds(e.target.value)}
                placeholder="e.g. 1, 2, 5"
              />
            </div>
            <div className="form-group">
              <label>Maintenance Type</label>
              <select className="glass-select" value={maintenanceType} onChange={(e) => setMaintenanceType(e.target.value)}>
                <option value="Planned">Planned Activity</option>
                <option value="Emergency">Emergency Maintenance</option>
              </select>
            </div>
            <div className="form-group">
              <label>Start DateTime</label>
              <input
                type="datetime-local"
                className="glass-input"
                required
                value={startDateTime}
                onChange={(e) => setStartDateTime(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label>End DateTime</label>
              <input
                type="datetime-local"
                className="glass-input"
                required
                value={endDateTime}
                onChange={(e) => setEndDateTime(e.target.value)}
              />
            </div>
            <div className="form-group">
              <label>Rollback Plan</label>
              <textarea
                className="glass-input"
                style={{ minHeight: '60px', resize: 'vertical' }}
                value={rollbackPlan}
                onChange={(e) => setRollbackPlan(e.target.value)}
                placeholder="Details of rollback procedure..."
              />
            </div>
            <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
              Submit Request
            </button>
          </form>
        </div>

        {/* Capacity Log Telemetry */}
        <div className="glass-panel">
          <div className="glass-panel-title">
            <Zap size={18} style={{ marginRight: '0.5rem', color: 'var(--accent-orange)' }} /> Inject Telemetry
          </div>
          <form onSubmit={handleCreateCapacity} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <div className="form-group">
              <label>Target Element</label>
              <select className="glass-select" required value={capacityElementId} onChange={(e) => setCapacityElementId(e.target.value)}>
                <option value="">-- Select Element --</option>
                {elements.map((el) => (
                  <option key={el.elementId} value={el.elementId}>
                    {el.elementName} ({el.ipAddress})
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label>Telemetry Metric</label>
              <select className="glass-select" value={metricType} onChange={(e) => setMetricType(e.target.value)}>
                <option value="CPULoad">CPU Load (%)</option>
                <option value="MemoryUsage">Memory Usage (%)</option>
                <option value="LinkUtilisation">Link Utilisation (%)</option>
                <option value="StorageUsage">Storage Usage (%)</option>
              </select>
            </div>
            <div className="form-grid">
              <div className="form-group">
                <label>Avg Value (%)</label>
                <input
                  type="number"
                  className="glass-input"
                  required
                  value={averageValue}
                  onChange={(e) => setAverageValue(parseInt(e.target.value))}
                />
              </div>
              <div className="form-group">
                <label>Peak Value (%)</label>
                <input
                  type="number"
                  className="glass-input"
                  required
                  value={peakValue}
                  onChange={(e) => setPeakValue(parseInt(e.target.value))}
                />
              </div>
            </div>
            <div className="form-group">
              <label>Alarm Threshold (%)</label>
              <input
                type="number"
                className="glass-input"
                required
                value={thresholdPercent}
                onChange={(e) => setThresholdPercent(parseInt(e.target.value))}
              />
            </div>
            <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center', background: 'linear-gradient(135deg, var(--accent-orange), var(--accent-red))' }}>
              Post Telemetry
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}
