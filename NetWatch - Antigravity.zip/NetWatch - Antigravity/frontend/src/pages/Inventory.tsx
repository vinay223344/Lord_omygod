import React, { useEffect, useState } from 'react';
import API from '../api';
import { Plus, Server, MapPin, Share2 } from 'lucide-react';

export default function Inventory() {
  const [activeTab, setActiveTab] = useState<'sites' | 'elements' | 'links'>('sites');
  const [sites, setSites] = useState<any[]>([]);
  const [elements, setElements] = useState<any[]>([]);
  const [links, setLinks] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // Form states
  const [siteName, setSiteName] = useState('');
  const [siteType, setSiteType] = useState('DataCentre');
  const [address, setAddress] = useState('');
  const [regionId, setRegionId] = useState('REG-NORTH');

  const [elementName, setElementName] = useState('');
  const [elementType, setElementType] = useState('Router');
  const [vendor, setVendor] = useState('');
  const [model, setModel] = useState('');
  const [ipAddress, setIpAddress] = useState('');
  const [selectedSiteId, setSelectedSiteId] = useState('');

  const [elementAId, setElementAId] = useState('');
  const [elementBId, setElementBId] = useState('');
  const [linkType, setLinkType] = useState('Fibre');
  const [capacityMbps, setCapacityMbps] = useState(1000);

  useEffect(() => {
    fetchInventory();
  }, []);

  const fetchInventory = async () => {
    setLoading(true);
    try {
      const [sitesRes, elementsRes, linksRes] = await Promise.all([
        API.get('/api/v1/inventory/sites'),
        API.get('/api/v1/inventory/elements'),
        API.get('/api/v1/inventory/links'),
      ]);
      setSites(sitesRes.data);
      setElements(elementsRes.data);
      setLinks(linksRes.data);
    } catch (error) {
      console.error('Error fetching inventory data', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateSite = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await API.post('/api/v1/inventory/sites', {
        siteName,
        siteType,
        address,
        regionId,
        status: 'Active',
      });
      setSites([...sites, response.data]);
      setSiteName('');
      setAddress('');
    } catch (error) {
      console.error(error);
      alert('Error creating site');
    }
  };

  const handleCreateElement = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await API.post('/api/v1/inventory/elements', {
        elementName,
        elementType,
        vendor,
        model,
        ipAddress,
        site: selectedSiteId ? { siteId: parseInt(selectedSiteId) } : null,
        regionId,
        managementStatus: 'Managed',
        status: 'Active',
      });
      setElements([...elements, response.data]);
      setElementName('');
      setVendor('');
      setModel('');
      setIpAddress('');
    } catch (error) {
      console.error(error);
      alert('Error creating network element');
    }
  };

  const handleCreateLink = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await API.post('/api/v1/inventory/links', {
        elementA: { elementId: parseInt(elementAId) },
        elementB: { elementId: parseInt(elementBId) },
        linkType,
        capacityMbps,
        utilisationPercent: 0.0,
        status: 'Active',
      });
      setLinks([...links, response.data]);
    } catch (error) {
      console.error(error);
      alert('Error creating topology link');
    }
  };

  if (loading) {
    return <div style={{ display: 'flex', justifyContent: 'center', padding: '3rem' }}>Loading Inventory...</div>;
  }

  return (
    <div>
      {/* Tabs */}
      <div className="tabs-container">
        <button className={`tab-btn ${activeTab === 'sites' ? 'active' : ''}`} onClick={() => setActiveTab('sites')}>
          Network Sites ({sites.length})
        </button>
        <button className={`tab-btn ${activeTab === 'elements' ? 'active' : ''}`} onClick={() => setActiveTab('elements')}>
          Network Elements ({elements.length})
        </button>
        <button className={`tab-btn ${activeTab === 'links' ? 'active' : ''}`} onClick={() => setActiveTab('links')}>
          Topology Links ({links.length})
        </button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem' }}>
        
        {/* Left Side: Tables/Lists */}
        <div>
          {activeTab === 'sites' && (
            <div className="glass-panel">
              <div className="glass-panel-title">Registered Sites</div>
              <div className="table-container">
                <table className="glass-table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Type</th>
                      <th>Region</th>
                      <th>Address</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sites.map((site) => (
                      <tr key={site.siteId}>
                        <td>#{site.siteId}</td>
                        <td style={{ fontWeight: 600 }}>{site.siteName}</td>
                        <td>{site.siteType}</td>
                        <td>{site.regionId}</td>
                        <td>{site.address}</td>
                        <td>
                          <span className={`status-pill ${site.status === 'Active' ? 'status-active' : 'status-critical'}`}>
                            {site.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'elements' && (
            <div className="glass-panel">
              <div className="glass-panel-title">Managed Elements</div>
              <div className="table-container">
                <table className="glass-table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Name</th>
                      <th>Type</th>
                      <th>IP Address</th>
                      <th>Vendor/Model</th>
                      <th>Site</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {elements.map((el) => (
                      <tr key={el.elementId}>
                        <td>#{el.elementId}</td>
                        <td style={{ fontWeight: 600 }}>{el.elementName}</td>
                        <td>{el.elementType}</td>
                        <td>{el.ipAddress}</td>
                        <td>{el.vendor} {el.model}</td>
                        <td>{el.site?.siteName || 'N/A'}</td>
                        <td>
                          <span className={`status-pill ${el.status === 'Active' ? 'status-active' : 'status-warning'}`}>
                            {el.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'links' && (
            <div className="glass-panel">
              <div className="glass-panel-title">Topology Links</div>
              <div className="table-container">
                <table className="glass-table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Source (A)</th>
                      <th>Destination (B)</th>
                      <th>Type</th>
                      <th>Capacity</th>
                      <th>Utilisation</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {links.map((link) => (
                      <tr key={link.linkId}>
                        <td>#{link.linkId}</td>
                        <td>{link.elementA?.elementName}</td>
                        <td>{link.elementB?.elementName}</td>
                        <td>{link.linkType}</td>
                        <td>{link.capacityMbps} Mbps</td>
                        <td>{link.utilisationPercent || 0}%</td>
                        <td>
                          <span className={`status-pill ${link.status === 'Active' ? 'status-active' : 'status-critical'}`}>
                            {link.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Right Side: Registration Forms */}
        <div>
          {activeTab === 'sites' && (
            <div className="glass-panel">
              <div className="glass-panel-title">
                <MapPin size={18} style={{ marginRight: '0.5rem', color: 'var(--accent-blue)' }} /> Add Network Site
              </div>
              <form onSubmit={handleCreateSite} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div className="form-group">
                  <label>Site Name</label>
                  <input
                    type="text"
                    className="glass-input"
                    required
                    value={siteName}
                    onChange={(e) => setSiteName(e.target.value)}
                    placeholder="e.g. London DC-1"
                  />
                </div>
                <div className="form-group">
                  <label>Site Type</label>
                  <select className="glass-select" value={siteType} onChange={(e) => setSiteType(e.target.value)}>
                    <option value="DataCentre">Data Centre</option>
                    <option value="Exchange">Exchange</option>
                    <option value="Tower">Cell Tower</option>
                    <option value="POP">POP Node</option>
                    <option value="RemoteNode">Remote Node</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Region ID</label>
                  <select className="glass-select" value={regionId} onChange={(e) => setRegionId(e.target.value)}>
                    <option value="REG-NORTH">North Region</option>
                    <option value="REG-SOUTH">South Region</option>
                    <option value="REG-EAST">East Region</option>
                    <option value="REG-WEST">West Region</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Address</label>
                  <textarea
                    className="glass-input"
                    style={{ minHeight: '80px', resize: 'vertical' }}
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Physical address info"
                  />
                </div>
                <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
                  <Plus size={16} /> Register Site
                </button>
              </form>
            </div>
          )}

          {activeTab === 'elements' && (
            <div className="glass-panel">
              <div className="glass-panel-title">
                <Server size={18} style={{ marginRight: '0.5rem', color: 'var(--accent-purple)' }} /> Add Element
              </div>
              <form onSubmit={handleCreateElement} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div className="form-group">
                  <label>Element Name</label>
                  <input
                    type="text"
                    className="glass-input"
                    required
                    value={elementName}
                    onChange={(e) => setElementName(e.target.value)}
                    placeholder="e.g. Core-RT-01"
                  />
                </div>
                <div className="form-grid">
                  <div className="form-group">
                    <label>Type</label>
                    <select className="glass-select" value={elementType} onChange={(e) => setElementType(e.target.value)}>
                      <option value="Router">Router</option>
                      <option value="Switch">Switch</option>
                      <option value="Firewall">Firewall</option>
                      <option value="OLT">OLT GPON</option>
                      <option value="BTS">BTS LTE</option>
                      <option value="Transmission">Transmission</option>
                      <option value="Server">Server Host</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label>IP Address</label>
                    <input
                      type="text"
                      className="glass-input"
                      required
                      value={ipAddress}
                      onChange={(e) => setIpAddress(e.target.value)}
                      placeholder="10.100.1.5"
                    />
                  </div>
                </div>
                <div className="form-grid">
                  <div className="form-group">
                    <label>Vendor</label>
                    <input
                      type="text"
                      className="glass-input"
                      value={vendor}
                      onChange={(e) => setVendor(e.target.value)}
                      placeholder="e.g. Cisco"
                    />
                  </div>
                  <div className="form-group">
                    <label>Model</label>
                    <input
                      type="text"
                      className="glass-input"
                      value={model}
                      onChange={(e) => setModel(e.target.value)}
                      placeholder="e.g. ASR9000"
                    />
                  </div>
                </div>
                <div className="form-group">
                  <label>Associated Site</label>
                  <select className="glass-select" value={selectedSiteId} onChange={(e) => setSelectedSiteId(e.target.value)}>
                    <option value="">-- No Site Linked --</option>
                    {sites.map((site) => (
                      <option key={site.siteId} value={site.siteId}>
                        {site.siteName}
                      </option>
                    ))}
                  </select>
                </div>
                <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
                  <Plus size={16} /> Add Element
                </button>
              </form>
            </div>
          )}

          {activeTab === 'links' && (
            <div className="glass-panel">
              <div className="glass-panel-title">
                <Share2 size={18} style={{ marginRight: '0.5rem', color: 'var(--accent-cyan)' }} /> Connect Topology
              </div>
              <form onSubmit={handleCreateLink} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                <div className="form-group">
                  <label>Source Element A</label>
                  <select className="glass-select" value={elementAId} onChange={(e) => setElementAId(e.target.value)}>
                    <option value="">-- Select Source --</option>
                    {elements.map((el) => (
                      <option key={el.elementId} value={el.elementId}>
                        {el.elementName} ({el.ipAddress})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label>Destination Element B</label>
                  <select className="glass-select" value={elementBId} onChange={(e) => setElementBId(e.target.value)}>
                    <option value="">-- Select Destination --</option>
                    {elements.map((el) => (
                      <option key={el.elementId} value={el.elementId}>
                        {el.elementName} ({el.ipAddress})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="form-grid">
                  <div className="form-group">
                    <label>Link Type</label>
                    <select className="glass-select" value={linkType} onChange={(e) => setLinkType(e.target.value)}>
                      <option value="Fibre">Fibre Optic</option>
                      <option value="Microwave">Microwave</option>
                      <option value="Ethernet">Ethernet</option>
                      <option value="SDH">SDH Ring</option>
                    </select>
                  </div>
                  <div className="form-group">
                    <label>Capacity (Mbps)</label>
                    <input
                      type="number"
                      className="glass-input"
                      value={capacityMbps}
                      onChange={(e) => setCapacityMbps(parseInt(e.target.value))}
                      placeholder="10000"
                    />
                  </div>
                </div>
                <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
                  <Plus size={16} /> Deploy Link
                </button>
              </form>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
