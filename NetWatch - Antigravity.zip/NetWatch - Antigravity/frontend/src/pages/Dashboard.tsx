import { useEffect, useState } from 'react';
import API from '../api';
import { AlertCircle, Activity, Server, ShieldAlert, Layers } from 'lucide-react';

interface DashboardMetrics {
  activeAlarmsCount: number;
  criticalTicketsCount: number;
  totalElementsCount: number;
  activeCircuitsCount: number;
  utilisedLinksCount: number;
  severityDistribution: Record<string, number>;
  ticketStatusDistribution: Record<string, number>;
  capacityWarnings: any[];
}

export default function Dashboard() {
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMetrics();
    const interval = setInterval(fetchMetrics, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchMetrics = async () => {
    try {
      const response = await API.get('/api/v1/analytics/dashboard');
      setMetrics(response.data);
    } catch (error) {
      console.error('Error fetching dashboard metrics', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div style={{ display: 'flex', justifyContent: 'center', padding: '3rem' }}>Loading dashboard...</div>;
  }

  return (
    <div>
      {/* Metric Grid */}
      <div className="metric-grid">
        <div className="metric-card">
          <div className="metric-icon-box" style={{ background: 'rgba(239, 68, 68, 0.1)', color: 'var(--accent-red)' }}>
            <ShieldAlert size={28} />
          </div>
          <div className="metric-data">
            <span className="metric-label">Active Alarms</span>
            <span className="metric-val" style={{ color: 'var(--accent-red)' }}>{metrics?.activeAlarmsCount || 0}</span>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon-box" style={{ background: 'rgba(249, 115, 22, 0.1)', color: 'var(--accent-orange)' }}>
            <AlertCircle size={28} />
          </div>
          <div className="metric-data">
            <span className="metric-label">P1 Outages</span>
            <span className="metric-val" style={{ color: 'var(--accent-orange)' }}>{metrics?.criticalTicketsCount || 0}</span>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon-box" style={{ background: 'rgba(59, 130, 246, 0.1)', color: 'var(--accent-blue)' }}>
            <Server size={28} />
          </div>
          <div className="metric-data">
            <span className="metric-label">Managed Elements</span>
            <span className="metric-val">{metrics?.totalElementsCount || 0}</span>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon-box" style={{ background: 'rgba(16, 185, 129, 0.1)', color: 'var(--accent-green)' }}>
            <Activity size={28} />
          </div>
          <div className="metric-data">
            <span className="metric-label">Active Circuits</span>
            <span className="metric-val" style={{ color: 'var(--accent-green)' }}>{metrics?.activeCircuitsCount || 0}</span>
          </div>
        </div>

        <div className="metric-card">
          <div className="metric-icon-box" style={{ background: 'rgba(6, 182, 212, 0.1)', color: 'var(--accent-cyan)' }}>
            <Layers size={28} />
          </div>
          <div className="metric-data">
            <span className="metric-label">Congested Links</span>
            <span className="metric-val">{metrics?.utilisedLinksCount || 0}</span>
          </div>
        </div>
      </div>

      {/* Main details */}
      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '1.5rem' }}>
        
        {/* Left column: Capacity Warnings & Breakdowns */}
        <div>
          <div className="glass-panel">
            <div className="glass-panel-title">
              <span>Capacity Alerts & Warnings</span>
              <span className="status-pill status-warning" style={{ fontSize: '0.7rem' }}>SLA Monitored</span>
            </div>
            
            {metrics?.capacityWarnings && metrics.capacityWarnings.length > 0 ? (
              <div className="table-container">
                <table className="glass-table">
                  <thead>
                    <tr>
                      <th>Element</th>
                      <th>Metric</th>
                      <th>Peak Value</th>
                      <th>Threshold</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {metrics.capacityWarnings.map((warning, index) => (
                      <tr key={index}>
                        <td>{warning.element?.elementName} ({warning.element?.ipAddress})</td>
                        <td>{warning.metricType}</td>
                        <td>{warning.peakValue}%</td>
                        <td>{warning.thresholdPercent}%</td>
                        <td>
                          <span className={`status-pill ${warning.status === 'Critical' ? 'status-critical' : 'status-warning'}`}>
                            {warning.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>All network element load parameters are within normal thresholds.</p>
            )}
          </div>

          <div className="glass-panel">
            <div className="glass-panel-title">Operational Summary</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem' }}>
              <div>
                <h4 style={{ marginBottom: '1rem', color: 'var(--text-muted)' }}>Alarms by Severity</h4>
                {metrics?.severityDistribution && Object.keys(metrics.severityDistribution).length > 0 ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    {Object.entries(metrics.severityDistribution).map(([sev, val]) => (
                      <div key={sev} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.5rem', background: 'rgba(255,255,255,0.02)', borderRadius: '6px' }}>
                        <span style={{ textTransform: 'capitalize' }}>{sev}</span>
                        <span style={{ fontWeight: 'bold' }}>{val}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p style={{ color: 'var(--text-muted)' }}>No statistics available.</p>
                )}
              </div>

              <div>
                <h4 style={{ marginBottom: '1rem', color: 'var(--text-muted)' }}>Tickets by Status</h4>
                {metrics?.ticketStatusDistribution && Object.keys(metrics.ticketStatusDistribution).length > 0 ? (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                    {Object.entries(metrics.ticketStatusDistribution).map(([stat, val]) => (
                      <div key={stat} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.5rem', background: 'rgba(255,255,255,0.02)', borderRadius: '6px' }}>
                        <span>{stat}</span>
                        <span style={{ fontWeight: 'bold' }}>{val}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p style={{ color: 'var(--text-muted)' }}>No tickets found.</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right column: Shift Info / Network Health */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          <div className="glass-panel" style={{ height: 'fit-content' }}>
            <div className="glass-panel-title">NOC Shift Status</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem', fontSize: '0.9rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-muted)' }}>Active Shift:</span>
                <span style={{ fontWeight: 'bold' }}>Shift A (06:00 - 14:00)</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-muted)' }}>Lead Engineer:</span>
                <span>NOC Lead (Admin)</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                <span style={{ color: 'var(--text-muted)' }}>System Health:</span>
                <span className="status-pill status-active">Optimal</span>
              </div>
            </div>
          </div>

          <div className="glass-panel" style={{ flexGrow: 1 }}>
            <div className="glass-panel-title">NOC SLA Benchmark</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', marginTop: '1rem' }}>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.4rem' }}>
                  <span>P1 Restore Time (&lt;4h)</span>
                  <span style={{ fontWeight: '600' }}>94.2%</span>
                </div>
                <div className="capacity-bar-bg" style={{ width: '100%' }}>
                  <div className="capacity-bar-fill capacity-green" style={{ width: '94.2%' }}></div>
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.4rem' }}>
                  <span>P2 Acknowledge Time (&lt;15m)</span>
                  <span style={{ fontWeight: '600' }}>98.5%</span>
                </div>
                <div className="capacity-bar-bg" style={{ width: '100%' }}>
                  <div className="capacity-bar-fill capacity-green" style={{ width: '98.5%' }}></div>
                </div>
              </div>

              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.85rem', marginBottom: '0.4rem' }}>
                  <span>Network Availability (Uptime)</span>
                  <span style={{ fontWeight: '600' }}>99.98%</span>
                </div>
                <div className="capacity-bar-bg" style={{ width: '100%' }}>
                  <div className="capacity-bar-fill capacity-green" style={{ width: '99.98%' }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
