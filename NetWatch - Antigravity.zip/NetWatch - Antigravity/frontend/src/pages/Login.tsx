import React, { useState } from 'react';
import API from '../api';

interface LoginProps {
  onLoginSuccess: (user: any) => void;
}

export default function Login({ onLoginSuccess }: LoginProps) {
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState('NOCEngineer');
  const [phone, setPhone] = useState('');
  const [regionId, setRegionId] = useState('REG-NORTH');
  const [shiftGroup, setShiftGroup] = useState('Shift-A');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isRegistering) {
        const response = await API.post('/api/v1/auth/register', {
          name,
          email,
          password,
          role,
          status: 'Active',
          regionId,
          phone,
          shiftGroup,
        });
        localStorage.setItem('token', response.data.token);
        localStorage.setItem('user', JSON.stringify(response.data));
        onLoginSuccess(response.data);
      } else {
        const response = await API.post('/api/v1/auth/authenticate', {
          email,
          password,
        });
        localStorage.setItem('token', response.data.token);
        localStorage.setItem('user', JSON.stringify(response.data));
        onLoginSuccess(response.data);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.response?.data?.message || 'Authentication failed. Please check credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-bg">
      <div className="login-card">
        <h2 style={{ marginBottom: '0.5rem', fontWeight: 700 }}>NetWatch Portal</h2>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.85rem', marginBottom: '2rem' }}>
          Network Infrastructure & NOC Operations
        </p>

        {error && (
          <div style={{ color: 'var(--accent-red)', padding: '0.75rem', background: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.2)', borderRadius: '8px', marginBottom: '1rem', fontSize: '0.85rem' }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem', textAlign: 'left' }}>
          {isRegistering && (
            <div className="form-group">
              <label>Full Name</label>
              <input
                type="text"
                className="glass-input"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. John Doe"
              />
            </div>
          )}

          <div className="form-group">
            <label>Email Address</label>
            <input
              type="email"
              className="glass-input"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. engineer@netwatch.net"
            />
          </div>

          <div className="form-group">
            <label>Password</label>
            <input
              type="password"
              className="glass-input"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </div>

          {isRegistering && (
            <>
              <div className="form-grid">
                <div className="form-group">
                  <label>Role</label>
                  <select className="glass-select" value={role} onChange={(e) => setRole(e.target.value)}>
                    <option value="NOCEngineer">NOC Engineer</option>
                    <option value="FieldEngineer">Field Engineer</option>
                    <option value="PlanningEngineer">Planning Engineer</option>
                    <option value="ServiceDesk">Service Desk</option>
                    <option value="ChangeManager">Change Manager</option>
                    <option value="Admin">Administrator</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Region</label>
                  <select className="glass-select" value={regionId} onChange={(e) => setRegionId(e.target.value)}>
                    <option value="REG-NORTH">North Region</option>
                    <option value="REG-SOUTH">South Region</option>
                    <option value="REG-EAST">East Region</option>
                    <option value="REG-WEST">West Region</option>
                  </select>
                </div>
              </div>
              <div className="form-grid">
                <div className="form-group">
                  <label>Phone</label>
                  <input
                    type="text"
                    className="glass-input"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+1 555-0199"
                  />
                </div>
                <div className="form-group">
                  <label>Shift Group</label>
                  <select className="glass-select" value={shiftGroup} onChange={(e) => setShiftGroup(e.target.value)}>
                    <option value="Shift-A">Shift A (Morning)</option>
                    <option value="Shift-B">Shift B (Evening)</option>
                    <option value="Shift-C">Shift C (Night)</option>
                  </select>
                </div>
              </div>
            </>
          )}

          <button type="submit" className="btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: '1rem', padding: '0.8rem' }} disabled={loading}>
            {loading ? 'Processing...' : isRegistering ? 'Create Account' : 'Sign In'}
          </button>
        </form>

        <p style={{ marginTop: '1.5rem', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
          {isRegistering ? 'Already have an account?' : "Don't have an account?"}{' '}
          <span
            style={{ color: 'var(--accent-blue)', cursor: 'pointer', fontWeight: 600 }}
            onClick={() => setIsRegistering(!isRegistering)}
          >
            {isRegistering ? 'Sign In' : 'Register Here'}
          </span>
        </p>
      </div>
    </div>
  );
}
