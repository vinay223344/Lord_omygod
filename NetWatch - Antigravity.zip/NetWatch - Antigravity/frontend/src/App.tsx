import { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, NavLink, Navigate } from 'react-router-dom';
import { Activity, Bell, Server, FileText, LayoutDashboard, Link2, Calendar, LogOut, CheckCheck } from 'lucide-react';
import './App.css';

import API from './api';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Inventory from './pages/Inventory';
import Alarms from './pages/Alarms';
import Tickets from './pages/Tickets';
import Provisioning from './pages/Provisioning';
import Maintenance from './pages/Maintenance';

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [showNotifSlider, setShowNotifSlider] = useState(false);

  useEffect(() => {
    const savedUser = localStorage.getItem('user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  useEffect(() => {
    if (user) {
      fetchNotifications();
      const interval = setInterval(fetchNotifications, 10000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const fetchNotifications = async () => {
    try {
      const res = await API.get(`/api/v1/notifications?userId=${user.userId}`);
      setNotifications(res.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };

  const handleMarkAllRead = async () => {
    try {
      await API.post(`/api/v1/notifications/read-all?userId=${user.userId}`);
      fetchNotifications();
    } catch (error) {
      console.error(error);
    }
  };

  const unreadCount = notifications.filter(n => n.status === 'Unread').length;

  if (!user) {
    return <Login onLoginSuccess={setUser} />;
  }

  return (
    <Router>
      <div className="app-container">
        
        {/* Sidebar */}
        <aside className="sidebar">
          <div>
            <div className="logo-section">
              <Activity size={24} style={{ color: 'var(--accent-blue)' }} />
              <span>NetWatch</span>
            </div>

            <nav className="nav-links">
              <NavLink to="/" className={({ isActive }) => `sidebar-nav-item ${isActive ? 'active' : ''}`}>
                <LayoutDashboard size={20} /> Dashboard
              </NavLink>
              <NavLink to="/inventory" className={({ isActive }) => `sidebar-nav-item ${isActive ? 'active' : ''}`}>
                <Server size={20} /> Inventory
              </NavLink>
              <NavLink to="/alarms" className={({ isActive }) => `sidebar-nav-item ${isActive ? 'active' : ''}`}>
                <Activity size={20} /> Alarms
              </NavLink>
              <NavLink to="/tickets" className={({ isActive }) => `sidebar-nav-item ${isActive ? 'active' : ''}`}>
                <FileText size={20} /> Tickets
              </NavLink>
              <NavLink to="/provisioning" className={({ isActive }) => `sidebar-nav-item ${isActive ? 'active' : ''}`}>
                <Link2 size={20} /> Provisioning
              </NavLink>
              <NavLink to="/maintenance" className={({ isActive }) => `sidebar-nav-item ${isActive ? 'active' : ''}`}>
                <Calendar size={20} /> Maintenance
              </NavLink>
            </nav>
          </div>

          <div className="user-profile-section">
            <div className="user-profile-card">
              <div className="user-avatar">
                {user.name?.charAt(0).toUpperCase()}
              </div>
              <div className="user-info">
                <span className="user-name">{user.name}</span>
                <span className="user-role">{user.role}</span>
              </div>
            </div>
            <button onClick={handleLogout} className="logout-btn">
              <LogOut size={16} /> Sign Out
            </button>
          </div>
        </aside>

        {/* Main Window */}
        <div className="main-window">
          
          {/* Top Bar */}
          <header className="top-bar">
            <div className="page-title">Operations Console</div>
            
            <div className="top-actions">
              {/* Notification bell */}
              <div className="notification-bell-container" onClick={() => setShowNotifSlider(!showNotifSlider)}>
                <Bell size={22} style={{ color: 'var(--text-main)' }} />
                {unreadCount > 0 && <span className="notif-badge">{unreadCount}</span>}
              </div>
            </div>
          </header>

          {/* Page Contents */}
          <main className="content-pane">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/alarms" element={<Alarms />} />
              <Route path="/tickets" element={<Tickets />} />
              <Route path="/provisioning" element={<Provisioning />} />
              <Route path="/maintenance" element={<Maintenance />} />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </main>
        </div>

        {/* Notifications slide-out panel */}
        <div className={`notif-slider ${showNotifSlider ? 'open' : ''}`}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', borderBottom: '1px solid var(--glass-border)', paddingBottom: '0.75rem' }}>
            <span style={{ fontWeight: '600' }}>Alert Notifications</span>
            {unreadCount > 0 && (
              <button onClick={handleMarkAllRead} className="btn-secondary" style={{ padding: '0.2rem 0.5rem', fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                <CheckCheck size={12} /> Mark all read
              </button>
            )}
          </div>

          <div className="notif-list">
            {notifications.map((n) => (
              <div key={n.notificationId} className={`notif-card ${n.status === 'Unread' ? 'unread' : ''}`}>
                <span className="notif-msg">{n.message}</span>
                <span className="notif-time">{new Date(n.createdDate).toLocaleTimeString()}</span>
              </div>
            ))}
            {notifications.length === 0 && (
              <div style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                No active notifications.
              </div>
            )}
          </div>
        </div>

      </div>
    </Router>
  );
}
