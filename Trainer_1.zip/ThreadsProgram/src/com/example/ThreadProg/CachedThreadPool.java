package com.example.ThreadProg;

import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

class LoopTaskA implements Runnable{
    private static int count;
    private int id;
    @Override
    public void run() {

        System.out.println("##### "+id+ " Starting ######");
        for(int i=10;i>0;i--) {
            System.out.println(id+"->Task "+i);

            try {
                TimeUnit.MICROSECONDS.sleep((long) (Math.random()*1000));
            }
            catch(Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println("***** "+id+ " Ending *******");
    }
    public LoopTaskA() {
        id=++count;
        //new
    }
}
public class CachedThreadPool {
    public static void main(String[] args) {
        ExecutorService e=Executors.newCachedThreadPool();
        for(int i=0;i<6;i++) {
            e.execute(new LoopTaskA());
        }
        e.shutdown();
    }


}
