package com.example.ThreadProg;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
class LoopTaskB implements Runnable{
    private static int count;
    private int id;
    @Override
    public void run() {
        System.out.println("##### "+id+ " Starting ######");
        for(int i=10;i>0;i--) {
            System.out.println(id+"->Task "+i);
            try {
                TimeUnit.MICROSECONDS.sleep((long) (Math.random()*10000));
            }
            catch(Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println("***** "+id+ " Ending *******");
    }
    public LoopTaskB() {
        id=++count;
    }
}
public class SingleThreadExecutor {
    public static void main(String[] args) {
        ExecutorService e=Executors.newSingleThreadExecutor();
        for(int i=0;i<3;i++) {
            e.execute(new LoopTaskB());
        }
        e.shutdown();
    }
}
