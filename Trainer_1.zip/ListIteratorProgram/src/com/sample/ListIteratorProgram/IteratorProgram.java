package com.sample.ListIteratorProgram;
import java.util.*;
public class IteratorProgram {
    public static void main(String[] args) {
        List<String> a=new ArrayList<>();
        a.add("Apple");
        a.add("Grapes");
        a.add("Banana");

        System.out.println(a);
        //Forward Traversal
        ListIterator<String> b=a.listIterator();
        System.out.println("Forward Traversal");
        while(b.hasNext())
        {
            int index=b.nextIndex();
            String name=b.next();
            System.out.println("Index:"+index+" Name:"+name);

            if(name.equals("Apple"))
            {
                //assigning value
                b.set("Mango");
            }
        }
        System.out.println();
        //Backward Traversal
        System.out.println("Backward Traversal");
        while(b.hasPrevious())
        {
            int index1=b.previousIndex();
            String name1=b.previous();
            System.out.println("Index:"+index1+" Name:"+name1);

            if(name1.equals("Mango"))
            {
                b.remove();
                //adding value
                b.add("Apple");
            }
        }
        System.out.println();
        //Removal
        System.out.println("Removing Mango");
        while(b.hasNext())
        {
            int index=b.nextIndex();
            String name=b.next();
            System.out.println("Index:"+index+" Name:"+name);
        }


    }
}
