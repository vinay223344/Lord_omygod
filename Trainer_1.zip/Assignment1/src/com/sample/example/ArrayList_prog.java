package com.sample.example;
import java.util.*;
public class ArrayList_prog {
    private String name;
    private int rollno;
    //constructor
    ArrayList_prog(String name, int rollno)
    {
        this.name=name;
        this.rollno=rollno;
    }
    //getter methods
    public String getname(){
        return name;
    }
    public int getrollno(){
        return rollno;
    }
    //print method
    public void display()
    {
        System.out.println("Name: "+name+" Roll no: "+rollno);
    }

    public static void main(String[] args) {
        ArrayList<ArrayList_prog> student=new ArrayList();
        //adding Student objects to arraylist
        student.add(new ArrayList_prog("Ash",18));
        student.add(new ArrayList_prog("Gobi",15));
        //displaying all students
        for(ArrayList_prog s:student)
        {
            System.out.println(s.getname());
            System.out.println(s.getrollno());
            s.display();
        }

    }
}
