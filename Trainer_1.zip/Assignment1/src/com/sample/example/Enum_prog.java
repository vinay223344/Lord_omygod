package com.sample.example;
enum Day{
    Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday
}
public class Enum_prog {
    //enum declaration
        public static void main(String[] args) {
            //to traverse the enum
            for(Day d:Day.values())
            {
                if(d==Day.Sunday)
                {
                    System.out.println(d+" - Be Happy, It's sunday");
                }
                else if(d==Day.Monday)
                {
                    System.out.println(d+" - It's start of a week");
                }
                else if(d==Day.Friday)
                {
                    System.out.println(d+" - Weekend is next");
                }
                else if(d==Day.Saturday)
                {
                    System.out.println(d+" - Start of the Weekend");
                }
                else {
                    System.out.println(d+" - Yet another day of a week");
                }
            }
        }

    }

