package Programs;
import java.util.*;

/**
* ============================================================
* MASTER COLLECTIONS PROGRAM (Cheat Sheet Included)
* ============================================================
* Demonstrates:
* - Array
* - ArrayList
* - LinkedList
* - HashMap
* - TreeMap
* - HashSet
* - TreeSet
* With: Sorting, Ordering, Retrieval
*
* CHEAT SHEET:
* ------------------------------------------------------------
* Array      : Fixed size, fast access, index-based
* ArrayList  : Dynamic size, ordered, allows duplicates
* LinkedList : Doubly linked, efficient insert/remove
* HashSet    : Unique elements, unordered
* TreeSet    : Unique elements, sorted order
* HashMap    : Key-Value pairs, unordered
* TreeMap    : Key-Value pairs, sorted by key
* ------------------------------------------------------------
* Common Methods:
* - add(), remove(), get(), contains(), sort(), put(), get()
* ============================================================
*/
 
// Example class for complex collections
class Employee {
    int id;
    String name;
    double salary;
 
    Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }
 
    @Override
    public String toString() {
        return id + " - " + name + " ($" + salary + ")";
    }
}
 
public class CollectionsMaster {
    public static void main(String[] args) {
        // ================= ARRAY =================
        System.out.println("=== ARRAY ===");
        String[] departments = {"HR", "Finance", "IT", "Sales"};
        for (String dept : departments) {
            System.out.println("Department: " + dept);
        }
 
        // ================= ARRAYLIST =================
        System.out.println("\n=== ARRAYLIST ===");
        ArrayList<Employee> employees = new ArrayList<>();
        employees.add(new Employee(3, "Ayush", 55000));
        employees.add(new Employee(1, "Sudheer", 60000));
        employees.add(new Employee(2, "Romit", 50000));
 
        System.out.println("Original ArrayList:");
        employees.forEach(System.out::println);
 
        employees.sort(Comparator.comparingDouble(e -> e.salary));
        System.out.println("\nSorted ArrayList by Salary:");
        employees.forEach(System.out::println);
 
        // ================= LINKEDLIST =================
        System.out.println("\n=== LINKEDLIST ===");
        LinkedList<String> tasks = new LinkedList<>();
        tasks.add("Design");
        tasks.add("Develop");
        tasks.add("Test");
        tasks.addFirst("Plan");
        tasks.addLast("Deploy");
 
        System.out.println("Tasks in LinkedList:");
        tasks.forEach(System.out::println);
 
        System.out.println("Retrieve first task: " + tasks.getFirst());
        System.out.println("Retrieve last task: " + tasks.getLast());
 
        // ================= HASHSET =================
        System.out.println("\n=== HASHSET ===");
        HashSet<String> skills = new HashSet<>();
        skills.add("Java");
        skills.add("Python");
        skills.add("C++");
        skills.add("Java"); // duplicate ignored
 
        System.out.println("HashSet (unordered, unique):");
        skills.forEach(System.out::println);
 
        // ================= TREESET =================
        System.out.println("\n=== TREESET ===");
        TreeSet<String> sortedSkills = new TreeSet<>(skills);
        System.out.println("TreeSet (sorted):");
        sortedSkills.forEach(System.out::println);
 
        // ================= HASHMAP =================
        System.out.println("\n=== HASHMAP ===");
        HashMap<Integer, String> projectMap = new HashMap<>();
        projectMap.put(101, "Website");
        projectMap.put(102, "Mobile App");
        projectMap.put(103, "Database");
 
        System.out.println("HashMap (unordered key-value):");
        projectMap.forEach((k, v) -> System.out.println(k + " -> " + v));
 
        System.out.println("Retrieve project 102: " + projectMap.get(102));
 
        // ================= TREEMAP =================
        System.out.println("\n=== TREEMAP ===");
        TreeMap<Integer, String> orderedProjects = new TreeMap<>(projectMap);
        System.out.println("TreeMap (sorted by key):");
        orderedProjects.forEach((k, v) -> System.out.println(k + " -> " + v));
 
        // ================= COMPLEX DEMO =================
        System.out.println("\n=== COMPLEX DEMO ===");
        Map<String, List<Employee>> deptEmployees = new HashMap<>();
 
        deptEmployees.put("IT", Arrays.asList(
                new Employee(10, "David", 70000),
                new Employee(11, "Eva", 72000)
        ));
        deptEmployees.put("HR", Arrays.asList(
                new Employee(20, "Frank", 50000),
                new Employee(21, "Grace", 52000)
        ));
 
        // Iterate over Map of Lists
        deptEmployees.forEach((dept, empList) -> {
            System.out.println("Department: " + dept);
            empList.forEach(System.out::println);
        });
 
        // Sorting employees inside a department
        List<Employee> itEmployees = deptEmployees.get("IT");
        itEmployees.sort(Comparator.comparing(e -> e.name));
        System.out.println("\nSorted IT Employees by Name:");
        itEmployees.forEach(System.out::println);
 
        // Using TreeSet with custom comparator
        TreeSet<Employee> sortedById = new TreeSet<>(Comparator.comparingInt(e -> e.id));
        sortedById.addAll(employees);
        sortedById.addAll(itEmployees);
 
        System.out.println("\nTreeSet of Employees (sorted by ID):");
        sortedById.forEach(System.out::println);
 
        // Retrieval examples
        System.out.println("\nRetrieve specific employee from ArrayList:");
        Employee emp = employees.get(1);
        System.out.println("Employee at index 1: " + emp);
 
        System.out.println("\nCheck if HashSet contains 'Java': " + skills.contains("Java"));
        System.out.println("Check if TreeMap has key 103: " + orderedProjects.containsKey(103));
 
        // ================= END OF PROGRAM =================
        System.out.println("\n=== END OF MASTER COLLECTIONS DEMO ===");
    }
}

