package com.cognizant.training.java.concurrent;

import java.util.concurrent.*;

class WriteTask extends Thread {
    ConcurrentHashMap<Integer, String> map;
 
    WriteTask(ConcurrentHashMap<Integer, String> map) {
        this.map = map;
    }
 
    public void run() {
        map.put(1, "Java");
    }
}
 
class ReadTask extends Thread {
    ConcurrentHashMap<Integer, String> map;
 
    ReadTask(ConcurrentHashMap<Integer, String> map) {
        this.map = map;
    }
 
    public void run() {
        System.out.println(map.get(1));
    }
}
 
public class ConcurrentMapDemo3 {
    public static void main(String[] args) {
        ConcurrentHashMap<Integer, String> map = new ConcurrentHashMap<>();
 
        new WriteTask(map).start();
        new ReadTask(map).start();
    }
}