package com.cognizant.training.java.exception;

//1. Basic Try-Catch

public class BasicTryCatch {
    public static void main(String[] args) {
        try {
            int result = 10 / 0; // ArithmeticException
        } catch (ArithmeticException e) {
            System.out.println("Error: Division by zero!");
        }
    }
}