package com.cognizant.training.java.javaeight;

import java.util.*;
import java.time.*;
import java.util.stream.Collectors;
	
interface Calculator
{
	int add(int a,int b);
 
}
public class Main {
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Java8 Features
				//Lambda Functions&& Functional Interfaces
				
				
				System.out.println("This is Lambda & Functional Interfaces Example...");
				Calculator sum = (a,b)->a+b;
				int res = sum.add(10,20);
				System.out.println("Addition is : "+res);
				
				System.out.println("This is StreamAPI , forEach, Collectors and Method Reference Example...");
				
				//StreamAPI
				List<Integer> li = new ArrayList<>();
				li.add(2);
				li.add(3);
				li.add(4);
				li.add(5);
				li.add(6);
				li.add(9);
				
				List<Integer>ress;
				ress= li.stream()	
				     .filter(x->x%2==1)
				     .collect(Collectors.toList());
				
				ress.forEach(x->System.out.println(x+" "));
				
				
				System.out.println("This is Date & Time API Example...");
				
				LocalDate date = LocalDate.now();
				LocalTime time = LocalTime.now();
				LocalDateTime dT = LocalDateTime.now();
				System.out.println("Date is : " +date);
				System.out.println("Time is : "+time);
				System.out.println("Date & Time is : "+dT);
 
	}
 
}
 