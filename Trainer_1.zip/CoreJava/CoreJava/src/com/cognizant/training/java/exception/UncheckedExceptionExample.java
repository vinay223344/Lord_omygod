package com.cognizant.training.java.exception;

//Unchecked Exception Example (NullPointerException):

public class UncheckedExceptionExample {
  public static void main(String[] args) {
      String str = null;
      System.out.println(str.length()); // NullPointerException
  }
}