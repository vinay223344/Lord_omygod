package com.cognizant.training.java.exception;

//7. Checked vs Unchecked Exceptions

import java.io.*;
 
public class CheckedExceptionExample {
    public static void main(String[] args) {
        try {
            FileReader fr = new FileReader("file.txt"); // File may not exist
        } catch (IOException e) {
            System.out.println("Checked Exception: " + e);
        }
    }
}

