package com.cognizant.training.java.exception;

//2. Multiple Catch Blocks

public class MultipleCatch {
    public static void main(String[] args) {
        try {
            int[] arr = new int[5];
            arr[10] = 50; // ArrayIndexOutOfBoundsException
        } catch (ArithmeticException e) {
            System.out.println("Arithmetic Exception caught!");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array Index Out Of Bounds Exception caught!");
        } catch (Exception e) {
            System.out.println("General Exception caught!");
        }
    }
}