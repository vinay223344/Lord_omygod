package com.cognizant.training.java.oops;


//Stage I Concepts Cheat Sheet + Demo Program
//Each section has 4+ technical lines (cheat sheet) + code demonstration

import java.util.*;

//--- Interfaces & Abstract Classes ---
/*
1. Interfaces define contracts with abstract methods.
2. Abstract classes provide partial implementation, cannot be instantiated.
3. Classes implement interfaces to provide behavior.
4. Supports multiple inheritance via interfaces.
*/
interface Operation {
	int calculate(int a, int b);
}

abstract class Animal {
	abstract void sound();

	void eat() {
		System.out.println("Animal eats food");
	}
}

class Dog extends Animal {
	@Override
	void sound() {
		System.out.println("Dog barks");
	}
}

//--- Calculator Class ---
/*
* 1. Methods encapsulate reusable logic, can return values. 2. Overloading
* allows same method name with different parameters. 3. Static methods belong
* to class, not objects. 4. Constructors initialize objects, can be overloaded.
*/
class Calculator {
	int add(int a, int b) {
		return a + b;
	}

	double add(double a, double b) {
		return a + b;
	}

	static void info() {
		System.out.println("Calculator supports basic operations");
	}
}

//--- Arrays ---
/*
* 1. Arrays store sequential elements of same type. 2. One-dimensional arrays
* represent lists. 3. Multi-dimensional arrays represent matrices. 4. Fixed
* size, accessed via index.
*/
class ArrayDemo {
	void showArrays() {
		int[] arr = { 1, 2, 3 };
		for (int val : arr)
			System.out.println("Array element: " + val);

		int[][] matrix = { { 1, 2 }, { 3, 4 } };
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				System.out.print(matrix[i][j] + " ");
			}
			System.out.println();
		}
	}
}

//--- Exceptions ---
/*
* 1. Exceptions handle runtime errors gracefully. 2. try-catch-finally manages
* error flow. 3. throw and throws propagate exceptions. 4. User-defined
* exceptions extend Exception class.
*/
class ExceptionDemo {
	void riskyDivision(int a, int b) {
		try {
			int result = a / b;
			System.out.println("Result: " + result);
		} catch (ArithmeticException e) {
			System.out.println("Caught exception: " + e.getMessage());
		} finally {
			System.out.println("Finally block executed");
		}
	}
}

//--- Strings & Wrappers ---
/*
* 1. String class immutable; StringBuilder/StringBuffer mutable. 2. Wrapper
* classes convert primitives to objects (Integer, Double, etc.). 3. Useful for
* collections and type conversions. 4. Provide utility methods like parsing and
* formatting.
*/
class StringWrapperDemo {
	void showDemo() {
		String s1 = "Hello";
		String s2 = "World";
		System.out.println(s1 + " " + s2);
		System.out.println("Length: " + s1.length());

		Integer i = Integer.valueOf(100);
		int primitive = i.intValue();
		System.out.println("Wrapper Integer: " + i + ", primitive: " + primitive);
	}
}

//--- Main Class ---
public class StageOneCheatSheetProgram {

	// Variables, Operators, Statements
	/*
	 * 1. Primitive types: int, double, char, boolean. 2. Operators: arithmetic
	 * (+,-,*), relational (>,<), logical (&&,||). 3. Statements: if-else, switch,
	 * loops (for, while, do-while). 4. Control flow structures manage execution.
	 */
	int number = 10;
	double decimal = 20.5;
	String name = "Java";

	// Constructors
	StageOneCheatSheetProgram() {
		System.out.println("Default Constructor");
	}

	StageOneCheatSheetProgram(String msg) {
		System.out.println("Constructor: " + msg);
	}

	// Methods
	int square(int x) {
		return x * x;
	}

	public static void main(String[] args) {
		// Constructors
		StageOneCheatSheetProgram demo1 = new StageOneCheatSheetProgram();
		StageOneCheatSheetProgram demo2 = new StageOneCheatSheetProgram("Hello Java");

		// Variables & Operators
		int a = 10, b = 5;
		System.out.println("a+b=" + (a + b));
		System.out.println("a>b? " + (a > b));

		// Statements
		if (a > b)
			System.out.println("a is greater");
		switch (b) {
		case 5:
			System.out.println("b=5");
			break;
		default:
			System.out.println("default case");
		}
		for (int i = 0; i < 3; i++)
			System.out.println("for loop i=" + i);

		// Methods & Overloading
		Calculator calc = new Calculator();
		System.out.println("Add int: " + calc.add(2, 3));
		System.out.println("Add double: " + calc.add(2.5, 3.5));
		Calculator.info();

		// Inheritance & Polymorphism
		Animal dog = new Dog();
		dog.sound();
		dog.eat();

		// Interfaces
		Operation op = (x, y) -> x * y;
		System.out.println("Interface multiply: " + op.calculate(4, 5));

		// Arrays
		ArrayDemo arrDemo = new ArrayDemo();
		arrDemo.showArrays();

		// Exceptions
		ExceptionDemo exDemo = new ExceptionDemo();
		exDemo.riskyDivision(10, 0);

		// Strings & Wrappers
		StringWrapperDemo swDemo = new StringWrapperDemo();
		swDemo.showDemo();

		// Casting
		Object obj = "Java";
		if (obj instanceof String) {
			String str = (String) obj;
			System.out.println("Casted string: " + str);
		}

		// Return values
		System.out.println("Square of 6: " + demo1.square(6));

		System.out.println("Stage I Concepts Cheat Sheet Program Complete!");
	}
}