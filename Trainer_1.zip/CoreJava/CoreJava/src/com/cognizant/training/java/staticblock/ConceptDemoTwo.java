package com.cognizant.training.java.staticblock;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
 
class StaticBlockTwo {
    static {
        System.out.println(">>> Static block executed in Program 2");
    }
}
 
class EmployeeTwo implements Serializable {
    private static final long serialVersionUID = 2L;
 
    int id;
    String name;
    transient String password;
    volatile boolean active;
 
    public EmployeeTwo(int id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.active = true;
    }
 
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof EmployeeTwo)) return false;
        EmployeeTwo e = (EmployeeTwo) o;
        return id == e.id && Objects.equals(name, e.name);
    }
 
    @Override
    public int hashCode() {
        return Objects.hash(id, name);
    }
 
    @Override
    public String toString() {
        return "EmployeeTwo{id=" + id + ", name='" + name + "', active=" + active + "}";
    }
}
 
public class ConceptDemoTwo {
    public static void main(String[] args) {
        // HashMap first
        Map<Integer, String> map = new HashMap<>();
        map.put(1, "One");
        map.put(2, "Two");
        map.put(3, "Three");
 
        map.forEach((k, v) -> System.out.println("Key=" + k + ", Value=" + v));
 
        map.remove(2);
        map.put(4, null);
        System.out.println("HashMap after changes: " + map);
 
        // ConcurrentHashMap next
        ConcurrentHashMap<Integer, String> cmap = new ConcurrentHashMap<>();
        cmap.put(1, "Alpha");
        cmap.put(2, "Beta");
 
        Runnable updater = () -> {
            for (int i = 0; i < 3; i++) {
                cmap.put(i, Thread.currentThread().getName() + "-" + i);
                System.out.println(Thread.currentThread().getName() + " updated cmap with key " + i);
            }
        };
 
        Thread u1 = new Thread(updater, "Updater1");
        Thread u2 = new Thread(updater, "Updater2");
        u1.start();
        u2.start();
 
        try {
            u1.join();
            u2.join();
        } catch (InterruptedException ex)
        {
        }
    }
}