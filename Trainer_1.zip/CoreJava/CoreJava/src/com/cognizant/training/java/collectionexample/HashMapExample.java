package com.cognizant.training.java.collectionexample;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class HashMapExample {

    public static void main(String[] args) {

        // HashMap demo
        Map<String, Integer> studentScores = new HashMap<>();

        studentScores.put("Alice", 85);
        studentScores.put("Bob", 90);
        studentScores.put("Charlie", 70);

        for (Map.Entry<String, Integer> entry : studentScores.entrySet()) {
            System.out.println("Student: " + entry.getKey() +
                               ", Score: " + entry.getValue());
        }

        studentScores.put("Bob", studentScores.get("Bob") + 5);

        studentScores.put(null, 100);
        studentScores.put(null, 200);     // overwrites previous null key
        studentScores.put("David", null);
        studentScores.put("Sachin", null);

        studentScores.forEach((name, score) ->
                System.out.println(name + " scored " + score));

        System.out.println("HashMap after modifications: " + studentScores);

        // ConcurrentHashMap demo
        ConcurrentHashMap<String, String> concurrentMap = new ConcurrentHashMap<>();

        concurrentMap.put("T1", "Running");
        concurrentMap.put("T2", "Waiting");

        concurrentMap.forEach((key, value) ->
                System.out.println("Thread: " + key + " Status: " + value));

        Runnable writerTask = () -> {
            for (int i = 0; i < 5; i++) {
                String threadName = Thread.currentThread().getName();
                concurrentMap.put(threadName + "-" + i, "Updated");
                System.out.println(threadName + " added entry: "
                        + threadName + "-" + i);
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };

        Thread writer1 = new Thread(writerTask, "Writer1");
        Thread writer2 = new Thread(writerTask, "Writer2");

        writer1.start();
        writer2.start();

        try {
            writer1.join();
            writer2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        concurrentMap.computeIfAbsent("NewKey",
                k -> "GeneratedValue");

        concurrentMap.replace("T1", "Running", "Completed");

        String combined = concurrentMap.reduceEntries(
                2,
                (e1, e2) -> new AbstractMap.SimpleEntry<>(
                        "Combined",
                        e1.getValue() + "-" + e2.getValue())
        ).getValue();

        System.out.println("ConcurrentHashMap after modifications: "
                + concurrentMap);
        System.out.println("Reduced combined value: " + combined);
    }
}
