package com.cognizant.training.java.exception;

public class Kusdj {

}
