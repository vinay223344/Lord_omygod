package com.cognizant.training.java.staticblock;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;
 
// Demonstrates static block execution
class StaticBlockExample {
    static {
        System.out.println(">>> Static block executed before main()");
    }
}
 
// Employee class to show Object methods, transient, volatile
class Employee implements Serializable {
    private static final long serialVersionUID = 1L;
 
    int id;
    String name;
    transient String password; // transient: not serialized
    volatile boolean active;   // volatile: ensures visibility across threads
 
    public Employee(int id, String name, String password) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.active = true;
    }
 
    // Overriding Object methods
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Employee)) return false;
        Employee e = (Employee) o;
        return id == e.id && Objects.equals(name, e.name);
    }
 
    @Override
    public int hashCode() {
        return Objects.hash(id, name);
    }
 
    @Override
    public String toString() {
        return "Employee{id=" + id + ", name='" + name + "', active=" + active + "}";
    }
}
 
public class ConceptDemoOne {
    public static void main(String[] args) {
        // Static block demo
        new StaticBlockExample();
 
        // try-with-resources demo
        try (FileWriter fw = new FileWriter("demo1.txt")) {
            fw.write("Hello, try-with-resources in Program 1!");
        } catch (IOException e) {
            System.out.println("Exception in try-with-resources: " + e.getMessage());
        }
 
        // try-catch demo
        try {
            int result = 10 / 0;
        } catch (ArithmeticException e) {
            System.out.println("Caught exception: " + e);
        }
 
        // HashMap demo
        Map<String, Integer> studentScores = new HashMap<>();
        studentScores.put("Alice", 85);
        studentScores.put("Bob", 90);
        studentScores.put("Charlie", 70);
 
        for (Map.Entry<String, Integer> entry : studentScores.entrySet()) {
            System.out.println("Student: " + entry.getKey() + ", Score: " + entry.getValue());
        }
 
        studentScores.put("Bob", studentScores.get("Bob") + 5);
        studentScores.put(null, 100);
        studentScores.put("David", null);
 
        studentScores.forEach((name, score) -> {
            System.out.println(name + " scored " + score);
        });
 
        System.out.println("HashMap after modifications: " + studentScores);
 
        // ConcurrentHashMap demo
        ConcurrentHashMap<String, String> concurrentMap = new ConcurrentHashMap<>();
        concurrentMap.put("T1", "Running");
        concurrentMap.put("T2", "Waiting");
 
        concurrentMap.forEach((key, value) -> {
            System.out.println("Thread: " + key + " Status: " + value);
        });
 
        Runnable writerTask = () -> {
            for (int i = 0; i < 5; i++) {
                String threadName = Thread.currentThread().getName();
                concurrentMap.put(threadName + "-" + i, "Updated");
                System.out.println(threadName + " added entry: " + threadName + "-" + i);
                try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
            }
        };
 
        Thread writer1 = new Thread(writerTask, "Writer1");
        Thread writer2 = new Thread(writerTask, "Writer2");
        writer1.start();
        writer2.start();
 
        try {
            writer1.join();
            writer2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
 
        concurrentMap.computeIfAbsent("NewKey", k -> "GeneratedValue");
        concurrentMap.replace("T1", "Running", "Completed");
 
        String combined = concurrentMap.reduceEntries(2,
                (e1, e2) -> new AbstractMap.SimpleEntry<>("Combined", e1.getValue() + "-" + e2.getValue()))
                .getValue();
 
        System.out.println("ConcurrentHashMap after modifications: " + concurrentMap);
        System.out.println("Reduced combined value: " + combined);
 
        // Object methods demo
        Employee emp1 = new Employee(101, "Alice", "secret");
        Employee emp2 = new Employee(101, "Alice", "hidden");
 
        System.out.println("emp1.equals(emp2): " + emp1.equals(emp2));
        System.out.println("emp1.hashCode(): " + emp1.hashCode());
        System.out.println("emp1.toString(): " + emp1);
 
        // synchronized block demo
        List<String> sharedList = new ArrayList<>();
        Runnable task = () -> {
            synchronized (sharedList) {
                sharedList.add(Thread.currentThread().getName());
                System.out.println("Thread added: " + Thread.currentThread().getName());
            }
        };
 
        Thread t1 = new Thread(task, "T1");
        Thread t2 = new Thread(task, "T2");
        t1.start();
        t2.start();
 
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
 
        System.out.println("Shared List: " + sharedList);
 
        // Stack vs Heap demo
        int x = 10; // stack
        Employee emp3 = new Employee(102, "Bob", "pwd"); // heap
        System.out.println("Stack variable x: " + x);
        System.out.println("Heap object emp3: " + emp3);
 
        // ClassLoader demo
        ClassLoader classLoader = ConceptDemoOne.class.getClassLoader();
        System.out.println("ClassLoader: " + classLoader);
 
        // Serialization demo
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("emp1.ser"))) {
            oos.writeObject(emp1);
        } catch (IOException e) {
            e.printStackTrace();
        }
 
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("emp1.ser"))) {
            Employee deserialized = (Employee) ois.readObject();
            System.out.println("Deserialized Employee: " + deserialized);
            System.out.println("Password after deserialization (transient): " + deserialized.password);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
 
 