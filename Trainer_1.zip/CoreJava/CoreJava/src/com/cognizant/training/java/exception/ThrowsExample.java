package com.cognizant.training.java.exception;

//5. Throws Keyword

public class ThrowsExample {
    public static void main(String[] args) {
        try {
            riskyMethod();
        } catch (Exception e) {
            System.out.println("Caught Exception: " + e);
        }
    }
 
    static void riskyMethod() throws Exception {
        throw new Exception("This method always throws an exception!");
    }
}