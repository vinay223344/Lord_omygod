package com.cognizant.training.java.comparableandcomparator;

import java.util.*;

class Employee {
    int id;
    double salary;
 
    Employee(int id, double salary) {
        this.id = id;
        this.salary = salary;
    }
}
 
public class ComparatorDemo2 {
    public static void main(String[] args) {
        List<Employee> list = new ArrayList<>();
 
        list.add(new Employee(101, 45000));
        list.add(new Employee(102, 30000));
        list.add(new Employee(103, 60000));
 
        Collections.sort(list, (e1, e2) ->
                Double.compare(e2.salary, e1.salary));
 
        for (Employee e : list)
            System.out.println(e.id + " " + e.salary);
    }
}