package com.cognizant.training.java.comparableandcomparator;

import java.util.*;

class Student implements Comparable<Student> {
    int id;
    String name;

    Student(int id, String name) {
        this.id = id;
        this.name = name;
    }

    @Override
    public int compareTo(Student s) {
        return this.id - s.id;  // ascending order
    }
}

public class ComparableDemo2 {
    public static void main(String[] args) {
        List<Student> list = new ArrayList<>();

        list.add(new Student(3, "Ravi"));
        list.add(new Student(1, "Anu"));
        list.add(new Student(2, "Kiran"));

        Collections.sort(list);

        for (Student s : list) {
            System.out.println(s.id + " " + s.name);
        }
    }
}