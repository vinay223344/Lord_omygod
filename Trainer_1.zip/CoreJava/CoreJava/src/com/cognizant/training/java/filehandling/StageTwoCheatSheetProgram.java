package com.cognizant.training.java.filehandling;

//Stage II Cheat Sheet + Demo Program
//Covers: I/O Streams, Readers/Writers, Serialization,
//JDBC basics, JVM memory, Annotations
//=======================================================

import java.io.*;
import java.sql.*;
import java.util.*;

//-------------------------------
//1. Introduction to I/O Streams
//-------------------------------
/*
- I/O streams handle input and output of data in Java.
- InputStream reads bytes; OutputStream writes bytes.
- Hierarchy: InputStream -> FileInputStream, BufferedInputStream, etc.
- Streams can be byte-oriented or character-oriented.
*/
class IOStreamsDemo {
	void fileInputOutputDemo() {
		try {
			// FileOutputStream Example
			FileOutputStream fos = new FileOutputStream("demo.txt");
			fos.write("Hello I/O Streams".getBytes());
			fos.close();

			// FileInputStream Example
			FileInputStream fis = new FileInputStream("demo.txt");
			int ch;
			while ((ch = fis.read()) != -1) {
				System.out.print((char) ch);
			}
			fis.close();
			System.out.println();

			// BufferedInputStream Example
			BufferedInputStream bis = new BufferedInputStream(new FileInputStream("demo.txt"));
			while ((ch = bis.read()) != -1) {
				System.out.print((char) ch);
			}
			bis.close();
			System.out.println();

			// BufferedOutputStream Example
			BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream("demo.txt", true));
			bos.write("\nBuffered Output Stream Example".getBytes());
			bos.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

//-------------------------------
//2. Readers and Writers
//-------------------------------
/*
* - FileReader reads characters from files. - BufferedReader improves
* efficiency with buffering. - FileWriter writes characters to files. -
* BufferedWriter writes text efficiently with buffering.
*/
class ReaderWriterDemo {
	void readerWriterDemo() {
		try {
			FileWriter fw = new FileWriter("readerwriter.txt");
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write("Hello from BufferedWriter");
			bw.newLine();
			bw.write("Second line of text");
			bw.close();

			FileReader fr = new FileReader("readerwriter.txt");
			BufferedReader br = new BufferedReader(fr);
			String line;
			while ((line = br.readLine()) != null) {
				System.out.println("Read: " + line);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

//-------------------------------
//3. Serialization & Deserialization
//-------------------------------
/*
* - Serialization converts objects into byte streams. - Deserialization
* reconstructs objects from byte streams. - Implement Serializable interface to
* enable serialization. - Useful for saving object state or transferring over
* network.
*/
class Student implements Serializable {
	int id;
	String name;

	Student(int id, String name) {
		this.id = id;
		this.name = name;
	}
}

class SerializationDemo {
	void serializeDeserializeDemo() {
		try {
			Student trainee = new Student(1, "NormanlHero");
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("student.ser"));
			oos.writeObject(trainee);
			oos.close();

			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("student.ser"));
			Student deserialized = (Student) ois.readObject();
			ois.close();
			System.out.println("Deserialized Student: " + deserialized.id + " " + deserialized.name);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

//-------------------------------
//4. JDBC Basics
//-------------------------------
/*
* - JDBC allows Java programs to interact with databases. - Types of drivers:
* JDBC-ODBC, Native-API, Network Protocol, Thin Driver. - APIs: Connection,
* Statement, PreparedStatement, ResultSet. - Exceptions handled via
* SQLException.
*/
class JDBCDemo {
	void jdbcDemo() {
		try {
			// Example: Using JDBC with SQLite (adjust driver as needed)
			Class.forName("org.sqlite.JDBC");
			Connection conn = DriverManager.getConnection("jdbc:sqlite:sample.db");
			Statement stmt = conn.createStatement();
			stmt.executeUpdate("CREATE TABLE IF NOT EXISTS users (id INTEGER, name TEXT)");
			stmt.executeUpdate("INSERT INTO users VALUES (1, 'Bob')");
			ResultSet rs = stmt.executeQuery("SELECT * FROM users");
			while (rs.next()) {
				System.out.println("User: " + rs.getInt("id") + " " + rs.getString("name"));
			}
			conn.close();
		} catch (Exception e) {
			System.out.println("JDBC Exception: " + e.getMessage());
		}
	}
}

//-------------------------------
//5. JVM Runtime Memory Architecture
//-------------------------------
/*
* - JVM memory divided into Heap, Stack, Method Area, and Native Method Stack.
* - Object creation allocates memory in Heap. - Garbage collection reclaims
* unused objects. - Memory leaks occur when references prevent GC from
* reclaiming memory.
*/
class MemoryDemo {
	void memoryDemo() {
		String str = new String("Memory Demo");
		System.out.println("Created object: " + str);
		System.gc(); // Suggest garbage collection
		System.out.println("System.gc() invoked");
	}
}

//-------------------------------
//6. Annotations
//-------------------------------
/*
* - Annotations provide metadata for code. - Built-in
* annotations: @Override, @Deprecated, @SuppressWarnings. - Custom annotations
* can be defined with @interface. -
* Meta-annotations: @Retention, @Target, @Inherited.
*/
@interface MyAnnotation {
	String info();
}

class AnnotationDemo {
	@Deprecated
	void oldMethod() {
		System.out.println("Deprecated method");
	}

	@Override
	public String toString() {
		return "AnnotationDemo";
	}

	@MyAnnotation(info = "Custom Annotation Example")
	void annotatedMethod() {
		System.out.println("Annotated method executed");
	}
}

//-------------------------------
//Main Program
//-------------------------------
public class StageTwoCheatSheetProgram {
	public static void main(String[] args) {
		System.out.println("=== I/O Streams Demo ===");
		new IOStreamsDemo().fileInputOutputDemo();

		System.out.println("\n=== Reader/Writer Demo ===");
		new ReaderWriterDemo().readerWriterDemo();

		System.out.println("\n=== Serialization Demo ===");
		new SerializationDemo().serializeDeserializeDemo();

		System.out.println("\n=== JDBC Demo ===");
		new JDBCDemo().jdbcDemo();

		System.out.println("\n=== Memory Demo ===");
		new MemoryDemo().memoryDemo();

		System.out.println("\n=== Annotation Demo ===");
		AnnotationDemo ad = new AnnotationDemo();
		ad.oldMethod();
		ad.annotatedMethod();
		System.out.println(ad.toString());

		System.out.println("\n=== Stage II Concepts Cheat Sheet Program Complete ===");
	}
}

