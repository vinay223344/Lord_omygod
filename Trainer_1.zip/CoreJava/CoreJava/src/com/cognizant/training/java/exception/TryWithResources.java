package com.cognizant.training.java.exception;

//8. Try-With-Resources (AutoCloseable)

import java.io.*;
 
public class TryWithResources {
    public static void main(String[] args) {
        try (FileReader fr = new FileReader("file.txt")) {
            System.out.println("File opened successfully!");
        } catch (IOException e) {
            System.out.println("Exception: " + e);
        }
    }
}