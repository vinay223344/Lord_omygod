package com.example.iteratorprogs;

import java.util.Hashtable;
import java.util.Enumeration;

class Employee {
    private String name;
    private String department;

    public Employee(String name, String department) {
        this.name = name;
        this.department = department;
    }

    public String getDetails() {
        return "Name: " + name + ", Department: " + department;
    }
}

public class HashtableEnumerationDemo {
    public static void main(String[] args) {
        // Create a Hashtable with Integer keys and com.example.iteratorprograms.Employee values
        Hashtable<Integer, Employee> employees = new Hashtable<>();

        // Add employee records
        employees.put(101, new Employee("Arun", "HR"));
        employees.put(102, new Employee("Dev", "Finance"));
        employees.put(103, new Employee("Suresh", "IT"));
        employees.put(104, new Employee("Ramesh", "Marketing"));

        // Get Enumeration of keys
        Enumeration<Integer> keys = employees.keys();

        System.out.println("com.example.iteratorprograms.Employee Records:");
        while (keys.hasMoreElements()) {
            int id = keys.nextElement();
            Employee emp = employees.get(id);
            System.out.println("ID: " + id + " -> " + emp.getDetails());
        }
    }
}
