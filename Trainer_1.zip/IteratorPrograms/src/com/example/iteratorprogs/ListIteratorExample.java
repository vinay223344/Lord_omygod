package com.example.iteratorprogs;

import java.util.*;

public class ListIteratorExample {
    public static void main(String[] args) {
        List<String> cars = new ArrayList<>();
        cars.add("Toyota");
        cars.add("Honda");
        cars.add("Ford");

        System.out.println(cars);

        // Forward Traversal
        ListIterator<String> iterator = cars.listIterator();
        System.out.println("Forward Traversal");
        while (iterator.hasNext()) {
            int index = iterator.nextIndex();
            String brand = iterator.next();
            System.out.println("Index:" + index + " Brand:" + brand);

            if (brand.equals("Toyota")) {
                // assigning value
                iterator.set("BMW");
            }
        }

        System.out.println();
        // Backward Traversal
        System.out.println("Backward Traversal");
        while (iterator.hasPrevious()) {
            int index1 = iterator.previousIndex();
            String brand1 = iterator.previous();
            System.out.println("Index:" + index1 + " Brand:" + brand1);

            if (brand1.equals("BMW")) {
                iterator.remove();
                // adding value
                iterator.add("Toyota");
            }
        }

        System.out.println();
        // Final Traversal
        System.out.println("Final List:");
        while (iterator.hasNext()) {
            int index = iterator.nextIndex();
            String brand = iterator.next();
            System.out.println("Index:" + index + " Brand:" + brand);
        }
    }
}