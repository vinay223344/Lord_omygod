package com.example.iteratorprogs;

import java.util.ArrayList;
import java.util.Iterator;

public class IteratorExample {
    public static void main(String[] args) {

        // Create a list of integers
        ArrayList<Integer> numbers = new ArrayList<>();
        numbers.add(10);
        numbers.add(20);
        numbers.add(30);
        numbers.add(40);

        // Get the iterator object from the list
        Iterator<Integer> iterator = numbers.iterator();

        // Traverse the list using iterator
        while (iterator.hasNext()) {   // Check if next element exists
            int num = iterator.next(); // Get the next element

            // Print each element
            System.out.println("Value: " + num);

            // Remove element if it is divisible by 20
            if (num % 20 == 0) {
                iterator.remove(); // Safe removal during iteration
            }
        }

        // Print updated list after removal
        System.out.println("Updated List: " + numbers);
    }
}