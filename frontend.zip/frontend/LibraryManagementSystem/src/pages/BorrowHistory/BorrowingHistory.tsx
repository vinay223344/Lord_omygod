import React, { useState } from 'react';
import './BorrowingHistory.css';
import { formatDate } from '../../utils/formatDate';
import { returnBook } from '../../services/borrowService';
import Button from '../../components/Button';
import type { BorrowRecord } from '../../models/borrow';
import Headsup from '../../components/Headsup';
import Pagination from '../../components/Pagination/Pagination';

interface BorrowingHistoryProps {
  borrowingHistory: BorrowRecord[];
  onReturn: () => void;
}
const pageSize = 8; // Number of records per page

const BorrowingHistory: React.FC<BorrowingHistoryProps> = ({ borrowingHistory, onReturn }) => {
  const [currentPage, setCurrentPage] = useState(1);

  const totalPages = Math.ceil(borrowingHistory.length / pageSize);

  const paginatedHistory = borrowingHistory.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };
  const handleReturn = async (borrowId: number) => {
    try {
      await returnBook(borrowId);
      alert('Book returned successfully!');
      // Call the callback to refresh the history list in the parent
      onReturn();
    } catch (error) {
      alert('Failed to return book.');
    }
  };

  return (
    <div className="borrowing-history-section">
      <Headsup />
      <h3>Borrowing History</h3>
      <div className="table-container" style={{ overflowX: 'auto' }}>
        <table className="borrowing-history-table">
          <thead>
            <tr>
              <th>BorrowId</th>
              <th>BookId</th>
              <th>Borrowed Date</th>
              <th>Returned Date</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {paginatedHistory.length === 0 ? (
              <tr><td colSpan={6}>No borrowing history found.</td></tr>
            ) : (
              paginatedHistory.map((item) => (
                <tr key={item.transactionId}>
                  <td data-label="TransactionId">{item.transactionId}</td>
                  <td data-label="BookId">{item.bookId}</td>

                  <td data-label="Borrowed Date">{formatDate(item.borrowDate)}</td>
                  <td data-label="Returned Date">{item.returnDate ? formatDate(item.returnDate) : 'N/A'}</td>
                  <td data-label="Status">{item.status === 'RETURNED' ? 'Returned' : 'Borrowed'}</td>
                  <td data-label="Action">
                    {item.status === 'BORROWED' ? (
                      <Button onClick={() => handleReturn(item.transactionId)} width="70%">Return</Button>
                    ) : (
                      <span style={{ color: '#888' }}>-</span>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={handlePageChange}
        />
      </div>
    </div>
  );
};

export default BorrowingHistory;