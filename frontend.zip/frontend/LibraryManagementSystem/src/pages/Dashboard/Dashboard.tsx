import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

import MembersPage from "../MembersPage/MembersPage";
import UpdateProfileModal from "../../components/UpdateProfileModal/UpdateProfileModal";
import LoginPage from "../LoginPage/LoginPage";
import Sidebar from "../../components/Dashboard/Sidebar";
import ManageBook from "../ManageBook";
import "./Dashboard.css";
import { getBooks } from "../../services/bookService";
import { getUsers, getUserByRole } from "../../services/authService";
import SearchBook from "../Search Book/SearchBook";
import Headsup from "../../components/Headsup";

interface ProfileData {
  userId: number | undefined;
  fullName?: string | undefined;
  email?: string;
  phoneNo?: string;
  address?: string;
}

function Dashboard() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [loggedOut, setLoggedOut] = useState(false);
  const [profileData, setProfileData] = useState<ProfileData>({
    userId: undefined,
    fullName: "",
    email: "",
    phoneNo: "",
    address: "",
  });
  const navigate = useNavigate();

  const [stats, setStats] = useState([
    { title: "Total Books", value: 0, icon: "📚", color: "#667eea" },
    { title: "Active Members", value: 0, icon: "👥", color: "#48bb78" },
  ]);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const books = await getBooks();
        const users = await getUsers();
        setStats([
          { title: "Total Books", value: books.length, icon: "📚", color: "#667eea" },
          { title: "Active Members", value: users.length, icon: "👥", color: "#48bb78" },
        ]);
      } catch (error) {
        console.error("Error fetching stats:", error);
      }
    };
    fetchStats();
  }, []);

  useEffect(() => {
    // Fetch admin profile dynamically
    const fetchAdminProfile = async () => {
      console.log("Fetching admin profile...");
      try {
        const adminResponse = await getUserByRole("ADMIN");
        const admin = Array.isArray(adminResponse) ? adminResponse[0] : adminResponse;
        if (admin) {
          setProfileData({
            userId: admin.userId || admin.userID, // handle both userId and userID
            fullName: admin.fullName,
            email: admin.email,
            phoneNo: admin.phoneNo,
            address: admin.address,
          });
        }
        console.log("Admin profile data:", admin);
      } catch (error) {
        console.error("Error fetching admin profile:", error);
      }
    };
    fetchAdminProfile();
  }, []);

  const menus = [
    {
      name: "Dashboard",
      onClick: () => setActiveTab("dashboard"),
    },
    {
      name: "Members",
      onClick: () => setActiveTab("members"),
    },
    {
      name: "Books",
      onClick: () => setActiveTab("books"),
    },
    
  ];

  // Simple data arrays

  function getInitials(name: string) {
    const words = name.split(" ");
    let initials = "";
    for (let i = 0; i < words.length; i++) {
      initials += words[i][0];
    }
    return initials.toUpperCase();
  }

  function openUpdateModal() {
    setShowUpdateModal(true);
  }

  function closeUpdateModal() {
    setShowUpdateModal(false);
  }

  function handleProfileUpdate(updatedProfile: ProfileData) {
    setProfileData(updatedProfile);
    alert("Profile updated successfully!");
  }

  function handleLogout() {
    if (confirm("Are you sure you want to logout?")) {
      setLoggedOut(true);
    }
  }

  // Show login page if logged out
  if (loggedOut) {
    navigate("/login");
  }

  // Render different content based on active tab
  function renderContent() {
    if (activeTab === "members") {
      return <MembersPage />;
    }

    if (activeTab === "books") {
  return (
    <ManageBook />
  );
}

   
    // Dashboard content
    return (
      <div className="main-content">
        <Headsup />
        <div className="content-header">
          <h1>Dashboard</h1>
          <p>Overview of your library management system</p>
        </div>

        {/* Profile Information */}
        <div className="profile-section">
          <div className="profile-header">
            <h3>Profile Information</h3>
            <button className="update-profile-btn" onClick={openUpdateModal}>
               Update Profile
            </button>
          </div>

          <div className="profile-content">
            <div className="profile-avatar">
              <div className="avatar-circle">
                {getInitials(profileData.fullName ?? '')}
              </div>
            </div>

            <div className="profile-details">
              <div className="detail-row">

                <span className="detail-label">Full Name:</span>
                <span className="detail-value">{profileData.fullName}</span>
              </div>
              <div className="detail-row">

                <span className="detail-label">Phone Number:</span>
                <span className="detail-value">
                  {profileData.phoneNo || "Not provided"}
                </span>
              </div>
              <div className="detail-row">

                <span className="detail-label">Account Type:</span>
                <span className="detail-value">Admin</span>
              </div>
            </div>

            <div className="profile-contact">
              <div className="detail-row">

                <span className="detail-label">Email Address:</span>
                <span className="detail-value">{profileData.email}</span>
              </div>
              <div className="detail-row">

                <span className="detail-label">Address:</span>
                <span className="detail-value">
                  {profileData.address || "Not provided"}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="stats-section">
          <h3>Statistics</h3>
          <div className="stats-grid">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="stat-card"
                style={{ borderLeftColor: stat.color }}
              >
                <div className="stat-icon" style={{ color: stat.color }}>
                  {stat.icon}
                </div>
                <div className="stat-content">
                  <div className="stat-value">{stat.value}</div>
                  <div className="stat-title">{stat.title}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Popular Books */}

      </div>
    );
  }

  return (
    <div className="dashboard-container">
      {/* Sidebar - visible on all pages except login */}
      <Sidebar
        menus={[
          {
      name: "Dashboard",
      onClick: () => setActiveTab("dashboard"),
    },
    {
      name: "Members",
      onClick: () => setActiveTab("members"),
    },
    {
      name: "Books",
      onClick: () => setActiveTab("books"),
    },
        ]}
        activeTab={activeTab}
        username={profileData.fullName || "ADMIN"}
        onLogout={handleLogout}
      />

      {/* Main Content */}
      {renderContent()}

      {/* Update Profile Modal */}
      <UpdateProfileModal
        isOpen={showUpdateModal}
        onClose={closeUpdateModal}
        currentProfile={profileData}
        onUpdate={handleProfileUpdate}
      />
    </div>
  );
}

export default Dashboard;