import React, { useState, useEffect } from 'react';
import './SearchBook.css';
import type { BookFormData } from '../../components/AddBookModal';
import AddBookModal from '../../components/AddBookModal';
import type { Book } from '../../models/book';
import type { User } from '../../models/users';
import { getBooks, deleteBook, addBook, updateBook, getBooksByTitle, getBooksByAuthor, getBooksByGenre } from '../../services/bookService';
import { borrowBook } from '../../services/borrowService';
import { getImageUrl } from '../../utils/getImageUrl';
import Button from '../../components/Button';
import Headsup from '../../components/Headsup';
import Pagination from '../../components/Pagination/Pagination';
interface SearchBookProps {
  user: User;
  onBookBorrowed: () => void;
}

const genres = ['Action', 'Adventure', 'Fantasy', 'Drama', 'Mystery', 'Tragedy', 'Dystopian', 'Southern Gothic', 'Science Fiction'];
const searchOptions = [
  { value: "title", label: "Title" },
  { value: "author", label: "Author" },
  { value: "genre", label: "Genre" },
  { value: "year", label: "Year Published" },
];

const SearchBook: React.FC<SearchBookProps> = ({ user, onBookBorrowed }) => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [genre, setGenre] = useState('');
  const [year, setYear] = useState('');
  const [books, setBooks] = useState<Book[]>([]);
  const [filteredBooks, setFilteredBooks] = useState<Book[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [bookToEdit, setBookToEdit] = useState<Book | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchBy, setSearchBy] = useState<string>("title");
  const [searchValue, setSearchValue] = useState<string>("");
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 8;
  

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await getBooks();
      setBooks(response);
      setFilteredBooks(response);
    } catch (error) {
      console.error('Error fetching books:', error);
    }
  };

  const handleSearch = async () => {
    console.log('[DEBUG] handleSearch called');
    if (!searchValue.trim() && searchBy !== "genre") {
      setFilteredBooks(books);
      return;
    }
    if (searchBy === "genre" && !genre) {
      setFilteredBooks(books);
      return;
    }

    

    setIsLoading(true);
    setError(null);

    try {
      let result: any = null;
      if (searchBy === "title") {
        console.log("[DEBUG] Sending getBooksByTitle request with:", searchValue);
        result = await getBooksByTitle(searchValue);
      } else if (searchBy === "author") {
        console.log("[DEBUG] Sending getBooksByAuthor request with:", searchValue);
        result = await getBooksByAuthor(searchValue);
      } else if (searchBy === "genre") {
        console.log("[DEBUG] Sending getBooksByGenre request with:", genre);
        result = await getBooksByGenre(genre);
      } else if (searchBy === "year") {
        // Filter on frontend as there is no backend API for year
        result = books.filter(book => String(book.yearPublished) === searchValue.trim());
      }

      if (Array.isArray(result) && result.length > 0) {
        setFilteredBooks(result);
      } else if (result && typeof result === 'object') {
        setFilteredBooks([result]);
      } else {
        setFilteredBooks([]);
      }
    } catch (err) {
      setError("Error searching for books. Please try again.");
      setFilteredBooks([]);
      console.error("Search error:", err);
    } finally {
      setIsLoading(false);
    }
  };
  const totalPages = Math.ceil(filteredBooks.length / pageSize);

  const paginatedBooks = filteredBooks.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize
  );
   useEffect(() => {
    setCurrentPage(1); // Reset to first page on new search/filter
  }, [filteredBooks]);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };


  const handleBorrow = async (bookId: number) => {
    if (!user || !user.userId) {
      alert('You must be logged in to borrow a book.');
      return;
    }

    try {
      await borrowBook({ bookId, userId: user.userId,  });
      alert('Book borrowed successfully!');
      // Update the book list to show one less available copy
      const updatedBooks = filteredBooks.map(book => {
        if (book.bookId === bookId) {
          return { ...book, availableCopies: book.availableCopies - 1 };
        }
        return book;
      });
      setFilteredBooks(updatedBooks);
      // Notify the parent component that a book has been borrowed
      onBookBorrowed();
    } catch (error) {
      console.error('Error borrowing book:', error);
      alert('Failed to borrow book. It might be unavailable.');
    }
  };

  const handleUpdateBook = (book: Book) => {
    setBookToEdit(book);
    setIsModalOpen(true);
  };

  const handleDeleteBook = async (bookId: number) => {
    if (window.confirm('Are you sure you want to delete this book?')) {
      try {
        await deleteBook(bookId);
        alert('Book deleted successfully!');
        const updatedBooks = filteredBooks.filter(book => book.bookId !== bookId);
        setFilteredBooks(updatedBooks);
      } catch (error) {
        console.error('Error deleting book:', error);
        alert('Failed to delete book.');
      }
    }
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    setBookToEdit(null);
  };

  const handleAddBook = async (book: BookFormData) => {
  try {
    const newBook: Omit<Book, 'bookId'> = {
      ...book,
      availableCopies: Number(book.copies),
      yearPublished: Number(book.year),
      isbn: book.isbn ?? '',
    };
    const response = await addBook(newBook);
    setBooks([...books, response]);
    setFilteredBooks([...filteredBooks, response]);
    handleModalClose();
  } catch (error) {
    console.error('Error adding book:', error);
  }
};

  const handleUpdate = async (updatedBook: Book) => {
    try {
      await updateBook(updatedBook.bookId, updatedBook);
      const updatedBooks = filteredBooks.map(book =>
        book.bookId === updatedBook.bookId ? updatedBook : book
      );
      setFilteredBooks(updatedBooks);
      handleModalClose();
    } catch (error) {
      console.error('Error updating book:', error);
    }
  };

  return (
    <div className="search-book-container">
      <Headsup />
      <h2>Books Management</h2>
      <p>Borrow your favourite book from library's collection</p>
      <div className="search-filter-box">
        <h3>Search & Filter Books</h3>
        <div className="search-fields">
          <select value={searchBy} onChange={e => {
            setSearchBy(e.target.value);
            setSearchValue("");
            setGenre("");
          }}>
            {searchOptions.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
          {searchBy === "genre" ? (
            <select value={genre} onChange={e => setGenre(e.target.value)}>
              <option value="">Select genre</option>
              {genres.map((g) => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          ) : (
            <input
              type={searchBy === "year" ? "number" : "text"}
              placeholder={
                searchBy === "title"
                  ? "Search by title..."
                  : searchBy === "author"
                  ? "Search by author..."
                  : "Year published..."
              }
              value={searchValue}
              onChange={e => setSearchValue(e.target.value)}
            />
          )}
          <Button onClick={handleSearch} width="25%" color="white" background="#3ddc97">Search</Button>
        </div>
      </div>
      <div className="books-list">
        <h4>Action</h4>
        <div className="books-cards">
          {paginatedBooks.length === 0 ? (
            <p>No books found.</p>
          ) : (
            paginatedBooks.map((book) => {
              const imageMap: Record<string, string> = {
  "The Silent Patient": "The Silent Patient.jpg",
  "Educated": "Educated.jpg",
  "Becoming": "Becoming.jpg",
  "Atomic Habits": "Atomic Habits.jpg",
  "The Midnight Library": "The Midnight Library.jpg",
  "Where the Crawdads Sing": "Where the crawdads sing.jpg",
  "Normal People": "Normal People.jpg",
  "The Testaments": "The testaments.jpg",
  "Circe": "Circe.jpg",
  "Dune": "Dune.jpg",
  "The Hobbit": "The hobbit.jpg",
  "1984": "1984.png",
  "Pride and Prejudice": "Pride and prejudice.jpg",
  "To Kill a Mockingbird": "ToKillAMocking.jpg",
  "The Catcher in the Rye": "The Catcher in the Rye.jpg",
  "The Great Gatsby": "GreatGatsby.jpg",
  "The Alchemist": "The Alchemist.jpg",
  "Harry Potter and the Sorcerer's Stone": "Harry Potter and the Sorcerers stone.jpg",
  "Harry Potter and the Chamber of Secrets": "Harry Potter and the Chamber of  Secrets.jpg",
  "Harry Potter and the Prisoner of Azkaban": "Harry Potter and the Prisoner of Azkaban.jpg",
  "The Fellowship of the Ring": "The Fellowship of the Ring.jpg",
  "The Two Towers": "The two towers.jpg",
  "The Return of the King": "The Return of the King.jpg",
  "The Hunger Games": "The Hunger Games.jpg",
  "Catching Fire": "Catching Fire.jpg",
  "Mockingjay": "Mockingjay.jpg",
  "Brave New World": "Brave new World.jpg",
  "The Road": "The road.jpg",
  "The Martian": "The martian.jpg",
  "Project Hail Mary": "Project Hail Mary.jpg",
  "The Shining": "The shining.jpg",
  "It": "It.jpg",
  "Doctor Sleep": "Doctor Sleep.jpg",
  "Pet Sematary": "Pet Semetary.jpg",
  "Frankenstein": "Frankenstein.jpg",
  "Dracula": "Dracula.jpg",
  "Moby Dick": "Moby Dick.jpg",
  "The Old Man and the Sea": "The old man and the sea.jpg",
  "A Game of Thrones": "A Game of thrones.jpg",
  "A Clash of Kings": "A clash of kings.jpg",
  "A Storm of Swords": "A storm of swords.jpg",
  "A Feast for Crows": "A feast of crows.jpg",
  "A Dance with Dragons": "A dance with dragons.jpg",
  "The Da Vinci Code": "The Da vinci Code.jpg",
  "Angels and Demons": "Angels and demons.jpg",
  "Inferno": "Inferno.jpg",
  "Origin": "Origin.jpg",
  "Digital Fortress": "Digital Fortress.jpg",
  "The Kite Runner": "The kite runner.jpg",
  "A Thousand Splendid Suns": "A thousand Splendid suns.jpg",
};

            const imageFile = imageMap[book.title] || "react.svg";
        return(
              <div className="book-card" key={book.bookId}>
                  <img src={getImageUrl(imageFile)} alt={book.title} className="book-cover" />
                <div className="book-info">
                  <b>{book.title}</b>
                  <div><b>ID:</b> {book.bookId}</div>
                  <div><b>Author:</b> {book.author}</div>
                  <div><b>Genre:</b> {book.genre}</div>
                  <div><b>Year:</b> {book.yearPublished ?? 'N/A'}</div>
                  <div><b>Available:</b> {book.availableCopies}</div>
                </div>
                {user.role === 'ADMIN' ? (
                  <div className="admin-actions">
                    <Button onClick={() => handleUpdateBook(book)} width="48%">Update</Button>
                    <Button onClick={() => handleDeleteBook(book.bookId)} width="48%">Delete</Button>
                  </div>
                ) : (
                  <Button onClick={() => handleBorrow(book.bookId)} width="100%">{book.availableCopies === 0 ? 'Unavailable' : 'Borrow'}</Button>
                )}
              </div>
            );
            })
          )}
        </div>
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={handlePageChange}
        />
      </div>
      <AddBookModal
        isOpen={isModalOpen}
        onClose={handleModalClose}
        onAddBook={handleAddBook} 
        onUpdateBook={handleUpdate}
        bookToEdit={bookToEdit}
      />
    </div>
  );
};

export default SearchBook;