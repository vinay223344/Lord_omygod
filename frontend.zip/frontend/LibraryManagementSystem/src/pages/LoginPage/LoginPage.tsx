import { useState } from "react";
import { useNavigate } from "react-router-dom";
import RegisterModal from "../../components/RegisterModal/RegisterModal";
import "./LoginPage.css";
import { loginUser } from "../../services/authService";
import Button from "../../components/Button";
import { useAuth } from "../../../AuthContext";

function LoginPage() {
  const [loginType, setLoginType] = useState("user");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();
  const { login, user } = useAuth();
  function handleEmailChange(e: React.ChangeEvent<HTMLInputElement>) {
    setEmail(e.target.value);
    setError(""); // Clear error when user types
  }

  function handlePasswordChange(e: React.ChangeEvent<HTMLInputElement>) {
    setPassword(e.target.value);
    setError(""); // Clear error when user types
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      
        if (loginType === "admin" && email !== "admin@library.com") {
            alert("Invalid admin email");
            return;
          }
          

   await login(email, password); // Use AuthContext login
      setLoading(false);

      if (user?.role === "ADMIN") {
        navigate("/dashboard");
      } else {
        navigate("/user-dashboard");
      }
    } catch (err) {
      setLoading(false);
      setError("Invalid credentials or network error.");
    }
  }

  function openModal() {
    setShowModal(true);
  }

  function closeModal() {
    setShowModal(false);
  }

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <h1 className="title">Library Management System</h1>
          <p className="subtitle">Sign in to your account</p>
        </div>

        <div className="login-type-selector">
          <button
            className={loginType === "user" ? "type-btn active" : "type-btn"}
            onClick={() => setLoginType("user")}
          >
            User Login

          </button>
          <button
            className={loginType === "admin" ? "type-btn active" : "type-btn"}
            onClick={() => setLoginType("admin")}
          >            Admin Login
          </button>
        </div>

        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <div className="input-wrapper">
              <input
                type="email"
                id="email"
                value={email}
                onChange={handleEmailChange}
                placeholder="Enter your email"
                required
              />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <div className="input-wrapper">
              <input
                type="password"
                id="password"
                value={password}
                onChange={handlePasswordChange}
                placeholder="Enter your password"
                required
              />
            </div>
          </div>

          {error && <div className="error-message">{error}</div>}

          <Button onClick={() => {}} width="100%" color="white" background="#2b6cb0" >
            {loading ? "Signing In..." : "Sign In"}
          </Button>
        </form>

        {loginType === "user" && (
          <div className="login-footer">
            <a href="#" className="register-link" onClick={openModal}>
              New? Register Now
            </a>
          </div>
        )}

        
      </div>

      <RegisterModal isOpen={showModal} onClose={closeModal} />
    </div>
  );
}

export default LoginPage;
