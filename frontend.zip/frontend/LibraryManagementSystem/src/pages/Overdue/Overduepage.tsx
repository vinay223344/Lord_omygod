import { useState, useEffect } from "react";
import { formatDate } from "../../utils/formatDate";
import { getOverdueItems, payFine } from "../../services/fineService";
import PaymentSuccessModal from "../../components/PaymentSuccessModal";
import Button from "../../components/Button";
import Headsup from "../../components/Headsup";

interface OverdueBook {
  transactionId: number;
  bookId: number;
  userId: number;
  borrowDate: string;
  returnDate: string | null;
  status: string;
  title?: string; // optional, if available
}

interface Fine {
  fineId: number;
  amount: number;
  paymentStatus: string;
  transactionDate: string | null;
}

function Overdue() {
  const [overdueBooks, setOverdueBooks] = useState<OverdueBook[]>([]);
  const [fines, setFines] = useState<Fine[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState<"overdue" | "fine">("overdue");

  // Get current user from localStorage
  const currentUser = localStorage.getItem("currentUser");
  let userId: number | null = null;
  if (currentUser) {
    try {
      const parsedUser = JSON.parse(currentUser);
      userId = parseInt(parsedUser.userId, 10);
    } catch (e) {
      console.error("Error parsing currentUser from localStorage", e);
    }
  }

  const fetchOverdueItems = async () => {
    console.log("fetchOverdueItems called with userId:", userId);
    try {
      if (userId !== null && !isNaN(userId)) {
        const response = await getOverdueItems(userId);
        console.log("Fetched overdue items:", response);
        setOverdueBooks(response.overdueBooks || []);
        setFines(response.paymentHistory || []);
      } else {
        setOverdueBooks([]);
        setFines([]);
        console.error("User ID not found or invalid in localStorage");
      }
    } catch (error) {
      console.error("Error fetching overdue items:", error);
    }
  };

  useEffect(() => {
    console.log("useEffect triggered");
    fetchOverdueItems();
  }, []);

  const getDueDate = (tx: OverdueBook) => {
    // Assuming due date is borrowDate + 14 days (or adjust as per business logic)
    const borrowDate = new Date(tx.borrowDate);
    borrowDate.setDate(borrowDate.getDate() + 14);
    return borrowDate;
  };

  const daysOverdue = (tx: OverdueBook) => {
    const dueDate = getDueDate(tx);
    const today = new Date();
    const diffTime = today.getTime() - dueDate.getTime();
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  const handlePay = async (fineId: number) => {
    try {
      await payFine(fineId);
      setModalOpen(true);

      // Optimistically update the UI
      setFines((prevFines) =>
        prevFines.map((fine) =>
          fine.fineId === fineId ? { ...fine, paymentStatus: "PAID" } : fine
        )
      );
    } catch (error) {
      console.error("Error paying fine:", error);
    }
  };

  return (
    <div className="borrowing-history-section">
      <Headsup />
      <h3>Overdue and Fine</h3>
      <div className="tab-buttons" style={{ marginBottom: "1rem", display: "flex", gap: "1rem" }}>
  <Button
    onClick={() => setSelectedTab("overdue")}
    width="48%"
    color={selectedTab === "overdue" ? "#ffffff" : "#333333"}
    background={selectedTab === "overdue" ? "#2b6cb0" : "#d3d3d3"}
  >
    Overdue
  </Button>

  <Button
    onClick={() => setSelectedTab("fine")}
    width="48%"
    color={selectedTab === "fine" ? "#ffffff" : "#333333"}
    background={selectedTab === "fine" ? "#2b6cb0" : "#d3d3d3"}
  >
    Fine
  </Button>
</div>
      <PaymentSuccessModal open={modalOpen} onClose={() => setModalOpen(false)} />
      {selectedTab === "overdue" && (
        <div className="table-container">
          <table className="borrowing-history-table">
            <thead>
              <tr>
                <th>Transaction ID</th>
                <th>Book ID</th>
                <th>Borrow Date</th>
                <th>Due Date</th>
                <th>Days Overdue</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {overdueBooks.map((tx) => (
                <tr key={tx.transactionId}>
                  <td>{tx.transactionId}</td>
                  <td>{tx.bookId}</td>
                  <td>{formatDate(tx.borrowDate)}</td>
                  <td>{formatDate(getDueDate(tx).toISOString())}</td>
                  <td>{daysOverdue(tx)}</td>
                  <td>{tx.status}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {selectedTab === "fine" && (
        <div className="fine-tab-container" style={{ textAlign: "center" }}>
          {fines.length > 0 && (
            <>
              {/* Show the first pending fine amount and Pay Now button */}
              {fines.find(fine => fine.paymentStatus === "PENDING") ? (
                <div style={{ marginBottom: "1rem" }}>
                  <h2>Fine Amount: ₹{fines.find(fine => fine.paymentStatus === "PENDING")?.amount}</h2>
                  <Button
                    onClick={() => handlePay(fines.find(fine => fine.paymentStatus === "PENDING")!.fineId)}
                    width="30%" background="#3ddc97"
                  >
                    Pay Now
                  </Button>
                </div>
              ) : (
                <h3>No pending fines to pay</h3>
              )}

              {/* Payment history table below */}
              <div className="table-container" style={{ marginTop: "2rem" }}>
                <h3>Payment History</h3>
                <table className="borrowing-history-table" style={{ margin: "0 auto" }}>
                  <thead>
                    <tr>
                      <th>Fine ID</th>
                      <th>Amount</th>
                      <th>Status</th>
                      <th>Transaction Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {fines.map((fine) => (
                      <tr key={fine.fineId}>
                        <td>{fine.fineId}</td>
                        <td>₹{fine.amount}</td>
                        <td>{fine.paymentStatus}</td>
                        <td>{fine.transactionDate ? formatDate(fine.transactionDate) : "-"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
          {fines.length === 0 && <h3>No fines found</h3>}
        </div>
      )}
    </div>
  );
}

export default Overdue;
