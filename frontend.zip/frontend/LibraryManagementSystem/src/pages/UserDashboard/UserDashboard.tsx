import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

// import LoginPage from "../LoginPage/LoginPage";

import "./UserDashboard.css";
import NotificationPopup from '../../components/Notification/NotificationPopup';
import Sidebar from "../../components/Dashboard/Sidebar";
import BorrowingHistory from "../BorrowHistory/BorrowingHistory";
import type { BorrowRecord } from "../../models/borrow";
import SearchBook from "../Search Book/SearchBook";
import UpdateProfileModal from "../../components/UpdateProfileModal/UpdateProfileModal";

import Overdue from "../Overdue/Overduepage"; // Import the Overdue component
import { getBorrowHistory } from "../../services/borrowService";
import { getBooks } from "../../services/bookService";
import NotificationTable from '../../components/Notification/NotificationTable';
import { getNotifications } from "../../services/notificationService";

import type { User } from "../../models/users";
import Headsup from "../../components/Headsup";

// Accept user prop
interface UserDashboardProps {
  user: User;
}


function UserDashboard({ user }: UserDashboardProps) {
    const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);

    const [sidebarOpen, setSidebarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  
  const [loggedOut, setLoggedOut] = useState(false);
  const [borrowingHistory, setBorrowingHistory] = useState<BorrowRecord[]>([]);
  const [stats, setStats] = useState([
    { title: "Total Books", value: 0, icon: "📚", color: "#667eea" },
    { title: "Books Borrowed", value: 0, icon: "🔄", color: "#ed8936" },
    { title: "Overdue Books", value: 0, icon: "⏰", color: "#e53e3e" },
  ]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState([
  ]);
  const navigate = useNavigate();
  const [profileData, setProfileData] = useState<User>({
      userId: undefined,
      fullName: "",
      email: "",
      phoneNo: "",
      address: "",
    });
useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth <= 768);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  // Debug log to see what user data is received
  console.log('📊 UserDashboard received user:', user);
  console.log('📊 UserDashboard - user.fullName:', user?.fullName);
  console.log('📊 UserDashboard - user.role:', user?.role);
  console.log('📊 UserDashboard - user.userId:', user?.userId);

  // Debug: show currentUser from localStorage
  const localUser = localStorage.getItem('currentUser');
  console.log('📦 localStorage currentUser:', localUser);

  const fetchDashboardData = async () => {
    if (!user.userId) return; // Use memid instead of id
    try {
      const history = await getBorrowHistory(user.userId);
      const notes = await getNotifications(user.userId);
      const books = await getBooks();
      setNotifications(notes);
      setBorrowingHistory(history);
      const borrowedCount = history.length;
      const overdueCount = history.filter((b: BorrowRecord) => !b.returnDate).length;
      setStats([
        { title: "Total Books", value: books.length, icon: "📚", color: "#667eea" },
        { title: "Books Borrowed", value: borrowedCount, icon: "🔄", color: "#ed8936" },
        { title: "Overdue Books", value: overdueCount, icon: "⏰", color: "#e53e3e" },
      ]);
    } catch (error) {
      console.error("Error fetching dashboard data:", error);
    }
  };

  

  useEffect(() => {
    fetchDashboardData();
  }, [user.userId]); // Use memid instead of id

  function getInitials(name: string | undefined) {
    if (!name) return "U"; // Return default initial if name is undefined
    const words = name.split(" ");
    let initials = "";
    for (let i = 0; i < words.length; i++) {
      initials += words[i][0];
    }
    return initials.toUpperCase();
  }

  function openUpdateModal() {
    setShowUpdateModal(true);
  }

  function closeUpdateModal() {
    setShowUpdateModal(false);
  }

  function handleProfileUpdate(updatedProfile: {
  userId: number | undefined;
  fullName?: string;
  email?: string;
  phoneNumber?: string;
  address?: string;
}) {
  setProfileData({
    userId: updatedProfile.userId,
    fullName: updatedProfile.fullName || "",
    email: updatedProfile.email || "",
    phoneNo: updatedProfile.phoneNumber || "", // Map phoneNumber to phoneNo
    address: updatedProfile.address || ""
  });
  alert("Profile updated successfully!");
}
  function handleLogout() {
    if (confirm("Are you sure you want to logout?")) {
      setLoggedOut(true);
    }
  }

  // Show login page if logged out
  if (loggedOut) {
    navigate("/login");
  }

  // Render different content based on active tab
  function renderContent() {
    if (activeTab === "books") {
      return (
        <div className="main-content">
          <SearchBook user={user} onBookBorrowed={fetchDashboardData} />
        </div>
      );
    }

    if (activeTab === "borrowing") {
      return (
        <div className="main-content">
          <BorrowingHistory borrowingHistory={borrowingHistory} onReturn={fetchDashboardData} />
        </div>
      );
    }

    if (activeTab === "overdues") {
         return (
        <div className="main-content">
          <Overdue  />
        </div>
      );
    }

    // Dashboard content
    return (
      <>
      <div className="main-content">
              <Headsup />

        <div className="content-header" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: '50px'}}>
          <div>
            <h1>Member Dashboard</h1>
            <p>Welcome to your library dashboard</p>
          </div>
          <button
            className="notification-btn"
            style={{ marginLeft: 'auto' }}
            onClick={() => setShowNotifications(true)}
            >
{isMobile ? <span role="img" aria-label="notifications">🔔</span> : "Show Notifications"}</button>
        </div>
          {showNotifications && (
            <div style={{ position: 'fixed', top: 70, right: 30, zIndex: 2000 }}>
              <NotificationPopup
                notifications={notifications}
                onClose={() => setShowNotifications(false)}
              />
            </div>
          )}
        

        {/* Profile Information */}
        <div className="profile-section">
          <div className="profile-header">
            <h3>Profile Information</h3>
            <button className="update-profile-btn" onClick={openUpdateModal}>
               Update Profile
            </button>
          </div>

          <div className="profile-content">
            <div className="profile-avatar">
              <div className="avatar-circle">{getInitials(user.fullName)}</div>
            </div>

            <div className="profile-details">
              <div className="detail-row">

                <span className="detail-label">Full Name:</span>
                <span className="detail-value">{user.fullName || "N/A"}</span>
              </div>
              <div className="detail-row">

                <span className="detail-label">Phone Number:</span>
                <span className="detail-value">
                  {user.phoneNo || "N/A"}
                </span>
              </div>
              <div className="detail-row">

                <span className="detail-label">Account Type:</span>
                <span className="detail-value">
                  {user.role === "USER" ? "Member" : user.role}
                </span>
              </div>
            </div>

            <div className="profile-contact">
              <div className="detail-row">

                <span className="detail-label">Email Address:</span>
                <span className="detail-value">{user.email || "N/A"}</span>
              </div>
              <div className="detail-row">

                <span className="detail-label">Address:</span>
                <span className="detail-value">{user.address || "N/A"}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="stats-section">
          <h3>My Library Statistics</h3>
          <div className="stats-grid">
            {stats.map((stat, index) => (
              <div
                key={index}
                className="stat-card"
                style={{ borderLeftColor: stat.color }}
              >
                <div className="stat-icon" style={{ color: stat.color }}>
                  {stat.icon}
                </div>
                <div className="stat-content">
                  <div className="stat-value">{stat.value}</div>
                  <div className="stat-title">{stat.title}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Activity */}
        

      </div>
      </>
    );
  }

  return (
    <div className="dashboard-container">
      {/* Sidebar - visible on all pages except login */}
      <Sidebar
        menus={[
          {
            name: "Dashboard",
            onClick: () => setActiveTab("dashboard"),
          },
          {
            name: "Books",
            onClick: () => setActiveTab("books"),
          },
          {
            name: "Borrowing",
            onClick: () => setActiveTab("borrowing"),
          },
          {
            name: "Overdues",
            onClick: () => setActiveTab("overdues"),
          },
        ]}
        activeTab={activeTab}
        username={user.fullName || "User"}
        onLogout={handleLogout}
      />

      {/* Main Content */}
      {renderContent()}
      {/* Notification Popup */}
      <UpdateProfileModal
              isOpen={showUpdateModal}
              onClose={closeUpdateModal}
              currentProfile={{
    userId: user.userId,
    fullName: user.fullName,
    email: user.email,
    phoneNo: user.phoneNo, // Map phoneNo to phoneNumber
    address: user.address}}
              onUpdate={handleProfileUpdate}
            />
      
    </div>
  );
}

export default UserDashboard;
