import { useState, useEffect } from "react";
import RegisterModal from "../../components/RegisterModal/RegisterModal";
import UpdateProfileModal from "../../components/UpdateProfileModal/UpdateProfileModal";
import "./MembersPage.css";
import { getUsers, deleteUser, getUserById, getUserByEmail, getUserByName, getUserByRole } from "../../services/authService";
import type { User } from "../../models/users";
import Headsup from "../../components/Headsup";

function MembersPage() {
  const [showModal, setShowModal] = useState(false);
  const [members, setMembers] = useState<User[]>([]);
  const [filteredMembers, setFilteredMembers] = useState<User[]>([]);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const searchOptions = [
  { value: "id", label: "Member ID" },
  { value: "name", label: "Name" },
  { value: "email", label: "Email" },
];
  const [searchBy, setSearchBy] = useState("id");
  const [searchTerm, setSearchTerm] = useState("");
  const fetchMembers = async () => {
    try {
      const response = await getUserByRole("USER");
      // If response is an array, filter for role USER just in case
      const users = Array.isArray(response)
        ? response.filter((user) => user.role === "USER")
        : [];
      setMembers(users);
      setFilteredMembers(users);
    } catch (error) {
      console.error("Error fetching members:", error);
    }
  };

  useEffect(() => {
    fetchMembers();
  }, []);

  

  function handleSearchChange(e: React.ChangeEvent<HTMLInputElement>) {
    setSearchTerm(e.target.value);
    setError(null); // Clear error on new input
  }

  async function handleSearch() {
    if (!searchTerm.trim()) {
      setFilteredMembers(members);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      let result: any = null;

      if (searchBy === "id" && !isNaN(Number(searchTerm))) {
        // Search by ID
        result = await getUserById(Number(searchTerm));
      } else if (searchBy === "email") {
        // Search by email
        result = await getUserByEmail(searchTerm);
      } else if (searchBy === "name") {
        // Search by name
        result = await getUserByName(searchTerm);
      }

      if (Array.isArray(result) && result.length > 0) {
        // If API returns an array, map to User
        const users = result.map((userData: any) => ({
          userId: userData.userId || userData.id,
          fullName: userData.fullName || userData.name,
          email: userData.email,
          phoneNo: userData.phoneNo,
          address: userData.address,
          role: userData.role,
        }));
        setFilteredMembers(users);
      } else if (result && typeof result === 'object') {
        // If API returns a single object
        const user: User = {
          userId: result.userId || result.id,
          fullName: result.fullName || result.name,
          email: result.email,
          phoneNo: result.phoneNo,
          address: result.address,
          role: result.role,
        };
        setFilteredMembers([user]);
      } else {
        setFilteredMembers([]);
      }
    } catch (err) {
      setError("Error searching for members. Please try again.");
      setFilteredMembers([]);
      console.error("Search error:", err);
    } finally {
      setIsLoading(false);
    }
  }
  function clearSearch() {
    setSearchTerm('');
  }

  function openModal() {
    setShowModal(true);
  }

  function closeModal() {
    setShowModal(false);
  }

  function handleEdit(memberId: number) {
    const memberToEdit = members.find(member => member.userId === memberId);
    if (memberToEdit) {
        setSelectedMember(memberToEdit);
        setIsEditModalOpen(true);
    }
  }

  function handleUpdate(updatedMember: User) {
    setMembers(members.map(member => member.userId === updatedMember.userId ? updatedMember : member));
    fetchMembers(); // to get the latest data from the server
    setIsEditModalOpen(false);
    setSelectedMember(null);
}

  async function handleDelete(memberId: number) {
    if (confirm(`Are you sure you want to delete member ${memberId}?`)) {
      try {
        await deleteUser(memberId);
        fetchMembers();
        alert(`Member ${memberId} deleted successfully`);
      } catch (error) {
        console.error("Error deleting member:", error);
      }
    }
  }

  return (
    <div className="members-container main-content">
      <div className="members-header">
        <Headsup />
        <div className="header-content">
          <h1>Members Management</h1>
          <p>Manage library members and their information</p>
        </div>
        <button className="add-member-btn" onClick={openModal}>
          + Add Member
        </button>
      </div>

      <div className="search-section">
        <h3>Search Members</h3>
        <div className="search-box">
          <div className="search-input-wrapper">
            <select
              value={searchBy}
              onChange={e => {
                setSearchBy(e.target.value);
                setSearchTerm("");
              }}
              style={{ marginRight: "8px" }}
            >
              {searchOptions.map(opt => (
                <option key={opt.value} value={opt.value}>{opt.label}</option>
              ))}
            </select>
            <input
              type={searchBy === "id" ? "number" : "text"}
              placeholder={
                searchBy === "id"
                  ? "Enter member ID..."
                  : searchBy === "email"
                  ? "Enter email..."
                  : "Enter name..."
              }
              value={searchTerm}
              onChange={handleSearchChange}
              className="search-input"
              disabled={isLoading}
            />
          </div>
          <button className="search-btn" onClick={handleSearch} disabled={isLoading}>
            {isLoading ? 'Searching...' : '🔍 Search'}
          </button>
          {searchTerm && !isLoading && (
            <button className="clear-search-btn" onClick={clearSearch} title="Clear search">
              ✕
            </button>
          )}
          {error && <div className="error-message">{error}</div>}
        </div>
      </div>
      <div className="members-table-section">
        <h3>Library Members</h3>
        <div className="table-container">
          <table className="members-table">
            <thead>
              <tr>
                <th>Member ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Join Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredMembers.length === 0 ? (
                <tr>
                  <td colSpan={7} style={{ textAlign: 'center', padding: '20px' }}>
                    {searchTerm.trim() ? 'No members found matching your search.' : 'No members available.'}
                  </td>
                </tr>
              ) : (
                filteredMembers.map((member) => (
                  <tr key={member.userId}>
                    <td>{member.userId}</td>
                    <td>{member.fullName}</td>
                    <td>
                      <div className="email-cell">
                        <span className="email-icon">📧</span>
                        {member.email}
                      </div>
                    </td>
                    <td>
                      <div className="phone-cell">
                        <span className="phone-icon">📞</span>
                        {member.phoneNo}
                      </div>
                    </td>
                    <td>{new Date().toLocaleDateString()}</td>
                    
                    <td>
                      <div className="action-buttons">
                        <button
                          className="edit-btn"
                          onClick={() => member.userId && handleEdit(member.userId)}
                          title="Edit member"
                        >
                          Update
                        </button>
                        <button
                          className="delete-btn"
                          onClick={() => member.userId && handleDelete(member.userId)}
                          title="Delete member"
                        >
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      <RegisterModal isOpen={showModal} onClose={closeModal} />
      {selectedMember && <UpdateProfileModal
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        currentProfile={{
            userId: selectedMember.userId,
            fullName: selectedMember.fullName,
            email: selectedMember.email,
            phoneNo: selectedMember.phoneNo,
            address: selectedMember.address
        }}
        onUpdate={(updatedProfile) => {
            const updatedMember = {
                ...selectedMember,
                ...updatedProfile
            };
            handleUpdate(updatedMember as User);
        }}
    />}
    </div>
  );
}

export default MembersPage;