export interface Fine {
  fineID: string;
  amount: number;
  status: string;
  transactionDate: string | null;
}
