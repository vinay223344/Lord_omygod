export interface User {
  fullName: string;
  email: string;
  phoneNo: string;
  address: string;
  password?: string;
  role?: 'ADMIN' | 'USER';
  userId?: number;
}
