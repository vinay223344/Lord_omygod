export interface Book {
  bookId: number;
  title: string;
  author: string;
  isbn: string;
  availableCopies: number;
  genre?: string;
  img?:string;
  yearPublished?: number;
}