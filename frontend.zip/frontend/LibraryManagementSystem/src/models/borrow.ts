export interface Borrow {
    transactionId: number;
    userId: string;
    bookId: string;
    borrowDate: string;
    returnDate: string | null;
    status: 'BORROWED' | 'RETURNED';

}

export interface BorrowRecord extends Borrow {
  bookTitle: string;
  bookAuthor: string;
}
