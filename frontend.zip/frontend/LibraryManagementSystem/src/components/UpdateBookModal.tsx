import React from "react";
import type { BookFormData } from "./AddBookModal";
import "./AddBookModal.css";

interface UpdateBookModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpdateBook: (form: BookFormData) => void;
  book: BookFormData | null;
}

const UpdateBookModal: React.FC<UpdateBookModalProps> = ({ isOpen, onClose, onUpdateBook, book }) => {
  const [form, setForm] = React.useState<BookFormData>(book || {
    title: '', author: '', genre: '', year: '', copies: '', isbn: ''
  });

  React.useEffect(() => {
    if (book) setForm(book);
  }, [book]);

  if (!isOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateBook(form);
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <h2>Update Book</h2>
          <button className="close-btn" onClick={onClose}>&times;</button>
        </div>
        <form className="modal-form" onSubmit={handleSubmit}>
          <label>Title</label>
          <input name="title" value={form.title} onChange={handleChange} required />
          <label>Author</label>
          <input name="author" value={form.author} onChange={handleChange} required />
          <label>Genre</label>
          <input name="genre" value={form.genre} onChange={handleChange} required />
          <label>Year</label>
          <input name="year" value={form.year} onChange={handleChange} required />
          <label>Copies</label>
          <input name="copies" value={form.copies} onChange={handleChange} required />
          <label>ISBN</label>
          <input name="isbn" value={form.isbn} onChange={handleChange} />
          <div className="modal-actions">
            <button type="submit" className="primary">Update</button>
            <button type="button" onClick={onClose}>Cancel</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default UpdateBookModal;
