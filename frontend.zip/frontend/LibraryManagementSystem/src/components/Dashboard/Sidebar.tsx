import React, { useState } from 'react';
import { useAuth } from '../../../AuthContext';
import './Sidebar.css';
import { useNavigate } from 'react-router-dom';

interface Menu {
  name: string;
  onClick: () => void;
}

interface SidebarProps {
  menus: Menu[];
  activeTab: string;
  username: string;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  menus,
  activeTab,
  username,
  onLogout,
}) => {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const toggleSidebar = () => setOpen(!open);

  const handleOverlayClick = () => setOpen(false);

  return (
    <>
      {/* Hamburger menu (only on mobile) */}
      <button className="hamburger" onClick={toggleSidebar}>
        &#9776;
      </button>

      {/* Overlay (mobile only when sidebar open) */}
      <div
        className={`sidebar-overlay${open ? ' open' : ''}`}
        onClick={handleOverlayClick}
      />

      {/* Sidebar */}
      <div className={`sidebar${open ? ' open' : ''}`}>
        <div className="sidebar-header">
          <h2>Library System</h2>
        </div>

        <div className="user-info">
          <div className="user-details">
            <div className="user-email">{username}</div>
          </div>
        </div>

        <nav className="sidebar-nav">
          {menus.map((menu) => (
            <button
              key={menu.name}
              className={activeTab === menu.name.toLowerCase() ? 'nav-item active' : 'nav-item'}
              onClick={menu.onClick}
            >
              {menu.name}
            </button>
          ))}
        </nav>

        <div className="sidebar-footer">
          <button className="logout-btn" onClick={handleLogout}>
            Logout
          </button>
        </div>
      </div>
    </>
  );
};

export default Sidebar;
