import React from "react";
import "./PaymentSuccessModal.css";

interface PaymentSuccessModalProps {
  open: boolean;
  onClose: () => void;
}

const PaymentSuccessModal: React.FC<PaymentSuccessModalProps> = ({ open, onClose }) => {
  if (!open) return null;
  return (
    <div className="payment-modal-backdrop">
      <div className="payment-modal">
        <div className="payment-modal-icon">✅</div>
        <h2>Payment Successful!</h2>
        <p>Your fine payment has been completed.</p>
        <button className="payment-modal-close" onClick={onClose}>
          Close
        </button>
      </div>
    </div>
  );
};

export default PaymentSuccessModal;
