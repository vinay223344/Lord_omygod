import React, { useState, useEffect } from 'react';
import { updateUser } from '../../services/authService';
import './UpdateProfileModal.css';

interface UpdateProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentProfile: {
    userId: number | undefined;
    fullName?: string;
    email?: string;
    phoneNo?: string;
    address?: string;
  };
  onUpdate: (updatedProfile: {
    userId: number | undefined;
    fullName?: string;
    email?: string;
    phoneNo?: string;
    address?: string;
  }) => void;
}

interface ValidationErrors {
  fullName?: string;
  email?: string;
  phoneNumber?: string;
  address?: string;
}


function UpdateProfileModal({ isOpen, onClose, currentProfile, onUpdate }: UpdateProfileModalProps) {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [address, setAddress] = useState('');
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<ValidationErrors>({});

  useEffect(() => {
    if (currentProfile) {
      setFullName(currentProfile.fullName || '');
      setEmail(currentProfile.email || '');
      setPhoneNumber(currentProfile.phoneNo || '');
      setAddress(currentProfile.address || '');
    }
  }, [currentProfile]);

  function handleFullNameChange(e: React.ChangeEvent<HTMLInputElement>) {
    setFullName(e.target.value);
    if (errors.fullName) {
      setErrors({...errors, fullName: ''});
    }
  }

  function handleEmailChange(e: React.ChangeEvent<HTMLInputElement>) {
    setEmail(e.target.value);
    if (errors.email) {
      setErrors({...errors, email: ''});
    }
  }

  function handlePhoneChange(e: React.ChangeEvent<HTMLInputElement>) {
    setPhoneNumber(e.target.value);
    if (errors.phoneNumber) {
      setErrors({...errors, phoneNumber: ''});
    }
  }

  function handleAddressChange(e: React.ChangeEvent<HTMLTextAreaElement>) {
    setAddress(e.target.value);
    if (errors.address) {
      setErrors({...errors, address: ''});
    }
  }

  function validateForm() {
    const newErrors: ValidationErrors = {};

    if (!fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }

    if (!email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!email.includes('@')) {
      newErrors.email = 'Please enter a valid email';
    }

    if (phoneNumber && !/^[+]?[1-9][\d]{0,15}$/.test(phoneNumber.replace(/\s/g, ''))) {
      newErrors.phoneNumber = 'Please enter a valid phone number';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setLoading(true);

    const updatedProfile = {
      fullName:fullName,
      email,
      phoneNo: phoneNumber,
      address
    };

    updateUser(currentProfile.userId!, updatedProfile)
      .then(() => {
        setLoading(false);
        onUpdate({ ...currentProfile, ...updatedProfile });
        onClose();
      })
      .catch((error: any) => {
        setLoading(false);
        console.error('Error updating profile:', error);
      });
  }

  function handleCancel() {
    // Reset form to original values
    setFullName(currentProfile?.fullName || 'Library Administrator');
    setEmail(currentProfile?.email || 'admin@library.com');
    setPhoneNumber(currentProfile?.phoneNo || '');
    setAddress(currentProfile?.address || '');
    setErrors({});
    onClose();
  }

  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={handleCancel}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Update Profile</h2>
          <button className="close-btn" onClick={handleCancel}>
            ✕
          </button>
        </div>

        <form onSubmit={handleSubmit} className="update-profile-form">
          <div className="form-group">
            <label htmlFor="fullName">Full Name *</label>
            <input
              type="text"
              id="fullName"
              value={fullName}
              onChange={handleFullNameChange}
              placeholder="Enter your full name"
              className={errors.fullName ? 'error' : ''}
            />
            {errors.fullName && <span className="error-message">{errors.fullName}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="email">Email Address *</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={handleEmailChange}
              placeholder="Enter your email address"
              className={errors.email ? 'error' : ''}
            />
            {errors.email && <span className="error-message">{errors.email}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="phoneNumber">Phone Number</label>
            <input
              type="tel"
              id="phoneNumber"
              value={phoneNumber}
              onChange={handlePhoneChange}
              placeholder="Enter your phone number"
              className={errors.phoneNumber ? 'error' : ''}
            />
            {errors.phoneNumber && <span className="error-message">{errors.phoneNumber}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="address">Address</label>
            <textarea
              id="address"
              value={address}
              onChange={handleAddressChange}
              placeholder="Enter your address"
              rows={3}
              className={errors.address ? 'error' : ''}
            />
            {errors.address && <span className="error-message">{errors.address}</span>}
          </div>

          <div className="modal-actions">
            <button type="button" className="cancel-btn" onClick={handleCancel}>
              Cancel
            </button>
            <button type="submit" className="update-btn" disabled={loading}>
              {loading ? 'Updating...' : 'Update Profile'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default UpdateProfileModal;