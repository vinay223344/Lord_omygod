import React, { useState, useEffect } from "react";
import "./AddBookModal.css";
import type { Book } from "../models/book";

interface AddBookModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddBook: (book: BookFormData) => void;
  onUpdateBook?: (book: Book) => void;
  bookToEdit?: Book | null;
}

export interface BookFormData {
  bookId?: number;
  title: string;
  author: string;
  genre: string;
  year: string;
  copies: string;
  isbn?: string;
}

const genres = [
  "Fiction",
  "Non-fiction",
  "Science",
  "Biography",
  "History",
  "Fantasy",
  "Other",
];

const currentYear = new Date().getFullYear().toString();

const AddBookModal: React.FC<AddBookModalProps> = ({
  isOpen,
  onClose,
  onAddBook,
  onUpdateBook,
  bookToEdit,
}) => {
  const [form, setForm] = useState<BookFormData>({
    title: "",
    author: "",
    genre: "",
    year: currentYear,
    copies: "1",
    isbn: "",
  });

  useEffect(() => {
    if (bookToEdit) {
      setForm({
        title: bookToEdit.title,
        author: bookToEdit.author,
        genre: bookToEdit.genre ?? "",
        year: bookToEdit.yearPublished?.toString() ?? currentYear,
        copies: bookToEdit.availableCopies.toString(),
        isbn: bookToEdit.isbn ?? "",
      });
    } else {
      setForm({
        title: "",
        author: "",
        genre: "",
        year: currentYear,
        copies: "1",
        isbn: "",
      });
    }
  }, [bookToEdit]);

  function handleChange(e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!form.title || !form.author || !form.copies) return;

    if (bookToEdit && onUpdateBook) {
        const updatedBook: Book = {
            ...bookToEdit,
            title: form.title,
            author: form.author,
            genre: form.genre,
            yearPublished: parseInt(form.year, 10),
            availableCopies: parseInt(form.copies, 10),
            isbn: form.isbn ?? '',
        };
        onUpdateBook(updatedBook);
    } else {
      onAddBook(form);
    }

    setForm({
      title: "",
      author: "",
      genre: "",
      year: currentYear,
      copies: "1",
      isbn: "",
    });
    onClose();
  }

  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <h2>{bookToEdit ? "Edit Book" : "Add New Book"}</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>
        <form className="modal-form" onSubmit={handleSubmit}>
          <label>
            Title *
            <input
              name="title"
              value={form.title}
              onChange={handleChange}
              placeholder="Enter book title"
              required
            />
          </label>
          <label>
            Author *
            <input
              name="author"
              value={form.author}
              onChange={handleChange}
              placeholder="Enter author name"
              required
            />
          </label>
          <label>
            Genre
            <select
              name="genre"
              value={form.genre}
              onChange={handleChange}
            >
              <option value="">Select genre</option>
              {genres.map((g) => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
          </label>
          <div className="row">
            <label>
              Year
              <input
                name="year"
                type="number"
                value={form.year}
                onChange={handleChange}
                min="1000"
                max={currentYear}
              />
            </label>
            <label>
              Copies *
              <input
                name="copies"
                type="number"
                min="1"
                value={form.copies}
                onChange={handleChange}
                required
              />
            </label>
          </div>
          <label>
            ISBN
            <input
              name="isbn"
              value={form.isbn}
              onChange={handleChange}
              placeholder="Enter ISBN (optional)"
            />
          </label>
          <div className="modal-actions">
            <button type="button" onClick={onClose}>Cancel</button>
            <button type="submit" className="primary">{bookToEdit ? "Update Book" : "Add Book"}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddBookModal;