import "./Button.css";

function Button({ onClick, children, width, color, background}: { onClick: () => void; children: React.ReactNode, width?: string, color?: string, background?: string}) {
  return (
    <button className="custom-button" onClick={onClick} style={{width: width ? width : 'auto', color: color, background: background}}>
      {children}
    </button>
  );
}

export default Button;