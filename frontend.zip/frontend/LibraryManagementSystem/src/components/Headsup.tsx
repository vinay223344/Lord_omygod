import "./Headsup.css";

const Headsup: React.FC = () => {
    return (
        <div className="headsup"><h1>Library Management System</h1></div>
    );
}

export default Headsup;