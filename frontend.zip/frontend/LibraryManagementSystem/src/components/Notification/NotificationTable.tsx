import React from 'react';
import '../../pages/BorrowHistory/BorrowingHistory.css';

interface Notification {
  notificationId: number;
  userId: number;
  message: string;
  dateSent: string;
}

interface NotificationTableProps {
  notifications: Notification[];
}

const NotificationTable: React.FC<NotificationTableProps> = ({ notifications }) => {
  return (
    <div className="notification-table-container">
      <table className="borrowing-history-table">
        <thead>
          <tr>
            <th>Notification ID</th>
            <th>Member ID</th>
            <th>Message</th>
            <th>Date Sent</th>
          </tr>
        </thead>
        <tbody>
          {notifications && notifications.length > 0 ? (
            notifications.map((notif) => (
              <tr key={notif.notificationId}>
                <td>{notif.notificationId}</td>
                <td>{notif.userId}</td>
                <td>{notif.message}</td>
                <td>{notif.dateSent}</td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan={4} style={{ textAlign: 'center' }}>No notifications found.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default NotificationTable;
