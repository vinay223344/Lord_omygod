import React from 'react';
import NotificationTable from './NotificationTable';
import './NotificationPopup.css'; // Optional: for styling

const NotificationPopup = ({ notifications, onClose }) => (
  <div className="notification-popup-overlay">
    <div className="notification-popup">
      <button className="close-btn" onClick={onClose}>Close</button>
      <NotificationTable notifications={notifications} />
    </div>
  </div>
);

export default NotificationPopup;