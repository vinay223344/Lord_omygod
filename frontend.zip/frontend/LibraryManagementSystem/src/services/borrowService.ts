import api from './api';

export const borrowBook = async (data: { bookId: number; userId: number }) => {
  const response = await api.post('/transactions/borrow', data);
  return response.data;
};

export const returnBook = async (borrowId: number) => {
  const response = await api.put(`/transactions/return/${borrowId}`, { status: 'RETURNED' });
  return response.data;
};

export const getBorrowHistory = async (userId: number) => {
    const response = await api.get(`/transactions/user/${userId}`);
    return response.data;
};
