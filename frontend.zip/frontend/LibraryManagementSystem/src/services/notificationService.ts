import api from './api';

export const getNotifications = async (userId: number) => {
  const response = await api.get(`/notification/user/${userId}`);
  return response.data;
};


