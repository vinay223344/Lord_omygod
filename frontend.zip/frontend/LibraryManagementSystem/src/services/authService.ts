import api from './api';

import type { User } from '../models/users';

export const loginUser = async (credentials: Pick<User, 'email' | 'password'>) => {
  const response = await api.post('/users/login', credentials);
  return response.data;
};

export const registerUser = async (userData: User) => {
  const response = await api.post('/users/register', userData);
  return response.data;
};

export const updateUser = async (userId: number, userData: Partial<User>) => {
  const response = await api.put(`/users/update/${userId}`, userData);
  return response.data;
};

export const deleteUser = async (userId: number) => {
  const response = await api.delete(`/users/delete/${userId}`);
  return response.data;
};

export const getUsers = async () => {
    const response = await api.get('/users/getMembers');
    return response.data;
};

export const getUserById = async (userId: number) => {
  const response = await api.get(`/users/${userId}`);
  return response.data;
}

export const getUserByEmail = async (email: string) => {
  const response = await api.get(`/users/email/${email}`);
  return response.data;
}

export const getUserByName = async (fullName: string) => {
  const response = await api.get(`/users/name/${fullName}`);
  return response.data;
}

export const getUserByRole = async (role: string) => {
  const response = await api.get(`/users/role/${role}`);
  return response.data;
}
