import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8090',
});

// Add a request interceptor to include the token in headers, except for login/register
api.interceptors.request.use(
  (config) => {
    // Do not add Authorization header for login or register
    if (
      config.url?.endsWith('/users/login') ||
      config.url?.endsWith('/users/register')
    ) {
      return config;
    }
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export default api;