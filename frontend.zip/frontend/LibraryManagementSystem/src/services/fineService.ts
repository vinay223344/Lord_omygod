import api from './api';

export const getOverdueItems = async (userId: number) => {
  const response = await api.get(`/fines/overdue/user/${userId}`);
  return response.data;
};

export const payFine = async (fineId: number) => {
  const response = await api.put(`/fines/pay/${fineId}`);
  return response.data;
};
