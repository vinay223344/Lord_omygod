import api from './api';

import type { Book } from '../models/book';

export const getBooks = async () => {
  const response = await api.get('/books/getbooks');
  return response.data;
};

export const getBookDetails = async (bookId: number) => {
  const response = await api.get(`/books/${bookId}`);
  return response.data;
};

export const addBook = async (bookData: Omit<Book, 'bookId'>) => {
  const response = await api.post('/books/add', bookData);
  return response.data;
};

export const updateBook = async (bookId: number, bookData: Partial<Book>) => {
  const response = await api.put(`/books/edit/${bookId}`, bookData);
  return response.data;
};

export const deleteBook = async (bookId: number) => {
  const response = await api.delete(`/books/${bookId}`);
  return response.data;
};

export const getBooksByTitle = async (title: string) => {
  const response = await api.get(`/books/search/title/${title}`);
  return response.data;
};

export const getBooksByAuthor = async (author: string) => {
  const response = await api.get(`/books/search/author/${author}`);
  return response.data;
};

export const getBooksByGenre = async (genre: string) => {
  const response = await api.get(`/books/search/genre/${genre}`);
  return response.data;
};
