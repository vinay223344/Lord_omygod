import { Route, Routes, Outlet } from "react-router-dom";
import LoginPage from "../pages/LoginPage/LoginPage";
import Dashboard from "../pages/Dashboard/Dashboard";
import MembersPage from "../pages/MembersPage/MembersPage";
import ManageBook from "../pages/ManageBook";
import UserDashboard from "../pages/UserDashboard/UserDashboard";
import ProtectedRoute from "./ProtectedRoute";
import type { User } from "../models/users";
import SearchBook from "../pages/Search Book/SearchBook";
import BorrowingHistory from "../pages/BorrowHistory/BorrowingHistory";
import Overdue from "../pages/Overdue/Overduepage";
import { getBorrowHistory } from "../services/borrowService";
import { useState, useEffect } from "react";
import type { BorrowRecord } from "../models/borrow";
import { useAuth } from "../../AuthContext";

const UserDashboardWrapper = () => {
  const { user , isLoading, isAuthenticated} = useAuth();

  // Add null check for user
  // if (!user) {
  //   return <div>Loading...</div>;
  // }
  if (isLoading) {
  return <div>Loading...</div>;
  }

  if (!isAuthenticated || !user) {
    return <Navigate to="/login" replace />;
  }
  return <UserDashboard user={user} />;
};

const SearchBookWrapper = () => {
  const { user } = useAuth();

  // Add null check for user
  if (!user) {
    return <div>Loading...</div>;
  }

  const handleBookBorrowed = () => {
    console.log("Book borrowed, refetching data...");
  };
  return <SearchBook user={user} onBookBorrowed={handleBookBorrowed} />;
};

const BorrowingHistoryWrapper = () => {
  const { user } = useAuth();
  const [borrowingHistory, setBorrowingHistory] = useState<BorrowRecord[]>([]);

  const fetchBorrowingHistory = async () => {
    if (user && user.userId) {
      const history = await getBorrowHistory(user.userId);
      setBorrowingHistory(history.borrows);
    }
  };

  useEffect(() => {
    fetchBorrowingHistory();
  }, [user]);

  // Add null check for user
  // if (!user) {
  //   return <div>Loading...</div>;
  // }

  return <BorrowingHistory borrowingHistory={borrowingHistory} onReturn={fetchBorrowingHistory} />;
};

// const OverdueWrapper = () => {
//   const { user } = useAuth();
//   console.log('🔍 routes user:', user);

//   // Add null check for user
//   if (!user) {
//     return <div>Loading...</div>;
//   }

//   return <Overdue />;
// };

const AppRoutes = () => {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<LoginPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/user-dashboard" element={<UserDashboardWrapper />} />

      {/* Admin routes */}
      <Route element={<ProtectedRoute role="ADMIN" />} >
        <Route path="/dashboard" element={<Dashboard />} />
       {/* <Route path="/dashboard/members" element={<MembersPage />} />
        <Route path="/dashboard/manage-books" element={<ManageBook />} /> */}
      </Route>

      
      <Route element={<ProtectedRoute role="USER" />}>
        {/* <Route path="/user-dashboard" element={<UserDashboardWrapper />} /> */}
        {/* <Route path="/user-dashboard/search-book" element={<SearchBookWrapper />} />
        <Route path="/user-dashboard/borrow-history" element={<BorrowingHistoryWrapper />} />
        <Route path="/user-dashboard/overdue" element={<OverdueWrapper />} /> */}
      </Route>

      {/* Unauthorized page */}
      <Route path="*" element={<h1>Unauthorized</h1>} />
    </Routes>
  );
};

export default AppRoutes;
