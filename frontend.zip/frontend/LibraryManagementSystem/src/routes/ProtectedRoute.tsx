import { Navigate, Outlet } from "react-router-dom";
import type { User } from "../models/users";

interface ProtectedRouteProps {
  role: "ADMIN" | "USER";
}

const ProtectedRoute = ({ role }: ProtectedRouteProps) => {
  const token = localStorage.getItem("token");
  const currentUserData = localStorage.getItem("currentUser");

  if (!token || !currentUserData) {
    return <Navigate to="/login" replace />;
  }

  const currentUser: User = JSON.parse(currentUserData);

  if (currentUser.role !== role) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <Outlet context={{ user: currentUser }} />;
};

export default ProtectedRoute;