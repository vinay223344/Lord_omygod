import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { User } from './src/models/users';

interface AuthContextType {
  user: User;
  token: string | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (userData: User) => Promise<void>;
  updateUser: (userData: Partial<User>) => Promise<void>;
  isAuthenticated: boolean;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize auth state from localStorage
  useEffect(() => {
    const initializeAuth = () => {
      const savedToken = localStorage.getItem('token');
      const savedUser = localStorage.getItem('currentUser');

      if (savedToken && savedUser) {
        try {
          const parsedUser = JSON.parse(savedUser);
          console.log('🔄 Loaded user from localStorage:', parsedUser); // Debug log
          setToken(savedToken);
          setUser(parsedUser);
        } catch (error) {
          console.error('❌ Error parsing stored user data:', error);
          localStorage.removeItem('token');
          localStorage.removeItem('currentUser');
        }
      }
      setIsLoading(false);
    };

    initializeAuth();
  }, []);

  const login = async (email: string, password: string) => {
    console.log('🔄 Login function called with:', email); // Debug log
    setIsLoading(true);
    try {
      console.log('📡 Making request to backend...'); // Debug log
      const response = await fetch('http://localhost:8090/users/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      console.log('📡 Response status:', response.status); // Debug log

      if (!response.ok) {
        console.error('❌ Login failed with status:', response.status); // Debug log
        throw new Error('Login failed');
      }

      const data = await response.json();
      console.log('✅ Login response data:', data); // Debug log
      console.log('👤 User data from response:', data.user); // Debug log

      // Transform backend response to match frontend expectations
      // const transformedUser: User = {
      //   fullName: data.user.name,
      //   email: data.user.email,
      //   phoneNo: data.user.phoneNo,
      //   address: data.user.address,
      //   role: (data.user.role === 'USER' ? 'USER' : 'ADMIN') as 'USER' | 'ADMIN',
      //   userId: data.user.userID.toString(),
      // };

      setUser(data.user);

      // console.log('🔄 Transformed user data:', transformedUser); // Debug log

      setToken(data.token);
      // setUser(transformedUser);

      localStorage.setItem('token', data.token);
      localStorage.setItem('currentUser', JSON.stringify(user));

      console.log('✅ Login successful, user set in state'); // Debug log
    } catch (error) {
      console.error('❌ Login error:', error);
      throw error;
    } finally {
      setIsLoading(false);
      console.log('🏁 Login function completed'); // Debug log
    }
  };

  const register = async (userData: User) => {
    setIsLoading(true);
    try {
      const response = await fetch('http://localhost:8090/users/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      });

      if (!response.ok) {
        throw new Error('Registration failed');
      }

      const data = await response.json();
      setToken(data.token);
      setUser(data.user);

      localStorage.setItem('token', data.token);
      localStorage.setItem('currentUser', JSON.stringify(data.user));
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    console.log('🔒 Logging out user'); // Debug log
    setIsLoading(false);
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('currentUser');
    localStorage.clear();
    sessionStorage.clear();
    window.location.href = '/login';

  };

  const updateUser = async (userData: Partial<User>) => {
    if (!token || !user) return;

    setIsLoading(true);
    try {
      const response = await fetch(`/users/${user.userID}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify(userData),
      });

      if (!response.ok) {
        throw new Error('Update failed');
      }

      const updatedUser = await response.json();
      setUser(updatedUser);
      localStorage.setItem('currentUser', JSON.stringify(updatedUser));
    } catch (error) {
      console.error('Update error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const value: AuthContextType = {
    user,
    token,
    login,
    logout,
    register,
    updateUser,
    isAuthenticated: !!token && !!user,
    isLoading,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Helper hook for checking if user has specific role
export const useRole = () => {
  const { user } = useAuth();
  return {
    isAdmin: user?.role === 'ADMIN',
    isUser: user?.role === 'USER',
    role: user?.role,
  };
};

// Helper hook for checking permissions
export const usePermissions = () => {
  const { user } = useAuth();
  return {
    canEditBooks: user?.role === 'ADMIN',
    canManageUsers: user?.role === 'ADMIN',
    canBorrowBooks: user?.role === 'USER' ,
  };
};
