package com.cognizant.travelagency.entity;

import java.time.LocalDateTime;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "agencies")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Travel Agency Entity")
public class TravelAgencyEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Agency ID", example = "1")
    private Long id;

    @Column(nullable = false)
    @NotBlank(message = "Agency name is required")
    @Schema(description = "Agency name", example = "Sky High Travels")
    private String name;
    
    @Column(name = "contact_email", nullable = false)
    @Email(message = "Invalid email format")
    @NotBlank(message = "Contact email is required")
    @Schema(description = "Contact email", example = "info@skyhightravels.com")
    private String contactEmail;

    @Column(nullable = false)
    @NotBlank(message = "Address is required")
    @Schema(description = "Agency address", example = "123 Main Plaza, Amsterdam")
    private String address;

    @Column(name = "created_at", nullable = false)
    @Schema(description = "Created date", example = "2025-07-28T09:00:00")
    private LocalDateTime createdAt;

   
    
}