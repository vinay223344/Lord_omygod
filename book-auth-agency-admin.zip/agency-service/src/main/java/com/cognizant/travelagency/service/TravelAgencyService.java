package com.cognizant.travelagency.service;

import java.util.List;

import com.cognizant.travelagency.dto.TravelAgencyRequestDTO;
import com.cognizant.travelagency.dto.TravelAgencyResponseDTO;

public interface TravelAgencyService {

  
    TravelAgencyResponseDTO createAgency(TravelAgencyRequestDTO dto);

    
    List<TravelAgencyResponseDTO> getAllAgencies();

    
    TravelAgencyResponseDTO getAgencyById(Long id);

   
    TravelAgencyResponseDTO updateAgency(Long id, TravelAgencyRequestDTO dto);

    
    void deleteAgency(Long id);
}