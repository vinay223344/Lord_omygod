package com.cognizant.travelagency.dto;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Travel Agency Request DTO")
public class TravelAgencyRequestDTO {

    @NotBlank(message = "Agency name is required")
    @Schema(description = "Agency name", example = "Sky High Travels")
    private String name;

    @Email(message = "Invalid email format")
    @NotBlank(message = "Contact email is required")
    @Schema(description = "Contact email", example = "info@skyhightravels.com")
    private String contactEmail;

    @NotBlank(message = "Address is required")
    @Schema(description = "Agency address", example = "123 Main Plaza, Amsterdam")
    private String address;

}