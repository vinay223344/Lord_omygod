package com.cognizant.travelagency.dto;

import java.time.LocalDateTime;
import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Travel Agency Response DTO")
public class TravelAgencyResponseDTO {

    @Schema(description = "Agency ID", example = "1")
    private Long id;

    @Schema(description = "Agency name", example = "Sky High Travels")
    private String name;

    @Schema(description = "Contact email", example = "info@skyhightravels.com")
    private String contactEmail;

    @Schema(description = "Agency address", example = "123 Main Plaza, Amsterdam")
    private String address;

    @Schema(description = "Created date", example = "2025-07-28T09:00:00")
    private LocalDateTime createdAt;
}
