package com.cognizant.travelagency.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.cognizant.travelagency.dto.TravelAgencyRequestDTO;
import com.cognizant.travelagency.dto.TravelAgencyResponseDTO;
import com.cognizant.travelagency.entity.TravelAgencyEntity;
import com.cognizant.travelagency.exception.AgencyNotFoundException;
import com.cognizant.travelagency.repository.TravelAgencyRepository;

@Service
public class TravelAgencyServiceImpl implements TravelAgencyService {

    private TravelAgencyRepository repository;

    public TravelAgencyServiceImpl(TravelAgencyRepository repository) {
        this.repository = repository;
    }

   
    @Override
    public TravelAgencyResponseDTO createAgency(TravelAgencyRequestDTO dto) {

        TravelAgencyEntity entity = new TravelAgencyEntity();

        entity.setName(dto.getName());
        entity.setContactEmail(dto.getContactEmail());
        entity.setAddress(dto.getAddress());
  

        entity.setCreatedAt(LocalDateTime.now()); // ✅ set automatically

        TravelAgencyEntity saved = repository.save(entity);

        return mapToDTO(saved);
    }

    
    @Override
    public List<TravelAgencyResponseDTO> getAllAgencies() {

        List<TravelAgencyEntity> list = repository.findAll();

        List<TravelAgencyResponseDTO> result = new ArrayList<>();

        for (TravelAgencyEntity entity : list) {
            result.add(mapToDTO(entity));
        }

        return result;
    }

   
    @Override
    public TravelAgencyResponseDTO getAgencyById(Long id) {

        TravelAgencyEntity entity = repository.findById(id)
                .orElseThrow(() -> new AgencyNotFoundException("Agency not found"));

        return mapToDTO(entity);
    }

   
    @Override
    public TravelAgencyResponseDTO updateAgency(Long id, TravelAgencyRequestDTO dto) {

        TravelAgencyEntity existing = repository.findById(id)
                .orElseThrow(() -> new AgencyNotFoundException("Agency not found"));

        existing.setName(dto.getName());
        existing.setContactEmail(dto.getContactEmail());
        existing.setAddress(dto.getAddress());
        

        TravelAgencyEntity updated = repository.save(existing);

        return mapToDTO(updated);
    }

   
    @Override
    public void deleteAgency(Long id) {

        TravelAgencyEntity existing = repository.findById(id)
                .orElseThrow(() -> new AgencyNotFoundException("Agency not found"));

        repository.delete(existing);
    }

    
    private TravelAgencyResponseDTO mapToDTO(TravelAgencyEntity entity) {

        return new TravelAgencyResponseDTO(
                entity.getId(),
                entity.getName(),
                entity.getContactEmail(),
                entity.getAddress(),
                entity.getCreatedAt()        
        );
    }
}