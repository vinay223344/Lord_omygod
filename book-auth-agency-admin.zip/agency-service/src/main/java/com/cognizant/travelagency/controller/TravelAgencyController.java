package com.cognizant.travelagency.controller;

import java.util.List;

import jakarta.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cognizant.travelagency.dto.TravelAgencyRequestDTO;
import com.cognizant.travelagency.dto.TravelAgencyResponseDTO;
import com.cognizant.travelagency.service.TravelAgencyService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/agencies")
@Tag(name = "Travel Agency API", description = "Operations related to Travel Agencies")
public class TravelAgencyController {

    private TravelAgencyService service;

    public TravelAgencyController(TravelAgencyService service) {
        this.service = service;
    }

    
    @Operation(
        summary = "Register a new agency",
        description = "Creates a new travel agency with given details"
    )
    @PostMapping("/create")
    public ResponseEntity<TravelAgencyResponseDTO> createAgency(
            @Valid @RequestBody TravelAgencyRequestDTO dto) {

        TravelAgencyResponseDTO response = service.createAgency(dto);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }

    
    @Operation(
        summary = "Get all agencies",
        description = "Retrieve list of all travel agencies"
    )
    @GetMapping
    public ResponseEntity<List<TravelAgencyResponseDTO>> getAllAgencies() {

        return ResponseEntity.ok(service.getAllAgencies());
    }

   
    @Operation(
        summary = "Get agency by ID",
        description = "Retrieve details of a specific agency by ID"
    )
    @GetMapping("/{id}")
    public ResponseEntity<TravelAgencyResponseDTO> getAgencyById(
            @PathVariable Long id) {

        return ResponseEntity.ok(service.getAgencyById(id));
    }

   
    @Operation(
        summary = "Update agency",
        description = "Update existing travel agency details"
    )
    @PutMapping("/{id}")
    public ResponseEntity<TravelAgencyResponseDTO> updateAgency(
            @PathVariable Long id,
            @Valid @RequestBody TravelAgencyRequestDTO dto) {

        return ResponseEntity.ok(service.updateAgency(id, dto));
    }

    
    @Operation(
        summary = "Delete agency",
        description = "Remove or deactivate a travel agency by ID"
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteAgency(@PathVariable Long id) {

        service.deleteAgency(id);
        return ResponseEntity.ok("Agency deleted successfully");
    }
}