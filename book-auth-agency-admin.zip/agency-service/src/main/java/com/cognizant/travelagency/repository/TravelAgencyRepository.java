package com.cognizant.travelagency.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.travelagency.dto.TravelAgencyRequestDTO;
import com.cognizant.travelagency.dto.TravelAgencyResponseDTO;
import com.cognizant.travelagency.entity.TravelAgencyEntity;

public interface TravelAgencyRepository extends JpaRepository<TravelAgencyEntity, Long> {


}
