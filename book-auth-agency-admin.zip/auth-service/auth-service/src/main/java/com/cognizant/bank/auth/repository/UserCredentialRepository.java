package com.cognizant.bank.auth.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.bank.auth.entity.UserCredentials;

@Repository
public interface UserCredentialRepository
        extends JpaRepository<UserCredentials, Long> {

    Optional<UserCredentials> findByUsername(
            String username
    );

    boolean existsByUsername(String username);
}
