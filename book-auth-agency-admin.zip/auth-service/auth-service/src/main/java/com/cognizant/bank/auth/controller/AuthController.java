package com.cognizant.bank.auth.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cognizant.bank.auth.dto.AuthRequestDto;
import com.cognizant.bank.auth.dto.AuthResponseDto;
import com.cognizant.bank.auth.dto.RegisterRequestDto;
import com.cognizant.bank.auth.service.AuthService;

import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping("/auth")
@AllArgsConstructor
public class AuthController {

    private final AuthService authService;

    // Register User
    @PostMapping("/register")
    public ResponseEntity<String> register(
            @Valid @RequestBody
            RegisterRequestDto dto) {

        return new ResponseEntity<>(
                authService.register(dto),
                HttpStatus.CREATED
        );
    }

    // Login User
    @PostMapping("/login")
    public ResponseEntity<AuthResponseDto> login(
            @Valid @RequestBody
            AuthRequestDto dto) {

        return ResponseEntity.ok(
                authService.login(dto)
        );
    }

    // Validate JWT Token
    @GetMapping("/validate")
    public ResponseEntity<String> validateToken(
            @RequestParam String token) {

        authService.validateToken(token);

        return ResponseEntity.ok(
                "Token is valid"
        );
    }
}