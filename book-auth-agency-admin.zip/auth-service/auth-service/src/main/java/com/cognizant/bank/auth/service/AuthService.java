package com.cognizant.bank.auth.service;


import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cognizant.bank.auth.dto.AuthRequestDto;
import com.cognizant.bank.auth.dto.AuthResponseDto;
import com.cognizant.bank.auth.dto.RegisterRequestDto;
import com.cognizant.bank.auth.entity.UserCredentials;
import com.cognizant.bank.auth.repository.UserCredentialRepository;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class AuthService {

    private final UserCredentialRepository repository;

    private final PasswordEncoder passwordEncoder;

    private final JwtService jwtService;

    // Register User
    public String register(
            RegisterRequestDto dto) {

        if (repository.existsByUsername(
                dto.getUsername())) {

            throw new RuntimeException(
                    "Username already exists"
            );
        }

        UserCredentials user =
                new UserCredentials();

        user.setUsername(dto.getUsername());

        // Encrypt Password
        user.setPassword(
                passwordEncoder.encode(
                        dto.getPassword()
                )
        );

        user.setRole(dto.getRole());

        repository.save(user);

        return "User registered successfully";
    }

    // Login User
    public AuthResponseDto login(
            AuthRequestDto dto) {

        UserCredentials user =
                repository.findByUsername(
                        dto.getUsername()
                ).orElseThrow(() ->
                        new RuntimeException(
                                "Invalid username"
                        )
                );

        // Check Password
        boolean passwordMatches =
                passwordEncoder.matches(
                        dto.getPassword(),
                        user.getPassword()
                );

        if (!passwordMatches) {

            throw new RuntimeException(
                    "Invalid password"
            );
        }

        // Generate JWT Token
        String token =
                jwtService.generateToken(
                        user.getUsername()
                );

        return new AuthResponseDto(token);
    }

    // Validate Token
    public void validateToken(
            String token) {

        jwtService.validateToken(token);
    }
}