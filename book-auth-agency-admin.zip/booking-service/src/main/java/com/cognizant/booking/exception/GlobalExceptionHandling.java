package com.cognizant.booking.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
@RestControllerAdvice
public class GlobalExceptionHandling {

	
	  @ExceptionHandler(BookingNotFoundException.class)
	    public ResponseEntity<String> handleBookingNotFound(BookingNotFoundException ex) {

	        return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	    }

	  @ExceptionHandler(CustomerNotFoundException.class)
	  public ResponseEntity<String> handleCustomer(CustomerNotFoundException ex) {
	      return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	  }

	  @ExceptionHandler(PackageNotFoundException.class)
	  public ResponseEntity<String> handlePackage(PackageNotFoundException ex) {
	      return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	  }

}
