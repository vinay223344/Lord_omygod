package com.cognizant.booking.dto;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Booking Response DTO")
public class BookingResponseDTO {

    @Schema(description = "Booking ID", example = "1")
    private Long id;

    @Schema(description = "Customer ID", example = "205")
    private Long customerId;

    @Schema(description = "Package ID", example = "3301")
    private Long packageId;

    @Schema(description = "Booking date", example = "2025-08-01")
    private LocalDate bookingDate;

    @Schema(description = "Booking status", example = "CONFIRMED")
    private String status;

    @Schema(description = "Total amount", example = "1250.00")
    private Double totalAmount;

    @Schema(description = "Payment status", example = "SUCCESS")
    private String paymentStatus;
}
