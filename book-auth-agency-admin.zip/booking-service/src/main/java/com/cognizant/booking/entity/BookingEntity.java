package com.cognizant.booking.entity;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "bookings")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Booking Entity")
public class BookingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Booking ID", example = "1")
    private Long id;

    @Column(name = "customer_id", nullable = false)
    @NotNull(message = "Customer ID is required")
    @Schema(description = "Customer ID", example = "205")
    private Long customerId;

    @Column(name = "package_id", nullable = false)
    @NotNull(message = "Package ID is required")
    @Schema(description = "Package ID", example = "3301")
    private Long packageId;

    @Column(name = "booking_date", nullable = false)
    @NotNull(message = "Booking date is required")
    @Schema(description = "Booking date", example = "2025-08-01")
    private LocalDate bookingDate;

    @Column(nullable = false)
    @NotBlank(message = "Status is required")
    @Schema(description = "Booking status", example = "CONFIRMED")
    private String status;

    @Column(name = "total_amount", nullable = false)
    @NotNull(message = "Total amount is required")
    @DecimalMin(value = "0.0", inclusive = false, message = "Total amount must be greater than 0")
    @Schema(description = "Total amount", example = "1250.00")
    private Double totalAmount;

    @Column(name = "payment_status", nullable = false)
    @NotBlank(message = "Payment status is required")
    @Schema(description = "Payment status", example = "SUCCESS")
    private String paymentStatus;
}
