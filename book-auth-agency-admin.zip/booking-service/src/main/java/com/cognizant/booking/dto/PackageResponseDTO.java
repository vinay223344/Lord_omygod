package com.cognizant.booking.dto;

import java.time.LocalDate;

import lombok.Data;

@Data
public class PackageResponseDTO {

    private Long id;
    private String name;
    private Long agencyId;
    private String description;
    private Double price;
    private LocalDate availableFrom;
    private LocalDate availableTo;
}