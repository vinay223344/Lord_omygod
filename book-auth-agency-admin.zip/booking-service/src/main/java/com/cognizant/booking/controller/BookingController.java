package com.cognizant.booking.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import com.cognizant.booking.dto.BookingRequestDTO;
import com.cognizant.booking.dto.BookingResponseDTO;
import com.cognizant.booking.service.BookingService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/bookings")
@Tag(name = "Booking API", description = "Manage travel bookings and reservations")
public class BookingController {

	private BookingService service;

	public BookingController(BookingService service) {
		this.service = service;
	}

	@Operation(summary = "Create a new booking")
	@PostMapping("/create")
	public ResponseEntity<BookingResponseDTO> createBooking(@Valid @RequestBody BookingRequestDTO dto) {

		BookingResponseDTO response = service.createBooking(dto);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@Operation(summary = "Get all bookings")
	@GetMapping
	public ResponseEntity<List<BookingResponseDTO>> getAllBookings() {

		return ResponseEntity.ok(service.getAllBookings());
	}

	@Operation(summary = "Get booking by ID")
	@GetMapping("/{id}")
	public ResponseEntity<BookingResponseDTO> getBookingById(@PathVariable Long id) {

		return ResponseEntity.ok(service.getBookingById(id));
	}

	@Operation(summary = "Update an existing booking")
	@PutMapping("/{id}")
	public ResponseEntity<BookingResponseDTO> updateBooking(@PathVariable Long id,
			@Valid @RequestBody BookingRequestDTO dto) {

		return ResponseEntity.ok(service.updateBooking(id, dto));
	}

	@PutMapping("/{id}/payment-status")
	public String updatePaymentStatus(@PathVariable Long id, @RequestParam String paymentStatus) {

		service.updatePaymentStatus(id, paymentStatus);

		return "Booking updated successfully";
	}

	@Operation(summary = "Cancel a booking")
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteBooking(@PathVariable Long id) {

		service.deleteBooking(id);
		return ResponseEntity.ok("Booking cancelled successfully");
	}
}