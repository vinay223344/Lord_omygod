package com.cognizant.booking.dto;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Booking Request DTO")
public class BookingRequestDTO {

    @NotNull(message = "Customer ID is required")
    @Schema(description = "Customer ID", example = "205")
    private Long customerId;

    @NotNull(message = "Package ID is required")
    @Schema(description = "Package ID", example = "3301")
    private Long packageId;

   

    

}