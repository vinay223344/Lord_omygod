package com.cognizant.booking.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cognizant.booking.dto.PackageResponseDTO;

@FeignClient(name="package-service")
public interface PackageClient {

	 @GetMapping("/api/packages/{id}")
	    PackageResponseDTO getPackageById(@PathVariable Long id);

}
