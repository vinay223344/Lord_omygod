package com.cognizant.booking.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.booking.entity.BookingEntity;

public interface BookingRepository extends JpaRepository<BookingEntity, Long> {

}
