	package com.cognizant.booking.service;
	
	import java.time.LocalDate;
	import java.util.ArrayList;
	import java.util.List;
	
	import org.springframework.stereotype.Service;
	
	import com.cognizant.booking.dto.BookingRequestDTO;
	import com.cognizant.booking.dto.BookingResponseDTO;
	import com.cognizant.booking.dto.PackageResponseDTO;
	import com.cognizant.booking.entity.BookingEntity;
	import com.cognizant.booking.exception.BookingNotFoundException;
	import com.cognizant.booking.exception.CustomerNotFoundException;
	import com.cognizant.booking.exception.PackageNotFoundException;
	import com.cognizant.booking.feign.CustomerClient;
	import com.cognizant.booking.feign.PackageClient;
	import com.cognizant.booking.repository.BookingRepository;
	
	import feign.FeignException;
	
	@Service
	public class BookingServiceImpl implements BookingService {
	
		private BookingRepository repository;
		private CustomerClient customerClient;
		private PackageClient packageClient;
	
		public BookingServiceImpl(BookingRepository repository, CustomerClient customerClient,
				PackageClient packageClient) {
			this.repository = repository;
			this.customerClient = customerClient;
			this.packageClient = packageClient;
		}
	
		@Override
		public BookingResponseDTO createBooking(BookingRequestDTO dto) {
	
			try {
				customerClient.getCustomerById(dto.getCustomerId());
			} catch (FeignException.NotFound e) {
				throw new CustomerNotFoundException("Customer not found with id: " + dto.getCustomerId());
			}
	
			PackageResponseDTO pkg;
			try {
				pkg = packageClient.getPackageById(dto.getPackageId());
			} catch (Exception e) {
				throw new PackageNotFoundException("Package not found with id: " + dto.getPackageId());
			}
	
			BookingEntity entity = new BookingEntity();
	
			entity.setCustomerId(dto.getCustomerId());
			entity.setPackageId(dto.getPackageId());
			entity.setBookingDate(LocalDate.now());
			entity.setTotalAmount(pkg.getPrice());
	
			entity.setStatus("PENDING");
			entity.setPaymentStatus("PENDING");
	
			BookingEntity saved = repository.save(entity);
	
			return mapToDTO(saved);
		}
	
		@Override
		public List<BookingResponseDTO> getAllBookings() {
	
			List<BookingEntity> list = repository.findAll();
			List<BookingResponseDTO> result = new ArrayList<>();
	
			for (BookingEntity entity : list) {
				result.add(mapToDTO(entity));
			}
	
			return result;
		}
	
		@Override
		public BookingResponseDTO getBookingById(Long id) {
	
			BookingEntity entity = repository.findById(id)
					.orElseThrow(() -> new BookingNotFoundException("Booking not found with id: " + id));
	
			return mapToDTO(entity);
		}
	
	
		@Override
		public BookingResponseDTO updateBooking(Long id, BookingRequestDTO dto) {
	
			BookingEntity existing = repository.findById(id)
					.orElseThrow(() -> new BookingNotFoundException("Booking not found"));
	
			 if ("CONFIRMED".equalsIgnoreCase(existing.getStatus())) {
			        throw new RuntimeException("Booking already confirmed. Cannot update.");
			    }
	
	
			// check customer
			customerClient.getCustomerById(dto.getCustomerId());
	
			// check package change
			if (!existing.getPackageId().equals(dto.getPackageId())) {
				PackageResponseDTO pkg = packageClient.getPackageById(dto.getPackageId());
				existing.setPackageId(dto.getPackageId());
				existing.setTotalAmount(pkg.getPrice());
			}
	
			//  update fields
			existing.setCustomerId(dto.getCustomerId());
			
	
			existing = repository.save(existing);
	
			return mapToDTO(existing);
		}
		
		//called from payment method to update 
		public void updatePaymentStatus(Long bookingId, String paymentStatus) {
	
		    BookingEntity booking = repository.findById(bookingId)
		            .orElseThrow(() -> new BookingNotFoundException("Booking not found"));
	
		    // update payment status
		    booking.setPaymentStatus(paymentStatus);
	
		    // if payment success → confirm booking
		    if ("SUCCESS".equalsIgnoreCase(paymentStatus)) {
		        booking.setStatus("CONFIRMED");
		    }
	
		    repository.save(booking);
		}
	
		@Override
		public void deleteBooking(Long id) {
	
			BookingEntity existing = repository.findById(id)
					.orElseThrow(() -> new BookingNotFoundException("Booking not found with id: " + id));
	
			// ✅ Recommended → soft delete (cancel instead of delete)
			existing.setStatus("CANCELLED");
	
			repository.save(existing);
		}
	
		private BookingResponseDTO mapToDTO(BookingEntity entity) {
	
			BookingResponseDTO dto = new BookingResponseDTO();
	
			dto.setId(entity.getId());
			dto.setCustomerId(entity.getCustomerId());
			dto.setPackageId(entity.getPackageId());
			dto.setBookingDate(entity.getBookingDate());
			dto.setStatus(entity.getStatus());
			dto.setTotalAmount(entity.getTotalAmount());
			dto.setPaymentStatus(entity.getPaymentStatus());
	
			return dto;
		}
	}