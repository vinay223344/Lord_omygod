package com.cognizant.booking.service;

import java.util.List;

import com.cognizant.booking.dto.BookingRequestDTO;
import com.cognizant.booking.dto.BookingResponseDTO;

public interface BookingService {

    BookingResponseDTO createBooking(BookingRequestDTO dto);

    List<BookingResponseDTO> getAllBookings();

    BookingResponseDTO getBookingById(Long id);

    BookingResponseDTO updateBooking(Long id, BookingRequestDTO dto);
    
    void updatePaymentStatus(Long bookingId, String paymentStatus);

    void deleteBooking(Long id);
}