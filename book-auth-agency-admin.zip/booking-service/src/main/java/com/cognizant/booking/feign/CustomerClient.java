package com.cognizant.booking.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cognizant.booking.dto.CustomerResponseDTO;

@FeignClient(name="customer-service")
public interface CustomerClient {

	

      @GetMapping("/api/customers/{id}")
         CustomerResponseDTO getCustomerById(@PathVariable Long id);

}
